# -*- coding: utf-8 -*-
"""GIU DU LIEU KHI QUET LAI.

Truoc day quet lai ghi de ca file Dam_<tang>.xlsx -> mat sheet Thep (nhom thep), Dai (vung dai ve tay), CaiDat, Chon
va cot Dai / Dai trong / Ghi chu thep o sheet Nhip. Gio:

  1. Sao luu file cu vao backup/ (khong sao luu duoc -> DUNG, khong ghi de).
  2. Dam co o ca file cu va lan quet moi, CUNG SO NHIP  -> giu nhom thep (Thep), dai nhap tay o Nhip, tick (Chon);
     vung dai ve tay (Dai) chi giu khi tong chieu dai dam khong doi (toa do tuyet doi).
  3. Dam doi so nhip / bien mat (doi Mark, xoa dam) -> KHONG xoa: chuyen sang sheet ThepCu / DaiCu / NhipCu.
  4. Giu nguyen CaiDat va moi sheet la cua nguoi dung them.
Hinh hoc (b, h, nhip, cote, goi, luoi...) luon lay moi tu Revit - Revit la nguon su that.
"""
import os
import bm_xlsxr as xr
import bm_backup

KEEP = ('Thep', 'Dai', 'CaiDat', 'Chon')
ORPHAN = {'Thep': 'ThepCu', 'Dai': 'DaiCu', 'Nhip': 'NhipCu'}
GENERATED = set(['Info', 'NhomDam', 'Nhip', 'Cot', 'Luoi', 'San', 'HuongDan', 'DamCon', 'BoQua', 'CotDam', 'CotCay', 'GoiLuoi'])
STIR_HDR = (u'Đai (Ø-a gối/a nhịp)', u'Đai trong', u'Ghi chú thép')
H_CLEAR, H_B, H_H, H_TOP = u'L thông thủy (mm)', u'b (mm)', u'h (mm)', u'Cao đỉnh (mm)'
H_WL, H_WR = u'Gối trái (mm)', u'Gối phải (mm)'


def _num(v, d=0.0):
    try:
        return float(v)
    except Exception:
        return d


def _by_beam(rows):
    """{ten dam: [chi so dong]} cua sheet Nhip (dong 0 = tieu de)."""
    out = {}
    for i in range(1, len(rows)):
        if rows[i] and rows[i][0] not in (None, ''):
            out.setdefault(rows[i][0], []).append(i)
    return out


def _cols(rows):
    return dict((h, i) for i, h in enumerate(rows[0])) if rows else {}


def _cell(rows, col, ri, h):
    i = col.get(h)
    return rows[ri][i] if (i is not None and i < len(rows[ri])) else None


def _total(rows, col, idxs):
    if not idxs:
        return 0.0
    t = _num(_cell(rows, col, idxs[0], H_WL))
    for ri in idxs:
        t += _num(_cell(rows, col, ri, H_CLEAR)) + _num(_cell(rows, col, ri, H_WR))
    return t


def _geo_changed(o_rows, o_col, o_idx, n_rows, n_col, n_idx):
    """True neu nhip / tiet dien / cote doi (> 1 mm) giua 2 lan quet (cung so nhip)."""
    for a, b in zip(o_idx, n_idx):
        for h in (H_CLEAR, H_B, H_H, H_TOP):
            if abs(_num(_cell(o_rows, o_col, a, h)) - _num(_cell(n_rows, n_col, b, h))) > 1.0:
                return True
    return False


def _sheet(sheets, name):
    for sh in sheets:
        if sh['name'] == name:
            return sh
    return None


def _norm(rows):
    ncol = max([len(r) for r in rows] + [1])
    return [list(r) + [None] * (ncol - len(r)) for r in rows], ncol


def _widths(rows, ncol):
    return [min(60, max([len(str(r[c])) for r in rows[:300] if r[c] is not None] + [6]) + 2) for c in range(ncol)]


def probe_writable(path):
    """File dang mo trong Excel / editor khac -> PermissionError ro rang (khong de roi vao giua chung)."""
    if os.path.isfile(path):
        try:
            open(path, 'ab').close()
        except (IOError, OSError, PermissionError):
            raise PermissionError(u'Không ghi được %s - file đang mở trong Excel hoặc cửa sổ Thép dầm. Hãy đóng rồi quét lại.' % os.path.basename(path))


def carry(path, sheets, stamp=u''):
    """sheets: danh sach sheet cua lan quet moi (sua tai cho). Tra ve info (dict) hoac None neu chua co file cu."""
    if not os.path.isfile(path):
        return None
    probe_writable(path)
    info = dict(backup=None, unreadable=False, kept=[], geo_changed=[], zones_dropped=[], orphan=[], new=[], stir=0, groups=0, ticked=0)
    info['backup'] = bm_backup.backup(path, 'truoc-quet')       # loi sao luu -> ngoai le -> khong ghi de
    try:
        old = xr.read_xlsx(path)
    except Exception:
        info['unreadable'] = True
        return info
    o_nhip, n_sh = old.get('Nhip'), _sheet(sheets, 'Nhip')
    if not o_nhip or n_sh is None:
        info['unreadable'] = not o_nhip
        return info
    n_nhip = n_sh['rows']
    o_col, n_col = _cols(o_nhip), _cols(n_nhip)
    o_map, n_map = _by_beam(o_nhip), _by_beam(n_nhip)
    info['new'] = [n for n in n_map if n not in o_map]

    # ---- phan loai dam cu
    keep, orphan = {}, {}
    for name, o_idx in o_map.items():
        n_idx = n_map.get(name)
        if n_idx is None:
            orphan[name] = u'Mark không còn trong lần quét mới (đổi Mark / xóa dầm / tầng khác)'
        elif len(n_idx) != len(o_idx):
            orphan[name] = u'Số nhịp đổi từ %d sang %d' % (len(o_idx), len(n_idx))
        else:
            keep[name] = (o_idx, n_idx)

    # ---- 1. dai nhap tay o sheet Nhip (theo ten dam + thu tu nhip)
    for h in STIR_HDR:
        if h not in n_col:
            n_nhip[0].append(h)
            n_col[h] = len(n_nhip[0]) - 1
            for r in n_nhip[1:]:
                r.append(None)
    for name, (o_idx, n_idx) in keep.items():
        for a, b in zip(o_idx, n_idx):
            for h in STIR_HDR:
                v = _cell(o_nhip, o_col, a, h)
                if v not in (None, ''):
                    while len(n_nhip[b]) <= n_col[h]:
                        n_nhip[b].append(None)
                    n_nhip[b][n_col[h]] = v
                    info['stir'] += 1
        if _geo_changed(o_nhip, o_col, o_idx, n_nhip, n_col, n_idx):
            info['geo_changed'].append(name)
    info['kept'] = list(keep)

    # ---- 2. Thep / Dai / Chon / CaiDat
    out = {}
    thep_old = old.get('Thep') or []
    dai_old = old.get('Dai') or []
    t_hdr = thep_old[0] if thep_old else [u'Dầm']
    d_hdr = dai_old[0] if dai_old else [u'Dầm']
    thep, dai = [list(t_hdr)], [list(d_hdr)]
    thep_cu, dai_cu = [], []
    for r in thep_old[1:]:
        if not r or r[0] in (None, ''):
            continue
        if r[0] in keep:
            thep.append(r)
            info['groups'] += 1
        else:
            thep_cu.append(list(r) + [orphan.get(r[0], u'Dầm không còn trong dữ liệu quét')])
    for r in dai_old[1:]:
        if not r or r[0] in (None, ''):
            continue
        if r[0] in keep:
            o_idx, n_idx = keep[r[0]]
            if abs(_total(o_nhip, o_col, o_idx) - _total(n_nhip, n_col, n_idx)) <= 1.0:
                dai.append(r)
            else:
                dai_cu.append(list(r) + [u'Chiều dài dầm đổi - toạ độ vùng đai vẽ tay không còn đúng'])
                if r[0] not in info['zones_dropped']:
                    info['zones_dropped'].append(r[0])
        else:
            dai_cu.append(list(r) + [orphan.get(r[0], u'Dầm không còn trong dữ liệu quét')])
    chon = [[u'Dầm đã tick']]
    for r in (old.get('Chon') or [])[1:]:
        if r and r[0] in n_map:
            chon.append([r[0]])
    info['ticked'] = len(chon) - 1
    cai = old.get('CaiDat')
    out['Thep'], out['Dai'], out['Chon'] = thep, dai, chon
    if cai:
        out['CaiDat'] = cai

    # ---- 3. dam mo coi: khong xoa, chuyen sang sheet *Cu (cong don qua cac lan quet)
    nhip_cu = []
    for name, why in orphan.items():
        for ri in o_map[name]:
            nhip_cu.append(list(o_nhip[ri]) + [why])
    info['orphan'] = list(orphan.items())
    for sheet_name, hdr_src, rows in (('ThepCu', t_hdr, thep_cu), ('DaiCu', d_hdr, dai_cu), ('NhipCu', o_nhip[0], nhip_cu)):
        prev = old.get(sheet_name) or []
        hdr = list(prev[0]) if prev else list(hdr_src) + [u'Lý do']
        body = [r for r in prev[1:] if r]
        if rows:
            body += rows
        if body:
            out[sheet_name] = [hdr] + body

    # ---- 4. sheet nguoi dung tu them
    for nm, rows in old.items():
        if nm not in GENERATED and nm not in KEEP and nm not in ('ThepCu', 'DaiCu', 'NhipCu'):
            out[nm] = rows

    # ---- gan vao danh sach sheet moi (ngay sau Nhip; HuongDan van o cuoi)
    pos = [s['name'] for s in sheets].index('Nhip') + 1
    for nm in ('Thep', 'Dai', 'CaiDat', 'Chon') + tuple(ORPHAN.values()) + tuple(
            k for k in out if k not in KEEP and k not in ORPHAN.values()):
        if nm not in out:
            continue
        rows, ncol = _norm(out[nm])
        sh = dict(name=nm, rows=rows, widths=_widths(rows, ncol))
        if nm in ('Thep', 'Dai'):
            sh['input_cols'] = set(range(2, ncol))
        sheets.insert(pos, sh)
        pos += 1

    # ---- ghi chu vao Info
    isheet = _sheet(sheets, 'Info')
    if isheet is not None:
        isheet['rows'] += [[u'Sao lưu file cũ trước khi quét', info['backup'] or u''],
                           [u'Dầm giữ lại thép / đai / tick', len(keep)],
                           [u'Nhóm thép giữ lại', info['groups']],
                           [u'Dầm chuyển sang sheet *Cu (đổi số nhịp / mất Mark)', len(orphan)],
                           [u'Dầm giữ thép nhưng hình học đã đổi - cần kiểm lại', len(info['geo_changed'])]]
    return info


def summary(info, level=u''):
    """Mot doan van ban ngan de hien cho nguoi dung."""
    if info is None:
        return u''
    if info['unreadable']:
        return u'[%s] File cũ không đọc được - đã sao lưu nhưng KHÔNG giữ lại được dữ liệu: %s' % (level, info['backup'])
    s = u'[%s] giữ %d nhóm thép / %d dầm, %d ô đai; ' % (level, info['groups'], len(info['kept']), info['stir'])
    s += u'%d dầm chuyển sang sheet *Cu' % len(info['orphan'])
    if info['geo_changed']:
        s += u'; %d dầm đổi hình học (kiểm lại: %s)' % (len(info['geo_changed']), u', '.join(info['geo_changed'][:6]) + (u'...' if len(info['geo_changed']) > 6 else u''))
    if info['zones_dropped']:
        s += u'; vùng đai vẽ tay bỏ ở %d dầm (đổi chiều dài, xem sheet DaiCu)' % len(info['zones_dropped'])
    return s
