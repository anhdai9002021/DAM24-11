#! python3
# -*- coding: utf-8 -*-
__title__ = u"Quét dầm\n→ Excel"
__author__ = u"Claude"
__doc__ = u"Quét dầm / cột / lưới / sàn của 1 tầng, gom thành dầm nhiều nhịp và xuất Excel để chọn thép."

import os, sys, traceback
_HERE = os.path.dirname(os.path.abspath(__file__))
_SHARED = os.path.join(os.path.dirname(_HERE), '_shared')     # bm_ui, bm_revit, bm_xlsxr, bm_xlsxw, bm_backup dung chung 2 nut
for _p in (_SHARED, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)
if not os.path.isdir(_SHARED):
    raise ImportError(u'Thieu thu muc _shared canh thu muc nut (BeamRebar.panel/_shared). Hay giai nen DU CA panel.')

import bm_silent
bm_silent.silence()

try:
    import importlib
    import bm_app
    importlib.reload(bm_app)      # sua code xong chay lai la nhan ngay (neu cua so cu dang mo thi chi dua len truoc)
    bm_app.main()
except Exception:
    from System.Windows.Forms import MessageBox
    MessageBox.Show(traceback.format_exc(), u"Quét dầm - lỗi")
