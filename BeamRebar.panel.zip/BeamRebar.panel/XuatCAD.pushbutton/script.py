#! python3
# -*- coding: utf-8 -*-
"""
XuatCAD.pushbutton/script.py — Nút bấm pyRevit trong BeamRebar.panel\\XuatCAD.pushbutton\\ (Revit 2025 + pyRevit 7)
Giao diện WinForms gọn nhẹ (tối ưu RAM):
  - Nguồn 1: Quét trực tiếp dầm từ Mô hình Revit đang mở (hiển thị ngay danh sách chọn dầm).
  - Nguồn 2: Đọc file Excel Dam_*.xlsx từ BeamRebar (đầy đủ thép chi tiết).
  - Vẽ trực tiếp vào Model Space AutoCAD (Pick điểm chèn) & nạp sẵn DAM_SUA / DAM_QTK / DAM_THEP / DAM_DAI / DAM_TEN.
"""
from __future__ import print_function, unicode_literals
import gc as _gc
import shutil
import tempfile
import time
import traceback

__title__ = 'Xuất\nAutoCAD'
__doc__ = 'Chọn dầm từ Revit/Excel và vẽ trực tiếp vào Model Space AutoCAD (Pick điểm).'

try:
    import Autodesk.Revit.DB as DB
except Exception:
    DB = None

try:
    import clr
    clr.AddReference('System')
    clr.AddReference('System.Drawing')
    clr.AddReference('System.Windows.Forms')
    import System
    import System.Drawing as Drawing
    import System.Windows.Forms as WinForms
    from System.Runtime.InteropServices import Marshal
except Exception:
    clr = None
    System = None
    Drawing = None
    WinForms = None
    Marshal = None

import io
import json
import math
import os
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

_HERE = os.path.dirname(os.path.abspath(__file__))
_SHARED = os.path.join(os.path.dirname(_HERE), '_shared')
if os.path.isdir(_SHARED) and _SHARED not in sys.path:
    sys.path.insert(0, _SHARED)
try:
    import bm_silent
    bm_silent.silence()
except Exception:
    pass


class _SilentWriter(object):
    def write(self, *args, **kwargs):
        pass

    def flush(self):
        pass

    def isatty(self):
        return False


def _silence_pyrevit():
    try:
        import warnings
        warnings.filterwarnings('ignore')
    except Exception:
        pass
    try:
        if os.environ.get('PYREVIT_VERSION') or '__revit__' in globals():
            sys.stdout = _SilentWriter()
            sys.stderr = _SilentWriter()
    except Exception:
        pass
    try:
        win = globals().get('__window__')
        if win is not None:
            try:
                win.Hide()
            except Exception:
                pass
            try:
                win.Close()
            except Exception:
                pass
    except Exception:
        pass
    try:
        from pyrevit.coreutils import logger as _pyr_logger
        if hasattr(_pyr_logger, 'set_quiet_mode'):
            _pyr_logger.set_quiet_mode()
    except Exception:
        pass
    try:
        _pyr_out_mod = sys.modules.get('pyrevit.output')
        if _pyr_out_mod is not None and hasattr(_pyr_out_mod, 'get_output'):
            out = _pyr_out_mod.get_output()
            if out is not None:
                try:
                    out.close()
                except Exception:
                    try:
                        out.hide()
                    except Exception:
                        pass
    except Exception:
        pass


_silence_pyrevit()


def _col_idx(ref):
    c = 0
    for ch in ref:
        if ch.isalpha():
            c = c * 26 + (ord(ch.upper()) - ord('A') + 1)
        else:
            break
    return c - 1


def read_xlsx_rows(path):
    sheets = {}
    with zipfile.ZipFile(path, 'r') as z:
        sst = []
        if 'xl/sharedStrings.xml' in z.namelist():
            root = ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in root.iter():
                if si.tag.endswith('}si'):
                    parts_si = []
                    for ch_si in si:
                        if ch_si.tag.endswith('}t'):
                            parts_si.append(ch_si.text or u'')
                        elif ch_si.tag.endswith('}r'):
                            for rc in ch_si:
                                if rc.tag.endswith('}t'):
                                    parts_si.append(rc.text or u'')
                    sst.append(u''.join(parts_si))
            root.clear()
            del root

        wb_root = ET.fromstring(z.read('xl/workbook.xml'))
        rels_root = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        rel_map = {}
        for rel in rels_root:
            rel_map[rel.attrib.get('Id', '')] = rel.attrib.get('Target', '')
        rels_root.clear()

        for sh in wb_root.iter():
            if sh.tag.endswith('}sheet'):
                name = sh.attrib.get('name', '')
                rid = ''
                for k, v in sh.attrib.items():
                    if k.endswith('}id') or k == 'r:id':
                        rid = v
                target = rel_map.get(rid, '').lstrip('/')
                if not target.startswith('xl/'):
                    target = 'xl/' + target
                if target not in z.namelist():
                    continue
                sroot = ET.fromstring(z.read(target))
                rows = []
                for row_el in sroot.iter():
                    if row_el.tag.endswith('}row'):
                        row_vals = []
                        for c_el in row_el:
                            if not c_el.tag.endswith('}c'):
                                continue
                            ref_attr = c_el.attrib.get('r', '')
                            ci = _col_idx(ref_attr) if ref_attr else len(row_vals)
                            while len(row_vals) <= ci:
                                row_vals.append('')
                            tp = c_el.attrib.get('t', '')
                            val_text = u''
                            for ch in c_el:
                                if ch.tag.endswith('}v'):
                                    val_text = ch.text or u''
                                elif ch.tag.endswith('}is'):
                                    val_text = u''.join((t.text or u'') for t in ch.iter() if t.tag.endswith('}t'))
                            if tp == 's' and val_text.strip().isdigit():
                                idx = int(val_text.strip())
                                val_text = sst[idx] if idx < len(sst) else u''
                            row_vals[ci] = val_text
                        rows.append(row_vals)
                sroot.clear()
                del sroot
                sheets[name] = rows
        wb_root.clear()
    return sheets


def num(v, d=0.0):
    if v is None or v == '':
        return d
    try:
        return float(str(v).replace(',', '.').strip())
    except Exception:
        return d


def sstr(v, d=u''):
    if v is None:
        return d
    try:
        return unicode(v).strip()
    except NameError:
        return str(v).strip()


def _natural_beam_key(name):
    s = sstr(name)
    parts = re.split(r'(\d+)', s)
    return (tuple((0, int(p), '') if p.isdigit() else (1, 0, p.lower()) for p in parts if p != ''), s.lower())


def unit_w(d):
    return (math.pi * d * d / 4.0) * 0.00785


def parse_len(txt, d, L, default='30d'):
    t = sstr(txt or default).replace(',', '.').replace(' ', '')
    if not t:
        return 0.0
    m = re.match(r'^(\d+(?:\.\d+)?)[dD]$', t)
    if m:
        return float(m.group(1)) * d
    m = re.match(r'^[Ll]/(\d+(?:\.\d+)?)$', t)
    if m:
        den = float(m.group(1))
        return L / den if den else 0.0
    m = re.match(r'^(\d+(?:\.\d+)?)[Ll]$', t)
    if m:
        return L * float(m.group(1))
    try:
        return float(t)
    except Exception:
        return 0.0


def is_down(txt):
    t = sstr(txt).lower()
    if t in (u'xuống', 'xuong', 'h', u'sát', 'sat', 'down', u'đáy', 'day', u'đáy dầm', 'day dam',
             u'móc', 'moc', 'hook', 'full', '100%', u'hết dầm', 'het dam', u'bẻ', 'be'):
        return True
    return any(k in t for k in (u'xuống', 'xuong', u'đáy', u'sát', 'down', 'full'))


def _is_explicit_straight(txt):
    t = sstr(txt).lower()
    return t in ('0', u'thẳng', 'thang', 'straight', u'không', 'khong', 'no', 'none')


def norm_pos(txt):
    s = sstr(txt).lower()
    if u'trên' in s or 'tren' in s:
        return 'Trên'
    if u'giữa' in s or 'giua' in s:
        return 'Giữa'
    return 'Dưới'


def norm_end(txt):
    s = sstr(txt).lower()
    if (u'gập' in s or 'gap' in s or u'móc' in s or 'moc' in s or u'bẻ' in s or 'hook' in s
            or u'mỏ' in s or '90' in s or u'xuống' in s or 'xuong' in s or u'đáy' in s
            or re.search(r'\b(be|mo|day)\b', s)):
        return 'Gập vào cột'
    if u'hết' in s or 'het' in s or u'đầu dầm' in s or 'dau dam' in s:
        return 'Hết cột / đầu dầm'
    if u'kéo' in s or 'keo' in s or u'vươn' in s or 'vuon' in s or u'sang nhịp' in s:
        return 'Kéo dài ra nhịp'
    if u'cắt' in s or 'cat' in s:
        return 'Cắt trong nhịp'
    if u'giữa' in s or 'giua' in s:
        return 'Giữa gối'
    if u'uốn' in s or 'uon' in s:
        return 'Uốn xiên'
    return 'Neo vào gối'


_CONCRETE_GRADES = ('B15', 'B20', 'B22.5', 'B25', 'B30', 'B35', 'B40', 'B45', 'B50')
_STEEL_GRADES = ('CB240-T', 'CB300-T', 'CB300-V', 'CB400-V', 'CB500-V')
_NEO_MODES = (
    u'Tự động (gập khi thiếu)',
    u'Luôn gập vào cột (móc 90°)',
    u'Neo thẳng vào gối (Lan)',
)
_STEP_NEO_MODES = (
    u'Neo sang nhịp sâu (Lan)',
    u'Gập vào cột (cắt tại gối)',
)


def _norm_concrete_grade(txt, default='B25'):
    s = sstr(txt).upper().replace(' ', '')
    if not s:
        return default
    m_map = {'M200': 'B15', 'M250': 'B20', 'M300': 'B22.5', 'M350': 'B25', 'M400': 'B30', 'M450': 'B35', 'M500': 'B40', 'M600': 'B45'}
    for mk, bv in m_map.items():
        if mk in s:
            return bv
    for g in ('B22.5', 'B15', 'B20', 'B25', 'B30', 'B35', 'B40', 'B45', 'B50'):
        if g in s or g.replace('.', ',') in s:
            return g
    m_b = re.search(r'B(\d{2})', s)
    if m_b:
        cand = 'B' + m_b.group(1)
        if cand in _CONCRETE_GRADES:
            return cand
    return default


def _norm_steel_grade(txt, default='CB400-V'):
    s = sstr(txt).upper().replace('_', '-').replace(' ', '')
    if not s:
        return default
    if '240' in s or re.search(r'\bA[- ]?I\b', s):
        return 'CB240-T'
    if '300' in s and 'T' in s:
        return 'CB300-T'
    if '300' in s or 'AII' in s or 'SD295' in s:
        return 'CB300-V'
    if '500' in s or 'SD490' in s:
        return 'CB500-V'
    if '400' in s or 'AIII' in s or 'SD390' in s:
        return 'CB400-V'
    return default


def _norm_std_name(txt, default='TCVN 5574:2018'):
    s = sstr(txt).lower()
    if not s:
        return default
    if '2012' in s or '356' in s:
        return u'TCVN 5574:2012'
    if '2018' in s or 'tcvn' in s:
        return u'TCVN 5574:2018'
    if u'tùy' in s or 'tuy' in s or 'custom' in s or u'thủ công' in s:
        return u'Tùy chỉnh'
    return default


def _norm_neo_mode(txt):
    s = sstr(txt).lower()
    if not s:
        return _NEO_MODES[0]
    if u'luôn gập' in s or 'luon gap' in s or u'móc 90' in s or 'moc 90' in s or u'bẻ mỏ' in s or u'luôn móc' in s:
        return _NEO_MODES[1]
    if u'thẳng' in s or 'thang' in s or 'straight' in s or 'lan' in s:
        return _NEO_MODES[2]
    return _NEO_MODES[0]


def _norm_step_neo(txt):
    s = sstr(txt).lower()
    if not s:
        return _STEP_NEO_MODES[0]
    if u'gập' in s or 'gap' in s or u'cắt' in s or 'cat' in s or u'móc' in s:
        return _STEP_NEO_MODES[1]
    return _STEP_NEO_MODES[0]


def _calc_tcvn_anchorage(std, concrete, steel):
    """Return (neo_top_str, neo_bot_str, lap_str) in multiple of 5d per TCVN 5574:2018 / 2012."""
    rbt_map = {
        'B15': 0.75, 'B20': 0.90, 'B22.5': 0.98, 'B25': 1.05,
        'B30': 1.15, 'B35': 1.30, 'B40': 1.40, 'B45': 1.50, 'B50': 1.60,
    }
    rs_map = {
        'CB240-T': (210.0, 1.5),
        'CB300-T': (260.0, 1.5),
        'CB300-V': (260.0, 2.5),
        'CB400-V': (350.0, 2.5),
        'CB500-V': (435.0, 2.5),
    }
    conc = _norm_concrete_grade(concrete, 'B25')
    st = _norm_steel_grade(steel, 'CB400-V')
    std_n = _norm_std_name(std, u'TCVN 5574:2018')
    rbt = rbt_map.get(conc, 1.05)
    rs, eta1 = rs_map.get(st, (350.0, 2.5))
    raw_k = rs / (4.0 * eta1 * rbt)
    if std_n == u'TCVN 5574:2012':
        raw_k *= 0.85

    def _round5(val, lo):
        return max(lo, int(math.ceil(val / 5.0)) * 5)

    k_ten = _round5(raw_k, 25)
    k_cmp = _round5(raw_k * 0.75, 20)
    k_lap = _round5(raw_k * 1.20, 30)
    return '%dd' % k_ten, '%dd' % k_cmp, '%dd' % k_lap


def _opt_neo_spec(opt, pos=u'Trên'):
    if not isinstance(opt, dict):
        return '30d'
    base = sstr(opt.get('neo', '30d')) or '30d'
    if pos == u'Trên':
        return sstr(opt.get('neo_top', '')) or base
    if pos == u'Dưới':
        return sstr(opt.get('neo_bot', '')) or base
    return base



def norm_cross(txt):
    s = sstr(txt).lower()
    if u'luôn neo' in s or u'cắt' in s:
        return 'Luôn neo (cắt)'
    if u'luôn uốn' in s:
        return 'Luôn uốn'
    if u'thẳng' in s:
        return 'Luôn thẳng (nối liền)'
    return 'Tự động'


def parse_stir_spec(spec):
    nums = re.findall(r'\d+', sstr(spec))
    if len(nums) >= 2:
        d = int(nums[0])
        a1 = int(nums[1])
        a2 = int(nums[2]) if len(nums) >= 3 else a1
        return d, a1, a2
    return 6, 100, 200


def _eid_int(id_obj):
    if id_obj is None:
        return -1
    try:
        return int(id_obj.Value)
    except Exception:
        try:
            return int(id_obj.IntegerValue)
        except Exception:
            return -1


_BULGE_90 = math.tan(math.pi / 8.0)
_BULGE_135 = math.tan(3.0 * math.pi / 16.0)


def _build_stirrup_135_pts(xL, xR, yB, yT, sd, corner_bar_d=18.0):
    """Build smooth G1-tangent rounded perimeter stirrup with 135-deg parallel seismic hooks at top-right."""
    w_in = max(20.0, float(xR - xL))
    h_in = max(20.0, float(yT - yB))
    rr = min(max(14.0, float(corner_bar_d) * 0.5 + float(sd) * 0.65), w_in * 0.24, h_in * 0.24)
    hk_len = min(max(36.0, 5.5 * float(sd)), w_in * 0.34, h_in * 0.34)
    cx = xR - rr
    cy = yT - rr
    s45 = math.sqrt(2.0) / 2.0
    p_h1_tan = (cx - rr * s45, cy + rr * s45)
    p_h1_tip = (p_h1_tan[0] - hk_len * s45, p_h1_tan[1] - hk_len * s45)
    p_h2_tan = (cx + rr * s45, cy - rr * s45)
    p_h2_tip = (p_h2_tan[0] - hk_len * s45, p_h2_tan[1] - hk_len * s45)
    return [
        (p_h1_tip[0], p_h1_tip[1], 0.0),
        (p_h1_tan[0], p_h1_tan[1], -_BULGE_135),
        (xR, cy, 0.0),
        (xR, yB + rr, -_BULGE_90),
        (xR - rr, yB, 0.0),
        (xL + rr, yB, -_BULGE_90),
        (xL, yB + rr, 0.0),
        (xL, yT - rr, -_BULGE_90),
        (xL + rr, yT, 0.0),
        (cx, yT, -_BULGE_135),
        (p_h2_tan[0], p_h2_tan[1], 0.0),
        (p_h2_tip[0], p_h2_tip[1], 0.0),
    ]


def _build_ctie_135_pts(x1, y1, x2, y2, bar_d, sd, horiz=True):
    """Build smooth G1-tangent rounded C-crosstie (135-deg hooks) wrapping 2 bars (horiz or vert)."""
    r = max(10.0, float(bar_d) * 0.5 + float(sd) * 0.55 + 1.5)
    s45 = math.sqrt(2.0) / 2.0
    if horiz:
        xL_b, xR_b = min(x1, x2), max(x1, x2)
        yc = (y1 + y2) * 0.5
        span_b = max(20.0, xR_b - xL_b)
        hk = max(24.0, min(38.0, span_b * 0.28))
        p_t1 = (xL_b - r * s45, yc - r * s45)
        p_tip1 = (p_t1[0] + hk * s45, p_t1[1] - hk * s45)
        p_t2 = (xR_b + r * s45, yc - r * s45)
        p_tip2 = (p_t2[0] - hk * s45, p_t2[1] - hk * s45)
        return [
            (p_tip1[0], p_tip1[1], 0.0),
            (p_t1[0], p_t1[1], -_BULGE_135),
            (xL_b, yc + r, 0.0),
            (xR_b, yc + r, -_BULGE_135),
            (p_t2[0], p_t2[1], 0.0),
            (p_tip2[0], p_tip2[1], 0.0),
        ], ((xL_b + xR_b) * 0.5, yc + r)
    else:
        yB_b, yT_b = min(y1, y2), max(y1, y2)
        xc = (x1 + x2) * 0.5
        span_b = max(20.0, yT_b - yB_b)
        hk = max(24.0, min(38.0, span_b * 0.28))
        p_t1 = (xc + r * s45, yT_b + r * s45)
        p_tip1 = (p_t1[0] + hk * s45, p_t1[1] - hk * s45)
        p_t2 = (xc + r * s45, yB_b - r * s45)
        p_tip2 = (p_t2[0] + hk * s45, p_t2[1] + hk * s45)
        return [
            (p_tip1[0], p_tip1[1], 0.0),
            (p_t1[0], p_t1[1], _BULGE_135),
            (xc - r, yT_b, 0.0),
            (xc - r, yB_b, _BULGE_135),
            (p_t2[0], p_t2[1], 0.0),
            (p_tip2[0], p_tip2[1], 0.0),
        ], (xc - r, (yB_b + yT_b) * 0.5)


class DxfOut(object):
    def __init__(self):
        self.buf = []
        self.blocks_buf = []
        self.dim_blocks_buf = []
        self.entities_buf = []
        self.block_records = []
        self.h = 0x300
        self.dim_idx = 20
        self.br_table_h = '1'
        self.ms_br_h = '2'
        self.ps_br_h = '1C'
        self.style_std_h = '11'
        self.style_dce_h = '38'
        self.style_dce2_h = '3A'
        self.arch_tick_br_h = '39'
        self.dot_blank_br_h = '45'
        self._cur_buf = self.buf
        self._cur_owner = self.ms_br_h

    def next_h(self):
        s = '%X' % self.h
        self.h += 1
        return s

    def p(self, c, v, buf=None):
        b = self._cur_buf if buf is None else buf
        b.append(str(c))
        if isinstance(v, (int, float)):
            b.append(str(v))
        else:
            b.append(sstr(v).replace('\r', '').replace('\n', ' '))

    def _emit_to(self, target_buf, owner_h):
        self._cur_buf = target_buf
        self._cur_owner = owner_h

    def set_target(self, target):
        if target == 'blocks':
            self._emit_to(self.blocks_buf, self.ms_br_h)
        elif target == 'entities':
            self._emit_to(self.entities_buf, self.ms_br_h)
        elif target == 'dim_blocks':
            self._emit_to(self.dim_blocks_buf, self.ms_br_h)
        else:
            self._emit_to(self.buf, self.ms_br_h)

    def register_block_record(self, bname, br_h):
        self.block_records.append((bname, br_h))

    def emit_block_records_table(self):
        self.set_target('buf')
        self.p(0, 'TABLE'); self.p(2, 'BLOCK_RECORD'); self.p(5, self.br_table_h); self.p(330, '0')
        self.p(100, 'AcDbSymbolTable'); self.p(70, len(self.block_records))
        for bname, br_h in self.block_records:
            self.p(0, 'BLOCK_RECORD'); self.p(5, br_h); self.p(330, self.br_table_h)
            self.p(100, 'AcDbSymbolTableRecord'); self.p(100, 'AcDbBlockTableRecord')
            self.p(2, bname); self.p(70, 0); self.p(280, 1); self.p(281, 0)
        self.p(0, 'ENDTAB')

    @staticmethod
    def write_lines_chunked(fh, lines, chunk_size=2500):
        n = len(lines)
        for i in range(0, n, chunk_size):
            fh.write((u'\r\n'.join(lines[i:i + chunk_size]) + u'\r\n').encode('utf-8'))

    def clear_buffers(self):
        del self.buf[:]
        del self.blocks_buf[:]
        del self.dim_blocks_buf[:]
        del self.entities_buf[:]
        del self.block_records[:]

    def text(self, x, y, h, txt, layer='Dce_text', color=256, ha=0, va=0,
             xdata_app=None, style='Dce_Text', width_factor=0.80, rot=0.0, wf=None):
        if wf is not None:
            width_factor = wf
        self.p(0, 'TEXT'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbText')
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0')
        self.p(40, '%.4f' % h); self.p(1, txt)
        if rot:
            self.p(50, '%.4f' % rot)
        if abs(width_factor - 1.0) > 1e-4:
            self.p(41, '%.4f' % width_factor)
        self.p(7, style)
        if ha or va:
            self.p(72, ha)
            self.p(11, '%.4f' % x); self.p(21, '%.4f' % y); self.p(31, '0.0')
        if va:
            self.p(100, 'AcDbText')
            self.p(73, va)
        if xdata_app:
            self.p(1001, xdata_app); self.p(1000, '1')

    def mtext(self, x, y, h, txt, layer='DCE_Dim', color=3, attach=5, style='Dce_Text', rot=0.0):
        self.p(0, 'MTEXT'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbMText')
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0')
        self.p(40, '%.4f' % h); self.p(41, '0.0'); self.p(46, '0.0')
        self.p(71, attach); self.p(72, 1)
        self.p(1, txt); self.p(7, style)
        if abs(rot - 90.0) < 1e-3:
            self.p(11, '0.0'); self.p(21, '1.0'); self.p(31, '0.0')
        elif abs(rot) > 1e-3:
            rad = math.radians(rot)
            self.p(11, '%.6f' % math.cos(rad)); self.p(21, '%.6f' % math.sin(rad)); self.p(31, '0.0')
        self.p(73, 1); self.p(44, '1.0')

    def point(self, x, y, layer='Defpoints', color=0):
        self.p(0, 'POINT'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer); self.p(62, color)
        self.p(100, 'AcDbPoint')
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0')

    def _emit_xdata(self, xdata):
        if not xdata:
            return
        if isinstance(xdata, str):
            self.p(1001, xdata); self.p(1000, '1')
            return
        items = xdata if isinstance(xdata, list) else [xdata]
        for entry in items:
            if not entry:
                continue
            if isinstance(entry, str):
                self.p(1001, entry); self.p(1000, '1')
                continue
            app, vals = entry[0], entry[1]
            self.p(1001, app)
            for xv in vals:
                if isinstance(xv, int) and not isinstance(xv, bool):
                    self.p(1070, xv)
                elif isinstance(xv, float):
                    self.p(1040, '%.4f' % xv)
                else:
                    self.p(1000, sstr(xv))

    def line(self, x1, y1, x2, y2, layer='DCE_BaoBeTong', color=256, xdata_app=None):
        self.p(0, 'LINE'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbLine')
        self.p(10, '%.4f' % x1); self.p(20, '%.4f' % y1); self.p(30, '0.0')
        self.p(11, '%.4f' % x2); self.p(21, '%.4f' % y2); self.p(31, '0.0')
        if xdata_app:
            self._emit_xdata(xdata_app)

    def circle(self, x, y, r, layer='DCE_ThepChu', color=256):
        self.p(0, 'CIRCLE'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbCircle')
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0'); self.p(40, '%.4f' % r)

    def pline(self, pts, layer='DCE_ThepChu', closed=False, color=256, xdata_app=None, cw=0.0):
        if len(pts) < 2:
            return
        self.p(0, 'LWPOLYLINE'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbPolyline')
        self.p(90, len(pts)); self.p(70, 1 if closed else 0)
        if cw > 0.0:
            self.p(43, '%.6f' % cw)
        for pt in pts:
            px, py = pt[0], pt[1]
            blg = pt[2] if len(pt) > 2 else 0.0
            self.p(10, '%.4f' % px); self.p(20, '%.4f' % py)
            if abs(blg) > 1e-6:
                self.p(42, '%.8f' % blg)
        if xdata_app:
            self._emit_xdata(xdata_app)

    def hatch_poly(self, pts, layer='0', color=256, pattern='SOLID', solid=1, scale=1.0, angle=0.0, visible=True):
        if len(pts) < 3:
            return
        self.p(0, 'HATCH'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        if not visible:
            self.p(60, 1)
        self.p(100, 'AcDbHatch')
        self.p(10, '0.0'); self.p(20, '0.0'); self.p(30, '0.0')
        self.p(210, '0.0'); self.p(220, '0.0'); self.p(230, '1.0')
        self.p(2, pattern); self.p(70, 1 if solid else 0); self.p(71, 0)
        self.p(91, 1); self.p(92, 7); self.p(72, 0); self.p(73, 1); self.p(93, len(pts))
        for px, py in pts:
            self.p(10, '%.4f' % px); self.p(20, '%.4f' % py)
        self.p(97, 0); self.p(75, 0); self.p(76, 1)
        if not solid:
            self.p(52, '%.4f' % angle); self.p(41, '%.6f' % scale); self.p(77, 0)
            self.p(78, 1); self.p(53, '45.0'); self.p(43, '0.0'); self.p(44, '0.0')
            self.p(45, '-3.1571'); self.p(46, '3.1571'); self.p(79, 0)
        self.p(47, '0.05'); self.p(98, 1)
        cx = sum(p[0] for p in pts) / float(len(pts))
        cy = sum(p[1] for p in pts) / float(len(pts))
        self.p(10, '%.4f' % cx); self.p(20, '%.4f' % cy)

    def leader(self, pts, layer='DCE_Dim', dimstyle='Dce_50MV', arrow=0, color=256, xdata_app=None):
        if len(pts) < 2:
            return
        self.p(0, 'LEADER'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbLeader')
        self.p(3, dimstyle)
        self.p(71, 1 if arrow else 0); self.p(72, 0); self.p(73, 3); self.p(74, 1); self.p(75, 0)
        self.p(76, len(pts))
        for px, py in pts:
            self.p(10, '%.4f' % px); self.p(20, '%.4f' % py); self.p(30, '0.0')
        if xdata_app:
            self._emit_xdata(xdata_app)

    def dim(self, x1, y1, x2, y2, dx_line, dy_line, layer='DCE_Dim', dim_scale=50.0,
            dimstyle=None, text_override='', suppress_lines=False, rot_deg=None,
            txt_xy=None, dimtmove=2):
        val_f = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        val = int(round(val_f))
        if val < 1 and not text_override:
            return
        if dimstyle is None:
            if abs(dim_scale - 25.0) < 0.5:
                dimstyle = 'Dce_25MV'
            elif abs(dim_scale - 20.0) < 0.5:
                dimstyle = 'Dce_20MV'
            else:
                dimstyle = 'Dce_50MV'
        if rot_deg is None:
            ang_deg = 0.0 if abs(y1 - y2) < 0.5 else 90.0
        else:
            ang_deg = float(rot_deg) % 360.0
        rad = math.radians(ang_deg)
        ux, uy = math.cos(rad), math.sin(rad)
        nx, ny = -uy, ux

        disp_txt = text_override if text_override else str(int(round(abs(x2 - x1) if (abs(ang_deg) < 0.5 or abs(ang_deg - 180.0) < 0.5) else (abs(y2 - y1) if (abs(ang_deg - 90.0) < 0.5 or abs(ang_deg - 270.0) < 0.5) else val_f))))
        est_half_tw = max(75.0, len(disp_txt) * 28.0 + 20.0) * (dim_scale / 50.0)

        if abs(ang_deg) < 0.5 or abs(ang_deg - 180.0) < 0.5:
            p10 = (x2, dy_line)
            dl1 = (x1, dy_line)
            dl2 = (x2, dy_line)
            tick_ang = 0.0
            default_txt_pt = ((x1 + x2) / 2.0, dy_line + (2.0 if not suppress_lines else 0.0) * dim_scale)
            meas = abs(x2 - x1)
        elif abs(ang_deg - 90.0) < 0.5 or abs(ang_deg - 270.0) < 0.5:
            p10 = (dx_line, y2)
            dl1 = (dx_line, y1)
            dl2 = (dx_line, y2)
            tick_ang = 90.0
            off_dir = -1.0 if dx_line <= min(x1, x2) + 1.0 else 1.0
            if suppress_lines:
                default_txt_pt = (dx_line, (y1 + y2) / 2.0)
            else:
                default_txt_pt = (dx_line + off_dir * 2.0 * dim_scale, (y1 + y2) / 2.0)
            meas = abs(y2 - y1)
        else:
            d_off = (dx_line - x2) * nx + (dy_line - y2) * ny
            p10 = (x2 + d_off * nx, y2 + d_off * ny)
            dl1 = (x1 + d_off * nx, y1 + d_off * ny)
            dl2 = p10
            tick_ang = ang_deg
            default_txt_pt = ((dl1[0] + dl2[0]) / 2.0, (dl1[1] + dl2[1]) / 2.0)
            meas = abs((x2 - x1) * ux + (y2 - y1) * uy)

        has_custom_txt = (txt_xy is not None)
        txt_pt = txt_xy if has_custom_txt else default_txt_pt

        self.dim_idx += 1
        bname = '*D%d' % self.dim_idx
        br_h = self.next_h()
        self.block_records.append((bname, br_h))

        prev_buf, prev_own = self._cur_buf, self._cur_owner
        self._emit_to(self.dim_blocks_buf, br_h)
        self.p(0, 'BLOCK'); self.p(5, self.next_h()); self.p(330, br_h)
        self.p(100, 'AcDbEntity'); self.p(8, '0'); self.p(100, 'AcDbBlockBegin')
        self.p(2, bname); self.p(70, 1); self.p(10, '0.0'); self.p(20, '0.0'); self.p(30, '0.0')
        self.p(3, bname); self.p(1, '')
        if not suppress_lines:
            exe = 1.0 * dim_scale
            exo = 2.0 * dim_scale
            for sx, sy, ex, ey in ((x1, y1, dl1[0], dl1[1]), (x2, y2, dl2[0], dl2[1])):
                vx, vy = ex - sx, ey - sy
                vl = math.hypot(vx, vy)
                if vl > 1e-3:
                    uxv, uyv = vx / vl, vy / vl
                    s_off = min(exo, max(0.0, vl - 1.0))
                    self.line(sx + uxv * s_off, sy + uyv * s_off, ex + uxv * exe, ey + uyv * exe, layer, 8)
            line_a, line_b = dl1, dl2
            if has_custom_txt and (abs(ang_deg) < 0.5 or abs(ang_deg - 180.0) < 0.5):
                lx_min = min(dl1[0], dl2[0])
                lx_max = max(dl1[0], dl2[0])
                if abs(txt_pt[1] - default_txt_pt[1]) < 5.0:
                    lx_min = min(lx_min, txt_pt[0] - est_half_tw)
                    lx_max = max(lx_max, txt_pt[0] + est_half_tw)
                    line_a = (lx_min, dy_line)
                    line_b = (lx_max, dy_line)
                elif dimtmove == 1:
                    self.line(0.5 * (dl1[0] + dl2[0]), dy_line, txt_pt[0], txt_pt[1], layer, 8)
            self.line(line_a[0], line_a[1], line_b[0], line_b[1], layer, 8)
            tick_sc = 1.5 * dim_scale
            self.insert('_ArchTick', dl1[0], dl1[1], tick_sc, tick_sc, layer, [], rot=tick_ang, color=8)
            self.insert('_ArchTick', dl2[0], dl2[1], tick_sc, tick_sc, layer, [], rot=(tick_ang + 180.0) % 360.0, color=8)
        disp_txt = text_override if text_override else str(int(round(meas)))
        mrot = 90.0 if abs((ang_deg % 180.0) - 90.0) < 0.5 else (ang_deg if ang_deg not in (0.0, 180.0) else 0.0)
        self.mtext(txt_pt[0], txt_pt[1], 2.0 * dim_scale, disp_txt, layer, 3, 5, 'Dce_Text', rot=mrot)
        self.point(x1, y1, 'Defpoints', 0)
        self.point(x2, y2, 'Defpoints', 0)
        self.point(p10[0], p10[1], 'Defpoints', 0)
        self.p(0, 'ENDBLK'); self.p(5, self.next_h()); self.p(330, br_h)
        self.p(100, 'AcDbEntity'); self.p(8, '0'); self.p(100, 'AcDbBlockEnd')
        self._emit_to(prev_buf, prev_own)

        self.p(0, 'DIMENSION'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        self.p(100, 'AcDbDimension'); self.p(2, bname)
        self.p(10, '%.4f' % p10[0]); self.p(20, '%.4f' % p10[1]); self.p(30, '0.0')
        self.p(11, '%.4f' % txt_pt[0]); self.p(21, '%.4f' % txt_pt[1]); self.p(31, '0.0')
        self.p(70, 160 if has_custom_txt else 32)
        if text_override:
            self.p(1, text_override)
        self.p(71, 5); self.p(42, '%.4f' % meas); self.p(73, 0); self.p(74, 0); self.p(75, 0)
        self.p(3, dimstyle)
        self.p(100, 'AcDbAlignedDimension')
        self.p(13, '%.4f' % x1); self.p(23, '%.4f' % y1); self.p(33, '0.0')
        self.p(14, '%.4f' % x2); self.p(24, '%.4f' % y2); self.p(34, '0.0')
        if abs(ang_deg) > 1e-3:
            self.p(50, '%.4f' % ang_deg)
        self.p(100, 'AcDbRotatedDimension')
        if suppress_lines or has_custom_txt:
            self.p(1001, 'ACAD'); self.p(1000, 'DSTYLE'); self.p(1002, '{')
            if has_custom_txt:
                self.p(1070, 279); self.p(1070, int(dimtmove))
            if suppress_lines:
                self.p(1070, 140); self.p(1040, '2.0')
                self.p(1070, 76); self.p(1070, 1)
                self.p(1070, 75); self.p(1070, 1)
                self.p(1070, 282); self.p(1070, 1)
                self.p(1070, 281); self.p(1070, 1)
                self.p(1070, 77); self.p(1070, 0)
            self.p(1002, '}')

    def zigzag_h(self, x0, x1, y):
        xm = (x0 + x1) / 2.0
        self.pline([(x0 - 35.0, y), (xm - 35.0, y), (xm - 35.0, y - 35.0),
                    (xm + 35.0, y + 35.0), (xm + 35.0, y), (x1 + 35.0, y)], 'DCE_MCZiCZac', False)

    def zigzag_v(self, x, y0, y1):
        ym = (y0 + y1) / 2.0
        self.pline([(x, y0 + 26.7), (x, ym + 26.7), (x - 26.7, ym + 26.7),
                    (x + 26.7, ym - 26.7), (x, ym - 26.7), (x, y1 - 26.7)], 'DCE_MCZiCZac', False)

    def attdef(self, tag, prompt, val, x, y, h, color=2, ha=1, va=2, layer='Dce_text', rot=0.0, flg=0):
        self.p(0, 'ATTDEF'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbText')
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0')
        self.p(40, '%.4f' % h); self.p(1, val)
        if rot:
            self.p(50, '%.4f' % rot)
        self.p(41, '0.80'); self.p(7, 'Dce_Text')
        if ha or va:
            self.p(72, ha); self.p(11, '%.4f' % x); self.p(21, '%.4f' % y); self.p(31, '0.0')
        self.p(100, 'AcDbAttributeDefinition')
        self.p(3, prompt); self.p(2, tag); self.p(70, flg)
        if va:
            self.p(74, va)

    def insert(self, bname, x, y, sx, sy, layer, atts, xdata=None, rot=0.0, color=256):
        ins_h = self.next_h()
        self.p(0, 'INSERT'); self.p(5, ins_h); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbBlockReference')
        if atts:
            self.p(66, 1)
        self.p(2, bname)
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0')
        self.p(41, '%.4f' % sx); self.p(42, '%.4f' % sy); self.p(43, '%.4f' % sx)
        if rot:
            self.p(50, '%.4f' % rot)
        if xdata:
            self._emit_xdata(xdata)
        if atts:
            rad = math.radians(rot)
            cr, sr = math.cos(rad), math.sin(rad)
            for item in atts:
                if len(item) >= 9:
                    tag, val, dx, dy, h, col, ha, va, alay = item[:9]
                    arot = item[9] if len(item) > 9 else rot
                else:
                    tag, val, dx, dy, h, col, ha = item[:7]
                    va = item[7] if len(item) > 7 else 2
                    alay = 'Dce_text'
                    arot = rot
                lx, ly = dx * sx, dy * sy
                ax = x + lx * cr - ly * sr
                ay = y + lx * sr + ly * cr
                ah = h * abs(sy)
                self.p(0, 'ATTRIB'); self.p(5, self.next_h()); self.p(330, ins_h)
                self.p(100, 'AcDbEntity'); self.p(8, alay)
                if col != 256:
                    self.p(62, col)
                self.p(100, 'AcDbText')
                self.p(10, '%.4f' % ax); self.p(20, '%.4f' % ay); self.p(30, '0.0')
                self.p(40, '%.4f' % ah); self.p(1, val)
                if arot:
                    self.p(50, '%.4f' % arot)
                self.p(41, '0.80'); self.p(7, 'Dce_Text')
                if ha or va:
                    self.p(72, ha); self.p(11, '%.4f' % ax); self.p(21, '%.4f' % ay); self.p(31, '0.0')
                self.p(100, 'AcDbAttribute')
                self.p(2, tag); self.p(70, 0)
                if va:
                    self.p(74, va)
            self.p(0, 'SEQEND'); self.p(5, self.next_h()); self.p(330, ins_h)
            self.p(100, 'AcDbEntity'); self.p(8, layer)



def _is_tc_group(g, n_spans):
    note = sstr(g.get('note', '')).lower()
    if u'tăng cường' in note or 'tang cuong' in note or note.startswith('tc'):
        return True
    pos, lay = g.get('pos', ''), int(g.get('layer', 1) or 1)
    if pos == u'Giữa':
        return False
    lk, rk = g.get('lk', ''), g.get('rk', '')
    if lk in (u'Cắt trong nhịp', u'Kéo dài ra nhịp') or rk in (u'Cắt trong nhịp', u'Kéo dài ra nhịp'):
        return True
    if lay >= 2 and (lk in (u'Cắt trong nhịp', u'Kéo dài ra nhịp', u'Gập vào cột')
                     or rk in (u'Cắt trong nhịp', u'Kéo dài ra nhịp', u'Gập vào cột')):
        return True
    return False


def _is_col_sup(sup):
    if not sup or sup.get('w', 0.0) <= 0.5:
        return False
    if u'Dầm phụ' in sstr(sup.get('role', '')):
        return False
    kd = sstr(sup.get('kind', '')).lower()
    if not kd:
        return True
    return ('cột' in kd or 'cot' in kd or kd == 'c' or 'vách' in kd or 'vach' in kd or kd == 'v')


def _is_real_sup(sup):
    if not sup or sup.get('w', 0.0) <= 0.5:
        return False
    if u'Dầm phụ' in sstr(sup.get('role', '')):
        return False
    kd = sstr(sup.get('kind', '')).lower()
    if not kd:
        return True
    return ('cột' in kd or 'cot' in kd or kd == 'c' or 'vách' in kd or 'vach' in kd or kd == 'v' or 'dầm' in kd or 'dam' in kd or kd == 'd')


def _effective_end_kind(g, side, k, sups, spans, opt, n_spans):
    kind = g['lk'] if side == 'L' else g['rk']
    val = g['lv'] if side == 'L' else g['rv']
    d = float(g['d'])
    pos, lay = g.get('pos', ''), int(g.get('layer', 1) or 1)
    edge = (k == 0) if side == 'L' else (k == n_spans)
    ci = k if side == 'L' else (k - 1)
    cl_k = spans[ci]['clear'] if 0 <= ci < n_spans else 0.0
    neo_def = _opt_neo_spec(opt, pos)
    neo_mode = _norm_neo_mode((opt or {}).get('neo_mode', ''))
    if kind == u'Kéo dài ra nhịp' and edge:
        kind = u'Hết cột / đầu dầm'
    near = float(opt.get('near') or 0.0)
    if kind == u'Cắt trong nhịp' and near > 0.0 and 0 <= k <= n_spans and _is_real_sup(sups[k]):
        if parse_len(val, d, cl_k, opt.get('cut') or opt.get('ext', 'L/4')) <= near + 0.5:
            kind, val = u'Neo vào gối', neo_def
    a, b = int(g.get('a', 0)), int(g.get('b', 0))
    is_extra = _is_tc_group(g, n_spans) or (
        lay >= 2 and not (a == 0 and b == n_spans and g.get('lk') in (u'Neo vào gối', u'Hết cột / đầu dầm')
                          and g.get('rk') in (u'Neo vào gối', u'Hết cột / đầu dầm'))
    )
    tc_hook = bool(opt.get('tc_hook', 1.0)) and pos != u'Giữa' and (is_extra or lay >= 2)
    hook = False
    if 0 <= k <= n_spans:
        is_free_tip = (sups[k]['w'] <= 0.5)
        explicit_len = parse_len(val, d, cl_k, '')
        want_down = is_down(val)
        want_straight = _is_explicit_straight(val)
        if kind == u'Gập vào cột':
            if neo_mode == _NEO_MODES[2] and not is_free_tip and explicit_len <= 10.0 and not want_straight:
                kind, val, hook = u'Neo vào gối', neo_def, False
            else:
                if pos != u'Giữa' and not want_down and explicit_len <= 10.0:
                    val = opt.get('gap', u'xuống')
                hook = True
        elif pos != u'Giữa' and not want_straight:
            if neo_mode == _NEO_MODES[2] and not is_free_tip and not want_down:
                # 'Neo thẳng vào gối (Lan)': keep straight end into support unless explicit hook requested
                if kind == u'Hết cột / đầu dầm' and explicit_len > 10.0:
                    kind, hook = u'Gập vào cột', True
            elif neo_mode == _NEO_MODES[1] and (edge or _is_col_sup(sups[k])) and kind in (u'Neo vào gối', u'Hết cột / đầu dầm', u'Giữa gối'):
                keep_val = val if (want_down or (kind == u'Hết cột / đầu dầm' and explicit_len > 10.0)) else opt.get('gap', u'xuống')
                kind, val, hook = u'Gập vào cột', keep_val, True
            elif tc_hook and is_extra and _is_col_sup(sups[k]) and kind in (u'Neo vào gối', u'Hết cột / đầu dầm', u'Giữa gối'):
                kind, val, hook = u'Gập vào cột', opt.get('gap', u'xuống'), True
            elif edge and kind in (u'Neo vào gối', u'Hết cột / đầu dầm', u'Giữa gối'):
                if pos == u'Trên' or is_free_tip or tc_hook or want_down or (
                        kind == u'Hết cột / đầu dầm' and explicit_len > 10.0) or (
                        kind == u'Neo vào gối' and sups[k]['w'] > 0.5
                        and parse_len(val, d, cl_k, neo_def) > max(sups[k]['w'] - opt['cover'], 0.0) + 1.0):
                    keep_val = val if (want_down or (kind == u'Hết cột / đầu dầm' and explicit_len > 10.0)) else opt.get('gap', u'xuống')
                    kind, val, hook = u'Gập vào cột', keep_val, True
            elif kind == u'Hết cột / đầu dầm' and (want_down or explicit_len > 10.0):
                kind, hook = u'Gập vào cột', True
    return kind, val, hook, k


def _col_zones(spans, sups, lay, d, opt):
    lan = max(parse_len(opt.get('neo', '30d'), d, 0.0, '30d'), 200.0)
    out = []
    for i, s in enumerate(spans):
        for q in s.get('planted') or []:
            w = float(q.get('w') or 0.0)
            xm = lay['fl'][i] + float(q['pos'])
            out.append((xm - w / 2.0, xm + w / 2.0, xm - w / 2.0 - lan, xm + w / 2.0 + lan))
    for k, su in enumerate(sups):
        if u'Dầm phụ' in sstr(su.get('role', '')) and su.get('w', 0.0) > 0.5:
            out.append((lay['sx0'][k], lay['sx0'][k] + su['w'], lay['sx0'][k] - lan, lay['sx0'][k] + su['w'] + lan))
    return out


def _cover_end(zones, lay, x, side, near=0.0):
    for _ in range(len(zones) + 1):
        moved = False
        for c0, c1, z0, z1 in zones:
            trig = max(near, c0 - z0)
            if side == 'R' and c0 - trig < x < z1 - 1.0:
                nx = min(z1, lay['L'])
            elif side == 'L' and z0 + 1.0 < x < c1 + trig:
                nx = max(z0, 0.0)
            else:
                continue
            if (side == 'L' and nx < x - 0.5) or (side == 'R' and nx > x + 0.5):
                x, moved = nx, True
        if not moved:
            break
    return x


def _round_cut_50(val):
    if val <= 0.0:
        return 0.0
    if abs(val - round(val / 50.0) * 50.0) < 0.05:
        return float(int(round(val)))
    return max(50.0, float(int(math.ceil((val - 1e-4) / 50.0)) * 50))


def build_group_polylines(g, spans, sups, lay, opt, all_groups=None):
    n = lay['n']
    if n == 0 or g['a'] < 0 or g['b'] > n or g['a'] > g['b']:
        return []
    pos, d, layer, a, b = g['pos'], float(g['d']), int(g['layer']), int(g['a']), int(g['b'])
    el = _effective_end_kind(g, 'L', a, sups, spans, opt, n)
    er = _effective_end_kind(g, 'R', b, sups, spans, opt, n)
    lk, glv, hk_l, _ = el
    rk, grv, hk_r, _ = er
    s0 = a - 1 if (lk == u'Kéo dài ra nhịp' and a > 0) else a
    s1 = b if (rk == u'Kéo dài ra nhịp' and b < n) else (b - 1)
    s0 = min(max(s0, 0), n - 1)
    s1 = min(max(s1, 0), n - 1)
    if s0 > s1:
        return []

    cov, stir, pitch = opt['cover'], opt['stir'], opt['pitch']
    near = float(opt.get('near') or 0.0)
    zones = _col_zones(spans, sups, lay, d, opt)

    def span_y(sp):
        t = lay['maxtop'] - sp['top']
        return t, t + sp['h']

    def y_line(sp, p_pos=pos, p_lay=layer, p_d=d):
        t, bt = span_y(sp)
        if p_pos == u'Giữa':
            frac = 1.0 / 3.0 if p_lay == 2 else (2.0 / 3.0 if p_lay == 3 else 0.5)
            return t + (bt - t) * frac
        off = cov + stir + p_d / 2.0 + (p_lay - 1) * (p_d + pitch)
        return t + off if p_pos == u'Trên' else bt - off

    ys = {s: y_line(spans[s]) for s in range(s0, s1 + 1)}
    modes = {}
    cmode = g['cross']
    for j in range(s0, s1):
        dy = abs(ys[j + 1] - ys[j])
        if cmode == u'Luôn neo (cắt)':
            modes[j] = 'split'
        elif cmode == u'Luôn thẳng (nối liền)':
            modes[j] = 'jog' if dy >= 0.5 else 'straight'
        elif cmode == u'Luôn uốn':
            modes[j] = 'jog' if dy >= 0.5 else 'straight'
        else:
            modes[j] = 'straight' if dy <= opt['straight'] + 1e-6 else ('jog' if dy <= opt['thr'] + 1e-6 else 'split')

    j = s0
    while j <= s1:
        k = j
        while k < s1 and modes[k] == 'straight':
            k += 1
        if k > j:
            vals = [ys[q] for q in range(j, k + 1)]
            yc = max(vals) if pos == u'Trên' else (min(vals) if pos == u'Dưới' else sum(vals) / len(vals))
            for q in range(j, k + 1):
                ys[q] = yc
        j = k + 1

    sign = -1.0 if pos == u'Dưới' else 1.0
    xL = lambda k: lay['sx0'][k]
    xR = lambda k: lay['sx0'][k] + sups[k]['w']
    cl = lambda i: spans[i]['clear'] if 0 <= i < n else 0.0
    cap = lambda k: max(sups[k]['w'] - cov, 0.0)

    def _present(og, eo, k):
        a2, b2 = int(og['a']), int(og['b'])
        if a2 < k < b2:
            return True
        ok = (u'Neo vào gối', u'Hết cột / đầu dầm', u'Gập vào cột', u'Giữa gối', u'Kéo dài ra nhịp')
        return (k == a2 and eo[0][0] in ok) or (k == b2 and eo[1][0] in ok)

    def _tip_y(k, sp_i):
        sp = spans[sp_i]
        t, bt = span_y(sp)
        want = u'Trên' if pos == u'Dưới' else u'Dưới'
        ys_ = []
        for og in (all_groups or []):
            if og is g or og.get('pos') != want:
                continue
            eo_l = _effective_end_kind(og, 'L', int(og['a']), sups, spans, opt, n)
            eo_r = _effective_end_kind(og, 'R', int(og['b']), sups, spans, opt, n)
            if _present(og, (eo_l, eo_r), k):
                d2 = float(og['d'])
                y2 = y_line(sp, want, int(og['layer']), d2)
                ys_.append(y2 + d2 / 2.0 if want == u'Trên' else y2 - d2 / 2.0)
        clr = float(opt.get('hook_clr') or 20.0)
        if pos == u'Dưới':
            return (max(ys_) + clr) if ys_ else (t + cov + stir + d + 25.0)
        return (min(ys_) - clr) if ys_ else (bt - cov - stir - d - 25.0)

    def _hook_shift(side, k):
        if pos != u'Dưới' or not all_groups:
            return 0.0
        clr = float(opt.get('hook_clr') or 20.0)
        t_edge, b_min = None, None
        for og in all_groups:
            if og.get('pos') not in (u'Trên', u'Dưới'):
                continue
            if og is not g:
                eo = _effective_end_kind(og, side, int(og['a'] if side == 'L' else og['b']), sups, spans, opt, n)
                if not eo[2] or eo[3] != k:
                    continue
            d2 = float(og['d'])
            off = cov + d2 / 2.0 + (int(og['layer']) - 1) * (d2 + pitch)
            if og.get('pos') == u'Trên':
                t_edge = off + d2 / 2.0 if t_edge is None else max(t_edge, off + d2 / 2.0)
            else:
                b_min = off - d2 / 2.0 if b_min is None else min(b_min, off - d2 / 2.0)
        if t_edge is None or b_min is None:
            return 0.0
        return max(0.0, t_edge + clr - b_min)

    def gap_leg(txt, sp_i, y0, tip=None):
        t, bt = span_y(sp_i)
        if tip is not None:
            full = (y0 - tip) if pos == u'Dưới' else (tip - y0)
        elif pos == u'Dưới':
            full = y0 - (t + cov + stir + d + 25.0)
        else:
            full = bt - cov - stir - d - 25.0 - y0
        full = max(full, 15.0 * d)
        if is_down(txt or opt['gap']):
            return full
        v = parse_len(txt, d, 0.0, opt['gap'])
        return min(v if v > 0 else 15.0 * d, full)

    def tc_hook_extra(side, k):
        if not all_groups or not _is_tc_group(g, n) or pos == u'Giữa':
            return 0.0
        for og in all_groups:
            if og is g or og.get('pos') != pos or int(og.get('layer', 1) or 1) != layer or _is_tc_group(og, n):
                continue
            eo = _effective_end_kind(og, side, int(og['a'] if side == 'L' else og['b']), sups, spans, opt, n)
            if eo[2] and eo[3] == k:
                return max(28.0, float(pitch), float(d))
        return 0.0

    def hook_x(side, k, sh_extra=0.0):
        off_h = cov + d / 2.0 + (layer - 1) * (d + pitch) + sh_extra
        if sups[k]['w'] > 0.5:
            if sh_extra > 0:
                off_h = min(off_h, max(sups[k]['w'] - cov - d / 2.0, cov + d / 2.0))
        else:
            adj_cl = cl(k) if side == 'L' else cl(k - 1)
            if adj_cl > 50.0:
                off_h = min(off_h, max(cov + d / 2.0, adj_cl * 0.6))
        return (xL(k) + off_h) if side == 'L' else (xR(k) - off_h)

    neo_spec_use = _opt_neo_spec(opt, pos)
    neo_mode = _norm_neo_mode(opt.get('neo_mode', ''))
    cut_def = opt.get('cut') or opt.get('ext', 'L/4')

    y0 = ys[s0]
    tip_l = _tip_y(a, s0) if (hk_l and pos != u'Giữa' and 0 <= a < n) else None
    sh_l = (_hook_shift('L', a) + tc_hook_extra('L', a)) if (hk_l and 0 <= a <= n) else 0.0
    if lk == u'Neo vào gối':
        need = parse_len(glv, d, cl(a), neo_spec_use)
        force_straight_l = (neo_mode == _NEO_MODES[2] and sups[a]['w'] > 0.5 and not is_down(glv))
        if (not force_straight_l) and a == 0 and pos != u'Giữa' and not _is_explicit_straight(glv) and (
                pos == u'Trên' or is_down(glv) or sups[a]['w'] <= 0.5 or need > cap(a) + 1.0):
            xh = hook_x('L', a, sh_l)
            leg_full = gap_leg(glv if (is_down(glv) or parse_len(glv, d, cl(a), '') > 0) else opt.get('gap', u'xuống'), spans[s0], y0, tip_l)
            leg = leg_full if (pos == u'Trên' or is_down(glv) or sups[a]['w'] <= 0.5) else min(max(need - cap(a), 15.0 * d), leg_full)
            pts = [(xh, y0 + sign * leg), (xh, y0)]
        else:
            pts = [(xR(a) - min(need, cap(a)), y0)]
    elif lk == u'Hết cột / đầu dầm':
        if pos != u'Giữa' and (is_down(glv) or parse_len(glv, d, cl(a), '') > 10.0 or (a == 0 and sups[a]['w'] <= 0.5 and not _is_explicit_straight(glv))):
            xh = hook_x('L', a, sh_l)
            pts = [(xh, y0 + sign * gap_leg(glv, spans[s0], y0, tip_l)), (xh, y0)]
        else:
            pts = [(xL(a) + cov, y0)]
    elif lk == u'Giữa gối':
        pts = [(xL(a) + sups[a]['w'] / 2.0, y0)]
    elif lk == u'Kéo dài ra nhịp':
        ext_spec_l = g['lv'] or opt.get('ext', 'L/4')
        ext_l = _round_cut_50(parse_len(ext_spec_l, d, cl(a - 1), opt.get('ext', 'L/4')))
        if ext_spec_l.strip().upper() == 'L/4' and cl(a - 1) > 0.0:
            ext_l = min(ext_l, round(cl(a - 1) * 0.35))
        pts = [(xL(a) - ext_l, y0)]
    elif lk == u'Cắt trong nhịp':
        cut_spec_l = g['lv'] or cut_def
        cut_l = _round_cut_50(parse_len(cut_spec_l, d, cl(a), cut_def))
        if cut_spec_l.strip().upper() == 'L/4' and cl(a) > 0.0:
            cut_l = min(cut_l, round(cl(a) * 0.35))
        pts = [(xR(a) + cut_l, y0)]
    elif lk == u'Gập vào cột':
        xh = hook_x('L', a, sh_l)
        pts = [(xh, y0 + sign * gap_leg(glv, spans[s0], y0, tip_l)), (xh, y0)]
    else:
        pts = [(xL(a) + cov, y0)]
    if lk in (u'Kéo dài ra nhịp', u'Cắt trong nhịp') and zones:
        pts[0] = (_cover_end(zones, lay, pts[0][0], 'L', near), pts[0][1])

    y1 = ys[s1]
    tip_r = _tip_y(b, s1) if (hk_r and pos != u'Giữa' and 0 < b <= n) else None
    sh_r = (_hook_shift('R', b) + tc_hook_extra('R', b)) if (hk_r and 0 <= b <= n) else 0.0
    if rk == u'Neo vào gối':
        need = parse_len(grv, d, cl(b - 1), neo_spec_use)
        force_straight_r = (neo_mode == _NEO_MODES[2] and sups[b]['w'] > 0.5 and not is_down(grv))
        if (not force_straight_r) and b == n and pos != u'Giữa' and not _is_explicit_straight(grv) and (
                pos == u'Trên' or is_down(grv) or sups[b]['w'] <= 0.5 or need > cap(b) + 1.0):
            xh = hook_x('R', b, sh_r)
            leg_full = gap_leg(grv if (is_down(grv) or parse_len(grv, d, cl(b - 1), '') > 0) else opt.get('gap', u'xuống'), spans[s1], y1, tip_r)
            leg = leg_full if (pos == u'Trên' or is_down(grv) or sups[b]['w'] <= 0.5) else min(max(need - cap(b), 15.0 * d), leg_full)
            rp = [(xh, y1), (xh, y1 + sign * leg)]
        else:
            rp = [(xL(b) + min(need, cap(b)), y1)]
    elif rk == u'Hết cột / đầu dầm':
        if pos != u'Giữa' and (is_down(grv) or parse_len(grv, d, cl(b - 1), '') > 10.0 or (b == n and sups[b]['w'] <= 0.5 and not _is_explicit_straight(grv))):
            xh = hook_x('R', b, sh_r)
            rp = [(xh, y1), (xh, y1 + sign * gap_leg(grv, spans[s1], y1, tip_r))]
        else:
            rp = [(xR(b) - cov, y1)]
    elif rk == u'Giữa gối':
        rp = [(xL(b) + sups[b]['w'] / 2.0, y1)]
    elif rk == u'Kéo dài ra nhịp':
        ext_spec_r = g['rv'] or opt.get('ext', 'L/4')
        ext_r = _round_cut_50(parse_len(ext_spec_r, d, cl(b), opt.get('ext', 'L/4')))
        if ext_spec_r.strip().upper() == 'L/4' and cl(b) > 0.0:
            ext_r = min(ext_r, round(cl(b) * 0.35))
        rp = [(xR(b) + ext_r, y1)]
    elif rk == u'Cắt trong nhịp':
        cut_spec_r = g['rv'] or cut_def
        cut_r = _round_cut_50(parse_len(cut_spec_r, d, cl(b - 1), cut_def))
        if cut_spec_r.strip().upper() == 'L/4' and cl(b - 1) > 0.0:
            cut_r = min(cut_r, round(cl(b - 1) * 0.35))
        rp = [(xL(b) - cut_r, y1)]
    elif rk == u'Gập vào cột':
        xh = hook_x('R', b, sh_r)
        rp = [(xh, y1), (xh, y1 + sign * gap_leg(grv, spans[s1], y1, tip_r))]
    else:
        rp = [(xR(b) - cov, y1)]
    if rk in (u'Kéo dài ra nhịp', u'Cắt trong nhịp') and zones:
        rp[-1] = (_cover_end(zones, lay, rp[-1][0], 'R', near), rp[-1][1])

    lines = []
    cur = list(pts)
    lan = max(parse_len(neo_spec_use, d, 0.0, '30d'), 200.0)
    step_mode = _norm_step_neo(opt.get('step_neo', ''))
    gap_def = opt.get('gap', u'xuống')
    for idx in range(s0, s1):
        k = idx + 1
        yl, yr = ys[idx], ys[idx + 1]
        dy = abs(yr - yl)
        m = modes[idx]
        if m == 'split' and pos != u'Giữa' and dy >= 0.5:
            poker_left = (yl > yr) if pos == u'Trên' else (yl < yr)
            off_s = cov + d / 2.0 + (layer - 1) * (d + pitch)
            if step_mode == _STEP_NEO_MODES[1]:
                xh_l = max(xL(k) + cov + d / 2.0, xR(k) - off_s)
                cur.append((xh_l, yl))
                cur.append((xh_l, yl + sign * gap_leg(gap_def, spans[idx], yl)))
                lines.append(cur)
                xh_r = min(xR(k) - cov - d / 2.0, xL(k) + off_s)
                cur = [(xh_r, yr + sign * gap_leg(gap_def, spans[idx + 1], yr)), (xh_r, yr)]
            elif poker_left:
                # Measure Lan from near face xL(k) of the stepped support instead of far face xR(k)
                cur.append((min(xL(k) + max(lan, cov + d), lay['fr'][idx + 1]), yl))
                lines.append(cur)
                xh = min(xL(k) + off_s, xR(k))
                cur = [(xh, yr + sign * gap_leg(gap_def, spans[idx + 1], yr)), (xh, yr)]
            else:
                xh = max(xR(k) - off_s, xL(k))
                cur.append((xh, yl))
                cur.append((xh, yl + sign * gap_leg(gap_def, spans[idx], yl)))
                lines.append(cur)
                # Measure Lan from near face xR(k) leftward instead of far face xL(k)
                cur = [(max(xR(k) - max(lan, cov + d), lay['fl'][idx]), yr)]
        elif m == 'split':
            la = parse_len(neo_spec_use, d, 0.0, '30d')
            av = cap(k)
            if sups[k]['w'] <= 0.5 or la <= av + 1e-6:
                cur.append((xL(k) + la, yl))
                lines.append(cur)
                cur = [(xR(k) - la, yr)]
            else:
                legl = min(max(la - av, 15.0 * d), gap_leg(gap_def, spans[idx], yl))
                legr = min(max(la - av, 15.0 * d), gap_leg(gap_def, spans[idx + 1], yr))
                cur.append((xL(k) + av, yl))
                cur.append((xL(k) + av, yl + sign * legl))
                lines.append(cur)
                cur = [(xR(k) - av, yr + sign * legr), (xR(k) - av, yr)]
        elif m == 'jog' and dy >= 0.5:
            xc = (xL(k) + xR(k)) / 2.0
            run = opt['slope'] * dy
            cur.append((xc - run / 2.0, yl))
            cur.append((xc + run / 2.0, yr))
    cur.extend(rp)
    lines.append(cur)

    clean = []
    for ln in lines:
        q = [ln[0]]
        for p in ln[1:]:
            if abs(p[0] - q[-1][0]) > 0.01 or abs(p[1] - q[-1][1]) > 0.01:
                q.append(p)
        if len(q) > 1:
            clean.append(q)
    return clean


def classify_poly(pts):
    segs = []
    for i in range(len(pts) - 1):
        dx = pts[i + 1][0] - pts[i][0]
        dy = pts[i + 1][1] - pts[i][1]
        ln = int(round(math.hypot(dx, dy)))
        if ln >= 5:
            segs.append((dx, dy, ln))
    sumL = sum(s[2] for s in segs)
    if len(segs) <= 1:
        return 'TK1', sumL, 0, 0, 0, 0, sumL
    if len(segs) == 2:
        shp = 'TK2' if abs(segs[0][1]) > abs(segs[0][0]) else 'TK3'
        return shp, segs[0][2], segs[1][2], 0, 0, 0, sumL
    if len(segs) == 3:
        shp = 'TK7' if segs[0][1] < 0 else 'TK4'
        return shp, segs[0][2], segs[1][2], segs[2][2], 0, 0, sumL
    if len(segs) == 5:
        return 'TK7R1', segs[0][2], segs[1][2], segs[2][2], segs[3][2], segs[4][2], sumL
    return 'TKTUnknown', sumL, 0, 0, 0, 0, sumL


def _bend_cad_polyline(cad_pts, pos='Trên', fillet_r=30.0, hook_ret=70.0):
    """Add 20-deg 70mm inward hook ticks and 90-deg rounded corner bulges matching beam.dxf."""
    if not cad_pts or len(cad_pts) < 2:
        return [(p[0], p[1], 0.0) for p in (cad_pts or [])]

    def _seg_dir(p0, p1):
        dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        ln = math.hypot(dx, dy)
        return (dx / ln, dy / ln, ln) if ln > 1e-6 else (1.0, 0.0, 0.0)

    def _inward_normal(ux, uy, default_ny):
        if abs(ux) >= abs(uy):
            # Horizontal bar: top points down (-1), bottom points up (+1)
            ny = -1.0 if pos == 'Trên' else (1.0 if pos == 'Dưới' else default_ny)
            return (0.0, ny)
        # Vertical leg: normal points toward interior (determined by default_nx passed in)
        return (default_ny, 0.0)

    mid_x = sum(p[0] for p in cad_pts) / float(len(cad_pts))
    pts = list(cad_pts)
    out = []

    # Start hook return tick (20 deg inward, length hook_ret)
    ux0, uy0, _ = _seg_dir(pts[0], pts[1])
    if abs(ux0) >= abs(uy0):
        nx0, ny0 = _inward_normal(ux0, uy0, -1.0)
    else:
        nx0 = 1.0 if pts[0][0] <= mid_x else -1.0
        ny0 = 0.0
    ang20_c = math.cos(math.radians(20.0))
    ang20_s = math.sin(math.radians(20.0))
    tick_s = (
        pts[0][0] + hook_ret * (ux0 * ang20_c + nx0 * ang20_s),
        pts[0][1] + hook_ret * (uy0 * ang20_c + ny0 * ang20_s),
        0.0
    )
    out.append(tick_s)

    n = len(pts)
    for i, p in enumerate(pts):
        if 0 < i < n - 1:
            u1x, u1y, l1 = _seg_dir(pts[i - 1], p)
            u2x, u2y, l2 = _seg_dir(p, pts[i + 1])
            dot = u1x * u2x + u1y * u2y
            cross = u1x * u2y - u1y * u2x
            # Fillet 90-degree corners (dot near 0)
            if abs(dot) < 0.25 and l1 > 20.0 and l2 > 20.0:
                r = min(fillet_r, l1 * 0.4, l2 * 0.4)
                p_in = (p[0] - u1x * r, p[1] - u1y * r)
                p_out = (p[0] + u2x * r, p[1] + u2y * r)
                bulge = _BULGE_90 if cross > 0.0 else -_BULGE_90
                out.append((p_in[0], p_in[1], bulge))
                out.append((p_out[0], p_out[1], 0.0))
                continue
        out.append((p[0], p[1], 0.0))

    # End hook return tick
    ux1, uy1, _ = _seg_dir(pts[-2], pts[-1])
    bx, by = -ux1, -uy1
    if abs(bx) >= abs(by):
        nx1, ny1 = _inward_normal(bx, by, -1.0)
    else:
        nx1 = 1.0 if pts[-1][0] <= mid_x else -1.0
        ny1 = 0.0
    tick_e = (
        pts[-1][0] + hook_ret * (bx * ang20_c + nx1 * ang20_s),
        pts[-1][1] + hook_ret * (by * ang20_c + ny1 * ang20_s),
        0.0
    )
    out.append(tick_e)
    return out


def _draw_tkt_unknown_diagram(dxf, raw_cad_pts, cx_col, row_top_y, row_h=675.0):
    """Draw scaled rebar shape + suppressed-line segment DIMENSIONs inside TKTUnknown cell."""
    if not raw_cad_pts or len(raw_cad_pts) < 2:
        return
    xs = [p[0] for p in raw_cad_pts]
    ys = [p[1] for p in raw_cad_pts]
    w_raw = max(1.0, max(xs) - min(xs))
    h_raw = max(1.0, max(ys) - min(ys))
    cell_x0 = cx_col + 1450.0
    cell_x1 = cx_col + 3550.0
    cell_y0 = row_top_y - row_h + 150.0
    cell_y1 = row_top_y - 240.0
    sc_x = (cell_x1 - cell_x0) / w_raw
    sc_y = (cell_y1 - cell_y0) / max(h_raw, 120.0)
    sc = min(sc_x, sc_y)
    # Keep horizontal compression readable for multi-span beams while bounding height
    sc_hx = min(sc_x, max(sc * 1.4, sc_x))
    cx_raw = (min(xs) + max(xs)) / 2.0
    cy_raw = (min(ys) + max(ys)) / 2.0
    cx_dst = (cell_x0 + cell_x1) / 2.0
    cy_dst = row_top_y - row_h * 0.62

    mapped = []
    for p in raw_cad_pts:
        mx = cx_dst + (p[0] - cx_raw) * sc_hx
        my = cy_dst + (p[1] - cy_raw) * sc
        mapped.append((mx, my))

    dxf.pline(mapped, 'DCE_ThepChu', False, 256)
    for i in range(len(mapped) - 1):
        p1, p2 = mapped[i], mapped[i + 1]
        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]
        seg_d = math.hypot(dx, dy)
        if seg_d < 8.0:
            continue
        raw_len = int(round(math.hypot(raw_cad_pts[i + 1][0] - raw_cad_pts[i][0],
                                       raw_cad_pts[i + 1][1] - raw_cad_pts[i][1])))
        if raw_len < 5:
            continue
        ang_deg = math.degrees(math.atan2(dy, dx)) % 360.0
        nx, ny = -dy / seg_d, dx / seg_d
        if ny < -0.5 or (abs(ny) < 0.2 and nx < 0):
            nx, ny = -nx, -ny
        dim_x = (p1[0] + p2[0]) / 2.0 + nx * 87.5
        dim_y = (p1[1] + p2[1]) / 2.0 + ny * 87.5
        dxf.dim(p1[0], p1[1], p2[0], p2[1], dim_x, dim_y, 'DCE_Dim', 50.0,
                text_override=str(raw_len), dimstyle='Dce_50MV', rot_deg=ang_deg,
                suppress_lines=True)



def read_excel_beam_names(xlsx_path):
    wb = read_xlsx_rows(xlsx_path)
    nhip = wb.get('Nhip', [])
    if len(nhip) < 2:
        return []
    names = []
    seen = set()
    for r in nhip[1:]:
        if not r or not sstr(r[0]):
            continue
        nm = sstr(r[0])
        if nm not in seen:
            seen.add(nm)
            names.append(nm)
    return sorted(names, key=_natural_beam_key)


def _norm_hdr(txt):
    s = sstr(txt).lower()
    rep = {
        u'à': 'a', u'á': 'a', u'ả': 'a', u'ã': 'a', u'ạ': 'a', u'ă': 'a', u'ằ': 'a', u'ắ': 'a', u'ẳ': 'a', u'ẵ': 'a', u'ặ': 'a',
        u'â': 'a', u'ầ': 'a', u'ấ': 'a', u'ẩ': 'a', u'ẫ': 'a', u'ậ': 'a', u'đ': 'd',
        u'è': 'e', u'é': 'e', u'ẻ': 'e', u'ẽ': 'e', u'ẹ': 'e', u'ê': 'e', u'ề': 'e', u'ế': 'e', u'ể': 'e', u'ễ': 'e', u'ệ': 'e',
        u'ì': 'i', u'í': 'i', u'ỉ': 'i', u'ĩ': 'i', u'ị': 'i',
        u'ò': 'o', u'ó': 'o', u'ỏ': 'o', u'õ': 'o', u'ọ': 'o', u'ô': 'o', u'ồ': 'o', u'ố': 'o', u'ổ': 'o', u'ỗ': 'o', u'ộ': 'o',
        u'ơ': 'o', u'ờ': 'o', u'ớ': 'o', u'ở': 'o', u'ỡ': 'o', u'ợ': 'o',
        u'ù': 'u', u'ú': 'u', u'ủ': 'u', u'ũ': 'u', u'ụ': 'u', u'ư': 'u', u'ừ': 'u', u'ứ': 'u', u'ử': 'u', u'ữ': 'u', u'ự': 'u',
        u'ỳ': 'y', u'ý': 'y', u'ỷ': 'y', u'ỹ': 'y', u'ỵ': 'y', u'ø': 'phi', u'Ø': 'phi',
    }
    out = []
    for ch in s:
        out.append(rep.get(ch, ch))
    return re.sub(r'\s+', ' ', ''.join(out)).strip()


def _build_col_lookup(hdr_row):
    exact = {}
    normd = {}
    hdr_list = []
    for i, h in enumerate(hdr_row or []):
        sh = sstr(h)
        if sh:
            exact.setdefault(sh, i)
            nh = _norm_hdr(sh)
            normd.setdefault(nh, i)
            hdr_list.append((i, sh, nh))
    return exact, normd, hdr_list


def _hdr_alias_matches(na, hk):
    if not na or not hk:
        return False
    if na == 'dai':
        if any(bad in hk for bad in ('chieu dai', 'keo dai', 'do dai')):
            return False
        return bool(re.search(r'(?:^|[^a-z0-9])dai(?:$|[^a-z0-9])', hk))
    if len(na) <= 3:
        return bool(re.search(r'(?:^|[^a-z0-9])' + re.escape(na) + r'(?:$|[^a-z0-9])', hk))
    return na in hk


def _find_col_idx(col_pair, aliases, fallback=None):
    exact, normd = col_pair[0], col_pair[1]
    for a in aliases:
        if a in exact:
            return exact[a]
    for a in aliases:
        na = _norm_hdr(a)
        if na in normd:
            return normd[na]
    for a in aliases:
        na = _norm_hdr(a)
        if not na:
            continue
        for hk, idx in normd.items():
            if _hdr_alias_matches(na, hk):
                return idx
    return fallback


def _find_all_col_idxs(col_pair, aliases):
    hdr_list = col_pair[2] if len(col_pair) > 2 else []
    idxs = []
    seen = set()
    for a in aliases:
        na = _norm_hdr(a)
        for i, sh, nh in hdr_list:
            if i in seen:
                continue
            if sh == a or (na and (nh == na or _hdr_alias_matches(na, nh))):
                seen.add(i)
                idxs.append(i)
    return sorted(idxs)


_STIR_COL_ALIASES = [u'Đai (Ø-a gối/a nhịp)', u'Đai (Ø-a gối/nhịp)', u'Thép đai', u'Thep dai', u'Cốt đai', u'Cot dai', u'Đai dầm', u'Dai dam', u'Đai']
_MODE_COL_ALIASES = [u'Cấu hình nhịp', u'Chế độ vẽ', u'Chế độ']
_PLANTED_COL_ALIASES = [u'Cột cấy (tên@vị trí@rộng)', u'Cột cấy', 'Cot cay', u'Cột trên dầm', 'Cot tren dam', u'Cột trên']
_THEP_NOTE_ALIASES = [u'Ghi chú', 'Ghi chu', 'Note', 'STT']
_THEP_LK_ALIASES = [u'Kiểu trái', 'Kieu trai', u'Kiểu neo trái', u'Loại trái', u'Neo trái', u'Đầu trái', u'Móc trái', u'Kiểu neo T']
_THEP_RK_ALIASES = [u'Kiểu phải', 'Kieu phai', u'Kiểu neo phải', u'Loại phải', u'Neo phải', u'Đầu phải', u'Móc phải', u'Kiểu neo P']
_THEP_CR_ALIASES = [u'Vượt gối', 'Vuot goi', u'Qua gối', 'Qua goi', u'Chênh cốt']


def _pick_stir_col(rows, col_pair, fallback=34):
    cands = _find_all_col_idxs(col_pair, _STIR_COL_ALIASES)
    if not cands:
        return fallback
    if len(cands) == 1:
        return cands[0]
    best_idx = cands[0]
    best_score = -1
    for ci in cands:
        sc = 0
        for r in (rows or [])[1:]:
            if ci < len(r):
                v = sstr(r[ci])
                if v:
                    sc += 3 if re.search(r'\d+\s*[-a/]\s*\d+', v) else 1
        if sc > best_score:
            best_score = sc
            best_idx = ci
    return best_idx


def _gc_aliases(row, col_pair, aliases, fallback=None):
    idx = _find_col_idx(col_pair, aliases, fallback)
    if idx is None or idx < 0 or idx >= len(row):
        return None
    return row[idx]


def _parse_sup_idx(val, default=0):
    v = sstr(val)
    if not v:
        return default
    try:
        return max(0, int(round(float(v.replace(',', '.')))))
    except Exception:
        m = re.search(r'\d+', v)
        if m:
            return max(0, int(m.group(0)))
    return default


def read_excel_beam_summaries_from_wb(wb):
    nhip = (wb or {}).get('Nhip', [])
    if len(nhip) < 2:
        return []
    cp = _build_col_lookup(nhip[0])
    c_nm = _find_col_idx(cp, [u'Tên dầm', 'Ten dam'], 0)
    c_b = _find_col_idx(cp, ['b (mm)', 'b', u'Rộng'], 14)
    c_h = _find_col_idx(cp, ['h (mm)', 'h', 'Cao'], 15)
    c_sl = _find_col_idx(cp, ['SL', u'Số lượng'], 1)
    c_st = _pick_stir_col(nhip, cp, 34)
    grouped = {}
    order = []
    for r in nhip[1:]:
        nm = sstr(r[c_nm] if c_nm < len(r) else '')
        if not r or not nm:
            continue
        if nm not in grouped:
            grouped[nm] = {'spans': 0, 'b': 0, 'h': 0, 'sl': 1, 'stirs': []}
            order.append(nm)
        g = grouped[nm]
        g['spans'] += 1
        g['b'] = int(round(num(r[c_b] if c_b < len(r) else 220, 220)))
        g['h'] = int(round(num(r[c_h] if c_h < len(r) else 500, 500)))
        g['sl'] = max(1, int(round(num(r[c_sl] if c_sl < len(r) else 1, 1))))
        if c_st is not None and c_st < len(r) and sstr(r[c_st]):
            st_v = sstr(r[c_st])
            if st_v not in g['stirs']:
                g['stirs'].append(st_v)

    thep_map = {}
    thep_sh = (wb or {}).get('Thep', [])
    if len(thep_sh) >= 2:
        th_cp = _build_col_lookup(thep_sh[0])
        c_tbn = _find_col_idx(th_cp, [u'Tên dầm', 'Ten dam'], 0)
        c_tps = _find_col_idx(th_cp, [u'Vị trí', 'Vi tri'], 2)
        c_tly = _find_col_idx(th_cp, [u'Lớp', 'Lop'], 3)
        c_tsl = _find_col_idx(th_cp, ['SL', u'Số lượng', 'So luong'], 4)
        c_tph = _find_col_idx(th_cp, ['Phi', u'Đường kính', 'DK', 'Duong kinh'], 5)
        for tr in thep_sh[1:]:
            if not tr or len(tr) < 6:
                continue
            bn = sstr(tr[c_tbn] if c_tbn is not None and c_tbn < len(tr) else '')
            if not bn:
                continue
            thep_map.setdefault(bn, []).append({
                'pos': norm_pos(tr[c_tps] if c_tps is not None and c_tps < len(tr) else u'Trên'),
                'layer': max(1, int(round(num(tr[c_tly] if c_tly is not None and c_tly < len(tr) else 1, 1)))),
                'n': max(1, int(round(num(tr[c_tsl] if c_tsl is not None and c_tsl < len(tr) else 2, 2)))),
                'd': max(6, int(round(num(tr[c_tph] if c_tph is not None and c_tph < len(tr) else 16, 16)))),
            })

    out = []
    for nm in sorted(order, key=_natural_beam_key):
        g = grouped[nm]
        grps_b = thep_map.get(nm, [])
        parts = []
        if g['sl'] > 1:
            parts.append(u'SL: %d' % g['sl'])
        if grps_b:
            top_l1 = [x for x in grps_b if x['pos'] == u'Trên' and x['layer'] == 1]
            bot_l1 = [x for x in grps_b if x['pos'] == u'Dưới' and x['layer'] == 1]
            mid_g = [x for x in grps_b if x['pos'] == u'Giữa']
            extra_cnt = max(0, len(grps_b) - (1 if top_l1 else 0) - (1 if bot_l1 else 0) - len(mid_g))
            top_s = (u'Trên %dØ%d' % (top_l1[0]['n'], top_l1[0]['d'])) if top_l1 else ''
            bot_s = (u'Dưới %dØ%d' % (bot_l1[0]['n'], bot_l1[0]['d'])) if bot_l1 else ''
            if top_s and bot_s:
                bar_s = u'%s · %s' % (top_s, bot_s)
            else:
                bar_s = top_s or bot_s
            if mid_g:
                bar_s += u' · Giữa %dØ%d' % (mid_g[0]['n'], mid_g[0]['d'])
            if extra_cnt > 0:
                bar_s += u' (+%d TC)' % extra_cnt
            if bar_s:
                parts.append(bar_s)
        if g['stirs']:
            stir_disp = u', '.join(u'Ø%s' % s for s in g['stirs'][:2]) + (u', ...' if len(g['stirs']) > 2 else '')
            parts.append(u'Đai %s' % stir_disp)
        note = u' · '.join(parts) if parts else (u'SL: %d' % g['sl'])
        out.append((nm, g['spans'], u'%d×%d' % (g['b'], g['h']), note))
    return out


def read_excel_beam_summaries(xlsx_path):
    return read_excel_beam_summaries_from_wb(read_xlsx_rows(xlsx_path))


def _is_mc_only_token(txt):
    s = _norm_hdr(txt).upper().replace('_', ' ')
    if ('CHI MC' in s) or ('CHIMC' in s) or ('CHI MAT CAT' in s) or ('MC ONLY' in s) or ('MCONLY' in s):
        return True
    return bool(re.search(r'(?:^|\s)GIANG(?:\s|$)', s))


def read_excel_beam_modes_from_wb(wb):
    nhip = (wb or {}).get('Nhip', [])
    if len(nhip) < 2:
        return {}
    cp = _build_col_lookup(nhip[0])
    c_nm = _find_col_idx(cp, [u'Tên dầm', 'Ten dam'], 0)
    c_mode = _find_col_idx(cp, _MODE_COL_ALIASES, 9)
    c_modes = _find_all_col_idxs(cp, _MODE_COL_ALIASES) or ([c_mode] if c_mode is not None else [])
    modes = {}
    for r in nhip[1:]:
        nm = sstr(r[c_nm] if c_nm < len(r) else '')
        if not r or not nm:
            continue
        if nm not in modes:
            modes[nm] = 'FULL'
        for cm_i in c_modes:
            raw_m = sstr(r[cm_i] if (cm_i is not None and cm_i < len(r)) else '')
            if _is_mc_only_token(raw_m):
                modes[nm] = 'MC_ONLY'
                break
    return modes


def read_excel_beam_modes(xlsx_path):
    return read_excel_beam_modes_from_wb(read_xlsx_rows(xlsx_path))


def _get_out_dir():
    out_dir = os.path.join(tempfile.gettempdir(), 'BeamCAD_Out')
    if not os.path.isdir(out_dir):
        try:
            os.makedirs(out_dir)
        except Exception:
            pass
    return out_dir


def _write_beamcad_tools_lisp(target_dir):
    """Ghi bo lenh AutoLISP BeamCAD_Tools.lsp + hop thoai DCL BeamCAD_Tools.dcl: DAM_SUA, DAM_QTK, DAM_THEP, DAM_DAI, DAM_TEN, DAM_HELP."""
    if not target_dir or not os.path.isdir(target_dir):
        return ''
    lsp_path = os.path.join(target_dir, 'BeamCAD_Tools.lsp')
    dcl_path = os.path.join(target_dir, 'BeamCAD_Tools.dcl')
    dcl_posix = dcl_path.replace('\\', '/')

    dcl_lines = [
        u'dam_edit_dlg : dialog {',
        u'  label = "BeamCAD - Sua nhanh & Dong bo Cot thep";',
        u'  : boxed_column {',
        u'    label = "Cau kien";',
        u'    : edit_box { key = "e_bname"; label = "Ten dam (Cau kien):"; edit_width = 22; }',
        u'    : edit_box { key = "e_skc";   label = "So cau kien (SKC):";  edit_width = 10; }',
        u'  }',
        u'  : boxed_column {',
        u'    label = "Thong tin thep / dai dang chon";',
        u'    : text     { key = "t_kind"; label = "Loai: Thep chu"; width = 44; }',
        u'    : edit_box { key = "e_sh";   label = "So hieu (SH):";       edit_width = 12; }',
        u'    : edit_box { key = "e_sl";   label = "So luong thanh (SL):"; edit_width = 12; }',
        u'    : edit_box { key = "e_dk";   label = "Duong kinh DK (mm):";  edit_width = 12; }',
        u'    : edit_box { key = "e_za";   label = "Buoc dai a (mm):";     edit_width = 12; }',
        u'  }',
        u'  : boxed_radio_column {',
        u'    label = "Pham vi ap dung";',
        u'    : radio_button { key = "r_one";     label = "Chi cap nhat nhom / SH dang chon (Thep + Tag + MC + TK)"; value = "1"; }',
        u'    : radio_button { key = "r_beam_dk"; label = "Doi hang loat cac thanh cung DK cu trong DAM NAY"; }',
        u'    : radio_button { key = "r_all_dk";  label = "Doi hang loat cac thanh cung DK cu TOAN BAN VE"; }',
        u'  }',
        u'  : row {',
        u'    : ok_button { label = "Cap nhat & Tinh TK"; is_default = true; }',
        u'    : button { key = "b_qtk"; label = "Quet TK ngay"; }',
        u'    : cancel_button { label = "Huy"; is_cancel = true; }',
        u'  }',
        u'}',
        u'',
        u'dam_batch_dlg : dialog {',
        u'  label = "BeamCAD - Doi hang loat Cot thep / Dai";',
        u'  : boxed_column {',
        u'    label = "Thong so thay doi";',
        u'    : text     { key = "b_title";  label = "Doi hang loat"; width = 42; }',
        u'    : edit_box { key = "b_old_dk"; label = "Loc theo DK cu mm (trong = tat ca):"; edit_width = 12; }',
        u'    : edit_box { key = "b_new_dk"; label = "DK moi mm (trong = giu nguyen):";     edit_width = 12; }',
        u'    : edit_box { key = "b_new_sl"; label = "SL thanh moi (trong = giu nguyen):";  edit_width = 12; }',
        u'    : edit_box { key = "b_new_za"; label = "Buoc dai a moi mm (trong = giu):";   edit_width = 12; }',
        u'  }',
        u'  : boxed_radio_column {',
        u'    label = "Pham vi quet";',
        u'    : radio_button { key = "br_all";  label = "Toan bo ban ve (nhanh)"; value = "1"; }',
        u'    : radio_button { key = "br_pick"; label = "Chon vung doi tuong tren ban ve"; }',
        u'  }',
        u'  ok_cancel;',
        u'}',
    ]
    with io.open(dcl_path, 'wb') as f_dcl:
        f_dcl.write((u'\r\n'.join(dcl_lines) + u'\r\n').encode('utf-8'))

    dcl_embed_lisp = u'\n'.join(u'      (write-line "%s" fp)' % ln.replace(u'\\', u'\\\\').replace(u'"', u'\\"') for ln in dcl_lines)

    lsp_code = u'''(vl-load-com)
(foreach _app '("BeamCAD_LINK" "BeamCAD_META" "BeamCAD_SUM" "BeamCAD_SKC" "DCEThongKeThep")
  (vl-catch-all-apply (quote regapp) (list _app))
)

(setq *BC_DCL_PATH* "__BC_DCL_PATH__")
(setq *BC_SCAN_JSON* "__BC_SCAN_JSON__")

(defun _bc-ensure-dcl (/ fp p)
  (setq p *BC_DCL_PATH*)
  (if (and p (findfile p))
    p
    (progn
      (setq p (strcat (getvar "TEMPPREFIX") "BeamCAD_Tools.dcl"))
      (if (setq fp (open p "w"))
        (progn
__BC_DCL_EMBED__
          (close fp)
        )
      )
      p
    )
  )
)

(defun _bc-str (v)
  (cond
    ((null v) "")
    ((= (type v) 'STR) v)
    ((= (type v) 'INT) (itoa v))
    ((= (type v) 'REAL) (rtos v 2 4))
    (t (vl-princ-to-string v))
  )
)

(defun _bc-trim (s)
  (vl-string-trim " \\t\\r\\n" (_bc-str s))
)

(defun _bc-up (s)
  (strcase (_bc-trim s))
)

(defun _bc-nums (s / i n ch cur res)
  (setq s (_bc-str s) n (strlen s) i 1 cur "" res nil)
  (while (<= i n)
    (setq ch (substr s i 1))
    (if (and (>= (ascii ch) 48) (<= (ascii ch) 57))
      (setq cur (strcat cur ch))
      (if (> (strlen cur) 0)
        (progn (setq res (cons (atoi cur) res)) (setq cur ""))
      )
    )
    (setq i (1+ i))
  )
  (if (> (strlen cur) 0)
    (setq res (cons (atoi cur) res))
  )
  (reverse res)
)

(defun _bc-int (s def / ns)
  (setq ns (_bc-nums s))
  (if ns (car ns) def)
)

(defun _bc-parse-spec (s / up ns)
  (setq up (_bc-up s) ns (_bc-nums up))
  (cond
    ((null ns) nil)
    ((or (vl-string-search "A" up) (vl-string-search "@" up))
      (list "STIR" 0 (car ns) (if (cadr ns) (cadr ns) 100))
    )
    ((>= (length ns) 2)
      (list "BAR" (car ns) (cadr ns) 0)
    )
    (t (list "BAR" 0 (car ns) 0))
  )
)

(defun _bc-unitw (dk)
  (* (/ (* 3.14159265358979 (float dk) (float dk)) 4.0) 0.00785)
)

(defun _bc-xd-get (ent app / ed xd pair)
  (setq ed (entget ent (list app)))
  (setq xd (cdr (assoc -3 ed)))
  (if xd
    (progn
      (setq pair (assoc app xd))
      (if pair (cdr pair) nil)
    )
    nil
  )
)

(defun _bc-xd-vals (ent / raw)
  (setq raw (_bc-xd-get ent "BeamCAD_LINK"))
  (if raw (mapcar (quote cdr) raw) nil)
)

(defun _bc-xd-set (ent app typed-pairs / ed old3 kept item new3)
  (vl-catch-all-apply (quote regapp) (list app))
  (setq ed (entget ent (list "*")))
  (setq old3 (cdr (assoc -3 ed)))
  (setq kept nil)
  (foreach item old3
    (if (/= (strcase (car item)) (strcase app))
      (setq kept (cons item kept))
    )
  )
  (setq new3 (cons -3 (append (reverse kept) (list (cons app typed-pairs)))))
  (if (assoc -3 ed)
    (entmod (subst new3 (assoc -3 ed) ed))
    (entmod (append ed (list new3)))
  )
)

(defun _bc-set-link (ent lst / typed v)
  (setq typed nil)
  (foreach v lst
    (cond
      ((= (type v) 'INT) (setq typed (cons (cons 1070 v) typed)))
      ((= (type v) 'REAL) (setq typed (cons (cons 1040 v) typed)))
      (t (setq typed (cons (cons 1000 (_bc-str v)) typed)))
    )
  )
  (_bc-xd-set ent "BeamCAD_LINK" (reverse typed))
)

(defun _bc-blk-name (obj / nm)
  (setq nm
    (if (vlax-property-available-p obj (quote EffectiveName))
      (vl-catch-all-apply (quote vla-get-EffectiveName) (list obj))
      (vl-catch-all-apply (quote vla-get-Name) (list obj))
    )
  )
  (if (vl-catch-all-error-p nm)
    (strcase (_bc-str (vla-get-Name obj)))
    (strcase (_bc-str nm))
  )
)

(defun _bc-atts (obj / res arr)
  (if (= (vla-get-HasAttributes obj) :vlax-true)
    (progn
      (setq arr (vl-catch-all-apply (quote vla-GetAttributes) (list obj)))
      (if (and arr (not (vl-catch-all-error-p arr)))
        (setq res (vlax-safearray->list (vlax-variant-value arr)))
      )
    )
  )
  res
)

(defun _bc-att-get (obj tag / up found a)
  (setq up (strcase tag) found nil)
  (foreach a (_bc-atts obj)
    (if (= (strcase (vla-get-TagString a)) up)
      (setq found (_bc-str (vla-get-TextString a)))
    )
  )
  found
)

(defun _bc-att-set (obj tag val / up a)
  (setq up (strcase tag))
  (foreach a (_bc-atts obj)
    (if (= (strcase (vla-get-TagString a)) up)
      (vl-catch-all-apply (quote vla-put-TextString) (list a (_bc-str val)))
    )
  )
)

(defun _bc-ss->list (ss / i n res)
  (setq res nil i 0)
  (if ss
    (progn
      (setq n (sslength ss))
      (while (< i n)
        (setq res (cons (ssname ss i) res))
        (setq i (1+ i))
      )
    )
  )
  (reverse res)
)

(defun _bc-link-ents (/ ss)
  (setq ss (ssget "X" (list (list -3 (list "BeamCAD_LINK")))))
  (_bc-ss->list ss)
)

(defun _bc-tk-ents (/ ss)
  (setq ss (ssget "X" (list (cons 0 "INSERT") (cons 2 "TK*,TenCauKien"))))
  (_bc-ss->list ss)
)

(defun _bc-sum-ents (/ ss)
  (setq ss (ssget "X" (list (list -3 (list "BeamCAD_SUM")))))
  (_bc-ss->list ss)
)

(defun _bc-is-tk-blk (bn)
  (member (strcase bn) '("TK1" "TK2" "TK3" "TK4" "TK7" "TK7R1" "TK9" "TKTUNKNOWN"))
)

(defun _bc-recalc-tk (obj / ent bn xd bname sh dk skc sl l1 l2 l3 l4 l5 mv sumL tsl lall kl)
  (setq ent (vlax-vla-object->ename obj))
  (setq bn (_bc-blk-name obj))
  (setq xd (_bc-xd-vals ent))
  (setq sh (_bc-trim (_bc-att-get obj "SH")))
  (setq dk (_bc-int (_bc-att-get obj "DK") 18))
  (setq skc (max 1 (_bc-int (_bc-att-get obj "SKC") 1)))
  (setq sl (max 0 (_bc-int (_bc-att-get obj "SL") 1)))
  (setq l1 (_bc-int (_bc-att-get obj (if (= bn "TK1") "L" "L1")) 0))
  (setq l2 (_bc-int (_bc-att-get obj "L2") 0))
  (setq l3 (_bc-int (_bc-att-get obj "L3") 0))
  (setq l4 (_bc-int (_bc-att-get obj "L4") 0))
  (setq l5 (_bc-int (_bc-att-get obj "L5") 0))
  (setq mv (_bc-int (_bc-att-get obj "M") 0))
  (setq sumL (_bc-int (_bc-att-get obj "sumL") 0))
  (cond
    ((and (= bn "TK1") (> l1 0)) (setq sumL l1))
    ((and (member bn '("TK2" "TK3")) (> (+ l1 l2) 0)) (setq sumL (+ l1 l2)))
    ((and (member bn '("TK4" "TK7")) (> (+ l1 l2 l3) 0)) (setq sumL (+ l1 l2 l3)))
    ((and (= bn "TK7R1") (> (+ l1 l2 l3 l4 l5) 0)) (setq sumL (+ l1 l2 l3 l4 l5)))
    ((and (= bn "TK9") (> (+ l1 l2) 0)) (setq sumL (+ (* 2 (+ l1 l2)) (* 2 mv))))
  )
  (setq tsl (* skc sl))
  (setq lall (* (/ (float sumL) 1000.0) (float tsl)))
  (setq lall (/ (float (fix (+ (* lall 100.0) 0.5))) 100.0))
  (setq kl (* lall (_bc-unitw dk)))
  (setq kl (/ (float (fix (+ (* kl 100.0) 0.5))) 100.0))
  (_bc-att-set obj "sumL" (itoa sumL))
  (_bc-att-set obj "SKC" (itoa skc))
  (_bc-att-set obj "SL" (itoa sl))
  (_bc-att-set obj "TSL" (itoa tsl))
  (_bc-att-set obj "Lall" (rtos lall 2 2))
  (_bc-att-set obj "KL" (rtos kl 2 2))
  (setq bname (if (and xd (>= (length xd) 2)) (_bc-str (nth 1 xd)) "DAM"))
  (_bc-set-link ent (list "TK_ROW" bname sh sl dk skc))
  (list dk lall kl skc sl sh bname)
)

(defun _bc-add-diam-tot (totals dk lall kl / prev)
  (setq prev (assoc dk totals))
  (if prev
    (subst (list dk (+ (cadr prev) lall) (+ (caddr prev) kl)) prev totals)
    (cons (list dk lall kl) totals)
  )
)

(defun _bc-ensure-sum-styles (doc / lyrs lyr stys sty)
  (setq lyrs (vla-get-Layers doc))
  (foreach lnm '("DCE_Lanh_To" "Dce_text")
    (if (vl-catch-all-error-p (vl-catch-all-apply (quote vla-Item) (list lyrs lnm)))
      (progn
        (setq lyr (vl-catch-all-apply (quote vla-Add) (list lyrs lnm)))
        (if (not (vl-catch-all-error-p lyr))
          (vl-catch-all-apply (quote vla-put-Color) (list lyr (if (= lnm "DCE_Lanh_To") 3 7)))
        )
      )
    )
  )
  (setq stys (vla-get-TextStyles doc))
  (if (vl-catch-all-error-p (vl-catch-all-apply (quote vla-Item) (list stys "Dce_Text2")))
    (progn
      (setq sty (vl-catch-all-apply (quote vla-Add) (list stys "Dce_Text2")))
      (if (not (vl-catch-all-error-p sty))
        (vl-catch-all-apply (quote vla-SetFont) (list sty "Arial" :vlax-false :vlax-false 0 0))
      )
    )
  )
)

(defun _bc-add-line (spc x1 y1 x2 y2 lyr / ln ent)
  (setq ln (vla-AddLine spc (vlax-3d-point (list x1 y1 0.0)) (vlax-3d-point (list x2 y2 0.0))))
  (vla-put-Layer ln lyr)
  (vla-put-Color ln 256)
  (setq ent (vlax-vla-object->ename ln))
  (_bc-xd-set ent "BeamCAD_SUM" (list (cons 1000 "1")))
  ln
)

(defun _bc-add-rect (spc x0 y0 x1 y1 lyr / arr pl ent)
  (setq arr (vlax-make-safearray vlax-vbDouble '(0 . 7)))
  (vlax-safearray-fill arr (list x0 y0 x1 y0 x1 y1 x0 y1))
  (setq pl (vla-AddLightWeightPolyline spc arr))
  (vla-put-Closed pl :vlax-true)
  (vla-put-Layer pl lyr)
  (vla-put-Color pl 256)
  (setq ent (vlax-vla-object->ename pl))
  (_bc-xd-set ent "BeamCAD_SUM" (list (cons 1000 "1")))
  pl
)

(defun _bc-add-text (spc x y h txt lyr ha va / to ent align)
  (setq to (vla-AddText spc (_bc-str txt) (vlax-3d-point (list x y 0.0)) (float h)))
  (vla-put-Layer to lyr)
  (vla-put-Color to 256)
  (vl-catch-all-apply (quote vla-put-StyleName) (list to "Dce_Text2"))
  (vl-catch-all-apply (quote vla-put-ScaleFactor) (list to 1.0))
  (if (or (/= ha 0) (/= va 0))
    (progn
      (setq align
        (cond
          ((and (= ha 1) (= va 2)) acAlignmentMiddleCenter)
          ((and (= ha 4) (= va 2)) acAlignmentMiddleCenter)
          ((and (= ha 0) (= va 2)) acAlignmentMiddleLeft)
          (t acAlignmentMiddleLeft)
        )
      )
      (vl-catch-all-apply (quote vla-put-Alignment) (list to align))
      (vl-catch-all-apply (quote vla-put-TextAlignmentPoint) (list to (vlax-3d-point (list x y 0.0))))
    )
  )
  (setq ent (vlax-vla-object->ename to))
  (_bc-xd-set ent "BeamCAD_SUM" (list (cons 1000 "1")))
  to
)

(defun _bc-recalc-drawing (ss-filter / doc spc ents tk-list tc-list sum-ents
                           e obj bn pt ix iy info dk lall kl totals min-x col0-bot
                           max-bot row-h best-tc best-dy tc skc xd-tc prev-skc skc-tc
                           dks sy y0 r ci lx k w-le10 w-mid w-gt18 grand totw cx0
                           row-top row-bot ym glbl gval is-tot cnt-rows old-txt y-t
                           lbl-title lbl-d lbl-l lbl-k lbl-11 lbl-g1 lbl-g2 lbl-g3 lbl-gt
                           sum-sc tk-sc sum-x0 sum-y0 pmin pmax bv-min bv-max)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq spc (vla-get-ModelSpace doc))
  (setq ents (if ss-filter (_bc-ss->list ss-filter) (_bc-tk-ents)))
  (setq tk-list nil tc-list nil sum-ents nil sum-sc 1.0)
  (setq lbl-title "TONG HOP COT THEP"
        lbl-d "- Duong kinh (mm):"
        lbl-l "- Chieu dai (m):"
        lbl-k "- Khoi luong (kg):"
        lbl-11 "- Chieu dai / 11.7"
        lbl-g1 "- Nhom %%c <= 10:"
        lbl-g2 "- Nhom 10 < %%c <= 18:"
        lbl-g3 "- Nhom %%c > 18:"
        lbl-gt "- Tong cong:")
  (foreach e ents
    (setq obj (vlax-ename->vla-object e))
    (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
      (progn
        (setq bn (_bc-blk-name obj))
        (cond
          ((_bc-is-tk-blk bn)
            (setq pt (vlax-safearray->list (vlax-variant-value (vla-get-InsertionPoint obj))))
            (setq tk-list (cons (list obj e bn (car pt) (cadr pt)) tk-list))
            (setq tk-sc (vl-catch-all-apply (quote vla-get-XScaleFactor) (list obj)))
            (if (and (not (vl-catch-all-error-p tk-sc)) (> tk-sc 0.01))
              (setq sum-sc (/ (float tk-sc) 50.0))
            )
          )
          ((= bn "TENCAUKIEN")
            (setq pt (vlax-safearray->list (vlax-variant-value (vla-get-InsertionPoint obj))))
            (setq xd-tc (_bc-xd-get e "BeamCAD_SKC"))
            (setq prev-skc (if xd-tc (_bc-int (cdr (car xd-tc)) 0) 0))
            (setq tc-list (cons (list obj e (car pt) (cadr pt) prev-skc) tc-list))
          )
        )
      )
    )
  )
  ;; Use actual owner space of TK blocks
  (if tk-list
    (progn
      (setq obj (vl-catch-all-apply (quote vla-ObjectIDToObject) (list doc (vla-get-OwnerID (nth 0 (car tk-list))))))
      (if (and obj (not (vl-catch-all-error-p obj)))
        (setq spc obj)
      )
    )
  )
  ;; Fast XDATA-only scan of existing BeamCAD_SUM entities + remember anchor (sum-x0, sum-y0)
  (setq sum-x0 nil sum-y0 nil)
  (foreach e (_bc-sum-ents)
    (setq obj (vlax-ename->vla-object e))
    (if (not (vl-catch-all-error-p (vl-catch-all-apply (quote vla-GetBoundingBox) (list obj (quote bv-min) (quote bv-max)))))
      (progn
        (setq pmin (vlax-safearray->list bv-min) pmax (vlax-safearray->list bv-max))
        (if (and (> (- (car pmax) (car pmin)) (* 1000.0 sum-sc)) (< (cadr pmax) 1e11))
          (progn
            (if (or (null sum-x0) (< (car pmin) sum-x0)) (setq sum-x0 (car pmin)))
            (if (or (null sum-y0) (> (cadr pmax) sum-y0)) (setq sum-y0 (cadr pmax)))
          )
        )
      )
    )
    (if (= (vla-get-ObjectName obj) "AcDbText")
      (progn
        (setq old-txt (_bc-str (vla-get-TextString obj)))
        (cond
          ((or (vl-string-search "C\\U+1ED0T TH\\U+00C9P" (strcase old-txt)) (vl-string-search "COT THEP" (strcase old-txt))) (setq lbl-title old-txt))
          ((vl-string-search "(mm):" old-txt) (setq lbl-d old-txt))
          ((vl-string-search "(m):" old-txt) (setq lbl-l old-txt))
          ((vl-string-search "(kg):" old-txt) (setq lbl-k old-txt))
          ((vl-string-search "11.7" old-txt) (setq lbl-11 old-txt))
          ((vl-string-search "<= 10:" old-txt) (setq lbl-g1 old-txt))
          ((vl-string-search "<= 18:" old-txt) (setq lbl-g2 old-txt))
          ((vl-string-search "> 18:" old-txt) (setq lbl-g3 old-txt))
          ((or (vl-string-search "c\\U+1ED9ng:" old-txt) (vl-string-search "cong:" old-txt)) (setq lbl-gt old-txt))
        )
      )
    )
    (setq sum-ents (cons obj sum-ents))
  )
  (if (null tk-list)
    (list 0 0.0)
    (progn
      (foreach item tk-list
        (setq obj (nth 0 item) e (nth 1 item) bn (nth 2 item) ix (nth 3 item) iy (nth 4 item))
        (setq best-tc nil best-dy 1e12)
        (foreach tc tc-list
          (if (< (abs (- (nth 2 tc) (+ ix (* 375.0 sum-sc)))) (* 1500.0 sum-sc))
            (progn
              (setq y-t (abs (- (nth 3 tc) iy)))
              (if (< y-t best-dy)
                (setq best-dy y-t best-tc tc)
              )
            )
          )
        )
        (if best-tc
          (progn
            (setq skc-tc (_bc-int (_bc-att-get (nth 0 best-tc) "SOCAUKIEN") 0))
            (setq prev-skc (nth 4 best-tc))
            (setq skc (_bc-int (_bc-att-get obj "SKC") 0))
            (if (and (> skc-tc 0) (> prev-skc 0) (/= skc-tc prev-skc) (= skc prev-skc))
              (_bc-att-set obj "SKC" (itoa skc-tc))
            )
          )
        )
      )
      (foreach tc tc-list
        (setq skc-tc (_bc-int (_bc-att-get (nth 0 tc) "SOCAUKIEN") 0))
        (if (> skc-tc 0)
          (_bc-xd-set (nth 1 tc) "BeamCAD_SKC" (list (cons 1000 (itoa skc-tc))))
        )
      )
      (setq min-x 1e12)
      (foreach item tk-list
        (if (< (nth 3 item) min-x) (setq min-x (nth 3 item)))
      )
      (setq col0-bot 1e12 max-bot 1e12 totals nil cnt-rows 0)
      (foreach item tk-list
        (setq obj (nth 0 item) bn (nth 2 item) ix (nth 3 item) iy (nth 4 item))
        (setq row-h (* (if (= bn "TKTUNKNOWN") 675.0 400.0) sum-sc))
        (setq info (_bc-recalc-tk obj))
        (setq dk (nth 0 info) lall (nth 1 info) kl (nth 2 info))
        (setq totals (_bc-add-diam-tot totals dk lall kl))
        (setq cnt-rows (1+ cnt-rows))
        (if (< (- iy row-h) max-bot) (setq max-bot (- iy row-h)))
        (if (< (abs (- ix min-x)) (* 1000.0 sum-sc))
          (if (< (- iy row-h) col0-bot) (setq col0-bot (- iy row-h)))
        )
      )
      (if (> col0-bot 1e11) (setq col0-bot max-bot))
      (foreach obj sum-ents
        (if (or (null ss-filter)
                (and (not (vlax-erased-p obj))
                     (progn
                       (setq e (vlax-vla-object->ename obj))
                       (or (ssmemb e ss-filter)
                           (and (setq pt (assoc 10 (entget e)))
                                (>= (cadr pt) (- min-x (* 500.0 sum-sc)))
                                (<= (cadr pt) (+ min-x (* 18000.0 sum-sc)))
                                (<= (caddr pt) (+ col0-bot (* 500.0 sum-sc))))
                       )
                     )
                )
            )
          (vl-catch-all-apply (quote vla-Delete) (list obj))
        )
      )
      (if totals
        (progn
          (_bc-ensure-sum-styles doc)
          (setq dks (vl-sort (mapcar (quote car) totals) (quote <)))
          (if (and sum-x0 sum-y0)
            (setq min-x sum-x0 sy sum-y0)
            (setq sy col0-bot)
          )
          (setq totw (* (+ 1900.0 (* (max 2 (length dks)) 1100.0)) sum-sc))
          (_bc-add-rect spc min-x sy (+ min-x totw) (- sy (* 600.0 sum-sc)) "DCE_Lanh_To")
          (_bc-add-text spc (+ min-x (/ totw 2.0)) (- sy (* 300.0 sum-sc)) (* 150.0 sum-sc) lbl-title "Dce_text" 1 2)
          (setq y0 (- sy (* 600.0 sum-sc)) r 0)
          (while (< r 5)
            (_bc-add-line spc min-x (- y0 (* r 400.0 sum-sc)) (+ min-x totw) (- y0 (* r 400.0 sum-sc)) "DCE_Lanh_To")
            (setq r (1+ r))
          )
          (_bc-add-line spc min-x y0 min-x (- y0 (* 1600.0 sum-sc)) "DCE_Lanh_To")
          (_bc-add-line spc (+ min-x (* 1900.0 sum-sc)) y0 (+ min-x (* 1900.0 sum-sc)) (- y0 (* 1600.0 sum-sc)) "DCE_Lanh_To")
          (_bc-add-text spc (+ min-x (* 100.0 sum-sc)) (- y0 (* 200.0 sum-sc)) (* 100.0 sum-sc) lbl-d "Dce_text" 0 2)
          (_bc-add-text spc (+ min-x (* 100.0 sum-sc)) (- y0 (* 600.0 sum-sc)) (* 100.0 sum-sc) lbl-l "Dce_text" 0 2)
          (_bc-add-text spc (+ min-x (* 100.0 sum-sc)) (- y0 (* 1000.0 sum-sc)) (* 100.0 sum-sc) lbl-k "Dce_text" 0 2)
          (_bc-add-text spc (+ min-x (* 100.0 sum-sc)) (- y0 (* 1400.0 sum-sc)) (* 100.0 sum-sc) lbl-11 "Dce_text" 0 2)
          (setq w-le10 0.0 w-mid 0.0 w-gt18 0.0 ci 0)
          (foreach dk dks
            (setq prev (assoc dk totals))
            (setq lx (cadr prev) k (caddr prev))
            (cond
              ((<= dk 10) (setq w-le10 (+ w-le10 k)))
              ((<= dk 18) (setq w-mid (+ w-mid k)))
              (t (setq w-gt18 (+ w-gt18 k)))
            )
            (setq cx0 (+ min-x (* (+ 1900.0 (* ci 1100.0)) sum-sc)))
            (_bc-add-line spc (+ cx0 (* 1100.0 sum-sc)) y0 (+ cx0 (* 1100.0 sum-sc)) (- y0 (* 1600.0 sum-sc)) "DCE_Lanh_To")
            (_bc-add-text spc (+ cx0 (* 550.0 sum-sc)) (- y0 (* 200.0 sum-sc)) (* 100.0 sum-sc) (strcat "%%c" (itoa dk)) "Dce_text" 1 2)
            (_bc-add-text spc (+ cx0 (* 550.0 sum-sc)) (- y0 (* 600.0 sum-sc)) (* 100.0 sum-sc) (rtos lx 2 2) "Dce_text" 1 2)
            (_bc-add-text spc (+ cx0 (* 550.0 sum-sc)) (- y0 (* 1000.0 sum-sc)) (* 100.0 sum-sc) (rtos k 2 2) "Dce_text" 1 2)
            (_bc-add-text spc (+ cx0 (* 550.0 sum-sc)) (- y0 (* 1400.0 sum-sc)) (* 100.0 sum-sc)
              (if (> dk 10) (itoa (fix (+ (/ lx 11.7) 0.999999))) "-") "Dce_text" 1 2)
            (setq ci (1+ ci))
          )
          (setq grand (+ w-le10 w-mid w-gt18))
          (setq row-top (- y0 (* 1650.0 sum-sc)))
          (foreach grp
            (list (list lbl-g1 w-le10 nil) (list lbl-g2 w-mid nil) (list lbl-g3 w-gt18 nil) (list lbl-gt grand t))
            (setq glbl (car grp) gval (cadr grp) is-tot (caddr grp))
            (if (or (not (equal glbl lbl-g3)) (> gval 0.0))
              (progn
                (if is-tot (setq row-top (- row-top (* 400.0 sum-sc))))
                (setq row-bot (- row-top (* 400.0 sum-sc)))
                (_bc-add-rect spc min-x row-top (+ min-x totw) row-bot "DCE_Lanh_To")
                (_bc-add-line spc (+ min-x (* 1900.0 sum-sc)) row-top (+ min-x (* 1900.0 sum-sc)) row-bot "DCE_Lanh_To")
                (if (>= totw (* 3000.0 sum-sc))
                  (_bc-add-line spc (+ min-x (* 3000.0 sum-sc)) row-top (+ min-x (* 3000.0 sum-sc)) row-bot "DCE_Lanh_To")
                )
                (setq ym (/ (+ row-top row-bot) 2.0))
                (_bc-add-text spc (+ min-x (* 100.0 sum-sc)) ym (* 100.0 sum-sc) glbl "Dce_text" 0 2)
                (_bc-add-text spc (+ min-x (* 2450.0 sum-sc)) ym (* 100.0 sum-sc) (rtos gval 2 2) "Dce_text" 4 2)
                (_bc-add-text spc (+ min-x (* 3550.0 sum-sc)) ym (* 100.0 sum-sc) "kg" "Dce_text" 4 2)
                (setq row-top row-bot)
              )
            )
          )
        )
      )
      (if (null grand)
        (progn
          (setq grand 0.0)
          (foreach prev totals (setq grand (+ grand (caddr prev))))
        )
      )
      (list cnt-rows grand)
    )
  )
)

(defun _bc-lookup-skc (bname / res e xd k)
  (setq res 1)
  (foreach e (_bc-link-ents)
    (setq xd (_bc-xd-vals e))
    (if (and xd (>= (length xd) 3) (= (_bc-up (_bc-str (nth 1 xd))) (_bc-up bname)))
      (progn
        (setq k (_bc-str (nth 0 xd)))
        (cond
          ((or (= k "BEAM_TITLE") (= k "TCK")) (setq res (max 1 (_bc-int (nth 2 xd) 1))))
          ((and (= k "TK_ROW") (>= (length xd) 6)) (setq res (max 1 (_bc-int (nth 5 xd) 1))))
        )
      )
    )
  )
  res
)

(defun _bc-propagate-bar (bname old-sh new-sh new-sl new-dk / e obj bn xd k xb xsh cur-sl cur-dk cur-pos)
  (foreach e (_bc-link-ents)
    (setq xd (_bc-xd-vals e))
    (if (and xd (>= (length xd) 3))
      (progn
        (setq k (_bc-str (nth 0 xd)) xb (_bc-str (nth 1 xd)) xsh (_bc-str (nth 2 xd)))
        (if (and (= (_bc-up xb) (_bc-up bname)) (= (_bc-up xsh) (_bc-up old-sh)))
          (progn
            (setq obj (vlax-ename->vla-object e))
            (cond
              ((= k "TAG_BAR")
                (setq cur-sl (if new-sl new-sl (_bc-int (nth 3 xd) 2)))
                (setq cur-dk (if new-dk new-dk (_bc-int (nth 4 xd) 18)))
                (setq cur-pos (if (>= (length xd) 6) (_bc-str (nth 5 xd)) ""))
                (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
                  (progn
                    (_bc-att-set obj "SH" new-sh)
                    (if (member (_bc-blk-name obj) '("DCE_KHTMCTHEPCHU_L" "DCE_KHTMCTHEPCHU_R" "DCE_KHTMCTHEPCHU"))
                      (_bc-att-set obj "DKVAKC" (strcat (itoa cur-sl) "%%c" (itoa cur-dk)))
                    )
                  )
                )
                (_bc-set-link e (list "TAG_BAR" bname new-sh cur-sl cur-dk cur-pos))
              )
              ((= k "REBAR")
                (setq cur-sl (if new-sl new-sl (_bc-int (nth 3 xd) 2)))
                (setq cur-dk (if new-dk new-dk (_bc-int (nth 4 xd) 18)))
                (setq cur-pos (if (>= (length xd) 6) (_bc-str (nth 5 xd)) ""))
                (_bc-set-link e (list "REBAR" bname new-sh cur-sl cur-dk cur-pos))
              )
              ((= k "TK_ROW")
                (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
                  (progn
                    (setq bn (_bc-blk-name obj))
                    (if (and (_bc-is-tk-blk bn) (/= bn "TK9"))
                      (progn
                        (setq cur-sl (if new-sl new-sl (_bc-int (_bc-att-get obj "SL") (nth 3 xd))))
                        (setq cur-dk (if new-dk new-dk (_bc-int (_bc-att-get obj "DK") (nth 4 xd))))
                        (_bc-att-set obj "SH" new-sh)
                        (_bc-att-set obj "SL" (itoa cur-sl))
                        (_bc-att-set obj "DK" (itoa cur-dk))
                        (_bc-recalc-tk obj)
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
    )
  )
)

(defun _bc-propagate-stir (bname old-sh new-sh new-dk new-za target-old-za new-sl-override / lents e obj bn xd k xb xsh cur-dk cur-za zlen cnt-sum)
  (setq cnt-sum 0 lents (_bc-link-ents))
  (foreach e lents
    (setq xd (_bc-xd-vals e))
    (if (and xd (>= (length xd) 3))
      (progn
        (setq k (_bc-str (nth 0 xd)) xb (_bc-str (nth 1 xd)) xsh (_bc-str (nth 2 xd)))
        (if (and (= (_bc-up xb) (_bc-up bname)) (= (_bc-up xsh) (_bc-up old-sh)))
          (progn
            (setq obj (vlax-ename->vla-object e))
            (cond
              ((= k "TAG_STIR")
                (setq cur-dk (if new-dk new-dk (_bc-int (nth 3 xd) 8)))
                (setq cur-za (if (and new-za (or (null target-old-za) (= (_bc-int (nth 4 xd) 0) target-old-za))) new-za (_bc-int (nth 4 xd) 100)))
                (setq zlen (if (>= (length xd) 6) (_bc-int (nth 5 xd) 0) 0))
                (if (and (= (vla-get-ObjectName obj) "AcDbBlockReference")
                         (member (_bc-blk-name obj) '("DCE_KHTTHEPDAI" "DCE_KHTMCTHEPCHU_L"))
                         (> zlen 0) (> cur-za 0))
                  (setq cnt-sum (+ cnt-sum (max 1 (1+ (fix (/ (float zlen) (float (max 50 cur-za))))))))
                )
                (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
                  (progn
                    (_bc-att-set obj "SH" new-sh)
                    (_bc-att-set obj "DKVAKC" (strcat "%%c" (itoa cur-dk) "a" (itoa cur-za)))
                    (_bc-att-set obj "DKVAKC2" "")
                  )
                )
                (_bc-set-link e (list "TAG_STIR" bname new-sh cur-dk cur-za zlen))
              )
              ((= k "STIR_LINE")
                (setq cur-dk (if new-dk new-dk (_bc-int (nth 3 xd) 8)))
                (setq cur-za (if (and new-za (or (null target-old-za) (= (_bc-int (nth 4 xd) 0) target-old-za))) new-za (_bc-int (nth 4 xd) 100)))
                (_bc-set-link e (list "STIR_LINE" bname new-sh cur-dk cur-za))
              )
            )
          )
        )
      )
    )
  )
  (foreach e lents
    (setq xd (_bc-xd-vals e))
    (if (and xd (>= (length xd) 3))
      (progn
        (setq k (_bc-str (nth 0 xd)) xb (_bc-str (nth 1 xd)) xsh (_bc-str (nth 2 xd)))
        (if (and (= k "TK_ROW") (= (_bc-up xb) (_bc-up bname)) (= (_bc-up xsh) (_bc-up old-sh)))
          (progn
            (setq obj (vlax-ename->vla-object e))
            (if (and (= (vla-get-ObjectName obj) "AcDbBlockReference") (member (_bc-blk-name obj) '("TK9" "TK7")))
              (progn
                (_bc-att-set obj "SH" new-sh)
                (if new-dk (_bc-att-set obj "DK" (itoa new-dk)))
                (cond
                  (new-sl-override (_bc-att-set obj "SL" (itoa new-sl-override)))
                  ((and new-za (> cnt-sum 0)) (_bc-att-set obj "SL" (itoa cnt-sum)))
                )
                (_bc-recalc-tk obj)
              )
            )
          )
        )
      )
    )
  )
)

(defun _bc-propagate-member (old-bname new-bname new-skc / e obj xd k cur-skc cur-len sc-s p1 new-xd)
  (foreach e (_bc-link-ents)
    (setq xd (_bc-xd-vals e))
    (if (and xd (>= (length xd) 2) (= (_bc-up (_bc-str (nth 1 xd))) (_bc-up old-bname)))
      (progn
        (setq k (_bc-str (nth 0 xd)))
        (setq obj (vlax-ename->vla-object e))
        (cond
          ((= k "BEAM_TITLE")
            (setq cur-skc (if new-skc new-skc (_bc-int (nth 2 xd) 1)))
            (setq cur-len (if (>= (length xd) 4) (_bc-int (nth 3 xd) 0) 0))
            (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
              (_bc-att-set obj "TENDAM"
                (if (> cur-len 0)
                  (strcat "%%UDAM " new-bname " (SL=" (itoa cur-skc) "; L=" (itoa cur-len) ")")
                  (strcat "%%UDAM " new-bname " (SL=" (itoa cur-skc) ")")
                )
              )
            )
            (_bc-set-link e (list "BEAM_TITLE" new-bname cur-skc cur-len))
          )
          ((= k "MC_TITLE")
            (setq sc-s (if (>= (length xd) 3) (_bc-int (nth 2 xd) 25) 25))
            (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
              (_bc-att-set obj "TL" (strcat new-bname " (TL: 1/" (itoa sc-s) ")"))
            )
            (_bc-set-link e (list "MC_TITLE" new-bname sc-s))
          )
          ((= k "TCK")
            (setq cur-skc (if new-skc new-skc (_bc-int (nth 2 xd) 1)))
            (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
              (progn
                (_bc-att-set obj "TENCAUKIEN" new-bname)
                (_bc-att-set obj "SOCAUKIEN" (strcat "SL: " (itoa cur-skc)))
                (_bc-xd-set e "BeamCAD_SKC" (list (cons 1000 (itoa cur-skc))))
              )
            )
            (_bc-set-link e (list "TCK" new-bname cur-skc))
          )
          ((= k "TK_ROW")
            (setq cur-skc (if new-skc new-skc (if (>= (length xd) 6) (_bc-int (nth 5 xd) 1) 1)))
            (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
              (progn
                (_bc-att-set obj "SKC" (itoa cur-skc))
                (_bc-set-link e (list "TK_ROW" new-bname (nth 2 xd) (nth 3 xd) (nth 4 xd) cur-skc))
                (_bc-recalc-tk obj)
              )
            )
          )
          (t
            (setq new-xd (list k new-bname))
            (setq p1 (cddr xd))
            (foreach item p1 (setq new-xd (append new-xd (list item))))
            (_bc-set-link e new-xd)
          )
        )
      )
    )
  )
)

(defun _bc-batch-bars (ents-list filter-bname old-dk new-dk new-sl / cnt e xd k bname sh cur-sl cur-dk cur-pos obj bn)
  (setq cnt 0)
  (foreach e ents-list
    (setq xd (_bc-xd-vals e))
    (if (and xd (member (_bc-str (car xd)) '("TAG_BAR" "REBAR" "TK_ROW")))
      (progn
        (setq k (_bc-str (car xd)) bname (_bc-str (nth 1 xd)) sh (_bc-str (nth 2 xd)))
        (if (or (null filter-bname) (= (_bc-up bname) (_bc-up filter-bname)))
          (progn
            (setq obj (vlax-ename->vla-object e))
            (setq bn (if (= (vla-get-ObjectName obj) "AcDbBlockReference") (_bc-blk-name obj) ""))
            (if (/= bn "TK9")
              (progn
                (setq cur-sl (_bc-int (nth 3 xd) 2) cur-dk (_bc-int (nth 4 xd) 18))
                (if (or (null old-dk) (= cur-dk old-dk))
                  (progn
                    (setq cnt (1+ cnt))
                    (if new-sl (setq cur-sl new-sl))
                    (if new-dk (setq cur-dk new-dk))
                    (cond
                      ((= k "TAG_BAR")
                        (setq cur-pos (if (>= (length xd) 6) (_bc-str (nth 5 xd)) ""))
                        (if (and (= (vla-get-ObjectName obj) "AcDbBlockReference")
                                 (member bn '("DCE_KHTMCTHEPCHU_L" "DCE_KHTMCTHEPCHU_R" "DCE_KHTMCTHEPCHU")))
                          (_bc-att-set obj "DKVAKC" (strcat (itoa cur-sl) "%%c" (itoa cur-dk)))
                        )
                        (_bc-set-link e (list "TAG_BAR" bname sh cur-sl cur-dk cur-pos))
                      )
                      ((= k "REBAR")
                        (setq cur-pos (if (>= (length xd) 6) (_bc-str (nth 5 xd)) ""))
                        (_bc-set-link e (list "REBAR" bname sh cur-sl cur-dk cur-pos))
                      )
                      ((= k "TK_ROW")
                        (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
                          (progn
                            (_bc-att-set obj "SL" (itoa cur-sl))
                            (_bc-att-set obj "DK" (itoa cur-dk))
                            (_bc-recalc-tk obj)
                          )
                        )
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
    )
  )
  cnt
)

(defun _bc-has-stir-link (bname sh / found e xd k)
  (setq found nil)
  (foreach e (_bc-link-ents)
    (if (not found)
      (progn
        (setq xd (_bc-xd-vals e))
        (if (and xd (>= (length xd) 3)
                 (member (_bc-str (nth 0 xd)) '("TAG_STIR" "STIR_LINE"))
                 (= (_bc-up (_bc-str (nth 1 xd))) (_bc-up bname))
                 (= (_bc-up (_bc-str (nth 2 xd))) (_bc-up sh)))
          (setq found t)
        )
      )
    )
  )
  found
)

(defun _bc-batch-stirs (ents-list filter-bname old-dk new-dk new-za / cnt e xd k bname sh cur-dk cur-za zlen obj zones-map stir-keys key pair cur-sum)
  (setq cnt 0 zones-map nil stir-keys nil)
  (foreach e ents-list
    (setq xd (_bc-xd-vals e))
    (if (and xd (member (_bc-str (car xd)) '("TAG_STIR" "STIR_LINE")))
      (progn
        (setq k (_bc-str (car xd)) bname (_bc-str (nth 1 xd)) sh (_bc-str (nth 2 xd)))
        (if (or (null filter-bname) (= (_bc-up bname) (_bc-up filter-bname)))
          (progn
            (setq cur-dk (_bc-int (nth 3 xd) 8) cur-za (if (>= (length xd) 5) (_bc-int (nth 4 xd) 100) 100))
            (if (or (null old-dk) (= cur-dk old-dk))
              (progn
                (if new-dk (setq cur-dk new-dk))
                (if new-za (setq cur-za new-za))
                (setq zlen (if (>= (length xd) 6) (_bc-int (nth 5 xd) 0) 0))
                (setq key (strcat (_bc-up bname) "|" (_bc-up sh)))
                (if (not (member key stir-keys))
                  (setq stir-keys (cons key stir-keys))
                )
                (setq obj (vlax-ename->vla-object e))
                (if (= k "TAG_STIR")
                  (progn
                    (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
                      (progn
                        (_bc-att-set obj "DKVAKC" (strcat "%%c" (itoa cur-dk) "a" (itoa cur-za)))
                        (_bc-att-set obj "DKVAKC2" "")
                      )
                    )
                    (_bc-set-link e (list "TAG_STIR" bname sh cur-dk cur-za zlen))
                    (if (and (= (vla-get-ObjectName obj) "AcDbBlockReference")
                             (member (_bc-blk-name obj) '("DCE_KHTTHEPDAI" "DCE_KHTMCTHEPCHU_L"))
                             (> zlen 0) (> cur-za 0))
                      (progn
                        (setq pair (assoc key zones-map))
                        (setq cur-sum (max 1 (1+ (fix (/ (float zlen) (float (max 50 cur-za)))))))
                        (setq zones-map
                          (if pair
                            (subst (cons key (+ (cdr pair) cur-sum)) pair zones-map)
                            (cons (cons key cur-sum) zones-map)
                          )
                        )
                      )
                    )
                  )
                  (_bc-set-link e (list "STIR_LINE" bname sh cur-dk cur-za))
                )
                (setq cnt (1+ cnt))
              )
            )
          )
        )
      )
    )
  )
  (foreach e ents-list
    (setq xd (_bc-xd-vals e))
    (if (and xd (= (_bc-str (car xd)) "TK_ROW"))
      (progn
        (setq bname (_bc-str (nth 1 xd)) sh (_bc-str (nth 2 xd)))
        (if (or (null filter-bname) (= (_bc-up bname) (_bc-up filter-bname)))
          (progn
            (setq obj (vlax-ename->vla-object e))
            (setq bn (if (= (vla-get-ObjectName obj) "AcDbBlockReference") (_bc-blk-name obj) ""))
            (setq key (strcat (_bc-up bname) "|" (_bc-up sh)))
            (if (or (= bn "TK9") (and (= bn "TK7") (member key stir-keys)))
              (progn
                (if (or (null old-dk) (= (_bc-int (nth 4 xd) 8) old-dk))
                  (progn
                    (if new-dk (_bc-att-set obj "DK" (itoa new-dk)))
                    (setq pair (assoc key zones-map))
                    (if (and new-za pair (> (cdr pair) 0))
                      (_bc-att-set obj "SL" (itoa (cdr pair)))
                    )
                    (_bc-recalc-tk obj)
                    (setq cnt (1+ cnt))
                  )
                )
              )
            )
          )
        )
      )
    )
  )
  cnt
)

(defun _bc-extract-pick-info (ent / obj bn xd parsed)
  (setq obj (vlax-ename->vla-object ent))
  (setq xd (_bc-xd-vals ent))
  (if (and (null xd) (= (vla-get-ObjectName obj) "AcDbBlockReference"))
    (progn
      (setq bn (_bc-blk-name obj))
      (cond
        ((= bn "DCE_KHTTHEPDAI")
          (setq parsed (_bc-parse-spec (_bc-att-get obj "DKVAKC")))
          (setq xd (list "TAG_STIR" "DAM" (_bc-att-get obj "SH") (if parsed (caddr parsed) 8) (if parsed (cadddr parsed) 100) 0))
        )
        ((member bn '("DCE_KHTMCTHEPCHU_L" "DCE_KHTMCTHEPCHU_R" "DCE_KHTMCTHEPCHU"))
          (setq parsed (_bc-parse-spec (_bc-att-get obj "DKVAKC")))
          (if (and parsed (= (car parsed) "STIR"))
            (setq xd (list "TAG_STIR" "DAM" (_bc-att-get obj "SH") (caddr parsed) (cadddr parsed) 0))
            (setq xd (list "TAG_BAR" "DAM" (_bc-att-get obj "SH") (if parsed (cadr parsed) 2) (if parsed (caddr parsed) 18) ""))
          )
        )
        ((_bc-is-tk-blk bn)
          (setq xd (list "TK_ROW" "DAM" (_bc-att-get obj "SH")
                         (_bc-int (_bc-att-get obj "SL") 1) (_bc-int (_bc-att-get obj "DK") 18)
                         (_bc-int (_bc-att-get obj "SKC") 1)))
        )
        ((= bn "TENCAUKIEN")
          (setq xd (list "TCK" (_bc-att-get obj "TENCAUKIEN") (_bc-int (_bc-att-get obj "SOCAUKIEN") 1)))
        )
      )
    )
  )
  xd
)

(defun c:DAM_QTK (/ doc ss res)
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (princ "\\n[BeamCAD] DAM_QTK - Quet & cap nhat bang thong ke (Enter = Toan bo ban ve):")
  (setq ss (ssget))
  (vla-StartUndoMark doc)
  (setq res (_bc-recalc-drawing ss))
  (vla-EndUndoMark doc)
  (vl-catch-all-apply (quote vla-Regen) (list doc acAllViewports))
  (if (and res (> (car res) 0))
    (princ (strcat "\\n[BeamCAD] DAM_QTK xong: " (itoa (car res)) " dong | Tong KL = " (rtos (cadr res) 2 2) " kg"))
    (princ "\\n[BeamCAD] Khong tim thay block TK1..TK9 nao.")
  )
  (princ)
)

(defun c:DAM_SUA (/ doc ent obj xd k bname skc sh sl dk za is-stir is-title dcl-file dcl-id rc
                    v-bname v-skc v-sh v-sl v-dk v-za v-mode new-bname new-skc new-sh new-sl new-dk new-za res lents)
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq ent (car (entsel "\\n[BeamCAD] DAM_SUA - Pick thanh thep / tag / dai / dong TK / ten dam: ")))
  (if (null ent) (progn (princ "\\n[BeamCAD] Da huy.") (exit)))
  (setq obj (vlax-ename->vla-object ent))
  (setq xd (_bc-extract-pick-info ent))
  (if (null xd)
    (princ "\\n[BeamCAD] Doi tuong nay chua co lien ket BeamCAD_LINK.")
    (progn
      (setq k (_bc-str (nth 0 xd)) bname (_bc-str (nth 1 xd)))
      (setq skc (_bc-lookup-skc bname))
      (setq is-title (member k '("BEAM_TITLE" "TCK" "MC_TITLE")))
      (setq is-stir (or (member k '("TAG_STIR" "STIR_LINE"))
                        (and (= k "TK_ROW")
                             (= (vla-get-ObjectName obj) "AcDbBlockReference")
                             (or (= (_bc-blk-name obj) "TK9")
                                 (and (= (_bc-blk-name obj) "TK7")
                                      (_bc-has-stir-link bname (_bc-str (nth 2 xd))))))))
      (setq sh "" sl 2 dk 18 za 100)
      (cond
        (is-title
          (if (>= (length xd) 3) (setq skc (max 1 (_bc-int (nth 2 xd) skc))))
        )
        (is-stir
          (setq sh (_bc-str (nth 2 xd)) dk (_bc-int (nth 3 xd) 8))
          (if (= k "TK_ROW")
            (progn
              (setq sl (_bc-int (_bc-att-get obj "SL") (_bc-int (nth 3 xd) 10)))
              (setq dk (_bc-int (_bc-att-get obj "DK") (_bc-int (nth 4 xd) 8)))
              (setq za 100)
            )
            (setq za (if (>= (length xd) 5) (_bc-int (nth 4 xd) 100) 100))
          )
        )
        (t
          (setq sh (_bc-str (nth 2 xd)) sl (_bc-int (nth 3 xd) 2) dk (_bc-int (nth 4 xd) 18))
          (if (and (= k "TK_ROW") (>= (length xd) 6))
            (setq skc (max 1 (_bc-int (nth 5 xd) skc)))
          )
        )
      )

      (setq dcl-file (_bc-ensure-dcl) dcl-id (load_dialog dcl-file))
      (if (and (> dcl-id 0) (new_dialog "dam_edit_dlg" dcl-id))
        (progn
          (set_tile "e_bname" bname)
          (set_tile "e_skc" (itoa skc))
          (cond
            (is-title
              (set_tile "t_kind" "Loai: Ten cau kien / Ten dam")
              (mode_tile "e_sh" 1) (mode_tile "e_sl" 1) (mode_tile "e_dk" 1) (mode_tile "e_za" 1)
              (mode_tile "r_beam_dk" 1) (mode_tile "r_all_dk" 1)
            )
            (is-stir
              (set_tile "t_kind" (strcat "Loai: Thep dai / Dai C (SH=" sh ")"))
              (set_tile "e_sh" sh) (set_tile "e_dk" (itoa dk)) (set_tile "e_za" (itoa za))
              (set_tile "e_sl" (if (= k "TK_ROW") (itoa sl) "(tu tinh)"))
              (if (/= k "TK_ROW") (mode_tile "e_sl" 1))
            )
            (t
              (set_tile "t_kind" (strcat "Loai: Thep chu (" (if (>= (length xd) 6) (_bc-str (nth 5 xd)) "doc") ")"))
              (set_tile "e_sh" sh) (set_tile "e_sl" (itoa sl)) (set_tile "e_dk" (itoa dk))
              (mode_tile "e_za" 1)
            )
          )
          (setq v-mode "ONE")
          (action_tile "accept"
            "(setq v-bname (get_tile \\"e_bname\\")
                   v-skc   (get_tile \\"e_skc\\")
                   v-sh    (get_tile \\"e_sh\\")
                   v-sl    (get_tile \\"e_sl\\")
                   v-dk    (get_tile \\"e_dk\\")
                   v-za    (get_tile \\"e_za\\")
                   v-mode  (cond ((= (get_tile \\"r_beam_dk\\") \\"1\\") \\"BEAM_DK\\")
                                 ((= (get_tile \\"r_all_dk\\")  \\"1\\") \\"ALL_DK\\")
                                 (t \\"ONE\\")))
             (done_dialog 1)")
          (action_tile "b_qtk" "(done_dialog 2)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq rc (start_dialog))
          (unload_dialog dcl-id)
          (cond
            ((= rc 2)
              (vla-StartUndoMark doc)
              (setq res (_bc-recalc-drawing nil))
              (vla-EndUndoMark doc)
              (vl-catch-all-apply (quote vla-Regen) (list doc acAllViewports))
              (princ (strcat "\\n[BeamCAD] Da quet TK: " (itoa (car res)) " dong | Tong KL = " (rtos (cadr res) 2 2) " kg"))
            )
            ((= rc 1)
              (vla-StartUndoMark doc)
              (setq new-bname (if (= (_bc-trim v-bname) "") bname (_bc-trim v-bname)))
              (setq new-skc (max 1 (_bc-int v-skc skc)))
              (if (or (/= new-bname bname) (/= new-skc skc))
                (progn
                  (_bc-propagate-member bname new-bname new-skc)
                  (setq bname new-bname)
                )
              )
              (if (not is-title)
                (progn
                  (setq new-sh (if (= (_bc-trim v-sh) "") sh (_bc-trim v-sh)))
                  (setq new-dk (_bc-int v-dk dk))
                  (setq new-sl (_bc-int v-sl sl))
                  (setq new-za (_bc-int v-za za))
                  (cond
                    ((= v-mode "ONE")
                      (if is-stir
                        (_bc-propagate-stir bname sh new-sh new-dk new-za
                          (if (= k "TK_ROW") nil za)
                          (if (= k "TK_ROW") new-sl nil))
                        (_bc-propagate-bar bname sh new-sh new-sl new-dk)
                      )
                    )
                    (t
                      (setq lents (_bc-link-ents))
                      (if is-stir
                        (_bc-batch-stirs lents (if (= v-mode "BEAM_DK") bname nil) dk new-dk new-za)
                        (_bc-batch-bars lents (if (= v-mode "BEAM_DK") bname nil) dk new-dk (if (/= new-sl sl) new-sl nil))
                      )
                    )
                  )
                )
              )
              (setq res (_bc-recalc-drawing nil))
              (vla-EndUndoMark doc)
              (vl-catch-all-apply (quote vla-Regen) (list doc acAllViewports))
              (princ (strcat "\\n[BeamCAD] DAM_SUA xong! Tong KL = " (rtos (cadr res) 2 2) " kg"))
            )
          )
        )
        (princ "\\n[BeamCAD] Khong mo duoc hop thoai DCL.")
      )
    )
  )
  (princ)
)

(defun c:DAM_THEP (/ doc dcl-file dcl-id rc v-old-dk v-new-dk v-new-sl v-scope ss ents cnt res)
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq dcl-file (_bc-ensure-dcl) dcl-id (load_dialog dcl-file))
  (if (and (> dcl-id 0) (new_dialog "dam_batch_dlg" dcl-id))
    (progn
      (set_tile "b_title" "Doi hang loat THEP CHU (DK / SL)")
      (mode_tile "b_new_za" 1)
      (action_tile "accept"
        "(setq v-old-dk (get_tile \\"b_old_dk\\")
               v-new-dk (get_tile \\"b_new_dk\\")
               v-new-sl (get_tile \\"b_new_sl\\")
               v-scope  (if (= (get_tile \\"br_pick\\") \\"1\\") \\"PICK\\" \\"ALL\\"))
         (done_dialog 1)")
      (action_tile "cancel" "(done_dialog 0)")
      (setq rc (start_dialog))
      (unload_dialog dcl-id)
      (if (= rc 1)
        (progn
          (setq ents (if (= v-scope "PICK") (_bc-ss->list (ssget)) (_bc-link-ents)))
          (vla-StartUndoMark doc)
          (setq cnt (_bc-batch-bars ents nil
                      (if (= (_bc-trim v-old-dk) "") nil (_bc-int v-old-dk 0))
                      (if (= (_bc-trim v-new-dk) "") nil (_bc-int v-new-dk 18))
                      (if (= (_bc-trim v-new-sl) "") nil (_bc-int v-new-sl 2))))
          (setq res (_bc-recalc-drawing nil))
          (vla-EndUndoMark doc)
          (vl-catch-all-apply (quote vla-Regen) (list doc acAllViewports))
          (princ (strcat "\\n[BeamCAD] DAM_THEP xong (" (itoa cnt) " doi tuong) | Tong KL = " (rtos (cadr res) 2 2) " kg"))
        )
      )
    )
  )
  (princ)
)

(defun c:DAM_DAI (/ doc dcl-file dcl-id rc v-old-dk v-new-dk v-new-za v-scope ss ents cnt res)
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq dcl-file (_bc-ensure-dcl) dcl-id (load_dialog dcl-file))
  (if (and (> dcl-id 0) (new_dialog "dam_batch_dlg" dcl-id))
    (progn
      (set_tile "b_title" "Doi hang loat THEP DAI (DK / Buoc dai a)")
      (mode_tile "b_new_sl" 1)
      (action_tile "accept"
        "(setq v-old-dk (get_tile \\"b_old_dk\\")
               v-new-dk (get_tile \\"b_new_dk\\")
               v-new-za (get_tile \\"b_new_za\\")
               v-scope  (if (= (get_tile \\"br_pick\\") \\"1\\") \\"PICK\\" \\"ALL\\"))
         (done_dialog 1)")
      (action_tile "cancel" "(done_dialog 0)")
      (setq rc (start_dialog))
      (unload_dialog dcl-id)
      (if (= rc 1)
        (progn
          (setq ents (if (= v-scope "PICK") (_bc-ss->list (ssget)) (_bc-link-ents)))
          (vla-StartUndoMark doc)
          (setq cnt (_bc-batch-stirs ents nil
                      (if (= (_bc-trim v-old-dk) "") nil (_bc-int v-old-dk 0))
                      (if (= (_bc-trim v-new-dk) "") nil (_bc-int v-new-dk 8))
                      (if (= (_bc-trim v-new-za) "") nil (_bc-int v-new-za 100))))
          (setq res (_bc-recalc-drawing nil))
          (vla-EndUndoMark doc)
          (vl-catch-all-apply (quote vla-Regen) (list doc acAllViewports))
          (princ (strcat "\\n[BeamCAD] DAM_DAI xong (" (itoa cnt) " doi tuong) | Tong KL = " (rtos (cadr res) 2 2) " kg"))
        )
      )
    )
  )
  (princ)
)

(defun c:DAM_TEN (/ doc ent xd bname cur-skc dcl-file dcl-id rc v-bname v-skc new-nm new-skc res)
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq ent (car (entsel "\\n[BeamCAD] DAM_TEN - Pick doi tuong bat ky thuoc dam de doi Ten & SKC: ")))
  (if (and ent (setq xd (_bc-extract-pick-info ent)) (>= (length xd) 2))
    (progn
      (setq bname (_bc-str (nth 1 xd)) cur-skc (_bc-lookup-skc bname))
      (setq dcl-file (_bc-ensure-dcl) dcl-id (load_dialog dcl-file))
      (if (and (> dcl-id 0) (new_dialog "dam_edit_dlg" dcl-id))
        (progn
          (set_tile "e_bname" bname)
          (set_tile "e_skc" (itoa cur-skc))
          (set_tile "t_kind" "Loai: Doi Ten cau kien & SKC toan bo dam")
          (mode_tile "e_sh" 1) (mode_tile "e_sl" 1) (mode_tile "e_dk" 1) (mode_tile "e_za" 1)
          (mode_tile "r_beam_dk" 1) (mode_tile "r_all_dk" 1)
          (action_tile "accept"
            "(setq v-bname (get_tile \\"e_bname\\") v-skc (get_tile \\"e_skc\\")) (done_dialog 1)")
          (action_tile "b_qtk" "(done_dialog 2)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq rc (start_dialog))
          (unload_dialog dcl-id)
          (cond
            ((= rc 1)
              (setq new-nm (if (= (_bc-trim v-bname) "") bname (_bc-trim v-bname)))
              (setq new-skc (max 1 (_bc-int v-skc cur-skc)))
              (vla-StartUndoMark doc)
              (_bc-propagate-member bname new-nm new-skc)
              (setq res (_bc-recalc-drawing nil))
              (vla-EndUndoMark doc)
              (vl-catch-all-apply (quote vla-Regen) (list doc acAllViewports))
              (princ (strcat "\\n[BeamCAD] Da doi ten -> " new-nm " (SKC=" (itoa new-skc) ")!"))
            )
            ((= rc 2)
              (c:DAM_QTK)
            )
          )
        )
      )
    )
    (princ "\\n[BeamCAD] Chua chon doi tuong BeamCAD hop le.")
  )
  (princ)
)

(defun _bc-json-esc (s / i n ch out)
  (setq s (_bc-str s) n (strlen s) i 1 out "")
  (while (<= i n)
    (setq ch (substr s i 1))
    (cond
      ((= ch "\\\\") (setq out (strcat out "\\\\\\\\")))
      ((= ch "\\"") (setq out (strcat out "\\\\\\"")))
      ((= ch "\\n") (setq out (strcat out "\\\\n")))
      ((= ch "\\r") (setq out (strcat out "")))
      ((= ch "\\t") (setq out (strcat out " ")))
      (t (setq out (strcat out ch)))
    )
    (setq i (1+ i))
  )
  out
)

(defun _bc-scan-to-file (out-path / ss ents e xd xd-m meta-raw bars-json stirs-json dims-json
                                    bname skc k sh sl dk za obj bn meas mlist tmp-p fp first-f)
  (princ "\\n[BeamCAD] Quet chon dam da trien khai (bao gom Ten dam, thep, kich thuoc) roi Enter: ")
  (setq ss (ssget))
  (if (null ss)
    (progn (princ "\\n[BeamCAD] Da huy quet.") nil)
    (progn
      (setq ents (_bc-ss->list ss))
      (setq meta-raw "" bname "" skc 0 bars-json "" stirs-json "" dims-json "" first-f t)
      (foreach e ents
        (setq xd-m (_bc-xd-get e "BeamCAD_META"))
        (if (and xd-m (= meta-raw ""))
          (foreach pair xd-m
            (setq meta-raw (strcat meta-raw (_bc-str (cdr pair))))
          )
        )
        (setq xd (_bc-xd-vals e))
        (if xd
          (progn
            (setq k (_bc-str (nth 0 xd)))
            (cond
              ((member k '("BEAM_TITLE" "TCK" "MC_TITLE"))
                (if (= bname "") (setq bname (_bc-str (nth 1 xd))))
                (if (and (= k "BEAM_TITLE") (>= (length xd) 3)) (setq skc (max skc (_bc-int (nth 2 xd) 1))))
              )
              ((= k "TAG_BAR")
                (setq bname (if (= bname "") (_bc-str (nth 1 xd)) bname))
                (setq sh (_bc-str (nth 2 xd)) sl (_bc-int (nth 3 xd) 2) dk (_bc-int (nth 4 xd) 18))
                (setq bars-json (strcat bars-json (if (= bars-json "") "" ",")
                  "{\\"sh\\":\\"" (_bc-json-esc sh) "\\",\\"sl\\":" (itoa sl) ",\\"dk\\":" (itoa dk) "}"))
              )
              ((= k "TAG_STIR")
                (setq bname (if (= bname "") (_bc-str (nth 1 xd)) bname))
                (setq sh (_bc-str (nth 2 xd)) dk (_bc-int (nth 3 xd) 8) za (if (>= (length xd) 5) (_bc-int (nth 4 xd) 100) 100))
                (setq stirs-json (strcat stirs-json (if (= stirs-json "") "" ",")
                  "{\\"sh\\":\\"" (_bc-json-esc sh) "\\",\\"dk\\":" (itoa dk) ",\\"a\\":" (itoa za) "}"))
              )
            )
          )
        )
        (setq obj (vlax-ename->vla-object e))
        (if (wcmatch (strcase (_bc-str (vla-get-ObjectName obj))) "*DIMENSION*")
          (progn
            (setq meas (vl-catch-all-apply (quote vla-get-Measurement) (list obj)))
            (if (and meas (not (vl-catch-all-error-p meas)) (> meas 1.0))
              (setq dims-json (strcat dims-json (if (= dims-json "") "" ",") (rtos meas 2 1)))
            )
          )
        )
      )
      ;; If user did not catch Dce_KhTenDam / Dce_KhMatCat in selection, search drawing for matching bname BeamCAD_META
      (if (and (= meta-raw "") (/= bname ""))
        (foreach e (_bc-link-ents)
          (if (= meta-raw "")
            (progn
              (setq xd (_bc-xd-vals e))
              (if (and xd (>= (length xd) 2) (member (_bc-str (nth 0 xd)) '("BEAM_TITLE" "MC_TITLE"))
                       (= (_bc-up (_bc-str (nth 1 xd))) (_bc-up bname)))
                (progn
                  (setq xd-m (_bc-xd-get e "BeamCAD_META"))
                  (if xd-m (foreach pair xd-m (setq meta-raw (strcat meta-raw (_bc-str (cdr pair))))))
                )
              )
            )
          )
        )
      )
      (setq tmp-p (strcat out-path ".tmp"))
      (if (setq fp (open tmp-p "w"))
        (progn
          (write-line (strcat
            "{\\"ok\\":true"
            ",\\"bname\\":\\"" (_bc-json-esc bname) "\\""
            ",\\"skc\\":" (itoa (max 1 skc))
            ",\\"meta\\":" (if (/= meta-raw "") meta-raw "null")
            ",\\"bars\\":[" bars-json "]"
            ",\\"stirs\\":[" stirs-json "]"
            ",\\"dims\\":[" dims-json "]"
            "}"
          ) fp)
          (close fp)
          (if (findfile out-path) (vl-file-delete out-path))
          (vl-file-rename tmp-p out-path)
        )
      )
      (princ (strcat "\\n[BeamCAD] Da quet xong dam " (if (/= bname "") bname "(chua dat ten)") "! Quay lai Revit BeamCAD de sua & ve lai."))
      t
    )
  )
)

(defun c:_BC_SCAN_BEAM (/ p)
  (vl-load-com)
  (setq p *BC_SCAN_JSON*)
  (_bc-scan-to-file p)
  (princ)
)

(defun c:DAM_QUET (/ p)
  (vl-load-com)
  (setq p (if (and *BC_SCAN_JSON* (/= *BC_SCAN_JSON* "")) *BC_SCAN_JSON* (strcat (getvar "TEMPPREFIX") "BeamCAD_ScanResult.json")))
  (_bc-scan-to-file p)
  (princ)
)

(defun c:DAM_HELP ()
  (princ "\\n=== Bo lenh BeamCAD trong AutoCAD ===")
  (princ "\\n  DAM_SUA   : Pick thep chu / tag / dai / TK -> Mo hop thoai sua & dong bo")
  (princ "\\n  DAM_QTK   : Quet & cap nhat nhanh bang thong ke + TONG HOP COT THEP")
  (princ "\\n  DAM_THEP  : Hop thoai doi hang loat DK & SL thep chu")
  (princ "\\n  DAM_DAI   : Hop thoai doi hang loat DK & buoc dai a")
  (princ "\\n  DAM_TEN   : Hop thoai doi Ten cau kien & So cau kien (SKC)")
  (princ "\\n  DAM_QUET  : Quet dam da trien khai de gui ve Revit BeamCAD")
  (princ)
)

(princ "\\n[BeamCAD] Da nap bo lenh CAD: DAM_SUA | DAM_QTK | DAM_THEP | DAM_DAI | DAM_TEN | DAM_QUET | DAM_HELP")
(princ)
'''
    scan_json_posix = os.path.join(target_dir, 'BeamCAD_ScanResult.json').replace('\\', '/')
    lsp_code = (
        lsp_code
        .replace('__BC_DCL_PATH__', dcl_posix)
        .replace('__BC_DCL_EMBED__', dcl_embed_lisp)
        .replace('__BC_SCAN_JSON__', scan_json_posix)
    )
    with io.open(lsp_path, 'wb') as f:
        f.write(lsp_code.replace('\n', '\r\n').encode('utf-8'))
    return lsp_path.replace('\\', '/')


def _build_drop_lisp_body(dxf_path, prompt_label=u'ban ve dam'):
    dxf_posix = dxf_path.replace('\\', '/')
    tools_posix = _write_beamcad_tools_lisp(os.path.dirname(dxf_path))
    lines = []
    if tools_posix:
        lines.append(u'(if (and (not c:DAM_SUA) (findfile "%s")) (load "%s" nil))' % (tools_posix, tools_posix))
    lines.extend([
        u'(defun _bc-drop-insert (/ *error* _bcpt _bccmd _bcatt _bciu _bcis _bcit _bclast _bcblk)',
        u'  (defun *error* (msg)',
        u'    (if _bccmd (setvar "CMDECHO" _bccmd))',
        u'    (if _bcatt (setvar "ATTREQ" _bcatt))',
        u'    (if _bciu (setvar "INSUNITS" _bciu))',
        u'    (if _bcis (setvar "INSUNITSDEFSOURCE" _bcis))',
        u'    (if _bcit (setvar "INSUNITSDEFTARGET" _bcit))',
        u'    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*")))',
        u'      (princ (strcat "\\n[BeamCAD] Loi chen CAD: " msg))',
        u'    )',
        u'    (princ)',
        u'  )',
        u'  (if (= (getvar "TILEMODE") 0) (setvar "TILEMODE" 1))',
        u'  (setq _bcpt (getpoint "\\n[BeamCAD] Pick diem chen %s trong Model Space: "))' % prompt_label,
        u'  (if _bcpt (progn',
        u'    (setq _bccmd (getvar "CMDECHO") _bcatt (getvar "ATTREQ") _bciu (getvar "INSUNITS") _bcis (getvar "INSUNITSDEFSOURCE") _bcit (getvar "INSUNITSDEFTARGET"))',
        u'    (setvar "CMDECHO" 0) (setvar "ATTREQ" 0) (setvar "INSUNITS" 4) (setvar "INSUNITSDEFSOURCE" 4) (setvar "INSUNITSDEFTARGET" 4)',
        u'    (setq _bclast (entlast))',
        u'    (command "._-INSERT" "*%s" "_non" _bcpt 1 0)' % dxf_posix,
        u'    (while (> (getvar "CMDACTIVE") 0) (command ""))',
        u'    (if (equal (entlast) _bclast)',
        u'      (progn',
        u'        (command "._-INSERT" "%s" "_non" _bcpt 1 1 0)' % dxf_posix,
        u'        (while (> (getvar "CMDACTIVE") 0) (command ""))',
        u'        (if (not (equal (entlast) _bclast))',
        u'          (progn (command "._EXPLODE" (entlast)) (while (> (getvar "CMDACTIVE") 0) (command "")))',
        u'        )',
        u'      )',
        u'    )',
        u'    (if _bccmd (setvar "CMDECHO" _bccmd))',
        u'    (if _bcatt (setvar "ATTREQ" _bcatt))',
        u'    (if _bciu (setvar "INSUNITS" _bciu))',
        u'    (if _bcis (setvar "INSUNITSDEFSOURCE" _bcis))',
        u'    (if _bcit (setvar "INSUNITSDEFTARGET" _bcit))',
        u'    (princ "\\n[BeamCAD] Da chen xong! Lenh CAD: DAM_SUA | DAM_QTK | DAM_THEP | DAM_DAI | DAM_TEN")',
        u'  ))',
        u'  (princ)',
        u')',
        u'(_bc-drop-insert)',
    ])
    return u'\r\n'.join(lines) + u'\r\n'


def _write_cad_drop_lisp(dxf_path, prompt_label=u'ban ve dam'):
    lsp_path = os.path.splitext(dxf_path)[0] + '_drop.lsp'
    body = _build_drop_lisp_body(dxf_path, prompt_label=prompt_label)
    with io.open(lsp_path, 'wb') as f:
        f.write(body.encode('utf-8'))
    return lsp_path.replace('\\', '/')



def parse_beam_selection(sel_text, all_names):
    if sel_text is None:
        return list(all_names)
    raw = sstr(sel_text).strip()
    up = raw.upper()
    if not up or up in ('ALL', '*'):
        return list(all_names)
    picked = []
    seen = set()
    for tok in re.split(r'[,;\s]+', raw):
        tok = tok.strip()
        if not tok:
            continue
        m_rng = re.match(r'^(\d+)-(\d+)$', tok)
        if m_rng:
            a, b = int(m_rng.group(1)), int(m_rng.group(2))
            lo, hi = min(a, b), max(a, b)
            for idx in range(lo, hi + 1):
                if 1 <= idx <= len(all_names):
                    nm = all_names[idx - 1]
                    if nm not in seen:
                        seen.add(nm)
                        picked.append(nm)
            continue
        if tok.isdigit():
            idx = int(tok)
            if 1 <= idx <= len(all_names):
                nm = all_names[idx - 1]
                if nm not in seen:
                    seen.add(nm)
                    picked.append(nm)
            continue
        for nm in all_names:
            if nm.upper() == tok.upper() and nm not in seen:
                seen.add(nm)
                picked.append(nm)
    return picked


def _pack_beam_meta_xdata(bname, sl_ck, beam_mode, sups, spans, grps, opt):
    payload = {
        'v': 2,
        'b': bname,
        'sl': int(sl_ck),
        'm': beam_mode,
        'opt': {
            'cover': opt.get('cover', 30.0),
            'ext': opt.get('ext', 'L/4'),
            'cut': opt.get('cut', 'L/4'),
            'neo': opt.get('neo', '30d'),
            'neo_top': opt.get('neo_top', ''),
            'neo_bot': opt.get('neo_bot', ''),
            'lap': opt.get('lap', '40d'),
            'gap': opt.get('gap', u'xuống'),
            'neo_mode': opt.get('neo_mode', _NEO_MODES[0]),
            'step_neo': opt.get('step_neo', _STEP_NEO_MODES[0]),
            'std': opt.get('std', u'TCVN 5574:2018'),
            'concrete': opt.get('concrete', 'B25'),
            'steel': opt.get('steel', 'CB400-V'),
            'straight': opt.get('straight', 0.0),
            'thr': opt.get('thr', 100.0),
            'slope': opt.get('slope', 6.0),
            'pitch': opt.get('pitch', 25.0),
            'near': opt.get('near', 800.0),
            'hook_clr': opt.get('hook_clr', 20.0),
            'tc_hook': opt.get('tc_hook', 1.0),
        },
        'sups': [{'w': round(s['w'], 2), 'k': s['kind'], 'g': s['grid'], 'o': round(s['off'], 2), 'r': s.get('role', '')} for s in sups],
        'spans': [{
            'c': round(sp['clear'], 2), 'b': round(sp['b'], 2), 'h': round(sp['h'], 2),
            't': round(sp['top'], 2), 'st': sp['stir'],
            'sl': round(sp.get('slabL', 0.0), 2), 'slt': round(sp.get('slabL_top', sp['top']), 2),
            'sr': round(sp.get('slabR', 0.0), 2), 'srt': round(sp.get('slabR_top', sp['top']), 2),
        } for sp in spans],
        'grps': [[
            g['pos'], int(g['layer']), int(g['n']), int(g['d']), int(g['a']),
            g['lk'], g['lv'], int(g['b']), g['rk'], g['rv'], g['cross'], g.get('note', '')
        ] for g in grps],
    }
    raw = json.dumps(payload, separators=(',', ':'), ensure_ascii=True)
    return [raw[i:i + 200] for i in range(0, len(raw), 200)]


def build_dxf_from_excel(xlsx_path, out_dxf, split_limit=50, elev_scale=50, sec_scale=25, selected_beams=None, part='all', beam_modes=None):
    s_elev = max(5, int(round(elev_scale or 50)))
    s_sec = max(5, int(round(sec_scale or 25)))
    k_elev = s_elev / 50.0
    k_sec = s_sec / 25.0
    wb = read_xlsx_rows(xlsx_path)
    nhip = wb.get('Nhip', [])
    if len(nhip) < 2:
        raise ValueError('File Excel khong co sheet Nhip hop le.')
    nhip_cp = _build_col_lookup(nhip[0])

    def gc(row, key_or_aliases, fallback=None):
        aliases = key_or_aliases if isinstance(key_or_aliases, (list, tuple)) else [key_or_aliases]
        return _gc_aliases(row, nhip_cp, aliases, fallback)

    opt, level_z = _read_wb_opt_and_level(wb)

    groups_map = {}
    thep_sheet = wb.get('Thep', [])
    if len(thep_sheet) >= 2:
        th_cp = _build_col_lookup(thep_sheet[0])
        c_th_bn = _find_col_idx(th_cp, [u'Tên dầm', 'Ten dam'], 0)
        c_th_note = _find_col_idx(th_cp, _THEP_NOTE_ALIASES, 1)
        c_th_pos = _find_col_idx(th_cp, [u'Vị trí', 'Vi tri'], 2)
        c_th_lay = _find_col_idx(th_cp, [u'Lớp', 'Lop'], 3)
        c_th_sl = _find_col_idx(th_cp, ['SL', u'Số lượng', 'So luong'], 4)
        c_th_phi = _find_col_idx(th_cp, ['Phi', u'Đường kính', 'DK', 'Duong kinh'], 5)
        c_th_ga = _find_col_idx(th_cp, [u'Gối A', u'Từ gối', 'Goi A', 'Tu goi'], 6)
        c_th_lk = _find_col_idx(th_cp, _THEP_LK_ALIASES, 7)
        c_th_lv = _find_col_idx(th_cp, [u'Giá trị trái', 'Gia tri trai', 'GT trai'], 8)
        c_th_gb = _find_col_idx(th_cp, [u'Gối B', u'Đến gối', 'Goi B', 'Den goi'], 9)
        c_th_rk = _find_col_idx(th_cp, _THEP_RK_ALIASES, 10)
        c_th_rv = _find_col_idx(th_cp, [u'Giá trị phải', 'Gia tri phai', 'GT phai'], 11)
        c_th_cr = _find_col_idx(th_cp, _THEP_CR_ALIASES, 12)
        c_th_n2 = _find_col_idx(th_cp, [u'Ghi chú thêm', 'Note 2'], 13)
        for tr in thep_sheet[1:]:
            if not tr or len(tr) < 6:
                continue
            bn = sstr(tr[c_th_bn] if c_th_bn is not None and c_th_bn < len(tr) else '')
            if not bn:
                continue
            note_s = sstr(tr[c_th_n2] if c_th_n2 is not None and c_th_n2 < len(tr) else '')
            if not note_s and c_th_note is not None and c_th_note < len(tr):
                cand_note = sstr(tr[c_th_note])
                if cand_note and not cand_note.isdigit():
                    note_s = cand_note
            groups_map.setdefault(bn, []).append({
                'pos': norm_pos(tr[c_th_pos] if c_th_pos is not None and c_th_pos < len(tr) else u'Trên'),
                'layer': max(1, int(round(num(tr[c_th_lay] if c_th_lay is not None and c_th_lay < len(tr) else 1, 1)))),
                'n': max(1, int(round(num(tr[c_th_sl] if c_th_sl is not None and c_th_sl < len(tr) else 2, 2)))),
                'd': max(6, int(round(num(tr[c_th_phi] if c_th_phi is not None and c_th_phi < len(tr) else 16, 16)))),
                'a': _parse_sup_idx(tr[c_th_ga] if c_th_ga is not None and c_th_ga < len(tr) else 0, 0),
                'lk': norm_end(tr[c_th_lk] if c_th_lk is not None and c_th_lk < len(tr) else u'Neo vào gối'),
                'lv': sstr(tr[c_th_lv] if c_th_lv is not None and c_th_lv < len(tr) else ''),
                'b': _parse_sup_idx(tr[c_th_gb] if c_th_gb is not None and c_th_gb < len(tr) else 1, 1),
                'rk': norm_end(tr[c_th_rk] if c_th_rk is not None and c_th_rk < len(tr) else u'Neo vào gối'),
                'rv': sstr(tr[c_th_rv] if c_th_rv is not None and c_th_rv < len(tr) else ''),
                'cross': norm_cross(tr[c_th_cr] if c_th_cr is not None and c_th_cr < len(tr) else u'Tự động'),
                'note': note_s,
            })

    c_nhip_bn = _find_col_idx(nhip_cp, [u'Tên dầm', 'Ten dam'], 0)
    beams_raw = {}
    order = []
    for r in nhip[1:]:
        nm = sstr(r[c_nhip_bn] if c_nhip_bn < len(r) else '')
        if not r or not nm:
            continue
        if nm not in beams_raw:
            beams_raw[nm] = []
            order.append(nm)
        beams_raw[nm].append(r)

    order.sort(key=_natural_beam_key)

    if selected_beams is not None:
        sel_set = set(sstr(x) for x in selected_beams)
        filtered = [nm for nm in order if nm in sel_set]
        if filtered:
            order = filtered

    dxf = DxfOut()

    def _emit_dimstyle(name, dimscale, txth=2.0, blk1_h=None, blk2_h=None):
        b1 = blk1_h if blk1_h is not None else dxf.arch_tick_br_h
        b2 = blk2_h if blk2_h is not None else dxf.arch_tick_br_h
        dxf.p(0, 'DIMSTYLE'); dxf.p(105, dxf.next_h()); dxf.p(330, 'A')
        dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbDimStyleTableRecord')
        dxf.p(2, name); dxf.p(70, 0)
        dxf.p(3, ''); dxf.p(4, '')
        dxf.p(40, '%.1f' % dimscale)
        dxf.p(41, '1.5'); dxf.p(42, '2.0'); dxf.p(43, '3.75'); dxf.p(44, '1.0')
        dxf.p(45, '5.0'); dxf.p(49, '4.0'); dxf.p(77, 1); dxf.p(140, '%.1f' % txth); dxf.p(141, '2.5')
        dxf.p(147, '1.0'); dxf.p(171, 3); dxf.p(172, 1); dxf.p(173, 0); dxf.p(174, 1)
        dxf.p(176, 8); dxf.p(177, 8); dxf.p(178, 3); dxf.p(271, 0); dxf.p(274, 3)
        dxf.p(278, 44); dxf.p(279, 2); dxf.p(283, 0); dxf.p(289, 3); dxf.p(290, 1)
        dxf.p(340, dxf.style_dce_h); dxf.p(341, b1); dxf.p(342, b2)

    # HEADER SECTION (AC1021 UTF-8 compatible)
    dxf.p(0, 'SECTION'); dxf.p(2, 'HEADER')
    dxf.p(9, '$ACADVER'); dxf.p(1, 'AC1021')
    dxf.p(9, '$DWGCODEPAGE'); dxf.p(3, 'ANSI_1252')
    dxf.p(9, '$INSBASE'); dxf.p(10, '0.0'); dxf.p(20, '0.0'); dxf.p(30, '0.0')
    dxf.p(9, '$EXTMIN'); dxf.p(10, '0.0'); dxf.p(20, '0.0'); dxf.p(30, '0.0')
    dxf.p(9, '$EXTMAX'); dxf.p(10, '10000.0'); dxf.p(20, '10000.0'); dxf.p(30, '0.0')
    dxf.p(9, '$LIMMIN'); dxf.p(10, '0.0'); dxf.p(20, '0.0')
    dxf.p(9, '$LIMMAX'); dxf.p(10, '420.0'); dxf.p(20, '297.0')
    dxf.p(9, '$CLAYER'); dxf.p(8, '0')
    dxf.p(9, '$HANDSEED'); dxf.p(5, 'FFFFF')
    dxf.p(9, '$LTSCALE'); dxf.p(40, '20.0')
    dxf.p(9, '$TEXTSTYLE'); dxf.p(7, 'Dce_Text2')
    dxf.p(9, '$DIMSCALE'); dxf.p(40, '20.0')
    dxf.p(9, '$DIMASZ'); dxf.p(40, '1.5')
    dxf.p(9, '$DIMEXO'); dxf.p(40, '2.0')
    dxf.p(9, '$DIMEXE'); dxf.p(40, '1.0')
    dxf.p(9, '$DIMTXT'); dxf.p(40, '2.0')
    dxf.p(9, '$DIMGAP'); dxf.p(40, '1.0')
    dxf.p(9, '$DIMTAD'); dxf.p(70, 1)
    dxf.p(9, '$DIMBLK'); dxf.p(1, 'ArchTick')
    dxf.p(9, '$DIMSAH'); dxf.p(70, 0)
    dxf.p(9, '$DIMSTYLE'); dxf.p(2, 'Dce_%dMV' % s_elev)
    dxf.p(9, '$DIMLDRBLK'); dxf.p(1, 'ArchTick')
    dxf.p(9, '$MEASUREMENT'); dxf.p(70, 1)
    dxf.p(9, '$INSUNITS'); dxf.p(70, 4)
    dxf.p(9, '$DIMASSOC'); dxf.p(280, 1)
    dxf.p(0, 'ENDSEC')

    # CLASSES SECTION
    dxf.p(0, 'SECTION'); dxf.p(2, 'CLASSES')
    for cname, cpp in (('ACDBDICTIONARYWDFLT', 'AcDbDictionaryWithDefault'), ('ACDBPLACEHOLDER', 'AcDbPlaceHolder')):
        dxf.p(0, 'CLASS'); dxf.p(1, cname); dxf.p(2, cpp); dxf.p(3, 'ObjectDBX Classes')
        dxf.p(90, 0); dxf.p(91, 0); dxf.p(280, 0); dxf.p(281, 0)
    dxf.p(0, 'ENDSEC')

    # TABLES SECTION
    dxf.p(0, 'SECTION'); dxf.p(2, 'TABLES')
    dxf.p(0, 'TABLE'); dxf.p(2, 'VPORT'); dxf.p(5, '8'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 1)
    dxf.p(0, 'VPORT'); dxf.p(5, 'B'); dxf.p(330, '8'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbViewportTableRecord')
    dxf.p(2, '*ACTIVE'); dxf.p(70, 0)
    dxf.p(10, '0.0'); dxf.p(20, '0.0'); dxf.p(11, '1.0'); dxf.p(21, '1.0')
    dxf.p(12, '0.0'); dxf.p(22, '0.0'); dxf.p(13, '0.0'); dxf.p(23, '0.0')
    dxf.p(14, '10.0'); dxf.p(24, '10.0'); dxf.p(15, '10.0'); dxf.p(25, '10.0')
    dxf.p(16, '0.0'); dxf.p(26, '0.0'); dxf.p(36, '1.0')
    dxf.p(17, '0.0'); dxf.p(27, '0.0'); dxf.p(37, '0.0')
    dxf.p(40, '10000.0'); dxf.p(41, '1.5'); dxf.p(42, '50.0'); dxf.p(43, '0.0'); dxf.p(44, '0.0')
    dxf.p(50, '0.0'); dxf.p(51, '0.0')
    dxf.p(71, 0); dxf.p(72, 100); dxf.p(73, 1); dxf.p(74, 3); dxf.p(75, 0); dxf.p(76, 0); dxf.p(77, 0); dxf.p(78, 0)
    dxf.p(0, 'ENDTAB')

    dxf.p(0, 'TABLE'); dxf.p(2, 'LTYPE'); dxf.p(5, '5'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 5)
    for lt_name, lt_h in (('ByBlock', '14'), ('ByLayer', '15')):
        dxf.p(0, 'LTYPE'); dxf.p(5, lt_h); dxf.p(330, '5'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbLinetypeTableRecord')
        dxf.p(2, lt_name); dxf.p(70, 0); dxf.p(3, ''); dxf.p(72, 65); dxf.p(73, 0); dxf.p(40, '0.0')
    dxf.p(0, 'LTYPE'); dxf.p(5, '16'); dxf.p(330, '5'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbLinetypeTableRecord')
    dxf.p(2, 'CONTINUOUS'); dxf.p(70, 0); dxf.p(3, 'Solid line'); dxf.p(72, 65); dxf.p(73, 0); dxf.p(40, '0.0')
    dxf.p(0, 'LTYPE'); dxf.p(5, dxf.next_h()); dxf.p(330, '5'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbLinetypeTableRecord')
    dxf.p(2, 'DASHDOT2_DBIM'); dxf.p(70, 0); dxf.p(3, 'Dash dot _._._.'); dxf.p(72, 65); dxf.p(73, 4); dxf.p(40, '12.7')
    dxf.p(49, '6.35'); dxf.p(74, 0); dxf.p(49, '-3.175'); dxf.p(74, 0); dxf.p(49, '0.0'); dxf.p(74, 0); dxf.p(49, '-3.175'); dxf.p(74, 0)
    dxf.p(0, 'LTYPE'); dxf.p(5, dxf.next_h()); dxf.p(330, '5'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbLinetypeTableRecord')
    dxf.p(2, 'HIDDEN2'); dxf.p(70, 0); dxf.p(3, 'Hidden (.5x) __ __ __'); dxf.p(72, 65); dxf.p(73, 2); dxf.p(40, '4.7625')
    dxf.p(49, '3.175'); dxf.p(74, 0); dxf.p(49, '-1.5875'); dxf.p(74, 0)
    dxf.p(0, 'ENDTAB')

    layers_def = [
        ('0', 7, 'CONTINUOUS', 1),
        ('DCE_BaoBeTong', 4, 'CONTINUOUS', 1),
        ('DCE_ThepChu', 1, 'CONTINUOUS', 1),
        ('DCE_ThepDai', 220, 'CONTINUOUS', 1),
        ('DCE_Dim', 254, 'CONTINUOUS', 1),
        ('DCE_Truc', 8, 'DASHDOT2_DBIM', 1),
        ('DCE_MCZiCZac', 144, 'CONTINUOUS', 1),
        ('Dce_text', 7, 'CONTINUOUS', 1),
        ('DCE_Lanh_To', 3, 'CONTINUOUS', 1),
        ('DCE_Block', 8, 'CONTINUOUS', 1),
        ('3', 3, 'HIDDEN2', 1),
        ('Dce_ViTriThep', 7, 'CONTINUOUS', 1),
        ('Defpoints', 7, 'CONTINUOUS', 0),
    ]
    dxf.p(0, 'TABLE'); dxf.p(2, 'LAYER'); dxf.p(5, '20'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, len(layers_def))
    for lname, lcol, ltp, lplot in layers_def:
        dxf.p(0, 'LAYER'); dxf.p(5, '10' if lname == '0' else dxf.next_h()); dxf.p(330, '20')
        dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbLayerTableRecord')
        dxf.p(2, lname); dxf.p(70, 0); dxf.p(62, lcol); dxf.p(6, ltp); dxf.p(290, lplot); dxf.p(370, -3); dxf.p(390, 'F')
    dxf.p(0, 'ENDTAB')

    dxf.p(0, 'TABLE'); dxf.p(2, 'STYLE'); dxf.p(5, '3'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 3)
    for st, sh_h, wf, fnt, h42 in (('Standard', '11', 1.0, 'txt', '0.2'), ('Dce_Text', dxf.style_dce_h, 0.8, 'arial.ttf', '2.5'), ('Dce_Text2', dxf.style_dce2_h, 0.8, 'arial.ttf', '2.5')):
        dxf.p(0, 'STYLE'); dxf.p(5, sh_h); dxf.p(330, '3'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbTextStyleTableRecord')
        dxf.p(2, st); dxf.p(70, 0); dxf.p(40, '0.0'); dxf.p(41, '%.2f' % wf)
        dxf.p(50, '0.0'); dxf.p(71, 0); dxf.p(42, h42); dxf.p(3, fnt); dxf.p(4, '')
    dxf.p(0, 'ENDTAB')

    dxf.p(0, 'TABLE'); dxf.p(2, 'VIEW'); dxf.p(5, '6'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 0); dxf.p(0, 'ENDTAB')
    dxf.p(0, 'TABLE'); dxf.p(2, 'UCS'); dxf.p(5, '7'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 0); dxf.p(0, 'ENDTAB')
    dxf.p(0, 'TABLE'); dxf.p(2, 'APPID'); dxf.p(5, '9'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 7)
    for app in ('ACAD', 'DCEThongKeThep', 'DcePro', 'BeamCAD_SUM', 'BeamCAD_SKC', 'BeamCAD_LINK', 'BeamCAD_META'):
        dxf.p(0, 'APPID'); dxf.p(5, '12' if app == 'ACAD' else dxf.next_h()); dxf.p(330, '9')
        dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbRegAppTableRecord'); dxf.p(2, app); dxf.p(70, 0)
    dxf.p(0, 'ENDTAB')

    elev_ds = 'Dce_%dMV' % s_elev
    sec_ds = 'Dce_%dMV' % s_sec
    sec_dot_ds = 'Dce_207MV' if s_sec == 25 else ('Dce_%dDot' % s_sec)
    dimstyle_specs = [
        ('Standard', 20.0, 2.0, dxf.arch_tick_br_h, dxf.arch_tick_br_h),
        ('Dce_20MV', 20.0, 2.0, dxf.arch_tick_br_h, dxf.arch_tick_br_h),
        ('Dce_25MV', 25.0, 2.0, dxf.arch_tick_br_h, dxf.arch_tick_br_h),
        ('Dce_50MV', 50.0, 2.0, dxf.arch_tick_br_h, dxf.arch_tick_br_h),
        ('Dce_207MV', 25.0, 2.5, dxf.dot_blank_br_h, dxf.arch_tick_br_h),
    ]
    seen_ds = set(x[0] for x in dimstyle_specs)
    if elev_ds not in seen_ds:
        dimstyle_specs.append((elev_ds, float(s_elev), 2.0, dxf.arch_tick_br_h, dxf.arch_tick_br_h))
        seen_ds.add(elev_ds)
    if sec_ds not in seen_ds:
        dimstyle_specs.append((sec_ds, float(s_sec), 2.0, dxf.arch_tick_br_h, dxf.arch_tick_br_h))
        seen_ds.add(sec_ds)
    if sec_dot_ds not in seen_ds:
        dimstyle_specs.append((sec_dot_ds, float(s_sec), 2.5, dxf.dot_blank_br_h, dxf.arch_tick_br_h))
        seen_ds.add(sec_dot_ds)
    dxf.p(0, 'TABLE'); dxf.p(2, 'DIMSTYLE'); dxf.p(5, 'A'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, len(dimstyle_specs))
    dxf.p(100, 'AcDbDimStyleTable'); dxf.p(71, 1)
    for ds_nm, ds_sc, ds_th, b1h, b2h in dimstyle_specs:
        _emit_dimstyle(ds_nm, ds_sc, ds_th, b1h, b2h)
    dxf.p(0, 'ENDTAB')

    # Build BLOCKS into dxf.blocks_buf first, then collect BLOCK_RECORD handles
    dxf.set_target('blocks')

    def start_blk(bname, br_handle=None, has_atts=True):
        br_h = br_handle or dxf.next_h()
        dxf.register_block_record(bname, br_h)
        dxf._cur_owner = br_h
        dxf.p(0, 'BLOCK'); dxf.p(5, dxf.next_h()); dxf.p(330, br_h); dxf.p(100, 'AcDbEntity'); dxf.p(8, '0')
        dxf.p(100, 'AcDbBlockBegin'); dxf.p(2, bname); dxf.p(70, 2 if has_atts else 0)
        dxf.p(10, '0.0'); dxf.p(20, '0.0'); dxf.p(30, '0.0'); dxf.p(3, bname); dxf.p(1, '')

    def end_blk():
        dxf.p(0, 'ENDBLK'); dxf.p(5, dxf.next_h()); dxf.p(330, dxf._cur_owner); dxf.p(100, 'AcDbEntity'); dxf.p(8, '0'); dxf.p(100, 'AcDbBlockEnd')
        dxf._cur_owner = dxf.ms_br_h

    # *Model_Space & *Paper_Space
    start_blk('*Model_Space', dxf.ms_br_h, False); end_blk()
    start_blk('*Paper_Space', dxf.ps_br_h, False); end_blk()

    # Arrowhead blocks matching beam.dxf
    start_blk('_ArchTick', dxf.arch_tick_br_h, False)
    dxf.pline([(-0.5, -0.5), (0.5, 0.5)], '0', False, 0, cw=0.15)
    end_blk()

    start_blk('_DotBlank', dxf.dot_blank_br_h, False)
    dxf.circle(0.0, 0.0, 0.5, '0', 0)
    dxf.line(-0.5, 0.0, -1.0, 0.0, '0', 0)
    end_blk()

    start_blk('Dce_KhTenTruc')
    dxf.circle(0.0, -3.5, 2.5, 'DCE_Block', 3)
    dxf.circle(0.0, -3.5, 2.7, 'DCE_Block', 256)
    dxf.line(0.0, 0.0, 0.0, -1.0, 'DCE_Truc', 256)
    dxf.line(0.0, -6.0, 0.0, -7.0, 'DCE_Truc', 256)
    dxf.line(-3.5, -3.5, -2.5, -3.5, 'DCE_Truc', 256)
    dxf.line(2.5, -3.5, 3.5, -3.5, 'DCE_Truc', 256)
    dxf.attdef('TRUC', 'Ten truc', '1', 0.0, -4.5, 2.0, 2, 1, 0, 'Dce_text')
    end_blk()

    start_blk('Dce_CaoTrinh')
    dxf.pline([(-11.56, 6.69), (-11.56, 0.0)], '0', False, 8)
    dxf.pline([(-11.56, 0.0), (-9.95, 1.6), (-11.56, 1.6)], '0', True, 8)
    dxf.pline([(-11.56, 0.0), (-13.17, 1.6), (-11.56, 1.6)], '0', True, 8)
    dxf.hatch_poly([(-11.56, 0.0), (-9.95, 1.6), (-11.56, 1.6)], '0', 256, solid=True)
    dxf.line(-13.15, 3.14, -0.09, 3.14, '0', 8)
    dxf.line(0.0, 0.0, -13.2, 0.0, '0', 8)
    dxf.attdef('CT', 'Cao trinh', '%%p0.000', -10.15, 4.07, 2.0, 3, 0, 0, '0')
    end_blk()

    start_blk('DCE_MatCatA')
    dxf.hatch_poly([(0.0, 5.5), (1.18, 2.75), (0.0, 0.0)], '0', 3, solid=True)
    dxf.line(0.0, 5.5, 0.0, 0.0, '0', 3)
    dxf.line(0.0, 5.5, 1.18, 2.75, '0', 3)
    dxf.line(1.18, 2.75, 0.0, 0.0, '0', 3)
    dxf.attdef('1', 'Ten MC', '1', -2.33, 1.70, 2.0, 11, 1, 0, '0')
    end_blk()

    start_blk('Dce_KhTenDam')
    dxf.attdef('TENDAM', 'Ten dam', '%%UDAM', 0.0, 0.74, 2.0, 255, 1, 0, '0')
    dxf.attdef('TL', 'Ti le', 'TL: 1/50', 0.0, -2.0, 1.0, 11, 1, 0, '0')
    end_blk()

    start_blk('Dce_KhMatCat')
    dxf.attdef('TENMATCAT', 'Ten MC', '%%UMC 1-1', 0.0, 0.74, 2.0, 255, 1, 0, '0')
    dxf.attdef('TL', 'Ti le', 'TL: 1/25', 0.0, -2.0, 1.0, 11, 1, 0, '0')
    end_blk()

    start_blk('Dce_McThepChu', has_atts=False)
    dxf.line(-0.35, 0.35, 0.35, -0.35, '0', 0)
    dxf.line(0.35, 0.35, -0.35, -0.35, '0', 0)
    dxf.line(-0.5, 0.0, 0.5, 0.0, '0', 0)
    dxf.line(0.0, 0.5, 0.0, -0.5, '0', 0)
    dxf.pline([(-0.5, 0.0, 1.0), (0.5, 0.0, 1.0)], '0', True, 0, cw=0.0833)
    dxf.circle(0.0, 0.0, 0.5, '0', 0)
    end_blk()

    start_blk('Dce_KhtMcThepChu')
    dxf.circle(2.5, 0.0, 2.5, '0', 256)
    dxf.attdef('SH', 'So hieu', '1', 2.5, 0.0, 2.0, 11, 1, 2, '0')
    dxf.attdef('DKVAKC', 'DK', '2%%c18', -0.54, 1.0, 2.0, 3, 2, 0, '0')
    dxf.attdef('DKVAKC2', 'Note', '', -0.54, -2.6, 2.0, 3, 2, 0, '0')
    end_blk()

    start_blk('Dce_KhtMcThepChu_R')
    dxf.circle(2.5, 0.0, 2.5, '0', 256)
    dxf.attdef('SH', 'So hieu', '1', 2.5, 0.0, 2.0, 11, 1, 2, '0')
    dxf.attdef('DKVAKC', 'DK', '2%%c18', -0.54, 1.0, 2.0, 3, 2, 0, '0')
    dxf.attdef('DKVAKC2', 'Note', '', -0.54, -2.6, 2.0, 3, 2, 0, '0')
    end_blk()

    start_blk('Dce_KhtMcThepChu_L')
    dxf.circle(-2.5, 0.0, 2.5, '0', 256)
    dxf.attdef('SH', 'So hieu', '1', -2.5, 0.0, 2.0, 11, 1, 2, '0')
    dxf.attdef('DKVAKC', 'DK', '2%%c18', 0.54, 1.0, 2.0, 3, 0, 0, '0')
    dxf.attdef('DKVAKC2', 'Note', '', 0.54, -2.6, 2.0, 3, 0, 0, '0')
    end_blk()

    start_blk('Dce_KhtThepDai')
    dxf.circle(-5.6, -3.5, 2.5, '0', 256)
    dxf.attdef('SH', 'So hieu', '8', -5.74, -4.5, 2.0, 11, 1, 0, '0')
    dxf.attdef('DKVAKC', 'Dai', '%%c6a100', -2.56, -4.5, 2.0, 3, 0, 0, '0')
    dxf.attdef('VITRI', 'Vi tri', '', 15.57, -4.5, 2.0, 11, 1, 0, 'Dce_ViTriThep')
    end_blk()

    start_blk('TenCauKien')
    dxf.attdef('SOCAUKIEN', 'So cau kien', 'SoCauKien', 2.0, 0.0, 2.5, 256, 1, 2, 'Dce_text', rot=90.0)
    dxf.attdef('TENCAUKIEN', 'Ten cau kien', u'Tên cấu kiện', -2.0, 0.0, 2.5, 256, 1, 2, 'Dce_text', rot=90.0)
    end_blk()

    start_blk('TKTitle', has_atts=False)
    dxf.pline([(0.0, 0.0), (0.0, -11.0), (0.0, -35.0), (15.0, -35.0), (25.0, -35.0),
               (75.0, -35.0), (90.0, -35.0), (122.5, -35.0), (135.0, -35.0),
               (147.5, -35.0), (167.5, -35.0), (192.5, -35.0), (192.5, -11.0), (192.5, 0.0)], 'DCE_BaoBeTong', True)
    dxf.pline([(0.0, -11.0), (15.0, -11.0), (25.0, -11.0), (75.0, -11.0), (90.0, -11.0),
               (122.5, -11.0), (147.5, -11.0), (167.5, -11.0), (192.5, -11.0)], 'DCE_BaoBeTong', False)
    for vx in (15.0, 25.0, 75.0, 90.0, 110.0, 122.5, 147.5, 167.5):
        dxf.line(vx, -11.0, vx, -35.0, 'DCE_BaoBeTong')
    dxf.line(122.5, -23.0, 147.5, -23.0, 'DCE_BaoBeTong')
    dxf.line(135.0, -23.0, 135.0, -35.0, 'DCE_BaoBeTong')
    dxf.text(92.5, -6.0, 4.5, u'BẢNG THỐNG KÊ CỐT THÉP', '0', 256, 1, 2)
    for tx, ty, th, lbl in [
        (7.5, -17.5, 2.5, u'TÊN'), (7.5, -23.0, 2.5, u'CẤU'), (7.5, -28.5, 2.5, u'KIỆN'),
        (20.0, -21.25, 2.5, u'SỐ'), (20.0, -26.75, 2.5, u'HIỆU'),
        (50.0, -23.0, 2.5, u'HÌNH DẠNG, KÍCH THƯỚC'),
        (82.5, -17.5, 2.5, u'ĐƯỜNG'), (82.5, -23.0, 2.5, u'KÍNH'), (82.5, -28.5, 2.5, '(mm)'),
        (100.0, -17.5, 2.5, u'CHIỀU DÀI'), (100.0, -23.0, 2.5, u'THANH'), (100.0, -28.5, 2.5, '(mm)'),
        (116.25, -17.5, 2.5, u'SỐ'), (116.25, -23.0, 2.5, u'CẤU'), (116.25, -28.5, 2.5, u'KIỆN'),
        (135.0, -17.0, 2.5, u'SỐ LƯỢNG'), (128.75, -29.0, 2.5, '1 CK'), (141.25, -29.0, 2.5, u'T. BỘ'),
        (157.5, -17.5, 2.5, u'TỔNG'), (157.5, -23.0, 2.5, u'CHIỀU DÀI'), (157.5, -28.5, 2.5, '(m)'),
        (180.0, -17.5, 2.5, u'TỔNG'), (180.0, -23.0, 2.5, u'KHỐI LƯỢNG'), (180.0, -28.5, 2.5, '(kg)'),
    ]:
        dxf.text(tx, ty, th, lbl, '0', 256, 1, 2)
    end_blk()

    for bcode in ('TK1', 'TK2', 'TK3', 'TK4', 'TK7', 'TK7R1', 'TK9', 'TKTUnknown'):
        start_blk(bcode)
        rh_blk = -13.5 if bcode == 'TKTUnknown' else -8.0
        yc_blk = rh_blk / 2.0
        dxf.pline([(15.0, rh_blk), (25.0, rh_blk), (75.0, rh_blk), (90.0, rh_blk),
                   (122.5, rh_blk), (135.0, rh_blk), (147.5, rh_blk), (167.5, rh_blk),
                   (192.5, rh_blk), (192.5, 0.0)], 'DCE_BaoBeTong', False)
        for vx in (0.0, 15.0, 25.0, 75.0, 90.0, 110.0, 122.5, 135.0, 147.5, 167.5):
            dxf.line(vx, 0.0, vx, rh_blk, 'DCE_BaoBeTong')
        if bcode == 'TK1':
            dxf.pline([(32.5, -6.5), (67.5, -6.5)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L', 'L', '4000', 50.0, -4.0, 2.5, 2, 1, 2)
        elif bcode == 'TK2':
            dxf.pline([(34.55, -6.5), (34.55, -2.0), (65.49, -2.0)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', 'L1', 33.18, -4.0, 2.5, 2, 2, 2)
            dxf.attdef('L2', 'L2', 'L2', 50.0, -4.26, 2.5, 2, 1, 2)
        elif bcode == 'TK3':
            dxf.pline([(65.52, -6.5), (65.52, -2.0), (33.99, -2.0)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', 'L1', 48.94, -4.19, 2.5, 2, 1, 2)
            dxf.attdef('L2', 'L2', 'L2', 67.26, -4.0, 2.5, 2, 0, 2)
        elif bcode == 'TK4':
            dxf.pline([(33.72, -6.5), (33.72, -2.0), (66.28, -2.0), (66.28, -6.5)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', 'L1', 32.68, -4.0, 2.5, 2, 2, 2)
            dxf.attdef('L2', 'L2', 'L2', 50.0, -4.0, 2.5, 2, 1, 2)
            dxf.attdef('L3', 'L3', 'L3', 67.53, -4.0, 2.5, 2, 0, 2)
        elif bcode == 'TK7':
            dxf.pline([(33.72, -2.0), (33.72, -6.5), (66.28, -6.5), (66.28, -2.0)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', 'L1', 32.68, -4.0, 2.5, 2, 2, 2)
            dxf.attdef('L2', 'L2', 'L2', 50.0, -4.0, 2.5, 2, 1, 2)
            dxf.attdef('L3', 'L3', 'L3', 67.53, -4.0, 2.5, 2, 0, 2)
        elif bcode == 'TK7R1':
            dxf.pline([(33.28, -2.8), (33.28, -7.3), (46.0, -7.3), (52.0, -4.8), (66.22, -4.8), (66.22, -0.8)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', 'L1', 31.93, -4.84, 2.5, 2, 2, 2)
            dxf.attdef('L2', 'L2', 'L2', 40.67, -4.84, 2.5, 2, 1, 2)
            dxf.attdef('L3', 'L3', 'L3', 47.45, -2.72, 2.5, 2, 0, 2)
            dxf.attdef('L4', 'L4', 'L4', 59.11, -2.72, 2.5, 2, 1, 2)
            dxf.attdef('L5', 'L5', 'L5', 67.48, -2.72, 2.5, 2, 0, 2)
        elif bcode == 'TK9':
            dxf.pline([(41.42, -7.37), (41.42, -1.7), (57.26, -1.7), (57.26, -5.81), (39.86, -5.81)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', '150', 49.34, -3.76, 2.5, 2, 1, 2)
            dxf.attdef('L2', 'L2', '350', 58.47, -3.76, 2.5, 2, 0, 2)
            dxf.attdef('M', 'M', '48', 38.78, -5.47, 2.5, 2, 2, 2)
        for tag, xatt, ha in [('SH', 20.0, 1), ('DK', 82.5, 1), ('sumL', 100.0, 1), ('SKC', 116.25, 1),
                              ('SL', 128.75, 1), ('TSL', 141.25, 1), ('Lall', 162.5, 2), ('KL', 185.5, 2)]:
            dxf.attdef(tag, tag, tag, xatt, yc_blk, 2.5, 2, ha, 2)
        end_blk()

    # ENTITIES SECTION (emit entities into dxf.buf so *D* anonymous dim blocks also accumulate before finalizing TABLES/BLOCKS)
    dxf.set_target('entities')
    base_y = 0.0
    last_beam_bottom_y = 0.0
    el_sec_gap = max(800.0, 500.0 * k_elev, 500.0 * k_sec)
    beam_gap = max(1200.0, 750.0 * k_elev, 750.0 * k_sec)
    sched = []
    stir_col = _pick_stir_col(nhip, nhip_cp, 34)
    level_label = '%s%.3f' % ('+' if level_z >= 0 else '', level_z / 1000.0)

    def _emit_rebar_tag_leader(x_bar, y_bar, x_end, y_tag, sh_s, txt_main, txt_sub, sc_val,
                               dir_left, dimstyle_name=elev_ds, arrow_blk='tick', xdata=None):
        dxf.leader([(x_bar, y_bar), (x_bar, y_tag), (x_end, y_tag)], 'DCE_Dim', dimstyle_name, 1 if arrow_blk else 0, xdata_app=xdata)
        if dir_left:
            dxf.insert('Dce_KhtMcThepChu_L', x_end, y_tag, sc_val, sc_val, 'DCE_Block', [
                ('SH', sh_s, -2.5, 0.0, 2.0, 11, 1, 2, '0'),
                ('DKVAKC', txt_main, 0.54, 1.0, 2.0, 3, 0, 0, '0'),
                ('DKVAKC2', txt_sub, 0.54, -2.6, 2.0, 3, 0, 0, '0'),
            ], xdata=xdata)
        else:
            dxf.insert('Dce_KhtMcThepChu_R', x_end, y_tag, sc_val, sc_val, 'DCE_Block', [
                ('SH', sh_s, 2.5, 0.0, 2.0, 11, 1, 2, '0'),
                ('DKVAKC', txt_main, -0.54, 1.0, 2.0, 3, 2, 0, '0'),
                ('DKVAKC2', txt_sub, -0.54, -2.6, 2.0, 3, 2, 0, '0'),
            ], xdata=xdata)

    def _emit_dim_row(segs_in, dy_line, layer='DCE_Dim', dim_scale=50.0, dimstyle=None, above_beam=True):
        """Emit a horizontal chain of DIMENSIONs, pulling clashing narrow dims left/right (or staggering) so zero texts overlap."""
        if not segs_in:
            return
        k_d = float(dim_scale) / 50.0
        items = []
        for s_item in segs_in:
            x1, y1, x2, y2 = float(s_item[0]), float(s_item[1]), float(s_item[2]), float(s_item[3])
            ovr = s_item[4] if len(s_item) > 4 else ''
            xa, xb = (x1, x2) if x1 <= x2 else (x2, x1)
            ya, yb = (y1, y2) if x1 <= x2 else (y2, y1)
            w = xb - xa
            if w < 1.0 and not ovr:
                continue
            disp = ovr if ovr else str(int(round(w)))
            tw = max(145.0 * k_d, (len(disp) * 58.0 + 44.0) * k_d)
            items.append({'xa': xa, 'ya': ya, 'xb': xb, 'yb': yb, 'w': w, 'ovr': ovr, 'tw': tw, 'cx': 0.5 * (xa + xb)})
        items.sort(key=lambda it: (it['xa'], it['xb']))
        n_it = len(items)
        if n_it == 0:
            return
        base_ty = dy_line + 2.0 * float(dim_scale)
        tick_pad = 36.0 * k_d
        gap_txt = 24.0 * k_d
        stagger_step = (155.0 * k_d) if above_beam else (-155.0 * k_d)
        txs = [it['cx'] for it in items]
        tys = [base_ty for _ in items]

        # Identify clashing / narrow clusters and pull 2 dims outward or 1 narrow dim to free side
        placed_boxes = []  # (x0, x1, ty)

        def _box_ok(tx_c, ty_c, tw_c, ignore_idx=None):
            bx0, bx1 = tx_c - tw_c * 0.5 - gap_txt * 0.5, tx_c + tw_c * 0.5 + gap_txt * 0.5
            for pi, (px0, px1, py) in enumerate(placed_boxes):
                if ignore_idx is not None and pi == ignore_idx:
                    continue
                if abs(py - ty_c) < 110.0 * k_d and not (bx1 <= px0 or bx0 >= px1):
                    return False
            return True

        i = 0
        while i < n_it:
            it = items[i]
            narrow_i = (it['w'] < it['tw'] + 2.0 * tick_pad)
            clash_prev = (i > 0 and abs(txs[i] - txs[i - 1]) < 0.5 * (it['tw'] + items[i - 1]['tw']) + gap_txt)
            clash_next = (i + 1 < n_it and abs(txs[i] - txs[i + 1]) < 0.5 * (it['tw'] + items[i + 1]['tw']) + gap_txt)
            if not (narrow_i or clash_prev or clash_next):
                placed_boxes.append((txs[i] - it['tw'] * 0.5, txs[i] + it['tw'] * 0.5, tys[i]))
                i += 1
                continue
            # Collect maximal contiguous narrow/clashing run [i..j]
            j = i
            while j + 1 < n_it:
                nxt = items[j + 1]
                cur = items[j]
                nxt_narrow = (nxt['w'] < nxt['tw'] + 2.0 * tick_pad)
                pair_clash = abs(cur['cx'] - nxt['cx']) < 0.5 * (cur['tw'] + nxt['tw']) + gap_txt
                if nxt_narrow or pair_clash:
                    j += 1
                else:
                    break

            run_len = j - i + 1
            left_limit = -1e12 if i == 0 else (txs[i - 1] + items[i - 1]['tw'] * 0.5 + gap_txt)
            right_limit = 1e12 if j + 1 >= n_it else (items[j + 1]['cx'] - items[j + 1]['tw'] * 0.5 - gap_txt)
            # Also ensure wide neighbor right/left margin stays clear of its own ticks
            if run_len == 1:
                c_left = it['xa'] - it['tw'] * 0.5 - tick_pad
                c_right = it['xb'] + it['tw'] * 0.5 + tick_pad
                if c_left - it['tw'] * 0.5 >= left_limit and (i == 0 or items[i - 1]['w'] >= items[i - 1]['tw'] + 2.0 * tick_pad):
                    txs[i] = c_left
                elif c_right + it['tw'] * 0.5 <= right_limit:
                    txs[i] = c_right
                elif c_left - it['tw'] * 0.5 >= left_limit:
                    txs[i] = c_left
                else:
                    tys[i] = base_ty + stagger_step
            else:
                # Pull outer ends of the run outward to opposite sides ("kéo 2 dim sang 2 bên")
                first_it, last_it = items[i], items[j]
                f_left = first_it['xa'] - first_it['tw'] * 0.5 - tick_pad
                l_right = last_it['xb'] + last_it['tw'] * 0.5 + tick_pad
                if f_left - first_it['tw'] * 0.5 >= left_limit:
                    txs[i] = f_left
                else:
                    tys[i] = base_ty + stagger_step
                if l_right + last_it['tw'] * 0.5 <= right_limit:
                    txs[j] = l_right
                else:
                    tys[j] = base_ty + (2.0 * stagger_step if tys[i] != base_ty else stagger_step)

                # Place any interior items (i+1 .. j-1) cleanly without colliding with already-placed txs[i], txs[j]
                for m_idx in range(i + 1, j):
                    mit = items[m_idx]
                    cand_tx = mit['cx']
                    cand_ty = base_ty
                    # Check collision against placed_boxes + endpoints of this run
                    local_boxes = list(placed_boxes)
                    local_boxes.append((txs[i] - first_it['tw'] * 0.5, txs[i] + first_it['tw'] * 0.5, tys[i]))
                    local_boxes.append((txs[j] - last_it['tw'] * 0.5, txs[j] + last_it['tw'] * 0.5, tys[j]))
                    for prev_m in range(i + 1, m_idx):
                        local_boxes.append((txs[prev_m] - items[prev_m]['tw'] * 0.5, txs[prev_m] + items[prev_m]['tw'] * 0.5, tys[prev_m]))

                    def _ok_local(xc, yc, twc):
                        bx0, bx1 = xc - twc * 0.5 - gap_txt * 0.5, xc + twc * 0.5 + gap_txt * 0.5
                        return all(abs(yc - py) >= 110.0 * k_d or bx1 <= px0 or bx0 >= px1 for px0, px1, py in local_boxes)

                    if not _ok_local(cand_tx, cand_ty, mit['tw']):
                        for step_mul in (1, -1, 2, -2):
                            test_ty = base_ty + step_mul * stagger_step
                            if _ok_local(cand_tx, test_ty, mit['tw']):
                                cand_ty = test_ty
                                break
                    txs[m_idx] = cand_tx
                    tys[m_idx] = cand_ty

            for k_r in range(i, j + 1):
                rk = items[k_r]
                placed_boxes.append((txs[k_r] - rk['tw'] * 0.5, txs[k_r] + rk['tw'] * 0.5, tys[k_r]))
            i = j + 1

        for idx_it, it in enumerate(items):
            tx, ty = txs[idx_it], tys[idx_it]
            is_moved = (abs(tx - it['cx']) > 1.0 or abs(ty - base_ty) > 1.0)
            dxf.dim(
                it['xa'], it['ya'], it['xb'], it['yb'],
                0.0, dy_line, layer, float(dim_scale),
                dimstyle=dimstyle, text_override=it['ovr'], rot_deg=0.0,
                txt_xy=(tx, ty) if is_moved else None,
                dimtmove=1 if abs(ty - base_ty) > 5.0 else 2,
            )

    base_br_len = len(dxf.block_records)
    base_dim_idx = dxf.dim_idx

    beam_modes_map = beam_modes or {}
    c_mode_col = _find_col_idx(nhip_cp, _MODE_COL_ALIASES, 9)
    c_mode_cols = _find_all_col_idxs(nhip_cp, _MODE_COL_ALIASES) or ([c_mode_col] if c_mode_col is not None else [])
    c_lvl_col = _find_col_idx(nhip_cp, [u'Cao độ tầng (mm)', 'Cao do tang (mm)', u'Cao độ tầng', 'Cao do tang'])

    for b_idx_ord, bname in enumerate(order):
        rows = beams_raw[bname]
        beam_lvl_z = level_z
        if c_lvl_col is not None and c_lvl_col < len(rows[0]) and sstr(rows[0][c_lvl_col]) != '':
            beam_lvl_z = num(rows[0][c_lvl_col], level_z)
        beam_level_label = '%s%.3f' % ('+' if beam_lvl_z >= 0 else '', beam_lvl_z / 1000.0)
        sl_ck = max(1, int(round(num(gc(rows[0], ['SL', u'Số lượng'], 1), 1))))
        row_mc_flag = any(
            _is_mc_only_token(r[cm_i] if (cm_i is not None and cm_i < len(r)) else '')
            for r in rows
            for cm_i in c_mode_cols
        )
        if bname in beam_modes_map:
            beam_mode = 'MC_ONLY' if beam_modes_map[bname] == 'MC_ONLY' else 'FULL'
        else:
            beam_mode = 'MC_ONLY' if row_mc_flag else 'FULL'
        is_mc_only = (beam_mode == 'MC_ONLY')

        sups, spans = [], []
        sx0, fl, fr = [], [], []
        cx = 0.0
        for k, r in enumerate(rows):
            if k == 0:
                raw_gw = gc(r, [u'Gối trái (mm)', u'Gối T (mm)', u'Gối trái'], 4)
                gw = 220.0 if (raw_gw is None or sstr(raw_gw) == '') else max(0.0, num(raw_gw, 220.0))
                kind_l = sstr(gc(r, [u'Loại gối T', u'Loại GT'], 5), 'C' if gw > 0.5 else '')
                role_l = sstr(gc(r, [u'Vai trò gối T', u'Vai trò GT'], 26), '')
                sups.append({
                    'w': gw,
                    'kind': kind_l,
                    'grid': sstr(gc(r, [u'Trục T', u'Trục trái'], 6), ''),
                    'off': num(gc(r, [u'Lệch trục T (mm)', u'Lệch trục T'], 7), 0.0),
                    'role': role_l,
                })
                sx0.append(cx)
                cx += gw
            cl = max(200.0, num(gc(r, [u'L thông thủy (mm)', u'L thông thủy', u'Nhịp (mm)'], 8), 3000.0))
            fl.append(cx)
            cx += cl
            fr.append(cx)
            bw = max(80.0, num(gc(r, ['b (mm)', 'b'], 14), 200.0))
            bh = max(80.0, num(gc(r, ['h (mm)', 'h'], 15), 400.0))
            topZ = num(gc(r, [u'Cao đỉnh (mm)', u'Cao đỉnh'], 16), 0.0)
            hs = max(0.0, num(gc(r, [u'h sàn (mm)', u'h sàn'], 17), 0.0))
            raw_sbL = gc(r, [u'Sàn T dày (mm)', u'Sàn T dày'], 18)
            sbL = hs if (raw_sbL is None or sstr(raw_sbL) == '') else max(0.0, num(raw_sbL, hs))
            sbL_top = num(gc(r, [u'Sàn T đỉnh (mm)', u'Sàn T đỉnh'], 19), topZ)
            raw_sbR = gc(r, [u'Sàn P dày (mm)', u'Sàn P dày'], 20)
            sbR = hs if (raw_sbR is None or sstr(raw_sbR) == '') else max(0.0, num(raw_sbR, hs))
            sbR_top = num(gc(r, [u'Sàn P đỉnh (mm)', u'Sàn P đỉnh'], 21), topZ)
            stir_s = sstr(r[stir_col] if (stir_col is not None and stir_col < len(r)) else '6-100/200', '6-100/200') or '6-100/200'
            planted_raw = sstr(gc(r, _PLANTED_COL_ALIASES, 29), '')
            pl_list = _parse_planted_str(planted_raw)
            spans.append({
                'clear': cl, 'b': bw, 'h': bh, 'top': topZ,
                'slabL': sbL, 'slabL_top': sbL_top, 'slabR': sbR, 'slabR_top': sbR_top,
                'stir': stir_s, 'planted': pl_list,
            })
            raw_gwr = gc(r, [u'Gối phải (mm)', u'Gối P (mm)', u'Gối phải'], 10)
            gw_r = 220.0 if (raw_gwr is None or sstr(raw_gwr) == '') else max(0.0, num(raw_gwr, 220.0))
            kind_r = sstr(gc(r, [u'Loại gối P', u'Loại GP'], 11), 'C' if gw_r > 0.5 else '')
            role_r = sstr(gc(r, [u'Vai trò gối P', u'Vai trò GP'], 28), '')
            sups.append({
                'w': gw_r,
                'kind': kind_r,
                'grid': sstr(gc(r, [u'Trục P', u'Trục phải'], 12), ''),
                'off': num(gc(r, [u'Lệch trục P (mm)', u'Lệch trục P'], 13), 0.0),
                'role': role_r,
            })
            sx0.append(cx)
            cx += gw_r

        # Only synthesize 1, 2, ... if the sheet didn't specify any grid axis names at all
        if not any(sstr(su['grid']) for su in sups):
            g_auto = 1
            for su in sups:
                if su['w'] > 0.5:
                    su['grid'] = str(g_auto)
                    g_auto += 1

        grps = groups_map.get(bname) or [
            {'pos': u'Trên', 'layer': 1, 'n': 2, 'd': 18, 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': len(spans), 'rk': u'Gập vào cột', 'rv': u'xuống', 'cross': u'Tự động', 'note': ''},
            {'pos': u'Dưới', 'layer': 1, 'n': 2, 'd': 18, 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': len(spans), 'rk': u'Gập vào cột', 'rv': u'xuống', 'cross': u'Tự động', 'note': ''},
        ]
        meta_chunks = _pack_beam_meta_xdata(bname, sl_ck, beam_mode, sups, spans, grps, opt)

        maxtop = max([s['top'] for s in spans] or [0.0])
        lay = {'n': len(spans), 'sx0': sx0, 'fl': fl, 'fr': fr, 'L': cx, 'maxtop': maxtop}
        to_cad_y = lambda yd: base_y - yd
        beam_bot_y = base_y - max(maxtop - s['top'] + s['h'] for s in spans)

        # 1. Concrete spans + hidden slab soffit / stepped slab top (layer 3 HIDDEN2) + free cantilever closing edge
        max_slab_top_cad = base_y
        for i, sp in enumerate(spans):
            ty = to_cad_y(maxtop - sp['top'])
            by = to_cad_y(maxtop - sp['top'] + sp['h'])
            if not is_mc_only:
                dxf.line(fl[i], ty, fr[i], ty, 'DCE_BaoBeTong')
                dxf.line(fl[i], by, fr[i], by, 'DCE_BaoBeTong')
            drawn_slab_y = set()
            for sb_th, sb_tp in ((sp['slabL'], sp['slabL_top']), (sp['slabR'], sp['slabR_top'])):
                if sb_th > 0:
                    st_y = to_cad_y(maxtop - sb_tp)
                    sb_y = st_y - sb_th
                    max_slab_top_cad = max(max_slab_top_cad, st_y)
                    if not is_mc_only:
                        key_sb = int(round(sb_y))
                        if key_sb not in drawn_slab_y:
                            drawn_slab_y.add(key_sb)
                            dxf.line(fl[i], sb_y, fr[i], sb_y, '3')
                        if abs(sb_tp - sp['top']) > 1.0:
                            key_st = ('top', int(round(st_y)))
                            if key_st not in drawn_slab_y:
                                drawn_slab_y.add(key_st)
                                dxf.line(fl[i], st_y, fr[i], st_y, '3')
        if not is_mc_only and sups and sups[0]['w'] <= 0.5 and spans:
            ty0 = to_cad_y(maxtop - spans[0]['top'])
            by0 = to_cad_y(maxtop - spans[0]['top'] + spans[0]['h'])
            dxf.line(fl[0], by0, fl[0], ty0, 'DCE_BaoBeTong')
        if not is_mc_only and sups and sups[-1]['w'] <= 0.5 and spans:
            tyn = to_cad_y(maxtop - spans[-1]['top'])
            byn = to_cad_y(maxtop - spans[-1]['top'] + spans[-1]['h'])
            dxf.line(fr[-1], byn, fr[-1], tyn, 'DCE_BaoBeTong')

        # 2. Longitudinal rebar + LEADER tags close to beam + TC cut bar dimensions (rounded 50mm)
        sx_top = max(base_y + 180.0 * k_elev, max_slab_top_cad + 90.0 * k_elev)
        sx_bot = beam_bot_y - 180.0 * k_elev

        col_boxes = []
        sup_x_bands = []
        grid_axes = []
        if not is_mc_only:
            for k_c, su_c in enumerate(sups):
                if su_c['w'] > 0.5:
                    cx0_c, cx1_c = sx0[k_c], sx0[k_c] + su_c['w']
                    sup_x_bands.append((cx0_c, cx1_c))
                    if _is_col_sup(su_c):
                        col_boxes.append((cx0_c, sx_bot - 20.0 * k_elev, cx1_c, sx_top + 20.0 * k_elev))
                if sstr(su_c.get('grid')):
                    grid_axes.append(sx0[k_c] + su_c['w'] * 0.5 + su_c.get('off', 0.0))
            for i_sp_c, sp_c in enumerate(spans):
                ty_sp_c = to_cad_y(maxtop - sp_c['top'])
                for q_c in (sp_c.get('planted') or []):
                    pw_c = max(80.0, float(q_c.get('w') or 250.0))
                    xm_c = fl[i_sp_c] + float(q_c.get('pos') or 0.0)
                    px0_c, px1_c = xm_c - pw_c * 0.5, xm_c + pw_c * 0.5
                    col_boxes.append((px0_c, ty_sp_c, px1_c, sx_top + 20.0 * k_elev))
                    sup_x_bands.append((px0_c, px1_c))
            sup_x_bands.sort()

        sh_i = 1
        bars_built = []
        placed_top_boxes = []
        placed_bot_boxes = []
        placed_mid_boxes = []
        used_top_mx = []
        used_bot_mx = []
        used_mid_mx = []
        tc_top_dims = []
        tc_bot_dims = []
        seen_tc_dims = set()
        max_top_tag_y = base_y + 180.0 * k_elev
        min_bot_tag_y = beam_bot_y - 180.0 * k_elev

        def _gen_mx_candidates(seg_a, seg_b, used_mxs):
            xa, xb = min(seg_a[0], seg_b[0]), max(seg_a[0], seg_b[0])
            bar_len = max(1.0, xb - xa)
            pad_edge = min(65.0, bar_len * 0.14)
            x_lo, x_hi = xa + pad_edge, xb - pad_edge
            if x_hi <= x_lo:
                x_lo, x_hi = xa, xb
            open_ivs = [(x_lo, x_hi)]
            pad_sup = 45.0 * k_elev
            for bx0_s, bx1_s in sup_x_bands:
                blo, bhi = bx0_s - pad_sup, bx1_s + pad_sup
                next_ivs = []
                for u0, u1 in open_ivs:
                    if bhi <= u0 or blo >= u1:
                        next_ivs.append((u0, u1))
                    else:
                        if blo > u0:
                            next_ivs.append((u0, blo))
                        if bhi < u1:
                            next_ivs.append((bhi, u1))
                open_ivs = next_ivs
            open_ivs = [(u0, u1) for u0, u1 in open_ivs if (u1 - u0) >= 30.0]

            raw_cands = []
            x_mid_all = 0.5 * (xa + xb)
            for u0, u1 in open_ivs:
                w_iv = u1 - u0
                pts_iv = []
                for fr_k in (0.50, 0.35, 0.65, 0.22, 0.78, 0.12, 0.88):
                    pts_iv.append(u0 + fr_k * w_iv)
                if w_iv > 650.0 * k_elev:
                    step_g = 320.0 * k_elev
                    xg = u0 + 180.0 * k_elev
                    while xg < u1 - 180.0 * k_elev:
                        pts_iv.append(xg)
                        xg += step_g
                seen_iv = set()
                for xv in pts_iv:
                    if w_iv >= 60.0:
                        xv = max(u0 + 20.0, min(u1 - 20.0, xv))
                    kx = int(round(xv / 15.0))
                    if kx not in seen_iv:
                        seen_iv.add(kx)
                        raw_cands.append((xv, u0, u1, False))

            if not raw_cands:
                for fr_k in (0.50, 0.30, 0.70):
                    raw_cands.append((xa + fr_k * bar_len, xa, xb, True))

            def _cand_score(item):
                xv, u0, u1, in_col = item
                d_used = min([abs(xv - um) for um in used_mxs] or [9999.0])
                clear_used = 0 if d_used >= 160.0 * k_elev else 1
                d_grid = min([abs(xv - gx) for gx in grid_axes] or [9999.0])
                near_grid = 0 if d_grid >= 110.0 * k_elev else 1
                w_iv = max(1.0, u1 - u0)
                off_mid = abs(xv - 0.5 * (u0 + u1)) / w_iv
                off_bar = abs(xv - x_mid_all) / max(1.0, bar_len)
                return (1 if in_col else 0, clear_used, near_grid, -d_used if clear_used else 0.0, -min(w_iv, 2500.0), off_mid + 0.25 * off_bar)

            raw_cands.sort(key=_cand_score)
            return raw_cands

        def _tag_bbox(mx_val, y_val, dl, tag_leg):
            tx_val = (mx_val - tag_leg) if dl else (mx_val + tag_leg)
            if dl:
                bx0 = tx_val - 260.0 * k_elev
                bx1 = mx_val + 35.0 * k_elev
            else:
                bx0 = mx_val - 35.0 * k_elev
                bx1 = tx_val + 260.0 * k_elev
            return tx_val, bx0, y_val - 135.0 * k_elev, bx1, y_val + 175.0 * k_elev

        def _hits_boxes(bx0, by0, bx1, by1, boxes, padx=10.0, pady=10.0):
            return any(not (bx1 + padx < x0 or bx0 - padx > x1 or by1 + pady < y0 or by0 - pady > y1) for x0, y0, x1, y1 in boxes)

        def _stem_hits_cols(mx_val, y_bar, y_tag, padx):
            sy_lo, sy_hi = min(y_bar, y_tag), max(y_bar, y_tag)
            return any((cx0 - padx <= mx_val <= cx1 + padx) and not (sy_hi < cy0 or sy_lo > cy1) for cx0, cy0, cx1, cy1 in col_boxes)

        def _hits_grid(bx0, bx1, padx):
            return any(bx0 - padx <= gx <= bx1 + padx for gx in grid_axes)

        def _dir_order(mx_val, u0, u1, sh_num):
            room_l = mx_val - u0
            room_r = u1 - mx_val
            if abs(room_l - room_r) > 120.0 * k_elev:
                pref = (room_l > room_r)
            else:
                pref = (mx_val > cx * 0.5) if (sh_num % 2 == 1) else (mx_val <= cx * 0.5)
            return (pref, not pref)

        def _alloc_tag_smart(seg_a, seg_b, my_val, is_top, layer_i, tag_leg, sh_num):
            boxes = placed_top_boxes if is_top else placed_bot_boxes
            used_mxs = used_top_mx if is_top else used_bot_mx
            y_start = (base_y + (200.0 + (layer_i - 1) * 235.0) * k_elev) if is_top else (beam_bot_y - (210.0 + (layer_i - 1) * 235.0) * k_elev)
            step = 235.0 * k_elev
            cands = _gen_mx_candidates(seg_a, seg_b, used_mxs)
            col_padx = 40.0 * k_elev
            col_pady = 25.0 * k_elev
            stem_pad = 30.0 * k_elev
            box_pad = 12.0 * k_elev
            grid_pad = 25.0 * k_elev

            for lane in range(16):
                y_try = (y_start + lane * step) if is_top else (y_start - lane * step)
                for strict_grid in (True, False):
                    for mx_c, u0, u1, in_col in cands:
                        if in_col:
                            continue
                        if strict_grid and any(abs(mx_c - um) < 120.0 * k_elev for um in used_mxs):
                            continue
                        if _stem_hits_cols(mx_c, my_val, y_try, stem_pad):
                            continue
                        for dl in _dir_order(mx_c, u0, u1, sh_num):
                            tx_try, bx0, by0, bx1, by1 = _tag_bbox(mx_c, y_try, dl, tag_leg)
                            if _hits_boxes(bx0, by0, bx1, by1, boxes, box_pad, box_pad):
                                continue
                            if _hits_boxes(bx0, by0, bx1, by1, col_boxes, col_padx, col_pady):
                                continue
                            if strict_grid and _hits_grid(bx0, bx1, grid_pad):
                                continue
                            boxes.append((bx0, by0, bx1, by1))
                            used_mxs.append(mx_c)
                            return mx_c, y_try, tx_try, dl

            # Fallback pass (when bar is narrower than column or extremely crowded): lift clear of columns
            for lane in range(16):
                y_try = (y_start + lane * step) if is_top else (y_start - lane * step)
                for mx_c, u0, u1, _ in cands:
                    for dl in _dir_order(mx_c, u0, u1, sh_num):
                        tx_try, bx0, by0, bx1, by1 = _tag_bbox(mx_c, y_try, dl, tag_leg)
                        if _hits_boxes(bx0, by0, bx1, by1, boxes, box_pad, box_pad):
                            continue
                        if _hits_boxes(bx0, by0, bx1, by1, col_boxes, col_padx, col_pady):
                            continue
                        boxes.append((bx0, by0, bx1, by1))
                        used_mxs.append(mx_c)
                        return mx_c, y_try, tx_try, dl

            mx_fb = cands[0][0]
            y_fb = (y_start + 16 * step) if is_top else (y_start - 16 * step)
            dl_fb = _dir_order(mx_fb, cands[0][1], cands[0][2], sh_num)[0]
            tx_fb, bx0, by0, bx1, by1 = _tag_bbox(mx_fb, y_fb, dl_fb, tag_leg)
            boxes.append((bx0, by0, bx1, by1))
            used_mxs.append(mx_fb)
            return mx_fb, y_fb, tx_fb, dl_fb

        def _alloc_mid_tag_smart(seg_a, seg_b, my_val, tag_leg, sh_num):
            cands = _gen_mx_candidates(seg_a, seg_b, used_mid_mx)
            col_padx = 40.0 * k_elev
            col_pady = 25.0 * k_elev
            stem_pad = 30.0 * k_elev
            box_pad = 12.0 * k_elev
            y_offsets = [145.0 * k_elev, -145.0 * k_elev, 85.0 * k_elev, -85.0 * k_elev]
            for check_beam_bounds in (True, False):
                for dy_off in y_offsets:
                    y_try = my_val + dy_off
                    for mx_c, u0, u1, in_col in cands:
                        if in_col or _stem_hits_cols(mx_c, my_val, y_try, stem_pad):
                            continue
                        for dl in _dir_order(mx_c, u0, u1, sh_num):
                            tx_try, bx0, by0, bx1, by1 = _tag_bbox(mx_c, y_try, dl, tag_leg)
                            if check_beam_bounds and (by0 < beam_bot_y + 20.0 or by1 > base_y - 20.0):
                                continue
                            if _hits_boxes(bx0, by0, bx1, by1, placed_mid_boxes, box_pad, box_pad):
                                continue
                            if _hits_boxes(bx0, by0, bx1, by1, col_boxes, col_padx, col_pady):
                                continue
                            placed_mid_boxes.append((bx0, by0, bx1, by1))
                            used_mid_mx.append(mx_c)
                            return mx_c, y_try, tx_try, dl, None
            # Span too narrow to fit tag inside beam web without touching columns -> lift cleanly above/below columns
            use_top = (len(placed_top_boxes) <= len(placed_bot_boxes))
            mx_res, y_res, tx_res, dl_res = _alloc_tag_smart(seg_a, seg_b, my_val, use_top, 1, tag_leg, sh_num)
            return mx_res, y_res, tx_res, dl_res, ('top' if use_top else 'bot')

        def _add_tc_dim(pos_s, x_face, x_bar, y_bar):
            xa, xb = min(x_face, x_bar), max(x_face, x_bar)
            if xb - xa < 50.0:
                return
            dk_key = (pos_s, int(round(xa / 10.0)), int(round(xb / 10.0)))
            if dk_key in seen_tc_dims:
                return
            seen_tc_dims.add(dk_key)
            if pos_s == u'Dưới':
                tc_bot_dims.append((xa, xb, y_bar))
            else:
                tc_top_dims.append((xa, xb, y_bar))

        n_spans = len(spans)
        for g in grps:
            polys = build_group_polylines(g, spans, sups, lay, opt, grps)
            n_poly = len(polys)
            for p_idx, pts in enumerate(polys):
                raw_cad_pts = [(px, to_cad_y(py)) for px, py in pts]
                shp, l1, l2, l3, l4, l5, sumL = classify_poly(pts)
                sh_s = str(sh_i)
                bars_built.append({'sh': sh_s, 'pos': g['pos'], 'layer': g['layer'], 'n': g['n'], 'd': g['d'], 'pts': pts})

                if not is_mc_only:
                    bent_pts = _bend_cad_polyline(raw_cad_pts, g['pos'])
                    xd_rebar = ('BeamCAD_LINK', ['REBAR', bname, sh_s, int(g['n']), int(g['d']), sstr(g['pos'])])
                    xd_tag = ('BeamCAD_LINK', ['TAG_BAR', bname, sh_s, int(g['n']), int(g['d']), sstr(g['pos'])])
                    dxf.pline(bent_pts, 'DCE_ThepChu', False, xdata_app=xd_rebar)

                    # Record TC/cut dimensions for cut/extended ends (skip if promoted inside support)
                    a_i, b_i = int(g['a']), int(g['b'])
                    if p_idx == 0 and g['lk'] == u'Cắt trong nhịp' and 0 <= a_i < n_spans and raw_cad_pts[0][0] > fl[a_i] + 50.0:
                        _add_tc_dim(g['pos'], fl[a_i], raw_cad_pts[0][0], raw_cad_pts[0][1])
                    elif p_idx == 0 and g['lk'] == u'Kéo dài ra nhịp' and 0 < a_i <= n_spans and raw_cad_pts[0][0] < sx0[a_i] - 50.0:
                        _add_tc_dim(g['pos'], sx0[a_i], raw_cad_pts[0][0], raw_cad_pts[0][1])
                    if p_idx == n_poly - 1 and g['rk'] == u'Cắt trong nhịp' and 0 < b_i <= n_spans and raw_cad_pts[-1][0] < fr[b_i - 1] - 50.0:
                        _add_tc_dim(g['pos'], fr[b_i - 1], raw_cad_pts[-1][0], raw_cad_pts[-1][1])
                    elif p_idx == n_poly - 1 and g['rk'] == u'Kéo dài ra nhịp' and 0 <= b_i < n_spans and raw_cad_pts[-1][0] > sx0[b_i] + sups[b_i]['w'] + 50.0:
                        _add_tc_dim(g['pos'], sx0[b_i] + sups[b_i]['w'], raw_cad_pts[-1][0], raw_cad_pts[-1][1])

                    best_seg = max(zip(raw_cad_pts[:-1], raw_cad_pts[1:]), key=lambda ab: abs(ab[1][0] - ab[0][0]))
                    my = (best_seg[0][1] + best_seg[1][1]) / 2.0
                    spec_txt = '%d%%%%c%d' % (g['n'], g['d'])
                    vis_len = len('%dØ%d' % (g['n'], g['d']))
                    tag_leg = max(375.0, 210.0 + vis_len * 40.0) * k_elev
                    if g['pos'] == u'Trên':
                        mx, tagY, tagX, dir_left = _alloc_tag_smart(best_seg[0], best_seg[1], my, True, g['layer'], tag_leg, sh_i)
                        max_top_tag_y = max(max_top_tag_y, tagY)
                    elif g['pos'] == u'Dưới':
                        mx, tagY, tagX, dir_left = _alloc_tag_smart(best_seg[0], best_seg[1], my, False, g['layer'], tag_leg, sh_i)
                        min_bot_tag_y = min(min_bot_tag_y, tagY)
                    else:
                        mx, tagY, tagX, dir_left, mid_side = _alloc_mid_tag_smart(best_seg[0], best_seg[1], my, tag_leg, sh_i)
                        if mid_side == 'top':
                            max_top_tag_y = max(max_top_tag_y, tagY)
                        elif mid_side == 'bot':
                            min_bot_tag_y = min(min_bot_tag_y, tagY)
                    _emit_rebar_tag_leader(mx, my, tagX, tagY, sh_s, spec_txt, '', s_elev, dir_left, elev_ds, 'tick', xdata=xd_tag)
                sched.append((bname, sh_s, shp, l1, l2, l3, l4, l5, 0, g['d'], sumL, sl_ck, g['n'],
                              raw_cad_pts if shp == 'TKTUnknown' else None))
                sh_i += 1


        # Emit TC cut bar dimensions (non-overlapping per lane, clear of tags)
        tc_top_lanes = []
        max_tc_top_y = sx_top + 40.0 * k_elev
        min_tc_bot_y = sx_bot - 40.0 * k_elev
        if not is_mc_only:
            for xa, xb, y_bar in tc_top_dims:
                lane_i = 0
                while lane_i < len(tc_top_lanes):
                    if not any(not (xb + 140.0 * k_elev < la - 140.0 * k_elev or xa - 140.0 * k_elev > lb + 140.0 * k_elev) for la, lb, _ in tc_top_lanes[lane_i]):
                        break
                    lane_i += 1
                if lane_i == len(tc_top_lanes):
                    tc_top_lanes.append([])
                tc_top_lanes[lane_i].append((xa, xb, y_bar))
            for lane_i, lane_items in enumerate(tc_top_lanes):
                dy_tc = max(sx_top + 95.0 * k_elev, max_top_tag_y + 190.0 * k_elev) + lane_i * 245.0 * k_elev
                max_tc_top_y = max(max_tc_top_y, dy_tc + 160.0 * k_elev)
                _emit_dim_row([(xa, y_bar, xb, y_bar) for xa, xb, y_bar in lane_items], dy_tc, 'DCE_Dim', float(s_elev), elev_ds, above_beam=True)

            tc_bot_lanes = []
            for xa, xb, y_bar in tc_bot_dims:
                lane_i = 0
                while lane_i < len(tc_bot_lanes):
                    if not any(not (xb + 140.0 * k_elev < la - 140.0 * k_elev or xa - 140.0 * k_elev > lb + 140.0 * k_elev) for la, lb, _ in tc_bot_lanes[lane_i]):
                        break
                    lane_i += 1
                if lane_i == len(tc_bot_lanes):
                    tc_bot_lanes.append([])
                tc_bot_lanes[lane_i].append((xa, xb, y_bar))
            for lane_i, lane_items in enumerate(tc_bot_lanes):
                dy_tc = min(sx_bot - 95.0 * k_elev, min_bot_tag_y - 190.0 * k_elev) - lane_i * 245.0 * k_elev
                min_tc_bot_y = min(min_tc_bot_y, dy_tc - 130.0 * k_elev)
                _emit_dim_row([(xa, y_bar, xb, y_bar) for xa, xb, y_bar in lane_items], dy_tc, 'DCE_Dim', float(s_elev), elev_ds, above_beam=False)

        # 3. Stirrup zones + TK9 + place stirrup tags STRICTLY BELOW top_dim_y
        zones = []
        for i, sp in enumerate(spans):
            sd, sa1, sa2 = parse_stir_spec(sp['stir'])
            if sp['clear'] < opt['short'] or sa1 == sa2:
                zones.append((fl[i], fr[i], sd, min(sa1, sa2), i))
            else:
                zl = min(_round_cut_50(sp['clear'] / 4.0), round(sp['clear'] * 0.35))
                zones.append((fl[i], fl[i] + zl, sd, sa1, i))
                zones.append((fl[i] + zl, fr[i] - zl, sd, sa2, i))
                zones.append((fr[i] - zl, fr[i], sd, sa1, i))

        stir_buckets = {}
        stir_bucket_order = []
        for x0z, x1z, zd, za, sp_i in zones:
            sp = spans[sp_i]
            l1s = max(80, int(round(sp['b'] - 2 * opt['cover'] + 10)))
            l2s = max(120, int(round(sp['h'] - 2 * opt['cover'] + 10)))
            cnt_s = max(1, int((x1z - x0z) // max(50, za)) + 1)
            key = (zd, l1s, l2s)
            if key not in stir_buckets:
                stir_buckets[key] = [zd, l1s, l2s, 0]
                stir_bucket_order.append(key)
            stir_buckets[key][3] += cnt_s
        stir_sh_map = {}
        for key in stir_bucket_order:
            zd, l1s, l2s, cnt_s = stir_buckets[key]
            ms = max(48, 6 * zd)
            sh_s_stir = str(sh_i)
            stir_sh_map[key] = sh_s_stir
            sched.append((bname, sh_s_stir, 'TK9', l1s, l2s, 0, 0, 0, ms, zd, 2 * (l1s + l2s) + 2 * ms, sl_ck, cnt_s, None))
            sh_i += 1

        # Anti-bulge horizontal C-crosstie ('đai C chống phình') schedule rows when 'Giữa' bars exist
        c_tie_buckets = {}
        c_tie_order = []
        for sp_i, sp in enumerate(spans):
            g_mids_sp = [
                b_ for b_ in bars_built
                if b_['pos'] == u'Giữa'
                and min(p[0] for p in b_['pts']) <= fr[sp_i] - 40.0
                and max(p[0] for p in b_['pts']) >= fl[sp_i] + 40.0
            ]
            if not g_mids_sp:
                continue
            sd_sp, _sa1_sp, sa2_sp = parse_stir_spec(sp['stir'])
            c_d = min(8, max(6, int(sd_sp)))
            c_a = max(150, int(sa2_sp))
            c_l2 = max(80, int(round(sp['b'] - 2 * opt['cover'] + 10)))
            c_hk = max(60, 10 * c_d)
            if len(g_mids_sp) == 1 and int(g_mids_sp[0]['n']) >= 4:
                n_rows_sp = max(2, (int(g_mids_sp[0]['n']) + 1) // 2)
            else:
                n_rows_sp = len(g_mids_sp)
            cov_len_sp = 0.0
            for bm_ in g_mids_sp:
                bx0 = max(fl[sp_i], min(p[0] for p in bm_['pts']))
                bx1 = min(fr[sp_i], max(p[0] for p in bm_['pts']))
                if bx1 > bx0:
                    cov_len_sp = max(cov_len_sp, bx1 - bx0)
            if cov_len_sp < 100.0:
                cov_len_sp = sp['clear']
            cnt_c = n_rows_sp * max(1, int(cov_len_sp // max(50, c_a)) + 1)
            ckey = (c_d, c_l2, c_hk, c_a)
            if ckey not in c_tie_buckets:
                c_tie_buckets[ckey] = [c_d, c_l2, c_hk, c_a, 0, 0]
                c_tie_order.append(ckey)
            c_tie_buckets[ckey][4] += cnt_c
            c_tie_buckets[ckey][5] += int(round(cov_len_sp * n_rows_sp))

        c_tie_sh_map = {}
        for ckey in c_tie_order:
            c_d, c_l2, c_hk, c_a, cnt_c, zlen_c = c_tie_buckets[ckey]
            sh_s_ctie = str(sh_i)
            c_tie_sh_map[ckey] = (sh_s_ctie, c_d, c_a, zlen_c)
            sched.append((bname, sh_s_ctie, 'TK7', c_hk, c_l2, c_hk, 0, 0, 0, c_d, 2 * c_hk + c_l2, sl_ck, cnt_c, None))
            sh_i += 1

        top_clear_y = max(sx_top + 60.0 * k_elev, max_top_tag_y + 200.0 * k_elev, max_tc_top_y + 40.0 * k_elev)
        stir_placed = []
        stir_zone_lanes = []
        for x0z, x1z, zd, za, sp_i in zones:
            xm_z = (x0z + x1z) / 2.0
            lane_s = 0
            while any(abs(xm_z - prev_xm) < 780.0 * k_elev and prev_l == lane_s for prev_xm, prev_l in stir_placed):
                lane_s += 1
            stir_placed.append((xm_z, lane_s))
            stir_zone_lanes.append((x0z, x1z, zd, za, sp_i, xm_z, lane_s))

        # Top stirrup spacing dim sits right ABOVE Dce_KhtThepDai tags (zero leader on elevation, matching reference DXF)
        max_lane_s = max([ln_ for _, ln_ in stir_placed] or [0])
        top_dim_y = top_clear_y + (320.0 + max_lane_s * 270.0) * k_elev

        bot_clear_y = min(sx_bot - 50.0 * k_elev, min_bot_tag_y - 185.0 * k_elev, min_tc_bot_y - 40.0 * k_elev)
        l1_dim_y = bot_clear_y - 220.0 * k_elev
        l2_dim_y = l1_dim_y - 310.0 * k_elev
        l3_dim_y = l2_dim_y - 310.0 * k_elev
        axis_scale = 1.2 * s_elev
        grid_bot_y = l3_dim_y - 210.0 * k_elev
        el_min_y = grid_bot_y - 1460.0 * k_elev

        if not is_mc_only:
            prev_dim_x = 0.0
            top_dim_segs = []
            for x0z, x1z, zd, za, sp_i, xm_z, lane_s in stir_zone_lanes:
                y_ins_s = top_dim_y - lane_s * 270.0 * k_elev
                sp = spans[sp_i]
                sp_ty = to_cad_y(maxtop - sp['top'])
                sp_by = to_cad_y(maxtop - sp['top'] + sp['h'])
                cov_line = max(15.0, min(opt['cover'], sp['h'] * 0.2))
                l1s = max(80, int(round(sp['b'] - 2 * opt['cover'] + 10)))
                l2s = max(120, int(round(sp['h'] - 2 * opt['cover'] + 10)))
                zone_sh = stir_sh_map[(zd, l1s, l2s)]
                zlen_s = max(100, int(round(x1z - x0z)))
                xd_stir = ('BeamCAD_LINK', ['TAG_STIR', bname, zone_sh, int(zd), int(za), zlen_s])
                xd_sline = ('BeamCAD_LINK', ['STIR_LINE', bname, zone_sh, int(zd), int(za)])
                if x1z - x0z > 150.0:
                    stir_legs_x = [x0z + 25.0, x0z + 175.0, x1z - 175.0, x1z - 25.0]
                else:
                    stir_legs_x = [(x0z + x1z) * 0.5]
                for sx_pair in stir_legs_x:
                    dxf.line(sx_pair, sp_ty - cov_line, sx_pair, sp_by + cov_line, 'DCE_ThepDai', xdata_app=xd_sline)
                if x0z > prev_dim_x + 5.0:
                    top_dim_segs.append((prev_dim_x, sx_top, x0z, sx_top))
                top_dim_segs.append((x0z, sx_top, x1z, sx_top))
                prev_dim_x = x1z
                dxf.insert('Dce_KhtThepDai', xm_z, y_ins_s, s_elev, s_elev, 'DCE_Block', [
                    ('SH', zone_sh, -5.74, -4.5, 2.0, 11, 1, 0, '0'),
                    ('DKVAKC', '%%%%c%da%d' % (zd, za), -2.56, -4.5, 2.0, 3, 0, 0, '0'),
                    ('VITRI', '', 15.57, -4.5, 2.0, 11, 1, 0, 'Dce_ViTriThep'),
                ], xdata=xd_stir)
            if cx > prev_dim_x + 5.0:
                top_dim_segs.append((prev_dim_x, sx_top, cx, sx_top))
            _emit_dim_row(top_dim_segs, top_dim_y, 'DCE_Dim', float(s_elev), elev_ds, above_beam=True)

            # 4. Bottom 3-Layer Dimensioning (l1, l2, l3) + Supports + Grid Axes & Bubbles
            grid_xs_raw = []
            has_grid_flags = []
            gcx_list = []
            for k, su in enumerate(sups):
                x0, x1 = sx0[k], sx0[k] + su['w']
                if su['w'] > 0.5:
                    role_n = _norm_hdr(su.get('role', '')).lower()
                    kd_n = _norm_hdr(su.get('kind', '')).lower()
                    is_upper_cc_only = (kd_n == 'cc') or (('cay' in role_n or 'cot tren' in role_n) and ('cot duoi' not in role_n))
                    if is_upper_cc_only:
                        adj_sp = spans[min(k, len(spans) - 1)]
                        if 0 < k < len(spans):
                            g_ty = max(to_cad_y(maxtop - spans[k - 1]['top']), to_cad_y(maxtop - spans[k]['top']))
                            g_by = min(to_cad_y(maxtop - spans[k - 1]['top'] + spans[k - 1]['h']), to_cad_y(maxtop - spans[k]['top'] + spans[k]['h']))
                        else:
                            g_ty = to_cad_y(maxtop - adj_sp['top'])
                            g_by = to_cad_y(maxtop - adj_sp['top'] + adj_sp['h'])
                        dxf.line(x0, g_ty, x0, sx_top, 'DCE_BaoBeTong')
                        dxf.line(x1, g_ty, x1, sx_top, 'DCE_BaoBeTong')
                        dxf.zigzag_h(x0, x1, sx_top)
                        dxf.line(x0, g_by, x1, g_by, 'DCE_BaoBeTong')
                        if k == 0 or k == len(spans):
                            dxf.line(x0 if k == 0 else x1, g_by, x0 if k == 0 else x1, g_ty, 'DCE_BaoBeTong')
                    elif _is_col_sup(su):
                        dxf.line(x0, sx_bot, x0, sx_top, 'DCE_BaoBeTong')
                        dxf.line(x1, sx_bot, x1, sx_top, 'DCE_BaoBeTong')
                        dxf.zigzag_h(x0, x1, sx_top)
                        dxf.zigzag_h(x0, x1, sx_bot)
                    else:
                        # Supporting Girder (D / Dam phu): outline within beam/girder depth only (no tall column cut)
                        adj_sp = spans[min(k, len(spans) - 1)]
                        if 0 < k < len(spans):
                            g_ty = max(to_cad_y(maxtop - spans[k - 1]['top']), to_cad_y(maxtop - spans[k]['top']))
                            g_by = min(to_cad_y(maxtop - spans[k - 1]['top'] + spans[k - 1]['h']), to_cad_y(maxtop - spans[k]['top'] + spans[k]['h']))
                        else:
                            g_ty = to_cad_y(maxtop - adj_sp['top'])
                            g_by = to_cad_y(maxtop - adj_sp['top'] + adj_sp['h'])
                        dxf.line(x0, g_by, x0, g_ty, 'DCE_BaoBeTong')
                        dxf.line(x1, g_by, x1, g_ty, 'DCE_BaoBeTong')
                        dxf.line(x0, g_ty, x1, g_ty, 'DCE_BaoBeTong')
                        dxf.line(x0, g_by, x1, g_by, 'DCE_BaoBeTong')
                has_g = bool(sstr(su['grid']))
                gcx_k = (x0 + x1) / 2.0 + su['off']
                has_grid_flags.append(has_g)
                gcx_list.append(gcx_k)
                if has_g:
                    grid_xs_raw.append(gcx_k)
                    dxf.line(gcx_k, top_dim_y + 240.0 * k_elev, gcx_k, grid_bot_y, 'DCE_Truc')
                    dxf.insert('Dce_KhTenTruc', gcx_k, grid_bot_y, axis_scale, axis_scale, '3', [
                        ('TRUC', su['grid'], 0.0, -4.5, 2.0, 2, 1, 0, 'Dce_text')
                    ])

            # Draw planted columns sitting ON TOP of beam spans ('Cột cấy trên dầm')
            planted_max_y = top_dim_y
            pdim_y = top_dim_y + 340.0 * k_elev
            pdim_segs = []
            for i_sp_p, sp_p in enumerate(spans):
                ty_sp_p = to_cad_y(maxtop - sp_p['top'])
                pl_sorted = sorted(
                    (sp_p.get('planted') or []),
                    key=lambda q_i: float(q_i.get('pos') or 0.0)
                )
                cur_dim_x = fl[i_sp_p]
                for q_p in pl_sorted:
                    pw_p = max(80.0, float(q_p.get('w') or 250.0))
                    xm_p = fl[i_sp_p] + float(q_p.get('pos') or 0.0)
                    px0_p, px1_p = xm_p - pw_p * 0.5, xm_p + pw_p * 0.5
                    dxf.line(px0_p, ty_sp_p, px0_p, sx_top, 'DCE_BaoBeTong')
                    dxf.line(px1_p, ty_sp_p, px1_p, sx_top, 'DCE_BaoBeTong')
                    dxf.zigzag_h(px0_p, px1_p, sx_top)
                    if px0_p > cur_dim_x + 30.0:
                        pdim_segs.append((cur_dim_x, ty_sp_p, px0_p, ty_sp_p))
                    elif cur_dim_x == fl[i_sp_p] and px0_p < fl[i_sp_p] - 30.0:
                        pdim_segs.append((px0_p, ty_sp_p, fl[i_sp_p], ty_sp_p))
                    pdim_segs.append((px0_p, ty_sp_p, px1_p, ty_sp_p))
                    cur_dim_x = max(cur_dim_x, px1_p)
                    planted_max_y = max(planted_max_y, pdim_y + 180.0 * k_elev)
            if pdim_segs:
                _emit_dim_row(pdim_segs, pdim_y, 'DCE_Dim', float(s_elev), elev_ds, above_beam=True)

            ty0_el = to_cad_y(maxtop - spans[0]['top']) if spans else base_y
            by0_el = to_cad_y(maxtop - spans[0]['top'] + spans[0]['h']) if spans else (base_y - 400.0)
            lbl0_z = beam_lvl_z + (spans[0]['top'] - maxtop if spans else 0.0)
            lbl0_el = '%s%.3f' % ('+' if lbl0_z >= 0 else '', lbl0_z / 1000.0)
            dxf.insert('Dce_CaoTrinh', -100.0 * k_elev, ty0_el, s_elev, s_elev, 'DCE_Block', [
                ('CT', lbl0_el, -10.15, 4.07, 2.0, 3, 0, 0, '0')
            ])
            dxf.dim(0.0, by0_el, 0.0, ty0_el, -980.0 * k_elev, 0.0, 'DCE_Dim', float(s_elev), dimstyle=elev_ds, rot_deg=90.0)

            def _dedup_sorted_xs(xs_in, tol=0.5):
                out_xs = []
                for xv in sorted(xs_in):
                    if not out_xs or xv - out_xs[-1] > tol:
                        out_xs.append(xv)
                return out_xs

            # Layer 1 (l1): dam(cot) -> truc -> dam(cot) -> thong thuy -> cot(dam) -> truc ...
            pts_l1_raw = [0.0, cx]
            for k, su in enumerate(sups):
                pts_l1_raw.append(sx0[k])
                pts_l1_raw.append(sx0[k] + su['w'])
                if has_grid_flags[k]:
                    pts_l1_raw.append(gcx_list[k])
            pts_l1 = _dedup_sorted_xs(pts_l1_raw)
            l1_segs = [(pts_l1[j_d], sx_bot, pts_l1[j_d + 1], sx_bot) for j_d in range(len(pts_l1) - 1)]
            _emit_dim_row(l1_segs, l1_dim_y, 'DCE_Dim', float(s_elev), elev_ds, above_beam=False)

            # Layer 2 (l2): dim luoi truc (bao gom doan dam conson / dua ra den luoi gan nhat)
            grid_xs = _dedup_sorted_xs(grid_xs_raw)
            pts_l2_raw = list(grid_xs)
            if grid_xs:
                if grid_xs[0] > 0.5 and (sups[0]['w'] <= 0.5 or not has_grid_flags[0]):
                    pts_l2_raw.append(0.0)
                if cx - grid_xs[-1] > 0.5 and (sups[-1]['w'] <= 0.5 or not has_grid_flags[-1]):
                    pts_l2_raw.append(cx)
            pts_l2 = _dedup_sorted_xs(pts_l2_raw)
            if len(pts_l2) < 2 and cx > 1.0:
                pts_l2 = [0.0, cx]
            l2_segs = [(pts_l2[j_d], sx_bot, pts_l2[j_d + 1], sx_bot) for j_d in range(len(pts_l2) - 1)]
            _emit_dim_row(l2_segs, l2_dim_y, 'DCE_Dim', float(s_elev), elev_ds, above_beam=False)

            # Layer 3 (l3): dim tong luoi truc
            if len(grid_xs) >= 2:
                dxf.dim(grid_xs[0], sx_bot, grid_xs[-1], sx_bot, 0.0, l3_dim_y, 'DCE_Dim', float(s_elev), dimstyle=elev_ds, rot_deg=0.0)
            elif cx > 1.0:
                dxf.dim(0.0, sx_bot, cx, sx_bot, 0.0, l3_dim_y, 'DCE_Dim', float(s_elev), dimstyle=elev_ds, rot_deg=0.0)

            title_scale = 2.0 * s_elev
            dxf.insert('Dce_KhTenDam', cx / 2.0, grid_bot_y - 1140.0 * k_elev, title_scale, title_scale, 'DCE_Block', [
                ('TENDAM', u'%%%%UDẦM %s (SL=%d; L=%d)' % (bname, sl_ck, int(round(cx))), 0.0, 0.74, 2.0, 255, 1, 0, '0'),
                ('TL', 'TL: 1/%d' % s_elev, 0.0, -2.0, 1.0, 11, 1, 0, '0'),
            ], xdata=[('BeamCAD_LINK', ['BEAM_TITLE', bname, int(sl_ck), int(round(cx))]), ('BeamCAD_META', meta_chunks)])

            el_min_x = -1420.0 * k_elev
            el_max_x = cx + 750.0 * k_elev
            el_max_y = max(top_dim_y + 980.0 * k_elev, planted_max_y + 520.0 * k_elev)
            dxf.pline([(el_min_x, el_max_y), (el_max_x, el_max_y), (el_max_x, el_min_y), (el_min_x, el_min_y)], 'Defpoints', True)

        # 5. Cross Sections MC 1-1..N-N (strictly 1 MC in MC_ONLY mode; deduplicate identical cuts in FULL mode)
        cuts = []
        if is_mc_only and spans:
            cuts.append((fl[0] + spans[0]['clear'] * 0.5, 0))
        else:
            for i, sp in enumerate(spans):
                if i == 0:
                    cuts.append((fl[0] + min(350.0, sp['clear'] * 0.2), 0))
                cuts.append((fl[i] + sp['clear'] / 2.0, i))
                if i < len(spans) - 1 and len(spans) <= 3:
                    cuts.append((fr[i] - min(350.0, sp['clear'] * 0.2), i))
                elif i == 0 and len(spans) > 3:
                    cuts.append((fr[0] - min(350.0, sp['clear'] * 0.2), 0))
            if len(cuts) > 6:
                picked_cuts = cuts[:6]
                have_dims = set((int(round(spans[spi]['b'])), int(round(spans[spi]['h']))) for _, spi in picked_cuts)
                for c_item in cuts[6:]:
                    dim_k = (int(round(spans[c_item[1]]['b'])), int(round(spans[c_item[1]]['h'])))
                    if dim_k not in have_dims:
                        picked_cuts[-1] = c_item
                        have_dims.add(dim_k)
                cuts = picked_cuts

        def _zone_stir_at(xw_val, spi_val):
            sp_v = spans[spi_val]
            sd_v, sa1_v, _ = parse_stir_spec(sp_v['stir'])
            za_v = sa1_v
            for x0z, x1z, zd_z, za_z, sp_iz in zones:
                if sp_iz == spi_val and (x0z - 1.0) <= xw_val <= (x1z + 1.0):
                    sd_v, za_v = zd_z, za_z
                    break
            l1_v = max(80, int(round(sp_v['b'] - 2 * opt['cover'] + 10)))
            l2_v = max(120, int(round(sp_v['h'] - 2 * opt['cover'] + 10)))
            sh_v = stir_sh_map.get((sd_v, l1_v, l2_v), '1')
            return sd_v, za_v, sh_v

        sig_to_sec_idx = {}
        unique_cuts = []
        cut_labels = []
        for xw, spi in cuts:
            sp_c = spans[spi]
            sd_c, za_c, sh_c = _zone_stir_at(xw, spi)
            sec_bars_c = []
            for bar in bars_built:
                minx = min(p[0] for p in bar['pts'])
                maxx = max(p[0] for p in bar['pts'])
                if minx - 10 <= xw <= maxx + 10:
                    sec_bars_c.append(bar)
            sorted_bars_c = sorted(sec_bars_c, key=lambda b_: (b_['pos'], int(b_['layer']), int(b_['sh'])))
            c_d_c = min(8, max(6, int(sd_c)))
            c_a_c = max(150, int(parse_stir_spec(sp_c['stir'])[2]))
            c_l2_c = max(80, int(round(sp_c['b'] - 2 * opt['cover'] + 10)))
            c_hk_c = max(60, 10 * c_d_c)
            c_info_c = c_tie_sh_map.get((c_d_c, c_l2_c, c_hk_c, c_a_c))
            ctie_key_c = sstr(c_info_c[0]) if (c_info_c and any(b_['pos'] == u'Giữa' for b_ in sec_bars_c)) else ''
            sig = (
                int(round(sp_c['b'])),
                int(round(sp_c['h'])),
                int(round(sp_c['slabL'])),
                int(round(sp_c['slabR'])),
                int(round(sp_c['slabL_top'] - sp_c['top'])),
                int(round(sp_c['slabR_top'] - sp_c['top'])),
                sstr(sh_c),
                int(sd_c),
                int(za_c),
                ctie_key_c,
                tuple((int(b_['sh']), b_['pos'], int(b_['layer']), int(b_['n']), int(b_['d'])) for b_ in sorted_bars_c),
            )
            if sig in sig_to_sec_idx:
                sec_idx = sig_to_sec_idx[sig]
            else:
                sec_idx = len(unique_cuts) + 1
                sig_to_sec_idx[sig] = sec_idx
                unique_cuts.append((sec_idx, xw, spi, sd_c, za_c, sh_c, sec_bars_c))
            cut_labels.append((sec_idx, xw))

        max_top_off = 360.0 * k_sec
        for _, xw, spi_c, _, _, _, _ in unique_cuts:
            sp_c = spans[spi_c]
            slab_up = max(0.0, sp_c['slabL_top'] - sp_c['top'], sp_c['slabR_top'] - sp_c['top'])
            top_cnt_s = 0
            for bar in bars_built:
                minx = min(p[0] for p in bar['pts'])
                maxx = max(p[0] for p in bar['pts'])
                if minx - 10 <= xw <= maxx + 10 and bar['pos'] == 'Trên':
                    top_cnt_s += 1
            max_top_off = max(max_top_off, slab_up + (125.0 + max(0, top_cnt_s - 1) * 145.0 + 240.0) * k_sec)

        sec_ytop = (base_y - max_top_off) if is_mc_only else (el_min_y - el_sec_gap - max_top_off)
        max_b_beam = max(s['b'] for s in spans) if spans else 200.0
        sec_pitch_x = max(1400.0 * k_sec, max_b_beam + 1150.0 * k_sec)
        first_cx = max(720.0 * k_sec, max_b_beam * 0.5 + 560.0 * k_sec)
        mc_title_scale = 2.0 * s_sec
        actual_sec_max_y = sec_ytop + max_top_off
        actual_sec_min_y = sec_ytop - 500.0 * k_sec

        if not is_mc_only:
            top_mc_y = max(top_dim_y + 250.0 * k_elev, planted_max_y + 70.0 * k_elev)
            bot_mc_y = grid_bot_y - 720.0 * k_elev
            for sec_idx_lbl, xw_lbl in cut_labels:
                dxf.insert('DCE_MatCatA', xw_lbl, top_mc_y, s_elev, s_elev, 'DCE_Block', [('1', str(sec_idx_lbl), -2.33, 1.70, 2.0, 11, 1, 0, '0')])
                dxf.insert('DCE_MatCatA', xw_lbl, bot_mc_y, s_elev, s_elev, 'DCE_Block', [('1', str(sec_idx_lbl), -2.33, 1.70, 2.0, 11, 1, 0, '0')])

        for u_pos, (sec_idx, xw, spi, sd_s, sa_cut, sec_stir_sh, sec_bars) in enumerate(unique_cuts):
            sp = spans[spi]
            scx = first_cx + u_pos * sec_pitch_x
            bw_s, bh_s = sp['b'], sp['h']
            stL = sp['slabL']
            stR = sp['slabR']
            sx_l, sx_r = scx - bw_s / 2.0, scx + bw_s / 2.0
            sy_t, sy_b = sec_ytop, sec_ytop - bh_s
            stL_top_y = sy_t + (sp['slabL_top'] - sp['top'])
            stR_top_y = sy_t + (sp['slabR_top'] - sp['top'])

            # Accurate stepped/one-sided slabs in section
            dxf.line(sx_l, sy_b, sx_r, sy_b, 'DCE_BaoBeTong')
            if stL > 0.5:
                dxf.line(sx_l, sy_b, sx_l, stL_top_y - stL, 'DCE_BaoBeTong')
                dxf.line(sx_l - 50.0, stL_top_y - stL, sx_l, stL_top_y - stL, 'DCE_BaoBeTong')
                dxf.line(sx_l - 50.0, stL_top_y, sx_l, stL_top_y, 'DCE_BaoBeTong')
                if abs(stL_top_y - sy_t) > 1.0:
                    dxf.line(sx_l, sy_t, sx_l, stL_top_y, 'DCE_BaoBeTong')
                dxf.zigzag_v(sx_l - 50.0, stL_top_y, stL_top_y - stL)
            else:
                dxf.line(sx_l, sy_b, sx_l, sy_t, 'DCE_BaoBeTong')

            dxf.line(sx_l, sy_t, sx_r, sy_t, 'DCE_BaoBeTong')

            if stR > 0.5:
                dxf.line(sx_r, sy_b, sx_r, stR_top_y - stR, 'DCE_BaoBeTong')
                dxf.line(sx_r, stR_top_y - stR, sx_r + 50.0, stR_top_y - stR, 'DCE_BaoBeTong')
                dxf.line(sx_r, stR_top_y, sx_r + 50.0, stR_top_y, 'DCE_BaoBeTong')
                if abs(stR_top_y - sy_t) > 1.0:
                    dxf.line(sx_r, sy_t, sx_r, stR_top_y, 'DCE_BaoBeTong')
                dxf.zigzag_v(sx_r + 50.0, stR_top_y, stR_top_y - stR)
            else:
                dxf.line(sx_r, sy_b, sx_r, sy_t, 'DCE_BaoBeTong')

            xd_sec_stir = ('BeamCAD_LINK', ['TAG_STIR', bname, sec_stir_sh, int(sd_s), int(sa_cut), 0])

            cov_s = opt['cover']
            xL_s, xR_s = sx_l + cov_s, sx_r - cov_s
            yT_s, yB_s = sy_t - cov_s, sy_b + cov_s

            leader_x = sx_l - (310.0 if stL <= 0.5 else 330.0) * k_sec

            layer_groups = {}
            for bar in sec_bars:
                layer_groups.setdefault((bar['pos'], int(bar['layer'])), []).append(bar)
            for key_pl in layer_groups:
                layer_groups[key_pl].sort(key=lambda b_: int(b_['sh']))

            top_bars = sorted([b_ for b_ in sec_bars if b_['pos'] == 'Trên'], key=lambda b_: (int(b_['layer']), int(b_['sh'])))
            bot_bars = sorted([b_ for b_ in sec_bars if b_['pos'] == 'Dưới'], key=lambda b_: (int(b_['layer']), int(b_['sh'])))
            mid_bars = sorted([b_ for b_ in sec_bars if b_['pos'] == 'Giữa'], key=lambda b_: (int(b_['layer']), int(b_['sh'])))

            corner_d = max([float(b_['d']) for b_ in top_bars + bot_bars] + [18.0])
            stir_pts_s = _build_stirrup_135_pts(xL_s, xR_s, yB_s, yT_s, sd_s, corner_d)
            dxf.pline(stir_pts_s, 'DCE_ThepDai', False, xdata_app=('BeamCAD_LINK', ['STIR_LINE', bname, sec_stir_sh, int(sd_s), int(sa_cut)]))

            def _emit_sec_bar_group(bar, tag_y):
                key_pl = (bar['pos'], int(bar['layer']))
                peers = layer_groups[key_pl]
                tot_n = sum(max(1, int(p_['n'])) for p_ in peers)
                dmax_l = max(float(p_['d']) for p_ in peers)
                yoff = cov_s + opt['stir'] + dmax_l / 2.0 + (int(bar['layer']) - 1) * (dmax_l + opt['pitch'])
                dy_bar = (sy_t - yoff) if bar['pos'] == 'Trên' else (sy_b + yoff)
                xa_bar = sx_l + cov_s + opt['stir'] + dmax_l / 2.0
                xb_bar = sx_r - cov_s - opt['stir'] - dmax_l / 2.0
                xs_all = [scx] if tot_n == 1 else [xa_bar + ((xb_bar - xa_bar) * si) / (tot_n - 1) for si in range(tot_n)]
                if len(peers) >= 2 and int(peers[0]['n']) >= 2 and tot_n >= 3:
                    slot_order = []
                    p0_n = int(peers[0]['n'])
                    mid_slots = list(range(1, tot_n - 1))
                    p0_slots = [0, tot_n - 1] + mid_slots[:max(0, p0_n - 2)]
                    rem_slots = mid_slots[max(0, p0_n - 2):]
                    for p_ in peers:
                        if p_ is peers[0]:
                            my_slots = p0_slots
                        else:
                            cn = max(1, int(p_['n']))
                            my_slots = rem_slots[:cn]
                            rem_slots = rem_slots[cn:]
                        if p_ is bar:
                            slot_order = my_slots
                            break
                else:
                    offset_bi = 0
                    for p_ in peers:
                        if p_ is bar:
                            break
                        offset_bi += max(1, int(p_['n']))
                    slot_order = [offset_bi + bi for bi in range(max(1, int(bar['n'])))]
                dot_sc = bar['d'] * k_sec
                xd_sec_bar = ('BeamCAD_LINK', ['TAG_BAR', bname, bar['sh'], int(bar['n']), int(bar['d']), sstr(bar['pos'])])
                for slot_i in slot_order:
                    bx = xs_all[min(max(0, slot_i), len(xs_all) - 1)]
                    dxf.leader([(bx, dy_bar), (bx, tag_y), (leader_x, tag_y)], 'DCE_Dim', sec_dot_ds, 1, xdata_app=xd_sec_bar)
                    dxf.insert('Dce_McThepChu', bx, dy_bar, dot_sc, dot_sc, 'DCE_ThepChu', [], xdata=xd_sec_bar)
                dxf.insert('Dce_KhtMcThepChu_L', leader_x, tag_y, s_sec, s_sec, 'DCE_Block', [
                    ('SH', bar['sh'], -2.5, 0.0, 2.0, 11, 1, 2, '0'),
                    ('DKVAKC', '%d%%%%c%d' % (bar['n'], bar['d']), 0.54, 1.0, 2.0, 3, 0, 0, '0'),
                    ('DKVAKC2', '', 0.54, -2.6, 2.0, 3, 0, 0, '0'),
                ], xdata=xd_sec_bar)

            sec_top_start = max(sy_t, stL_top_y if stL > 0.5 else sy_t, stR_top_y if stR > 0.5 else sy_t)
            for top_idx, bar in enumerate(top_bars):
                tag_y = sec_top_start + (115.0 + top_idx * 145.0) * k_sec
                _emit_sec_bar_group(bar, tag_y)
                actual_sec_max_y = max(actual_sec_max_y, tag_y + 240.0 * k_sec)

            lowest_bot_tag_y = sy_b - 120.0 * k_sec
            for bot_idx, bar in enumerate(bot_bars):
                tag_y = sy_b - (115.0 + bot_idx * 145.0) * k_sec
                _emit_sec_bar_group(bar, tag_y)
                lowest_bot_tag_y = min(lowest_bot_tag_y, tag_y)

            # Anti-bulge side bars ('Giữa') + horizontal C-crosstie ('đai C chống phình') + C-tie tag for deep beams
            mid_tag_ys = []
            mid_bar_ys = []
            c_tie_drawn = []
            c_d_sp = min(8, max(6, int(sd_s)))
            c_a_sp = max(150, int(parse_stir_spec(sp['stir'])[2]))
            c_l2_sp = max(80, int(round(bw_s - 2 * opt['cover'] + 10)))
            c_hk_sp = max(60, 10 * c_d_sp)
            c_info = c_tie_sh_map.get((c_d_sp, c_l2_sp, c_hk_sp, c_a_sp))
            ctie_sh = c_info[0] if c_info else sec_stir_sh
            ctie_d = c_info[1] if c_info else c_d_sp
            ctie_a = c_info[2] if c_info else c_a_sp
            ctie_zlen = c_info[3] if c_info else 0
            xd_ctie_tag = ('BeamCAD_LINK', ['TAG_STIR', bname, ctie_sh, int(ctie_d), int(ctie_a), int(ctie_zlen)])
            xd_ctie_line = ('BeamCAD_LINK', ['STIR_LINE', bname, ctie_sh, int(ctie_d), int(ctie_a)])

            if mid_bars:
                n_mg = len(mid_bars)
                for m_idx, bar in enumerate(mid_bars):
                    mlay = int(bar['layer'])
                    mn = max(1, int(bar['n']))
                    md = float(bar['d'])
                    x_mid_L = sx_l + cov_s + opt['stir'] + md / 2.0
                    x_mid_R = sx_r - cov_s - opt['stir'] - md / 2.0
                    if n_mg == 1 and mn >= 4:
                        n_rows_m = max(2, (mn + 1) // 2)
                        row_fracs = [float(ri + 1) / float(n_rows_m + 1) for ri in range(n_rows_m)]
                    elif n_mg >= 2 and all(int(mb_['layer']) == 1 for mb_ in mid_bars):
                        row_fracs = [float(m_idx + 1) / float(n_mg + 1)]
                    else:
                        frac_m = (1.0 / 3.0) if mlay == 2 else ((2.0 / 3.0) if mlay == 3 else 0.5)
                        row_fracs = [frac_m]

                    dot_sc = md * k_sec
                    xd_mid_bar = ('BeamCAD_LINK', ['TAG_BAR', bname, bar['sh'], int(bar['n']), int(bar['d']), sstr(bar['pos'])])
                    row_ys = [sy_t - rf * bh_s for rf in row_fracs]
                    mid_bar_ys.extend(row_ys)
                    tag_ym = row_ys[0]
                    while any(abs(tag_ym - py) < 135.0 * k_sec for py in mid_tag_ys):
                        tag_ym -= 145.0 * k_sec
                    mid_tag_ys.append(tag_ym)

                    for y_rm in row_ys:
                        dxf.insert('Dce_McThepChu', x_mid_L, y_rm, dot_sc, dot_sc, 'DCE_ThepChu', [], xdata=xd_mid_bar)
                        dxf.insert('Dce_McThepChu', x_mid_R, y_rm, dot_sc, dot_sc, 'DCE_ThepChu', [], xdata=xd_mid_bar)
                        # Smooth G1-tangent anti-bulge C-crosstie (135-deg hooks) wrapping left & right side bars
                        c_pts, c_pick_pt = _build_ctie_135_pts(x_mid_L, y_rm, x_mid_R, y_rm, md, ctie_d, horiz=True)
                        dxf.pline(c_pts, 'DCE_ThepDai', False, xdata_app=xd_ctie_line)
                        c_tie_drawn.append(c_pick_pt)
                        mid_ldr_pts = (
                            [(x_mid_L, y_rm), (leader_x, tag_ym)]
                            if abs(tag_ym - y_rm) <= 2.0 else
                            [(x_mid_L, y_rm), (x_mid_L, tag_ym), (leader_x, tag_ym)]
                        )
                        dxf.leader(mid_ldr_pts, 'DCE_Dim', sec_dot_ds, 1, xdata_app=xd_mid_bar)

                    dxf.insert('Dce_KhtMcThepChu_L', leader_x, tag_ym, s_sec, s_sec, 'DCE_Block', [
                        ('SH', bar['sh'], -2.5, 0.0, 2.0, 11, 1, 2, '0'),
                        ('DKVAKC', '%d%%%%c%d' % (bar['n'], bar['d']), 0.54, 1.0, 2.0, 3, 0, 0, '0'),
                        ('DKVAKC2', '', 0.54, -2.6, 2.0, 3, 0, 0, '0'),
                    ], xdata=xd_mid_bar)

                if c_tie_drawn:
                    tag_yc = max(mid_tag_ys) + 155.0 * k_sec
                    while any(abs(tag_yc - py) < 135.0 * k_sec for py in mid_tag_ys):
                        tag_yc += 145.0 * k_sec
                    mid_tag_ys.append(tag_yc)
                    for cx_t, cy_t in c_tie_drawn:
                        ctie_ldr_pts = (
                            [(cx_t, cy_t), (leader_x, tag_yc)]
                            if abs(tag_yc - cy_t) <= 2.0 else
                            [(cx_t, cy_t), (cx_t, tag_yc), (leader_x, tag_yc)]
                        )
                        dxf.leader(ctie_ldr_pts, 'DCE_Dim', sec_ds, 1, xdata_app=xd_ctie_tag)
                    dxf.insert('Dce_KhtMcThepChu_L', leader_x, tag_yc, s_sec, s_sec, 'DCE_Block', [
                        ('SH', ctie_sh, -2.5, 0.0, 2.0, 11, 1, 2, '0'),
                        ('DKVAKC', '%%%%c%da%d' % (ctie_d, ctie_a), 0.54, 1.0, 2.0, 3, 0, 0, '0'),
                        ('DKVAKC2', '', 0.54, -2.6, 2.0, 3, 0, 0, '0'),
                    ], xdata=xd_ctie_tag)

            if mid_bar_ys:
                y_low_ref = min(mid_bar_ys)
                y_cand = max(yB_s + 35.0, min(yT_s - 35.0, (y_low_ref + yB_s) * 0.5))
                if any(abs(y_cand - my_) < 135.0 * k_sec for my_ in mid_tag_ys):
                    found_clear_y = None
                    for step_y in range(1, 12):
                        for sgn_y in (-1.0, 1.0):
                            yt = y_cand + sgn_y * step_y * 35.0 * k_sec
                            if (yB_s + 35.0) <= yt <= (yT_s - 35.0) and not any(abs(yt - my_) < 135.0 * k_sec for my_ in mid_tag_ys):
                                found_clear_y = yt
                                break
                        if found_clear_y is not None:
                            break
                    if found_clear_y is not None:
                        y_stir_pick = y_stir_mid = found_clear_y
                    else:
                        y_stir_pick = y_cand
                        y_stir_mid = y_cand
                        while any(abs(y_stir_mid - my_) < 135.0 * k_sec for my_ in mid_tag_ys):
                            y_stir_mid -= 140.0 * k_sec
                else:
                    y_stir_pick = y_stir_mid = y_cand
            else:
                y_stir_pick = max(yB_s + 35.0, min(yT_s - 35.0, sy_t - bh_s * 0.65))
                y_stir_mid = y_stir_pick
            stir_ldr_pts = (
                [(xL_s, y_stir_pick), (leader_x, y_stir_mid)]
                if abs(y_stir_mid - y_stir_pick) <= 5.0 else
                [(xL_s, y_stir_pick), (xL_s - 55.0 * k_sec, y_stir_pick), (xL_s - 55.0 * k_sec, y_stir_mid), (leader_x, y_stir_mid)]
            )
            dxf.leader(stir_ldr_pts, 'DCE_Dim', sec_ds, 1, xdata_app=xd_sec_stir)
            _sd_mc, _sa1_mc, _sa2_mc = parse_stir_spec(sp['stir'])
            _dk1_s = '%%%%c%da%d' % (sd_s, _sa1_mc if is_mc_only else sa_cut)
            _dk2_s = ('/%d' % _sa2_mc) if (is_mc_only and _sa1_mc != _sa2_mc) else ''
            dxf.insert('Dce_KhtMcThepChu_L', leader_x, y_stir_mid, s_sec, s_sec, 'DCE_Block', [
                ('SH', sec_stir_sh, -2.5, 0.0, 2.0, 11, 1, 2, '0'),
                ('DKVAKC', _dk1_s, 0.54, 1.0, 2.0, 3, 0, 0, '0'),
                ('DKVAKC2', _dk2_s, 0.54, -2.6, 2.0, 3, 0, 0, '0'),
            ], xdata=xd_sec_stir)
            dxf.dim(sx_r + 65.0, sy_t, sx_r + 65.0, sy_b, sx_r + 225.0 * k_sec, 0.0, 'DCE_Dim', float(s_sec), dimstyle=sec_ds, rot_deg=90.0)
            sec_lvl_z = beam_lvl_z + (sp['top'] - maxtop)
            sec_lvl_lbl = '%s%.3f' % ('+' if sec_lvl_z >= 0 else '', sec_lvl_z / 1000.0)
            dxf.insert('Dce_CaoTrinh', sx_r + 665.0 * k_sec, sy_t, s_sec, s_sec, 'DCE_Block', [
                ('CT', sec_lvl_lbl, -10.15, 4.07, 2.0, 3, 0, 0, '0'),
            ])
            actual_sec_max_y = max(actual_sec_max_y, sec_top_start + 280.0 * k_sec)
            b_dim_y = min(sy_b - 220.0 * k_sec, lowest_bot_tag_y - 210.0 * k_sec)
            dxf.dim(sx_l, sy_b - 50.0 * k_sec, sx_r, sy_b - 50.0 * k_sec, 0.0, b_dim_y, 'DCE_Dim', float(s_sec), dimstyle=sec_ds, rot_deg=0.0)
            mc_ins_y = b_dim_y - 250.0 * k_sec
            mc_xd = [('BeamCAD_LINK', ['MC_TITLE', bname, int(s_sec)])]
            if is_mc_only and u_pos == 0:
                mc_xd.append(('BeamCAD_META', meta_chunks))
            tl_mc_str = ('%s (SL=%d; TL: 1/%d)' % (bname, sl_ck, s_sec)) if (is_mc_only and sl_ck > 1) else ('%s (TL: 1/%d)' % (bname, s_sec))
            dxf.insert('Dce_KhMatCat', scx, mc_ins_y, mc_title_scale, mc_title_scale, 'DCE_Block', [
                ('TENMATCAT', '%%%%UMC %d-%d' % (sec_idx, sec_idx), 0.0, 0.74, 2.0, 255, 1, 0, '0'),
                ('TL', tl_mc_str, 0.0, -2.0, 1.0, 11, 1, 0, '0'),
            ], xdata=mc_xd)
            actual_sec_min_y = min(actual_sec_min_y, mc_ins_y - 260.0 * k_sec)

        beam_bottom_y = base_y if is_mc_only else el_min_y
        if unique_cuts:
            sec_min_x = first_cx - max_b_beam / 2.0 - 720.0 * k_sec
            sec_max_x = first_cx + (len(unique_cuts) - 1) * sec_pitch_x + max_b_beam / 2.0 + 750.0 * k_sec
            sec_max_y = actual_sec_max_y
            sec_min_y = actual_sec_min_y
            dxf.pline([(sec_min_x, sec_max_y), (sec_max_x, sec_max_y), (sec_max_x, sec_min_y), (sec_min_x, sec_min_y)], 'Defpoints', True)
            beam_bottom_y = sec_min_y
        last_beam_bottom_y = beam_bottom_y
        next_is_mc = False
        if b_idx_ord + 1 < len(order):
            nxt_bn = order[b_idx_ord + 1]
            if nxt_bn in beam_modes_map:
                next_is_mc = (beam_modes_map[nxt_bn] == 'MC_ONLY')
            else:
                next_is_mc = any(
                    _is_mc_only_token(r[c_mode_col] if (c_mode_col is not None and c_mode_col < len(r)) else '')
                    for r in beams_raw[nxt_bn]
                )
        base_y = beam_bottom_y - beam_gap - ((480.0 * k_sec) if next_is_mc else (2400.0 * k_elev))

    grand = 0.0
    if part == 'beam':
        for row in sched:
            _, _, _, _, _, _, _, _, _, dk_r, sumL_r, skc_r, sl_r, _ = row
            lall_r = round((sumL_r / 1000.0) * (skc_r * sl_r), 2)
            grand += round(lall_r * unit_w(dk_r), 2)
    else:
        if part == 'tk':
            del dxf.entities_buf[:]
            del dxf.dim_blocks_buf[:]
            del dxf.block_records[base_br_len:]
            dxf.dim_idx = base_dim_idx
            dxf.set_target('entities')

        # Split Schedule Tables + TenCauKien (rot=90) + TKTUnknown inner diagrams
        col_w = 9625.0
        col_gap = 1200.0
        title_h = 1750.0
        sched_origin_y = 0.0 if part == 'tk' else ((last_beam_bottom_y - beam_gap - 250.0) if order else 0.0)
        max_bot = sched_origin_y - title_h
        col0_bot = max_bot
        diam_totals = {}
        lim = max(1, int(split_limit or 50))

        packed_cols = [sched[i:i + lim] for i in range(0, len(sched), lim)] or [[]]
        for col_idx, chunk in enumerate(packed_cols):
            cx_col = col_idx * (col_w + col_gap)
            dxf.insert('TKTitle', cx_col, sched_origin_y, 50, 50, 'DCE_Lanh_To', [])
            cur_y = sched_origin_y - title_h

            member_spans = []  # [bname, skc, y_top, y_bot]
            for row in chunk:
                bname, sh, bcode, l1, l2, l3, l4, l5, m, dk, sumL, skc, sl, raw_cad_pts = row
                row_h = 675.0 if bcode == 'TKTUnknown' else 400.0
                yc_off = -(row_h / 100.0)  # -6.75 for TKTUnknown, -4.0 for TK*

                if member_spans and member_spans[-1][0] == bname and member_spans[-1][1] == skc:
                    member_spans[-1][3] = cur_y - row_h
                else:
                    member_spans.append([bname, skc, cur_y, cur_y - row_h])

                tsl = skc * sl
                lall = round((sumL / 1000.0) * tsl, 2)
                kl = round(lall * unit_w(dk), 2)
                atts = [
                    ('SH', sh, 20.0, yc_off, 2.5, 2, 1),
                    ('DK', str(int(dk)), 82.5, yc_off, 2.5, 2, 1),
                    ('sumL', str(int(round(sumL))), 100.0, yc_off, 2.5, 2, 1),
                    ('SKC', str(skc), 116.25, yc_off, 2.5, 2, 1),
                    ('SL', str(sl), 128.75, yc_off, 2.5, 2, 1),
                    ('TSL', str(tsl), 141.25, yc_off, 2.5, 2, 1),
                    ('Lall', '%.2f' % lall, 162.5, yc_off, 2.5, 2, 2),
                    ('KL', '%.2f' % kl, 185.5, yc_off, 2.5, 2, 2),
                ]
                if bcode == 'TK1':
                    atts += [('L', str(l1), 50.0, -4.0, 2.5, 2, 1)]
                elif bcode == 'TK2':
                    atts += [('L1', str(l1), 33.18, -4.0, 2.5, 2, 2), ('L2', str(l2), 50.0, -4.26, 2.5, 2, 1)]
                elif bcode == 'TK3':
                    atts += [('L1', str(l1), 48.94, -4.19, 2.5, 2, 1), ('L2', str(l2), 67.26, -4.0, 2.5, 2, 0)]
                elif bcode == 'TK4':
                    atts += [('L1', str(l1), 32.68, -4.0, 2.5, 2, 2), ('L2', str(l2), 50.0, -4.0, 2.5, 2, 1), ('L3', str(l3), 67.53, -4.0, 2.5, 2, 0)]
                elif bcode == 'TK7':
                    atts += [('L1', str(l1), 32.68, -4.0, 2.5, 2, 2), ('L2', str(l2), 50.0, -4.0, 2.5, 2, 1), ('L3', str(l3), 67.53, -4.0, 2.5, 2, 0)]
                elif bcode == 'TK7R1':
                    atts += [('L1', str(l1), 31.93, -4.84, 2.5, 2, 2), ('L2', str(l2), 40.67, -4.84, 2.5, 2, 1),
                             ('L3', str(l3), 47.45, -2.72, 2.5, 2, 0), ('L4', str(l4), 59.11, -2.72, 2.5, 2, 1), ('L5', str(l5), 67.48, -2.72, 2.5, 2, 0)]
                elif bcode == 'TK9':
                    atts += [('L1', str(l1), 49.34, -3.76, 2.5, 2, 1), ('L2', str(l2), 58.47, -3.76, 2.5, 2, 0), ('M', str(m), 38.78, -5.47, 2.5, 2, 2)]

                dxf.insert(bcode, cx_col, cur_y, 50, 50, 'DCE_Lanh_To', atts, [
                    ('DCEThongKeThep', ['(0)_%s(1)_%s(2)_%s(3)_%d(4)_%d(5)_%d(6)_0(7)_0(8)_0' % (bname, sh, bcode, dk, skc, sl)]),
                    ('BeamCAD_LINK', ['TK_ROW', bname, sh, int(sl), int(dk), int(skc)]),
                ])
                if bcode == 'TKTUnknown' and raw_cad_pts:
                    _draw_tkt_unknown_diagram(dxf, raw_cad_pts, cx_col, cur_y, row_h)

                prev = diam_totals.get(dk, [0.0, 0.0])
                diam_totals[dk] = [prev[0] + lall, prev[1] + kl]
                cur_y -= row_h
                max_bot = min(max_bot, cur_y)
                if col_idx == 0:
                    col0_bot = cur_y

            for ms_bname, ms_skc, top_m, bot_m in member_spans:
                mid_m = (top_m + bot_m) / 2.0
                dxf.pline([(cx_col, bot_m), (cx_col + 750.0, bot_m)], 'DCE_Lanh_To', False, 256, 'BeamCAD_SUM')
                dxf.insert('TenCauKien', cx_col + 375.0, mid_m, 50, 50, 'DCE_Lanh_To', [
                    ('SOCAUKIEN', 'SL: %d' % ms_skc, 2.0, 0.0, 2.5, 256, 1, 2, 'Dce_text', 90.0),
                    ('TENCAUKIEN', ms_bname, -2.0, 0.0, 2.5, 256, 1, 2, 'Dce_text', 90.0),
                ], [
                    ('BeamCAD_SKC', [str(ms_skc)]),
                    ('BeamCAD_LINK', ['TCK', ms_bname, int(ms_skc)]),
                ])

        # Compute diam totals + exact Summary Table placement
        dks = sorted(diam_totals.keys())
        totw = 1900.0 + max(2, len(dks)) * 1100.0
        w_le10 = w_mid = w_gt18 = 0.0
        for dk_v in dks:
            _lx, _kv = diam_totals[dk_v]
            if dk_v <= 10:
                w_le10 += _kv
            elif dk_v <= 18:
                w_mid += _kv
            else:
                w_gt18 += _kv

        sum_x, sy = 0.0, col0_bot
        dxf.pline([(sum_x, sy), (sum_x + totw, sy), (sum_x + totw, sy - 600.0), (sum_x, sy - 600.0)], 'DCE_Lanh_To', True, 256, 'BeamCAD_SUM')
        dxf.text(sum_x + totw / 2.0, sy - 300.0, 150.0, u'TỔNG HỢP CỐT THÉP', 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
        y0 = sy - 600.0
        for r in range(5):
            dxf.line(sum_x, y0 - r * 400.0, sum_x + totw, y0 - r * 400.0, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
        dxf.line(sum_x, y0, sum_x, y0 - 1600.0, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
        dxf.line(sum_x + 1900.0, y0, sum_x + 1900.0, y0 - 1600.0, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
        for idx, lbl in enumerate([u'- Đường kính (mm):', u'- Chiều dài (m):', u'- Khối lượng (kg):', u'- Chiều dài / 11.7']):
            dxf.text(sum_x + 100.0, y0 - idx * 400.0 - 200.0, 100.0, lbl, 'Dce_text', 256, 0, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
        for ci, dk in enumerate(dks):
            lx, k = diam_totals[dk]
            cx0 = sum_x + 1900.0 + ci * 1100.0
            dxf.line(cx0 + 1100.0, y0, cx0 + 1100.0, y0 - 1600.0, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
            dxf.text(cx0 + 550.0, y0 - 200.0, 100.0, '%%%%c%d' % dk, 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
            dxf.text(cx0 + 550.0, y0 - 600.0, 100.0, '%.2f' % lx, 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
            dxf.text(cx0 + 550.0, y0 - 1000.0, 100.0, '%.2f' % k, 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
            dxf.text(cx0 + 550.0, y0 - 1400.0, 100.0, str(int(math.ceil(lx / 11.7))) if dk > 10 else '-', 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
        grand = w_le10 + w_mid + w_gt18
        row_top = y0 - 1650.0
        grp_rows = [
            (u'- Nhóm %%c <= 10:', w_le10, False),
            (u'- Nhóm 10 < %%c <= 18:', w_mid, False),
            (u'- Nhóm %%c > 18:', w_gt18, False),
            (u'- Tổng cộng:', grand, True),
        ]
        for glbl, gval, is_total in grp_rows:
            if glbl != u'- Nhóm %%c > 18:' or gval > 0.0:
                if is_total:
                    row_top -= 400.0
                row_bot = row_top - 400.0
                dxf.pline([(sum_x, row_top), (sum_x + totw, row_top), (sum_x + totw, row_bot), (sum_x, row_bot)], 'DCE_Lanh_To', True, 256, 'BeamCAD_SUM')
                dxf.line(sum_x + 1900.0, row_top, sum_x + 1900.0, row_bot, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
                if totw >= 3000.0:
                    dxf.line(sum_x + 3000.0, row_top, sum_x + 3000.0, row_bot, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
                ym = (row_top + row_bot) / 2.0
                dxf.text(sum_x + 100.0, ym, 100.0, glbl, 'Dce_text', 256, 0, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
                dxf.text(sum_x + 2450.0, ym, 100.0, '%.2f' % gval, 'Dce_text', 256, 4, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
                dxf.text(sum_x + 3550.0, ym, 100.0, 'kg', 'Dce_text', 256, 4, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
                row_top = row_bot

        num_cols = len(packed_cols)
        sched_total_w = max(num_cols * col_w + max(0, num_cols - 1) * col_gap, totw)
        sched_box = [(-125.0, sched_origin_y + 125.0), (sched_total_w + 125.0, sched_origin_y + 125.0),
                     (sched_total_w + 125.0, min(row_top, max_bot) - 470.0), (-125.0, min(row_top, max_bot) - 470.0)]
        dxf.pline(sched_box, 'Defpoints', True, 256, 'BeamCAD_SUM')

    # Stream DXF sections directly to disk in chunks to avoid giant string RAM spikes
    header_tables = dxf.buf
    dxf.buf = []
    dxf.set_target('buf')
    dxf.emit_block_records_table()
    dxf.p(0, 'ENDSEC')
    br_endsec = dxf.buf
    dxf.buf = []
    dxf.set_target('buf')
    dxf.p(0, 'SECTION'); dxf.p(2, 'OBJECTS')
    dxf.p(0, 'DICTIONARY'); dxf.p(5, 'C'); dxf.p(330, '0')
    dxf.p(100, 'AcDbDictionary'); dxf.p(281, 1)
    dxf.p(3, 'ACAD_GROUP'); dxf.p(350, 'D')
    dxf.p(3, 'ACAD_PLOTSTYLENAME'); dxf.p(350, 'E')
    dxf.p(0, 'DICTIONARY'); dxf.p(5, 'D'); dxf.p(330, 'C')
    dxf.p(100, 'AcDbDictionary'); dxf.p(281, 1)
    dxf.p(0, 'ACDBDICTIONARYWDFLT'); dxf.p(5, 'E'); dxf.p(330, 'C')
    dxf.p(100, 'AcDbDictionary'); dxf.p(281, 1)
    dxf.p(3, 'Normal'); dxf.p(350, 'F')
    dxf.p(100, 'AcDbDictionaryWithDefault'); dxf.p(340, 'F')
    dxf.p(0, 'ACDBPLACEHOLDER'); dxf.p(5, 'F'); dxf.p(330, 'E')
    dxf.p(0, 'ENDSEC')
    dxf.p(0, 'EOF')
    objects_eof = dxf.buf
    dxf.buf = []

    with io.open(out_dxf, 'wb') as f:
        DxfOut.write_lines_chunked(f, header_tables)
        del header_tables[:]
        DxfOut.write_lines_chunked(f, br_endsec)
        del br_endsec[:]
        DxfOut.write_lines_chunked(f, [u'0', u'SECTION', u'2', u'BLOCKS'])
        DxfOut.write_lines_chunked(f, dxf.blocks_buf)
        del dxf.blocks_buf[:]
        DxfOut.write_lines_chunked(f, dxf.dim_blocks_buf)
        del dxf.dim_blocks_buf[:]
        DxfOut.write_lines_chunked(f, [u'0', u'ENDSEC', u'0', u'SECTION', u'2', u'ENTITIES'])
        DxfOut.write_lines_chunked(f, dxf.entities_buf)
        del dxf.entities_buf[:]
        DxfOut.write_lines_chunked(f, [u'0', u'ENDSEC'])
        DxfOut.write_lines_chunked(f, objects_eof)
        del objects_eof[:]
    sched_cnt = len(sched)
    dxf.clear_buffers()
    del sched[:]
    wb.clear()
    beams_raw.clear()
    groups_map.clear()
    _gc.collect()
    return sched_cnt, grand


def _update_xlsx_nhip_edits(src_xlsx, edited_spans_by_beam, out_xlsx=None):
    wb = read_xlsx_rows(src_xlsx)
    nhip = [list(r) for r in wb.get('Nhip', [])]
    if len(nhip) < 2:
        raise ValueError(u'File Excel không có sheet Nhip hợp lệ.')
    cp = _build_col_lookup(nhip[0])
    c_nm = _find_col_idx(cp, [u'Tên dầm', 'Ten dam'], 0)
    c_sl = _find_col_idx(cp, ['SL', u'Số lượng'], 1)
    c_gt = _find_col_idx(cp, [u'Gối trái (mm)', u'Gối T (mm)', u'Gối trái'], 4)
    c_cl = _find_col_idx(cp, [u'L thông thủy (mm)', u'L thông thủy', u'Nhịp (mm)'], 8)
    c_mode = _find_col_idx(cp, _MODE_COL_ALIASES, 9)
    c_gp = _find_col_idx(cp, [u'Gối phải (mm)', u'Gối P (mm)', u'Gối phải'], 10)
    c_b = _find_col_idx(cp, ['b (mm)', 'b', u'Rộng'], 14)
    c_h = _find_col_idx(cp, ['h (mm)', 'h', 'Cao'], 15)
    c_st = _pick_stir_col(nhip, cp, 34)
    c_sts = _find_all_col_idxs(cp, _STIR_COL_ALIASES) or [c_st]

    max_col = max(35, len(nhip[0]), c_mode + 1, c_st + 1, max(c_sts) + 1)
    while len(nhip[0]) < max_col:
        nhip[0].append('')
    if not sstr(nhip[0][c_mode]):
        nhip[0][c_mode] = u'Cấu hình nhịp'
    if not sstr(nhip[0][c_st]):
        nhip[0][c_st] = u'Đai (Ø-a gối/a nhịp)'

    beam_row_idxs = {}
    for r_idx in range(1, len(nhip)):
        row = nhip[r_idx]
        while len(row) < max_col:
            row.append('')
        nm = sstr(row[c_nm] if c_nm < len(row) else '')
        if nm:
            beam_row_idxs.setdefault(nm, []).append(r_idx)

    for nm, idxs in beam_row_idxs.items():
        if nm not in edited_spans_by_beam:
            continue
        ed_list = edited_spans_by_beam[nm]
        for k, r_idx in enumerate(idxs):
            if k >= len(ed_list):
                break
            ed = ed_list[k]
            row = nhip[r_idx]
            row[c_sl] = max(1, int(round(num(ed.get('sl', 1), 1))))
            row[c_gt] = round(max(0.0, num(ed.get('gt', 0.0), 0.0)), 1)
            row[c_cl] = round(max(200.0, num(ed.get('clear', 3000.0), 3000.0)), 1)
            row[c_gp] = round(max(0.0, num(ed.get('gp', 0.0), 0.0)), 1)
            row[c_b] = round(max(80.0, num(ed.get('b', 200.0), 200.0)), 1)
            row[c_h] = round(max(80.0, num(ed.get('h', 400.0), 400.0)), 1)
            row[c_mode] = 'CHI_MAT_CAT' if ed.get('mode') == 'MC_ONLY' else ''
            st_s = sstr(ed.get('stir', ''))
            if st_s:
                for _cs in c_sts:
                    row[_cs] = st_s

    sheets_ordered = []
    for sh_name, rows in wb.items():
        if sh_name == 'Nhip':
            sheets_ordered.append(('Nhip', nhip))
        else:
            sheets_ordered.append((sh_name, rows))
    if 'Nhip' not in wb:
        sheets_ordered.insert(0, ('Nhip', nhip))
    target_path = out_xlsx or src_xlsx
    write_simple_xlsx(target_path, sheets_ordered)
    return target_path


def _default_beam_opt():
    return {
        'cover': 30.0, 'straight': 0.0, 'short': 1500.0, 'neo': '30d',
        'neo_top': '', 'neo_bot': '', 'cut': 'L/4', 'lap': '40d',
        'gap': u'xuống', 'ext': 'L/4', 'thr': 100.0, 'slope': 6.0,
        'stir': 8.0, 'pitch': 25.0, 'near': 800.0, 'hook_clr': 20.0, 'tc_hook': 1.0,
        'std': u'TCVN 5574:2018', 'concrete': 'B25', 'steel': 'CB400-V',
        'neo_mode': _NEO_MODES[0], 'step_neo': _STEP_NEO_MODES[0],
    }


def _apply_caidat_rows(opt, rows):
    def _parse_bool_opt(raw_v, default_v=1.0):
        vs = sstr(raw_v).lower()
        if not vs:
            return default_v
        if vs in ('0', 'false', 'no', u'không', 'khong', 'off', 'tắt', 'tat'):
            return 0.0
        if vs in ('1', 'true', 'yes', u'có', 'co', 'on', u'bật', 'bat'):
            return 1.0
        return 1.0 if num(raw_v, default_v) > 0 else 0.0

    def _apply_kv_pair(k_raw, v_raw):
        k = sstr(k_raw)
        v = sstr(v_raw)
        if not k or v == '':
            return
        kn = _norm_hdr(k).lower()
        if kn in ('thong so', 'ten thong so', 'stt', 'parameter', 'setting', 'cau hinh', 'gia tri'):
            return
        if (k == u'Lớp bảo vệ (mm)' or 'lop bao ve' in kn or 'cover' in kn) and num(v_raw, -1) > 0:
            opt['cover'] = num(v_raw)
        elif (u'chạy thẳng liền' in k or 'chay thang' in kn or 'chenh cote thang' in kn or 'chenh cao thang' in kn):
            opt['straight'] = max(0.0, num(v_raw, 0.0))
        elif (u'Nhịp < x mm' in k or 'nhip <' in kn or 'nhip ngan' in kn) and num(v_raw, -1) > 0:
            opt['short'] = num(v_raw)
        elif ('tieu chuan' in kn or 'standard' in kn or kn == 'tcvn') and v:
            opt['std'] = _norm_std_name(v, opt.get('std', u'TCVN 5574:2018'))
        elif ('mac be tong' in kn or 'cap do ben' in kn or 'be tong' in kn or 'concrete' in kn) and v:
            opt['concrete'] = _norm_concrete_grade(v, opt.get('concrete', 'B25'))
        elif ('nhom thep' in kn or 'mac thep' in kn or 'cot thep' in kn or 'steel' in kn) and v:
            opt['steel'] = _norm_steel_grade(v, opt.get('steel', 'CB400-V'))
        elif ('che do neo' in kn or 'kieu neo' in kn or 'quy cach neo' in kn) and v:
            opt['neo_mode'] = _norm_neo_mode(v)
        elif ('neo dam chenh' in kn or 'neo chenh' in kn or 'neo lech' in kn or 'giat cap' in kn or (('chenh cot' in kn or 'lech cot' in kn) and 'nguong' not in kn and 'chay thang' not in kn)) and v:
            opt['step_neo'] = _norm_step_neo(v)
        elif ('neo keo' in kn or 'neo tren' in kn or 'neo chiu keo' in kn or 'neo thep tren' in kn or 'lan keo' in kn) and v:
            opt['neo_top'] = v
        elif ('neo nen' in kn or 'neo duoi' in kn or 'neo chiu nen' in kn or 'neo thep duoi' in kn or 'lan nen' in kn) and v:
            opt['neo_bot'] = v
        elif (k == u'Chiều dài neo mặc định' or 'chieu dai neo' in kn or kn in ('neo', 'neo mac dinh', 'lan')) and v:
            opt['neo'] = v
        elif (k == u'Chiều dài gập mặc định' or 'chieu dai gap' in kn or 'chan be' in kn or 'moc neo' in kn) and v:
            opt['gap'] = v
        elif ('cat trong nhip' in kn or 'cat nhip' in kn or 'cat thep trong nhip' in kn) and v:
            opt['cut'] = v
        elif (k == u'Kéo dài ra nhịp mặc định' or 'keo dai ra nhip' in kn or 'vuon ra nhip' in kn or 'keo goi' in kn) and v:
            opt['ext'] = v
        elif ('noi chong' in kn or 'chieu dai noi' in kn or 'lap' in kn) and v:
            opt['lap'] = v
        elif ('tc luon gap' in kn or 'tang cuong gap' in kn or 'moc tang cuong' in kn or 'tc_hook' in kn):
            opt['tc_hook'] = _parse_bool_opt(v_raw, opt.get('tc_hook', 1.0))
        elif (u'Ngưỡng lệch tiết diện' in k or 'nguong lech' in kn or 'nguong chenh' in kn or ('chenh cote' in kn and 'cat' in kn) or 'cat neo' in kn) and num(v_raw, -1.0) >= 0.0:
            opt['thr'] = max(0.0, num(v_raw, 100.0))
        elif (u'Độ dốc uốn' in k or 'do doc' in kn) and num(v_raw, -1) > 0:
            opt['slope'] = num(v_raw)
        elif (u'giữa các lớp thép' in k or 'giua cac lop' in kn) and num(v_raw, -1) > 0:
            opt['pitch'] = num(v_raw)
        elif (u'lao ra' in k or 'lao ra' in kn or 'near' in kn) and num(v_raw, -1.0) >= 0.0:
            opt['near'] = num(v_raw, 800.0)
        elif (u'Khoảng hở chân bẻ' in k or 'khoang ho chan be' in kn) and num(v_raw, -1.0) >= 0.0:
            opt['hook_clr'] = num(v_raw, 20.0)

    for r in (rows or []):
        if not r or len(r) < 2:
            continue
        # Support 2-col [Key, Val], 3-col [STT, Key, Val], or multi-pair rows
        if len(r) >= 3 and (sstr(r[0]).isdigit() or not sstr(r[0])):
            _apply_kv_pair(r[1], r[2])
            if len(r) >= 5:
                _apply_kv_pair(r[3], r[4])
        else:
            _apply_kv_pair(r[0], r[1])
            if len(r) >= 4:
                _apply_kv_pair(r[2], r[3])
    return opt


def _apply_caidat_from_wb(opt, wb):
    if not isinstance(wb, dict):
        return opt
    seen_sh = set()
    for cand in ('CaiDat', u'CàiĐặt', 'Settings', 'CauHinh', u'CấuHình', 'Config', 'TieuChuan', u'TiêuChuẩn', 'Info'):
        for sh_nm, rows in wb.items():
            if sh_nm in seen_sh:
                continue
            if _norm_hdr(sh_nm).lower() == _norm_hdr(cand).lower() and rows:
                seen_sh.add(sh_nm)
                _apply_caidat_rows(opt, rows)
    # Infer concrete grade from Nhip 'Vật liệu' if concrete wasn't explicitly set in CaiDat
    nhip = wb.get('Nhip', [])
    if len(nhip) >= 2:
        cp = _build_col_lookup(nhip[0])
        c_mat = _find_col_idx(cp, [u'Vật liệu', 'Vat lieu'], None)
        if c_mat is not None:
            for r in nhip[1:]:
                if r and c_mat < len(r) and sstr(r[c_mat]):
                    g_inferred = _norm_concrete_grade(r[c_mat], '')
                    if g_inferred and opt.get('concrete', 'B25') == 'B25' and g_inferred != 'B25':
                        has_explicit = any(
                            len(cr) >= 2 and any('be tong' in _norm_hdr(x).lower() or 'concrete' in _norm_hdr(x).lower() for x in cr[:2])
                            for cr in (wb.get('CaiDat') or [])
                        )
                        if not has_explicit:
                            opt['concrete'] = g_inferred
                    break
    return opt


def _read_wb_opt_and_level(wb):
    opt = _default_beam_opt()
    _apply_caidat_from_wb(opt, wb)
    level_z = 0.0
    for sh_nm, rows in (wb or {}).items():
        if _norm_hdr(sh_nm).lower() in ('info', 'caidat'):
            for r in (rows or []):
                if r and len(r) >= 2 and (u'Cao độ' in sstr(r[0]) or 'Cao do' in _norm_hdr(r[0])):
                    level_z = num(r[1], 0.0)
    return opt, level_z


def _snapshot_beam_style(pl):
    return {
        'grps': [dict(g) for g in (pl.get('grps') or [])],
        'stirs': [sstr(sp.get('stir', '8-100/200')) for sp in (pl.get('spans') or [])],
        'cover': num((pl.get('opt') or {}).get('cover', 30.0), 30.0),
        'stir': num((pl.get('opt') or {}).get('stir', 8.0), 8.0),
    }


def _restore_beam_style(pl, snap, target_mode):
    pl['mode'] = 'MC_ONLY' if target_mode == 'MC_ONLY' else 'FULL'
    if not snap:
        return pl
    if 'grps' in snap and snap['grps'] is not None:
        pl['grps'] = [dict(g) for g in snap['grps']]
    stirs = snap.get('stirs') or []
    for idx_s, sp in enumerate(pl.get('spans') or []):
        if stirs:
            sp['stir'] = stirs[min(idx_s, len(stirs) - 1)]
    if 'opt' not in pl or not isinstance(pl['opt'], dict):
        pl['opt'] = _default_beam_opt()
    if 'cover' in snap:
        pl['opt']['cover'] = num(snap['cover'], pl['opt'].get('cover', 30.0))
    if 'stir' in snap:
        pl['opt']['stir'] = num(snap['stir'], pl['opt'].get('stir', 8.0))
    return pl


def _parse_planted_str(raw_s):
    out = []
    for tok in re.split(r'[;,]', sstr(raw_s)):
        tok = tok.strip()
        if not tok:
            continue
        parts = tok.split('@')
        if len(parts) >= 2:
            pname = parts[0].strip() or 'CC'
            ppos = num(parts[1], 1000.0)
            pw = num(parts[2], 200.0) if len(parts) >= 3 else 200.0
            out.append({'name': pname, 'pos': ppos, 'w': pw})
    return out


def _fmt_planted_str(planted_list):
    if not planted_list:
        return ''
    return ';'.join(
        '%s@%d@%d' % (sstr(p.get('name', 'CC')) or 'CC', int(round(num(p.get('pos', 1000.0)))), int(round(num(p.get('w', 200.0)))))
        for p in planted_list
    )


def _extract_payload_from_wb(wb, bname):
    opt, level_z = _read_wb_opt_and_level(wb)
    nhip = wb.get('Nhip', [])
    if len(nhip) < 2:
        raise ValueError(u'File Excel không có sheet Nhip hợp lệ.')
    cp = _build_col_lookup(nhip[0])
    c_nm = _find_col_idx(cp, [u'Tên dầm', 'Ten dam'], 0)
    c_sl = _find_col_idx(cp, ['SL', u'Số lượng'], 1)
    c_mat = _find_col_idx(cp, [u'Vật liệu', 'Vat lieu'], 3)
    c_gt = _find_col_idx(cp, [u'Gối trái (mm)', u'Gối T (mm)', u'Gối trái'], 4)
    c_lgt = _find_col_idx(cp, [u'Loại gối T', u'Loại GT', 'Loai goi T', 'Loai GT'], 5)
    c_tt = _find_col_idx(cp, [u'Trục T', u'Trục trái', 'Truc T', 'Truc trai'], 6)
    c_lt = _find_col_idx(cp, [u'Lệch trục T (mm)', 'Lech truc T'], 7)
    c_cl = _find_col_idx(cp, [u'L thông thủy (mm)', u'L thông thủy', u'Nhịp (mm)'], 8)
    c_mode = _find_col_idx(cp, _MODE_COL_ALIASES, 9)
    c_modes = _find_all_col_idxs(cp, _MODE_COL_ALIASES) or ([c_mode] if c_mode is not None else [])
    c_gp = _find_col_idx(cp, [u'Gối phải (mm)', u'Gối P (mm)', u'Gối phải'], 10)
    c_lgp = _find_col_idx(cp, [u'Loại gối P', u'Loại GP', 'Loai goi P', 'Loai GP'], 11)
    c_tp = _find_col_idx(cp, [u'Trục P', u'Trục phải', 'Truc P', 'Truc phai'], 12)
    c_lp = _find_col_idx(cp, [u'Lệch trục P (mm)', 'Lech truc P'], 13)
    c_b = _find_col_idx(cp, ['b (mm)', 'b', u'Rộng'], 14)
    c_h = _find_col_idx(cp, ['h (mm)', 'h', 'Cao'], 15)
    c_top = _find_col_idx(cp, [u'Cao đỉnh (mm)', 'Cao dinh'], 16)
    c_hs = _find_col_idx(cp, [u'h sàn (mm)', 'h san'], 17)
    c_sl_th = _find_col_idx(cp, [u'Sàn T dày (mm)', 'San T day'], 18)
    c_sl_tp = _find_col_idx(cp, [u'Sàn T đỉnh (mm)', 'San T dinh'], 19)
    c_sr_th = _find_col_idx(cp, [u'Sàn P dày (mm)', 'San P day'], 20)
    c_sr_tp = _find_col_idx(cp, [u'Sàn P đỉnh (mm)', 'San P dinh'], 21)
    c_role_l = _find_col_idx(cp, [u'Vai trò gối T', u'Vai trò GT', 'Vai tro goi T', 'Vai tro GT'], 26)
    c_role_r = _find_col_idx(cp, [u'Vai trò gối P', u'Vai trò GP', 'Vai tro goi P', 'Vai tro GP'], 28)
    c_pl = _find_col_idx(cp, _PLANTED_COL_ALIASES, 29)
    c_lvl = _find_col_idx(cp, [u'Cao độ tầng (mm)', 'Cao do tang (mm)', u'Cao độ tầng', 'Cao do tang'])
    c_st = _pick_stir_col(nhip, cp, 34)

    rows_b = [r for r in nhip[1:] if r and sstr(r[c_nm] if c_nm < len(r) else '') == sstr(bname)]
    if not rows_b:
        raise ValueError(u'Không tìm thấy dầm "%s" trong dữ liệu.' % sstr(bname))

    def _rv(r, idx, default=''):
        return r[idx] if (idx is not None and idx < len(r)) else default

    if c_lvl is not None and sstr(_rv(rows_b[0], c_lvl, '')) != '':
        level_z = num(_rv(rows_b[0], c_lvl, level_z), level_z)
    sl_ck = max(1, int(round(num(_rv(rows_b[0], c_sl, 1), 1))))
    mat_s = sstr(_rv(rows_b[0], c_mat, 'B25')) or 'B25'
    mode_s = 'MC_ONLY' if any(_is_mc_only_token(_rv(rr, cm_i, '')) for rr in rows_b for cm_i in c_modes) else 'FULL'

    sups = []
    spans = []
    for i, r in enumerate(rows_b):
        gt_w = max(0.0, num(_rv(r, c_gt, 220.0), 220.0))
        gt_k = sstr(_rv(r, c_lgt, 'C')) or 'C'
        gt_g = sstr(_rv(r, c_tt, str(i + 1)))
        gt_o = num(_rv(r, c_lt, 0.0), 0.0)
        gt_r = sstr(_rv(r, c_role_l, ''))
        gp_w = max(0.0, num(_rv(r, c_gp, 220.0), 220.0))
        gp_k = sstr(_rv(r, c_lgp, 'C')) or 'C'
        gp_g = sstr(_rv(r, c_tp, str(i + 2)))
        gp_o = num(_rv(r, c_lp, 0.0), 0.0)
        gp_r = sstr(_rv(r, c_role_r, ''))
        if i == 0:
            sups.append({'w': gt_w, 'kind': gt_k, 'grid': gt_g, 'off': gt_o, 'role': gt_r})
        else:
            if gt_w > 0 and sups[-1]['w'] <= 0:
                sups[-1]['w'] = gt_w
            if gt_g and not sups[-1]['grid']:
                sups[-1]['grid'] = gt_g
            if gt_r and not sups[-1]['role']:
                sups[-1]['role'] = gt_r
        sups.append({'w': gp_w, 'kind': gp_k, 'grid': gp_g, 'off': gp_o, 'role': gp_r})

        top_v = num(_rv(r, c_top, 0.0), 0.0)
        hs_v = max(0.0, num(_rv(r, c_hs, 120.0), 120.0))
        s_lt = num(_rv(r, c_sl_th, hs_v), hs_v)
        s_ltp = num(_rv(r, c_sl_tp, top_v), top_v)
        s_rt = num(_rv(r, c_sr_th, hs_v), hs_v)
        s_rtp = num(_rv(r, c_sr_tp, top_v), top_v)
        spans.append({
            'clear': max(200.0, num(_rv(r, c_cl, 3000.0), 3000.0)),
            'b': max(80.0, num(_rv(r, c_b, 200.0), 200.0)),
            'h': max(80.0, num(_rv(r, c_h, 400.0), 400.0)),
            'top': top_v,
            'hs': hs_v,
            'slabL': s_lt,
            'slabL_top': s_ltp,
            'slabR': s_rt,
            'slabR_top': s_rtp,
            'stir': sstr(_rv(r, c_st, '6-100/200')) or '6-100/200',
            'planted': _parse_planted_str(_rv(r, c_pl, '')),
        })

    grps = []
    thep_sh = wb.get('Thep', [])
    if len(thep_sh) >= 2:
        th_cp = _build_col_lookup(thep_sh[0])
        c_tbn = _find_col_idx(th_cp, [u'Tên dầm', 'Ten dam'], 0)
        c_tnt = _find_col_idx(th_cp, _THEP_NOTE_ALIASES, 1)
        c_tps = _find_col_idx(th_cp, [u'Vị trí', 'Vi tri'], 2)
        c_tly = _find_col_idx(th_cp, [u'Lớp', 'Lop'], 3)
        c_tsl = _find_col_idx(th_cp, ['SL', u'Số lượng', 'So luong'], 4)
        c_tph = _find_col_idx(th_cp, ['Phi', u'Đường kính', 'DK', 'Duong kinh'], 5)
        c_tga = _find_col_idx(th_cp, [u'Gối A', u'Từ gối', 'Goi A', 'Tu goi'], 6)
        c_tlk = _find_col_idx(th_cp, _THEP_LK_ALIASES, 7)
        c_tlv = _find_col_idx(th_cp, [u'Giá trị trái', 'Gia tri trai', 'GT trai'], 8)
        c_tgb = _find_col_idx(th_cp, [u'Gối B', u'Đến gối', 'Goi B', 'Den goi'], 9)
        c_trk = _find_col_idx(th_cp, _THEP_RK_ALIASES, 10)
        c_trv = _find_col_idx(th_cp, [u'Giá trị phải', 'Gia tri phai', 'GT phai'], 11)
        c_tcr = _find_col_idx(th_cp, _THEP_CR_ALIASES, 12)
        c_tn2 = _find_col_idx(th_cp, [u'Ghi chú thêm', 'Note 2'], 13)
        for tr in thep_sh[1:]:
            if not tr or len(tr) < 6 or sstr(tr[c_tbn] if c_tbn is not None and c_tbn < len(tr) else '') != sstr(bname):
                continue
            note_s = sstr(_rv(tr, c_tn2, ''))
            if not note_s:
                cand_nt = sstr(_rv(tr, c_tnt, ''))
                if cand_nt and not cand_nt.isdigit():
                    note_s = cand_nt
            grps.append({
                'pos': norm_pos(_rv(tr, c_tps, u'Trên')),
                'layer': max(1, int(round(num(_rv(tr, c_tly, 1), 1)))),
                'n': max(1, int(round(num(_rv(tr, c_tsl, 2), 2)))),
                'd': max(6, int(round(num(_rv(tr, c_tph, 18), 18)))),
                'a': _parse_sup_idx(_rv(tr, c_tga, 0), 0),
                'lk': norm_end(_rv(tr, c_tlk, u'Gập vào cột')),
                'lv': sstr(_rv(tr, c_tlv, u'xuống')),
                'b': _parse_sup_idx(_rv(tr, c_tgb, len(spans)), len(spans)),
                'rk': norm_end(_rv(tr, c_trk, u'Gập vào cột')),
                'rv': sstr(_rv(tr, c_trv, u'xuống')),
                'cross': norm_cross(_rv(tr, c_tcr, u'Tự động')),
                'note': note_s,
            })
    if not grps:
        grps = [
            {'pos': u'Trên', 'layer': 1, 'n': 2, 'd': 18, 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': len(spans), 'rk': u'Gập vào cột', 'rv': u'xuống', 'cross': u'Tự động', 'note': ''},
            {'pos': u'Dưới', 'layer': 1, 'n': 2, 'd': 18, 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': len(spans), 'rk': u'Gập vào cột', 'rv': u'xuống', 'cross': u'Tự động', 'note': ''},
        ]

    return {
        'bname': sstr(bname),
        'sl': sl_ck,
        'mode': mode_s,
        'mat': mat_s,
        'level_z': level_z,
        'opt': opt,
        'sups': sups,
        'spans': spans,
        'grps': grps,
    }


def _load_beam_payload_from_xlsx(src_xlsx, bname):
    return _extract_payload_from_wb(read_xlsx_rows(src_xlsx), bname)


def _apply_payload_to_wb(wb, payload, orig_bname=None):
    def _std_nhip_hdr():
        h = [
            'Tên dầm', 'SL', 'Nhịp', 'Vật liệu',
            'Gối trái (mm)', 'Loại GT', 'Trục T', 'Lệch trục T (mm)', 'L thông thủy (mm)', 'Cấu hình nhịp',
            'Gối phải (mm)', 'Loại GP', 'Trục P', 'Lệch trục P (mm)',
            'b (mm)', 'h (mm)', 'Cao đỉnh (mm)', 'h sàn (mm)', 'Sàn T dày (mm)', 'Sàn T đỉnh (mm)', 'Sàn P dày (mm)', 'Sàn P đỉnh (mm)',
        ]
        while len(h) < 35:
            if len(h) == 22:
                h.append(u'Cao độ tầng (mm)')
            elif len(h) == 26:
                h.append(u'Vai trò gối T')
            elif len(h) == 28:
                h.append(u'Vai trò gối P')
            elif len(h) == 29:
                h.append(u'Cột cấy (tên@vị trí@rộng)')
            elif len(h) == 34:
                h.append('Đai (Ø-a gối/a nhịp)')
            else:
                h.append('')
        return h

    nhip = [list(r) for r in wb.get('Nhip', [])]
    if not nhip:
        nhip = [_std_nhip_hdr()]
    cp = _build_col_lookup(nhip[0])
    c_nm = _find_col_idx(cp, [u'Tên dầm', 'Ten dam'], 0)
    c_sl = _find_col_idx(cp, ['SL', u'Số lượng'], 1)
    c_sp = _find_col_idx(cp, [u'Nhịp', 'Nhip'], 2)
    c_mat = _find_col_idx(cp, [u'Vật liệu', 'Vat lieu'], 3)
    c_gt = _find_col_idx(cp, [u'Gối trái (mm)', u'Gối T (mm)', u'Gối trái'], 4)
    c_lgt = _find_col_idx(cp, [u'Loại gối T', u'Loại GT', 'Loai goi T', 'Loai GT'], 5)
    c_tt = _find_col_idx(cp, [u'Trục T', u'Trục trái', 'Truc T', 'Truc trai'], 6)
    c_lt = _find_col_idx(cp, [u'Lệch trục T (mm)', 'Lech truc T'], 7)
    c_cl = _find_col_idx(cp, [u'L thông thủy (mm)', u'L thông thủy', u'Nhịp (mm)'], 8)
    c_mode = _find_col_idx(cp, _MODE_COL_ALIASES, 9)
    c_modes = _find_all_col_idxs(cp, _MODE_COL_ALIASES) or [c_mode]
    c_gp = _find_col_idx(cp, [u'Gối phải (mm)', u'Gối P (mm)', u'Gối phải'], 10)
    c_lgp = _find_col_idx(cp, [u'Loại gối P', u'Loại GP', 'Loai goi P', 'Loai GP'], 11)
    c_tp = _find_col_idx(cp, [u'Trục P', u'Trục phải', 'Truc P', 'Truc phai'], 12)
    c_lp = _find_col_idx(cp, [u'Lệch trục P (mm)', 'Lech truc P'], 13)
    c_b = _find_col_idx(cp, ['b (mm)', 'b', u'Rộng'], 14)
    c_h = _find_col_idx(cp, ['h (mm)', 'h', 'Cao'], 15)
    c_top = _find_col_idx(cp, [u'Cao đỉnh (mm)', 'Cao dinh'], 16)
    c_hs = _find_col_idx(cp, [u'h sàn (mm)', 'h san'], 17)
    c_slt = _find_col_idx(cp, [u'Sàn T dày (mm)', 'San T day'], 18)
    c_slp = _find_col_idx(cp, [u'Sàn T đỉnh (mm)', 'San T dinh'], 19)
    c_srt = _find_col_idx(cp, [u'Sàn P dày (mm)', 'San P day'], 20)
    c_srp = _find_col_idx(cp, [u'Sàn P đỉnh (mm)', 'San P dinh'], 21)
    c_role_l = _find_col_idx(cp, [u'Vai trò gối T', u'Vai trò GT', 'Vai tro goi T', 'Vai tro GT'], 26)
    c_role_r = _find_col_idx(cp, [u'Vai trò gối P', u'Vai trò GP', 'Vai tro goi P', 'Vai tro GP'], 28)
    c_pl = _find_col_idx(cp, _PLANTED_COL_ALIASES, 29)
    c_lvl = _find_col_idx(cp, [u'Cao độ tầng (mm)', 'Cao do tang (mm)', u'Cao độ tầng', 'Cao do tang'])
    c_st = _pick_stir_col(nhip, cp, 34)
    c_sts = _find_all_col_idxs(cp, _STIR_COL_ALIASES) or [c_st]
    max_col = max(35, len(nhip[0]), c_st + 1, c_mode + 1, max(c_modes) + 1, c_pl + 1, (c_lvl + 1 if c_lvl is not None else 0), max(c_sts) + 1)
    while len(nhip[0]) < max_col:
        nhip[0].append('')
    if not sstr(nhip[0][c_mode]):
        nhip[0][c_mode] = u'Cấu hình nhịp'
    if not sstr(nhip[0][c_pl]):
        nhip[0][c_pl] = u'Cột cấy (tên@vị trí@rộng)'
    if not sstr(nhip[0][c_st]):
        nhip[0][c_st] = u'Đai (Ø-a gối/a nhịp)'

    new_bname = sstr(payload.get('bname', '')) or 'D1'
    old_names = set([new_bname])
    if orig_bname:
        old_names.add(sstr(orig_bname))

    orig_rows_b = [list(r) for r in nhip[1:] if r and sstr(r[c_nm] if c_nm < len(r) else '') in old_names]

    spans = payload.get('spans') or []
    sups = payload.get('sups') or []
    while len(sups) < len(spans) + 1:
        sups.append({'w': 220.0, 'kind': 'C', 'grid': str(len(sups) + 1), 'off': 0.0, 'role': ''})

    mode_tok = 'CHI_MAT_CAT' if payload.get('mode') == 'MC_ONLY' else ''
    sl_val = max(1, int(round(num(payload.get('sl', 1), 1))))
    mat_val = sstr(payload.get('mat', 'B25')) or 'B25'
    new_nhip_rows = []
    for sp_i, sp in enumerate(spans):
        sL = sups[sp_i]
        sR = sups[sp_i + 1]
        if sp_i < len(orig_rows_b):
            row = list(orig_rows_b[sp_i]) + [''] * max(0, max_col - len(orig_rows_b[sp_i]))
        else:
            row = [''] * max_col
        row[c_nm] = new_bname
        row[c_sl] = sl_val
        row[c_sp] = sp_i + 1
        if c_mat is not None:
            row[c_mat] = mat_val
        row[c_gt] = round(max(0.0, num(sL.get('w', 220.0), 220.0)), 1)
        row[c_lgt] = sstr(sL.get('kind', 'C')) or 'C'
        row[c_tt] = sstr(sL.get('grid', ''))
        row[c_lt] = round(num(sL.get('off', 0.0), 0.0), 1)
        row[c_cl] = round(max(200.0, num(sp.get('clear', 3000.0), 3000.0)), 1)
        for _cm in c_modes:
            row[_cm] = mode_tok
        row[c_gp] = round(max(0.0, num(sR.get('w', 220.0), 220.0)), 1)
        row[c_lgp] = sstr(sR.get('kind', 'C')) or 'C'
        row[c_tp] = sstr(sR.get('grid', ''))
        row[c_lp] = round(num(sR.get('off', 0.0), 0.0), 1)
        row[c_b] = round(max(80.0, num(sp.get('b', 200.0), 200.0)), 1)
        row[c_h] = round(max(80.0, num(sp.get('h', 400.0), 400.0)), 1)
        if c_top is not None:
            row[c_top] = round(num(sp.get('top', 0.0), 0.0), 1)
        if c_hs is not None:
            row[c_hs] = round(max(0.0, num(sp.get('hs', 120.0), 120.0)), 1)
        if c_slt is not None:
            row[c_slt] = round(max(0.0, num(sp.get('slabL', sp.get('hs', 120.0)), 120.0)), 1)
        if c_slp is not None:
            row[c_slp] = round(num(sp.get('slabL_top', sp.get('top', 0.0)), 0.0), 1)
        if c_srt is not None:
            row[c_srt] = round(max(0.0, num(sp.get('slabR', sp.get('hs', 120.0)), 120.0)), 1)
        if c_srp is not None:
            row[c_srp] = round(num(sp.get('slabR_top', sp.get('top', 0.0)), 0.0), 1)
        if c_role_l is not None and sstr(sL.get('role', '')):
            row[c_role_l] = sstr(sL.get('role', ''))
        if c_role_r is not None and sstr(sR.get('role', '')):
            row[c_role_r] = sstr(sR.get('role', ''))
        if c_pl is not None:
            row[c_pl] = _fmt_planted_str(sp.get('planted'))
        if c_lvl is not None:
            row[c_lvl] = round(num(payload.get('level_z', 0.0), 0.0), 1)
        stir_val = sstr(sp.get('stir', '6-100/200')) or '6-100/200'
        for _cs in c_sts:
            row[_cs] = stir_val
        new_nhip_rows.append(row)

    out_nhip = [nhip[0]]
    inserted_nhip = False
    for r in nhip[1:]:
        bn = sstr(r[c_nm] if c_nm < len(r) else '')
        if bn in old_names:
            if not inserted_nhip:
                out_nhip.extend(new_nhip_rows)
                inserted_nhip = True
        else:
            out_nhip.append(r)
    if not inserted_nhip:
        out_nhip.extend(new_nhip_rows)

    thep = [list(r) for r in wb.get('Thep', [])]
    if not thep:
        thep = [[
            'Tên dầm', 'Ghi chú', 'Vị trí', 'Lớp', 'SL', 'Phi', 'Gối A', 'Kiểu trái', 'Giá trị trái',
            'Gối B', 'Kiểu phải', 'Giá trị phải', 'Vượt gối'
        ]]
    th_cp = _build_col_lookup(thep[0])
    c_tbn = _find_col_idx(th_cp, [u'Tên dầm', 'Ten dam'], 0)
    c_tnt = _find_col_idx(th_cp, _THEP_NOTE_ALIASES, 1)
    c_tps = _find_col_idx(th_cp, [u'Vị trí', 'Vi tri'], 2)
    c_tly = _find_col_idx(th_cp, [u'Lớp', 'Lop'], 3)
    c_tsl = _find_col_idx(th_cp, ['SL', u'Số lượng', 'So luong'], 4)
    c_tph = _find_col_idx(th_cp, ['Phi', u'Đường kính', 'DK', 'Duong kinh'], 5)
    c_tga = _find_col_idx(th_cp, [u'Gối A', u'Từ gối', 'Goi A', 'Tu goi'], 6)
    c_tlk = _find_col_idx(th_cp, _THEP_LK_ALIASES, 7)
    c_tlv = _find_col_idx(th_cp, [u'Giá trị trái', 'Gia tri trai', 'GT trai'], 8)
    c_tgb = _find_col_idx(th_cp, [u'Gối B', u'Đến gối', 'Goi B', 'Den goi'], 9)
    c_trk = _find_col_idx(th_cp, _THEP_RK_ALIASES, 10)
    c_trv = _find_col_idx(th_cp, [u'Giá trị phải', 'Gia tri phai', 'GT phai'], 11)
    c_tcr = _find_col_idx(th_cp, _THEP_CR_ALIASES, 12)
    c_tn2 = _find_col_idx(th_cp, [u'Ghi chú thêm', 'Note 2'], None)
    max_th_idx = max([c_tbn, c_tnt, c_tps, c_tly, c_tsl, c_tph, c_tga, c_tlk, c_tlv, c_tgb, c_trk, c_trv, c_tcr] + ([c_tn2] if c_tn2 is not None else []))
    th_cols = max(13, len(thep[0]), max_th_idx + 1)
    while len(thep[0]) < th_cols:
        thep[0].append('')

    tnt_is_stt = (c_tnt is not None and _norm_hdr(thep[0][c_tnt]) == 'stt')
    new_thep_rows = []
    for gi_t, g in enumerate(payload.get('grps') or [], 1):
        tr = [''] * th_cols
        tr[c_tbn] = new_bname
        if c_tn2 is not None:
            tr[c_tn2] = sstr(g.get('note', ''))
            if tnt_is_stt:
                tr[c_tnt] = gi_t
        elif c_tnt is not None:
            tr[c_tnt] = gi_t if (tnt_is_stt and not sstr(g.get('note', ''))) else sstr(g.get('note', ''))
        tr[c_tps] = norm_pos(g.get('pos', u'Trên'))
        tr[c_tly] = max(1, int(round(num(g.get('layer', 1), 1))))
        tr[c_tsl] = max(1, int(round(num(g.get('n', 2), 2))))
        tr[c_tph] = max(6, int(round(num(g.get('d', 18), 18))))
        ga_idx = max(0, min(len(spans), int(round(num(g.get('a', 0), 0)))))
        tr[c_tga] = ga_idx
        tr[c_tlk] = norm_end(g.get('lk', u'Gập vào cột'))
        tr[c_tlv] = sstr(g.get('lv', u'xuống'))
        tr[c_tgb] = max(ga_idx, min(len(spans), int(round(num(g.get('b', len(spans)), len(spans))))))
        tr[c_trk] = norm_end(g.get('rk', u'Gập vào cột'))
        tr[c_trv] = sstr(g.get('rv', u'xuống'))
        tr[c_tcr] = norm_cross(g.get('cross', u'Tự động'))
        new_thep_rows.append(tr)

    out_thep = [thep[0]]
    inserted_thep = False
    for tr in thep[1:]:
        bn = sstr(tr[c_tbn] if c_tbn < len(tr) else '')
        if bn in old_names:
            if not inserted_thep:
                out_thep.extend(new_thep_rows)
                inserted_thep = True
        else:
            out_thep.append(tr)
    if not inserted_thep:
        out_thep.extend(new_thep_rows)

    opt_ed = payload.get('opt') or {}
    opt_updates = [
        (u'Tiêu chuẩn thiết kế', _norm_std_name(opt_ed.get('std', ''), u'TCVN 5574:2018'), ('tieu chuan', 'standard')),
        (u'Mác bê tông', _norm_concrete_grade(opt_ed.get('concrete', ''), 'B25'), ('mac be tong', 'be tong', 'cap do ben')),
        (u'Nhóm thép chủ', _norm_steel_grade(opt_ed.get('steel', ''), 'CB400-V'), ('nhom thep', 'mac thep', 'cot thep')),
        (u'Chế độ neo thép', _norm_neo_mode(opt_ed.get('neo_mode', '')), ('che do neo', 'kieu neo', 'quy cach neo')),
        (u'Neo dầm chênh cốt', _norm_step_neo(opt_ed.get('step_neo', '')), ('neo dam chenh', 'neo chenh', 'neo lech', 'giat cap', 'chenh cot')),
        (u'Lớp bảo vệ (mm)', round(max(10.0, num(opt_ed.get('cover', 30.0), 30.0)), 1), ('lop bao ve',)),
        (u'Chênh cao chạy thẳng liền (mm)', round(max(0.0, num(opt_ed.get('straight', 0.0), 0.0)), 1), ('chay thang', 'chenh cote thang', 'chenh cao thang')),
        (u'Ngưỡng lệch tiết diện để uốn / cắt neo (mm)', round(max(0.0, num(opt_ed.get('thr', 100.0), 100.0)), 1), ('nguong lech', 'nguong chenh', 'cat neo')),
        (u'Độ dốc uốn xiên thép qua gối (1:k)', round(max(1.0, num(opt_ed.get('slope', 6.0), 6.0)), 1), ('do doc',)),
        (u'Chiều dài neo mặc định', sstr(opt_ed.get('neo', '30d')) or '30d', ('chieu dai neo',)),
        (u'Chiều dài neo kéo (Trên)', sstr(opt_ed.get('neo_top', '')), ('neo keo', 'neo tren')),
        (u'Chiều dài neo nén (Dưới)', sstr(opt_ed.get('neo_bot', '')), ('neo nen', 'neo duoi')),
        (u'Chiều dài nối chồng', sstr(opt_ed.get('lap', '40d')) or '40d', ('noi chong', 'chieu dai noi')),
        (u'Chiều dài gập mặc định', sstr(opt_ed.get('gap', u'xuống')) or u'xuống', ('chieu dai gap',)),
        (u'Kéo dài ra nhịp mặc định', sstr(opt_ed.get('ext', 'L/4')) or 'L/4', ('keo dai ra nhip',)),
        (u'Cắt trong nhịp mặc định', sstr(opt_ed.get('cut', 'L/4')) or 'L/4', ('cat trong nhip', 'cat nhip')),
        (u'TC luôn gập vào cột', '1' if bool(opt_ed.get('tc_hook', 1.0)) else '0', ('tc luon gap', 'tang cuong gap')),
        (u'Khoảng hở giữa các lớp thép (mm)', round(max(15.0, num(opt_ed.get('pitch', 25.0), 25.0)), 1), ('giua cac lop',)),
        (u'Khoảng cách lao ra khỏi gối (mm)', round(max(0.0, num(opt_ed.get('near', 800.0), 800.0)), 1), ('lao ra',)),
    ]
    caidat = [list(r) for r in wb.get('CaiDat', [])]
    if not caidat:
        caidat = [[u'Thông số', u'Giá trị']]
    cd_norm_map = [(_norm_hdr(r[0]).lower() if r else '', i) for i, r in enumerate(caidat) if i > 0 and r]
    for ck, cv, match_toks in opt_updates:
        idx_c = None
        for kn_row, r_i in cd_norm_map:
            if any(tok in kn_row for tok in match_toks):
                idx_c = r_i
                break
        if idx_c is not None:
            while len(caidat[idx_c]) < 2:
                caidat[idx_c].append('')
            caidat[idx_c][1] = cv
        elif sstr(cv) != '':
            caidat.append([ck, cv])

    info = [list(r) for r in wb.get('Info', [])]
    lvl_val = round(num(payload.get('level_z', 0.0), 0.0), 1)
    updated_lvl = False
    for r in info:
        if r and len(r) >= 2 and (u'Cao độ' in sstr(r[0]) or 'Cao do' in _norm_hdr(r[0])):
            r[1] = lvl_val
            updated_lvl = True
            break
    if not updated_lvl:
        info.append([u'Cao độ tầng theo Project Base Point (mm)', lvl_val])

    wb['Nhip'] = out_nhip
    wb['Thep'] = out_thep
    wb['CaiDat'] = caidat
    wb['Info'] = info
    return wb


def _wb_to_sheets_ordered(wb):
    sheets_ordered = []
    seen_sh = set()
    for sh_name, rows in wb.items():
        seen_sh.add(sh_name)
        sheets_ordered.append((sh_name, rows))
    for sh_name in ('Nhip', 'Thep', 'CaiDat', 'Info'):
        if sh_name not in seen_sh:
            sheets_ordered.append((sh_name, wb.get(sh_name, [])))
    return sheets_ordered


def _save_beam_payload_to_xlsx(src_xlsx, payload, orig_bname=None, out_xlsx=None):
    target_path = out_xlsx or src_xlsx
    wb = read_xlsx_rows(src_xlsx) if (src_xlsx and os.path.isfile(src_xlsx)) else {}
    _apply_payload_to_wb(wb, payload, orig_bname=orig_bname)
    write_simple_xlsx(target_path, _wb_to_sheets_ordered(wb))
    return target_path


def _batch_update_xlsx_payloads(src_xlsx, target_bnames, mutator_fn, out_xlsx=None):
    """Read XLSX once, mutate multiple beam payloads in memory (O(N)), and write XLSX once."""
    if not src_xlsx or not os.path.isfile(src_xlsx):
        return 0, {}, []
    target_path = out_xlsx or src_xlsx
    wb = read_xlsx_rows(src_xlsx)
    nhip = wb.get('Nhip', [])
    if len(nhip) < 2:
        return 0, wb, []
    cp = _build_col_lookup(nhip[0])
    c_nm = _find_col_idx(cp, [u'Tên dầm', 'Ten dam'], 0)
    avail = []
    seen = set()
    for r in nhip[1:]:
        nm = sstr(r[c_nm] if c_nm < len(r) else '')
        if nm and nm not in seen:
            seen.add(nm)
            avail.append(nm)
    targets = [sstr(b) for b in (target_bnames or avail) if sstr(b) in seen]
    updated = 0
    errs = []
    for bname in targets:
        try:
            pl = _extract_payload_from_wb(wb, bname)
            res = mutator_fn(bname, pl)
            if res is False:
                continue
            _apply_payload_to_wb(wb, pl, orig_bname=bname)
            updated += 1
        except Exception as ex_b:
            errs.append(u'%s: %s' % (bname, sstr(ex_b)))
    if updated > 0 or target_path != src_xlsx:
        write_simple_xlsx(target_path, _wb_to_sheets_ordered(wb))
    return updated, wb, errs


def _parse_cad_scan_to_payload(scan_json_path):
    with io.open(scan_json_path, 'rb') as f:
        raw_txt = f.read().decode('utf-8-sig', 'replace')
    data = json.loads(raw_txt)
    if not isinstance(data, dict) or not data.get('ok'):
        raise ValueError(u'Không đọc được dữ liệu dầm hợp lệ từ AutoCAD.')

    bname = sstr(data.get('bname', ''))
    skc = max(1, int(round(num(data.get('skc', 1), 1))))
    meta = data.get('meta')
    opt = _default_beam_opt()

    if isinstance(meta, dict) and meta.get('spans'):
        if meta.get('b') and not bname:
            bname = sstr(meta.get('b'))
        skc = max(skc, max(1, int(round(num(meta.get('sl', 1), 1)))))
        m_opt = meta.get('opt') or {}
        opt['cover'] = num(m_opt.get('cover', 30.0), 30.0)
        opt['ext'] = sstr(m_opt.get('ext', 'L/4')) or 'L/4'
        opt['cut'] = sstr(m_opt.get('cut', opt['ext'])) or 'L/4'
        opt['neo'] = sstr(m_opt.get('neo', '30d')) or '30d'
        opt['neo_top'] = sstr(m_opt.get('neo_top', ''))
        opt['neo_bot'] = sstr(m_opt.get('neo_bot', ''))
        opt['lap'] = sstr(m_opt.get('lap', '40d')) or '40d'
        opt['gap'] = sstr(m_opt.get('gap', u'xuống')) or u'xuống'
        opt['neo_mode'] = _norm_neo_mode(m_opt.get('neo_mode', ''))
        opt['step_neo'] = _norm_step_neo(m_opt.get('step_neo', ''))
        opt['std'] = _norm_std_name(m_opt.get('std', ''), u'TCVN 5574:2018')
        opt['concrete'] = _norm_concrete_grade(m_opt.get('concrete', ''), 'B25')
        opt['steel'] = _norm_steel_grade(m_opt.get('steel', ''), 'CB400-V')
        if 'straight' in m_opt:
            opt['straight'] = max(0.0, num(m_opt.get('straight', 0.0), 0.0))
        if 'thr' in m_opt:
            opt['thr'] = max(0.0, num(m_opt.get('thr', 100.0), 100.0))
        if 'slope' in m_opt:
            opt['slope'] = max(1.0, num(m_opt.get('slope', 6.0), 6.0))
        if 'pitch' in m_opt:
            opt['pitch'] = max(15.0, num(m_opt.get('pitch', 25.0), 25.0))
        if 'near' in m_opt:
            opt['near'] = max(0.0, num(m_opt.get('near', 800.0), 800.0))
        if 'tc_hook' in m_opt:
            opt['tc_hook'] = 1.0 if num(m_opt.get('tc_hook', 1.0), 1.0) > 0 else 0.0
        sups = [{
            'w': num(s.get('w', 220.0), 220.0),
            'kind': sstr(s.get('k', 'C')) or 'C',
            'grid': sstr(s.get('g', '')),
            'off': num(s.get('o', 0.0), 0.0),
            'role': sstr(s.get('r', '')),
        } for s in (meta.get('sups') or [])]
        spans = [{
            'clear': max(200.0, num(sp.get('c', 3000.0), 3000.0)),
            'b': max(80.0, num(sp.get('b', 200.0), 200.0)),
            'h': max(80.0, num(sp.get('h', 400.0), 400.0)),
            'top': num(sp.get('t', 0.0), 0.0),
            'hs': max(0.0, num(sp.get('sl', 120.0), 120.0)),
            'slabL': max(0.0, num(sp.get('sl', 120.0), 120.0)),
            'slabL_top': num(sp.get('slt', sp.get('t', 0.0)), 0.0),
            'slabR': max(0.0, num(sp.get('sr', 120.0), 120.0)),
            'slabR_top': num(sp.get('srt', sp.get('t', 0.0)), 0.0),
            'stir': sstr(sp.get('st', '6-100/200')) or '6-100/200',
            'planted': [],
        } for sp in (meta.get('spans') or [])]
        grps = []
        for g_arr in (meta.get('grps') or []):
            if len(g_arr) < 11:
                continue
            grps.append({
                'pos': norm_pos(g_arr[0]),
                'layer': max(1, int(round(num(g_arr[1], 1)))),
                'n': max(1, int(round(num(g_arr[2], 2)))),
                'd': max(6, int(round(num(g_arr[3], 18)))),
                'a': max(0, int(round(num(g_arr[4], 0)))),
                'lk': norm_end(g_arr[5]),
                'lv': sstr(g_arr[6]),
                'b': max(0, int(round(num(g_arr[7], len(spans))))),
                'rk': norm_end(g_arr[8]),
                'rv': sstr(g_arr[9]),
                'cross': norm_cross(g_arr[10]),
                'note': sstr(g_arr[11]) if len(g_arr) > 11 else '',
            })

        # Merge live CAD edits (DAM_SUA / DAM_THEP / DAM_DAI / DAM_TEN) onto reconstructed groups
        cx = 0.0
        sx0_t, fl_t, fr_t = [], [], []
        for si, sp in enumerate(spans):
            sx0_t.append(cx)
            cx += sups[si]['w']
            fl_t.append(cx)
            cx += sp['clear']
            fr_t.append(cx)
        sx0_t.append(cx)
        if len(sups) > len(spans):
            cx += sups[len(spans)]['w']
        lay_t = {'n': len(spans), 'sx0': sx0_t, 'fl': fl_t, 'fr': fr_t, 'L': cx, 'maxtop': max([sp['top'] for sp in spans] or [0.0])}

        sh_to_grp = {}
        sh_i = 1
        for gi, g in enumerate(grps):
            polys = build_group_polylines(g, spans, sups, lay_t, opt, grps)
            for _p in polys:
                sh_to_grp[str(sh_i)] = gi
                sh_i += 1

        for bar_ov in (data.get('bars') or []):
            sh_k = sstr(bar_ov.get('sh', ''))
            if sh_k in sh_to_grp:
                gi = sh_to_grp[sh_k]
                grps[gi]['n'] = max(1, int(round(num(bar_ov.get('sl', grps[gi]['n']), grps[gi]['n']))))
                grps[gi]['d'] = max(6, int(round(num(bar_ov.get('dk', grps[gi]['d']), grps[gi]['d']))))

        stirs_ov = data.get('stirs') or []
        if stirs_ov:
            sd_ov = max(6, int(round(num(stirs_ov[0].get('dk', 8), 8))))
            a_vals = sorted(set(max(50, int(round(num(st.get('a', 100), 100)))) for st in stirs_ov if num(st.get('a', 0)) > 0))
            if a_vals:
                a_goi = a_vals[0]
                a_nhip = a_vals[-1]
                new_stir = '%d-%d/%d' % (sd_ov, a_goi, a_nhip)
                for sp in spans:
                    sp['stir'] = new_stir

        return {
            'bname': bname or 'D1',
            'sl': skc,
            'mode': 'MC_ONLY' if sstr(meta.get('m', 'FULL')).upper() == 'MC_ONLY' else 'FULL',
            'mat': 'B25',
            'level_z': 0.0,
            'opt': opt,
            'sups': sups,
            'spans': spans,
            'grps': grps,
            'from_cad': True,
        }

    # Fallback when scanning an older BeamCAD drawing without BeamCAD_META XDATA
    dims = sorted([round(float(v), 1) for v in (data.get('dims') or []) if num(v) >= 80.0])
    clear_est = max([v for v in dims if v >= 1200.0] or [3600.0])
    sup_cand = [v for v in dims if 180.0 <= v <= 650.0]
    w_est = sup_cand[0] if sup_cand else 220.0
    b_est = sup_cand[0] if sup_cand else 200.0
    h_est = max([v for v in dims if 300.0 <= v <= 1200.0] or [400.0])
    stirs_ov = data.get('stirs') or []
    stir_est = '%d-%d/%d' % (
        int(round(num(stirs_ov[0].get('dk', 6), 6))),
        min([int(round(num(x.get('a', 100), 100))) for x in stirs_ov] or [100]),
        max([int(round(num(x.get('a', 200), 200))) for x in stirs_ov] or [200]),
    ) if stirs_ov else '6-100/200'
    grps = []
    seen_sh = set()
    for idx_b, bar_ov in enumerate(data.get('bars') or []):
        sh_b = sstr(bar_ov.get('sh', str(idx_b + 1)))
        if sh_b in seen_sh:
            continue
        seen_sh.add(sh_b)
        pos_guess = u'Trên' if len(grps) % 2 == 0 else u'Dưới'
        grps.append({
            'pos': pos_guess, 'layer': 1,
            'n': max(1, int(round(num(bar_ov.get('sl', 2), 2)))),
            'd': max(6, int(round(num(bar_ov.get('dk', 18), 18)))),
            'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống',
            'b': 1, 'rk': u'Gập vào cột', 'rv': u'xuống',
            'cross': u'Tự động', 'note': u'Quét CAD (SH %s)' % sh_b,
        })
    if not grps:
        grps = [
            {'pos': u'Trên', 'layer': 1, 'n': 2, 'd': 18, 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': 1, 'rk': u'Gập vào cột', 'rv': u'xuống', 'cross': u'Tự động', 'note': ''},
            {'pos': u'Dưới', 'layer': 1, 'n': 2, 'd': 18, 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': 1, 'rk': u'Gập vào cột', 'rv': u'xuống', 'cross': u'Tự động', 'note': ''},
        ]
    return {
        'bname': bname or 'CAD_D1',
        'sl': skc,
        'mode': 'FULL',
        'mat': 'B25',
        'level_z': 0.0,
        'opt': opt,
        'sups': [
            {'w': w_est, 'kind': 'C', 'grid': '1', 'off': 0.0, 'role': ''},
            {'w': w_est, 'kind': 'C', 'grid': '2', 'off': 0.0, 'role': ''},
        ],
        'spans': [{
            'clear': clear_est, 'b': b_est, 'h': h_est, 'top': 0.0,
            'hs': 120.0, 'slabL': 120.0, 'slabL_top': 0.0, 'slabR': 120.0, 'slabR_top': 0.0,
            'stir': stir_est, 'planted': [],
        }],
        'grps': grps,
        'from_cad': True,
    }


def _xml_esc(val):
    s = sstr(val)
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


def _col_letter(idx):
    out = ''
    n = idx + 1
    while n > 0:
        n, rem = divmod(n - 1, 26)
        out = chr(65 + rem) + out
    return out


def write_simple_xlsx(xlsx_path, sheets_ordered):
    ct_parts = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
        '<Default Extension="xml" ContentType="application/xml"/>',
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
    ]
    wb_sheets = []
    wb_rels = []
    for i, (sh_name, _) in enumerate(sheets_ordered, 1):
        ct_parts.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % i)
        wb_sheets.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (_xml_esc(sh_name), i, i))
        wb_rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i, i))
    ct_parts.append('</Types>')

    root_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    wb_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + ''.join(wb_sheets) + '</sheets></workbook>'
    wb_rels_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + ''.join(wb_rels) + '</Relationships>'

    with zipfile.ZipFile(xlsx_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('[Content_Types].xml', ''.join(ct_parts).encode('utf-8'))
        zf.writestr('_rels/.rels', root_rels.encode('utf-8'))
        zf.writestr('xl/workbook.xml', wb_xml.encode('utf-8'))
        zf.writestr('xl/_rels/workbook.xml.rels', wb_rels_xml.encode('utf-8'))
        for i, (_, rows) in enumerate(sheets_ordered, 1):
            rxml = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
            for r_idx, row in enumerate(rows, 1):
                cells = []
                for c_idx, val in enumerate(row):
                    if val is None or val == '':
                        continue
                    ref = '%s%d' % (_col_letter(c_idx), r_idx)
                    if isinstance(val, (int, float)) and not isinstance(val, bool):
                        cells.append('<c r="%s"><v>%s</v></c>' % (ref, str(val)))
                    else:
                        cells.append('<c r="%s" t="inlineStr"><is><t>%s</t></is></c>' % (ref, _xml_esc(val)))
                rxml.append('<row r="%d">%s</row>' % (r_idx, ''.join(cells)))
            rxml.append('</sheetData></worksheet>')
            zf.writestr('xl/worksheets/sheet%d.xml' % i, ''.join(rxml).encode('utf-8'))


def _get_revit_param_mm(el, names, default_mm=0.0):
    if DB is None or el is None:
        return default_mm
    for nm in names:
        try:
            p = el.LookupParameter(nm)
            if p and p.HasValue and p.StorageType == DB.StorageType.Double:
                return round(p.AsDouble() * 304.8, 1)
        except Exception:
            pass
    norm_targets = set(_norm_hdr(nm).lower() for nm in names)
    try:
        for p in el.Parameters:
            try:
                if p and p.HasValue and p.StorageType == DB.StorageType.Double:
                    pn = _norm_hdr(getattr(p.Definition, 'Name', '')).lower()
                    if pn in norm_targets:
                        return round(p.AsDouble() * 304.8, 1)
            except Exception:
                pass
    except Exception:
        pass
    return default_mm


def _get_revit_bip_mm(el, bip_names, default_mm=0.0):
    if DB is None or el is None:
        return default_mm
    for bnm in bip_names:
        try:
            bip = getattr(DB.BuiltInParameter, bnm, None)
            if bip is None:
                continue
            p = el.get_Parameter(bip)
            if p and p.HasValue and p.StorageType == DB.StorageType.Double:
                v = round(p.AsDouble() * 304.8, 1)
                if v > 1.0:
                    return v
        except Exception:
            pass
    return default_mm


def _parse_nxm_from_name(name_str):
    s = sstr(name_str)
    if not s:
        return 0.0, 0.0
    m = re.search(r'(\d{2,4})\s*[xX\*×]\s*(\d{2,4})', s)
    if m:
        bv, hv = float(m.group(1)), float(m.group(2))
        if 80.0 <= bv <= 3000.0 and 80.0 <= hv <= 5000.0:
            return bv, hv
    return 0.0, 0.0


def _get_revit_solid_vh_mm(el, geom_opt, vx, vy):
    if DB is None or el is None or geom_opt is None:
        return 0.0, 0.0
    vs, zs = [], []
    try:
        ge = el.get_Geometry(geom_opt)
        if ge is not None:
            stacks = [ge]
            while stacks:
                cur = stacks.pop()
                for gobj in cur:
                    if isinstance(gobj, DB.Solid) and getattr(gobj, 'Volume', 0.0) > 1e-6:
                        for edge in gobj.Edges:
                            for pt in edge.Tessellate():
                                vs.append(pt.X * vx + pt.Y * vy)
                                zs.append(pt.Z)
                    elif isinstance(gobj, DB.GeometryInstance):
                        try:
                            stacks.append(gobj.GetInstanceGeometry())
                        except Exception:
                            pass
    except Exception:
        pass
    if vs and zs:
        return round((max(vs) - min(vs)) * 304.8, 1), round((max(zs) - min(zs)) * 304.8, 1)
    return 0.0, 0.0


def _get_revit_beam_dims(el, sym, doc, geom_opt, vx, vy, bb_el):
    w_aliases = ['b', 'bw', 'Width', 'Beam Width', 'Rong', u'Rộng', u'Bề rộng', u'Bề rộng dầm', 'b dam', 'b_dam', u'Chiều rộng']
    h_aliases = ['h', 'bh', 'Height', 'Depth', 'Beam Depth', 'Beam Height', 'Cao', u'Chiều cao', u'Chiều cao dầm', 'h dam', 'h_dam']
    bw = (
        _get_revit_bip_mm(sym, ['STRUCTURAL_SECTION_COMMON_WIDTH', 'FAMILY_WIDTH_PARAM', 'CASEWORK_WIDTH', 'GENERIC_WIDTH'], 0.0)
        or _get_revit_param_mm(sym, w_aliases, 0.0)
        or _get_revit_bip_mm(el, ['STRUCTURAL_SECTION_COMMON_WIDTH', 'FAMILY_WIDTH_PARAM'], 0.0)
        or _get_revit_param_mm(el, w_aliases, 0.0)
    )
    bh = (
        _get_revit_bip_mm(sym, ['STRUCTURAL_SECTION_COMMON_HEIGHT', 'FAMILY_HEIGHT_PARAM', 'GENERIC_DEPTH'], 0.0)
        or _get_revit_param_mm(sym, h_aliases, 0.0)
        or _get_revit_bip_mm(el, ['STRUCTURAL_SECTION_COMMON_HEIGHT', 'FAMILY_HEIGHT_PARAM'], 0.0)
        or _get_revit_param_mm(el, h_aliases, 0.0)
    )
    if bw <= 10.0 or bh <= 10.0:
        nb, nh = _parse_nxm_from_name(getattr(sym, 'Name', '') if sym is not None else '')
        if nb <= 10.0 or nh <= 10.0:
            nb2, nh2 = _parse_nxm_from_name(getattr(el, 'Name', ''))
            nb = nb or nb2
            nh = nh or nh2
        if bw <= 10.0 and nb > 10.0:
            bw = nb
        if bh <= 10.0 and nh > 10.0:
            bh = nh
    if bw <= 10.0 or bh <= 10.0:
        sv_mm, sz_mm = _get_revit_solid_vh_mm(el, geom_opt, vx, vy)
        if bw <= 10.0 and 60.0 <= sv_mm <= 3000.0:
            bw = sv_mm
        if bh <= 10.0 and 60.0 <= sz_mm <= 5000.0:
            bh = sz_mm
    if bh <= 10.0 and bb_el is not None:
        bh_bb = round((bb_el.Max.Z - bb_el.Min.Z) * 304.8, 1)
        if bh_bb > 10.0:
            bh = bh_bb
    return (bw if bw > 10.0 else 220.0), (bh if bh > 10.0 else 500.0)


def _get_revit_beam_material(el, sym, doc):
    if DB is None or doc is None:
        return ''
    for obj in (el, sym):
        if obj is None:
            continue
        try:
            pm = obj.get_Parameter(DB.BuiltInParameter.STRUCTURAL_MATERIAL_PARAM)
            if pm and pm.HasValue:
                mid = pm.AsElementId()
                if mid and mid != DB.ElementId.InvalidElementId:
                    mat = doc.GetElement(mid)
                    if mat is not None:
                        mnm = sstr(getattr(mat, 'Name', '') or '')
                        if mnm:
                            m_b = re.search(r'\b(B\d{2}|C\d{2}/\d{2}|M\d{3})\b', mnm, re.I)
                            return m_b.group(1).upper() if m_b else mnm[:24]
        except Exception:
            pass
    return ''


def _get_revit_beam_cover_mm(el, doc):
    if DB is None or el is None or doc is None:
        return 0.0
    for bnm in ('CLEAR_COVER_TOP', 'CLEAR_COVER_BOTTOM', 'CLEAR_COVER_OTHER'):
        try:
            bip = getattr(DB.BuiltInParameter, bnm, None)
            if bip is None:
                continue
            p = el.get_Parameter(bip)
            if p and p.HasValue:
                cid = p.AsElementId()
                if cid and cid != DB.ElementId.InvalidElementId:
                    ct = doc.GetElement(cid)
                    if ct is not None and hasattr(ct, 'CoverDistance'):
                        cov = round(float(ct.CoverDistance) * 304.8, 1)
                        if 10.0 <= cov <= 100.0:
                            return cov
        except Exception:
            pass
    return 0.0


def _get_revit_beam_top_z_mm(el, ep, bb_el, sp_lvl_ft, bh_mm):
    curve_top_mm = None
    if ep is not None and DB is not None:
        try:
            p0_z, p1_z = ep[0][2], ep[1][2]
            if abs(p0_z - p1_z) <= 0.025:
                cz_ft = 0.5 * (p0_z + p1_z)
                z_off_ft = 0.0
                try:
                    p_zo = el.get_Parameter(DB.BuiltInParameter.Z_OFFSET_VALUE)
                    if p_zo and p_zo.HasValue:
                        z_off_ft = float(p_zo.AsDouble())
                except Exception:
                    pass
                z_just = 0
                try:
                    p_zj = el.get_Parameter(DB.BuiltInParameter.Z_JUSTIFICATION)
                    if p_zj and p_zj.HasValue:
                        z_just = int(p_zj.AsInteger())
                except Exception:
                    pass
                bh_ft = bh_mm / 304.8
                if z_just == 0:  # Top
                    top_ft = cz_ft + z_off_ft
                elif z_just == 1:  # Center
                    top_ft = cz_ft + z_off_ft + 0.5 * bh_ft
                elif z_just == 2:  # Bottom
                    top_ft = cz_ft + z_off_ft + bh_ft
                else:  # Origin (usually Top in Vietnamese framing families)
                    top_ft = cz_ft + z_off_ft
                curve_top_mm = round((top_ft - sp_lvl_ft) * 304.8, 1)
        except Exception:
            curve_top_mm = None

    if bb_el is not None:
        bb_top_mm = round((bb_el.Max.Z - sp_lvl_ft) * 304.8, 1)
        if curve_top_mm is None:
            return bb_top_mm
        if z_just == 3 and abs(bb_top_mm - (curve_top_mm + 0.5 * bh_mm)) <= 15.0:
            return bb_top_mm
        # Prefer curve+zOffset if bounding box matches closely OR looks inflated by an attached element above
        if abs(bb_top_mm - curve_top_mm) <= 15.0 or (bb_top_mm - curve_top_mm) > 25.0:
            return curve_top_mm
        return bb_top_mm
    return curve_top_mm if curve_top_mm is not None else 0.0


def _pt_in_loops_2d(px, py, loops):
    inside = False
    for ring in loops:
        n_r = len(ring)
        if n_r < 3:
            continue
        j = n_r - 1
        for i in range(n_r):
            xi, yi = ring[i]
            xj, yj = ring[j]
            if (yi > py) != (yj > py):
                x_int = (xj - xi) * (py - yi) / ((yj - yi) or 1e-12) + xi
                if px < x_int:
                    inside = not inside
            j = i
    return inside


def _revit_extract_floor_polys(fl_el, geom_opt):
    """Return list of (loops_2d, z_top_ft) from floor's top PlanarFaces for exact void/cutout detection."""
    out_faces = []
    if DB is None or fl_el is None or geom_opt is None:
        return out_faces
    try:
        ge = fl_el.get_Geometry(geom_opt)
        if ge is None:
            return out_faces
        stacks = [ge]
        while stacks:
            cur = stacks.pop()
            for gobj in cur:
                if isinstance(gobj, DB.Solid) and getattr(gobj, 'Volume', 0.0) > 1e-6:
                    for face in gobj.Faces:
                        if isinstance(face, DB.PlanarFace) and face.FaceNormal.Z > 0.5:
                            loops_2d = []
                            try:
                                for cloop in face.GetEdgesAsCurveLoops():
                                    ring = []
                                    for c_ed in cloop:
                                        tpts = list(c_ed.Tessellate())
                                        for pt in tpts[:-1]:
                                            ring.append((pt.X, pt.Y))
                                    if len(ring) >= 3:
                                        loops_2d.append(ring)
                            except Exception:
                                loops_2d = []
                            if loops_2d:
                                out_faces.append((loops_2d, float(face.Origin.Z)))
                elif isinstance(gobj, DB.GeometryInstance):
                    try:
                        stacks.append(gobj.GetInstanceGeometry())
                    except Exception:
                        pass
    except Exception:
        pass
    return out_faces


def _revit_col_footprint_pts_2d(e_s, doc, geom_opt, bb=None, allow_solid=True):
    """Exact XY footprint points for rotated/eccentric/circular structural columns (with lazy solid mode)."""
    if DB is None or e_s is None:
        return None
    if allow_solid and geom_opt is not None:
        try:
            ge = e_s.get_Geometry(geom_opt)
            if ge is not None:
                pts = []
                stacks = [ge]
                while stacks:
                    cur = stacks.pop()
                    for gobj in cur:
                        if isinstance(gobj, DB.Solid) and getattr(gobj, 'Volume', 0.0) > 1e-6:
                            for edge in gobj.Edges:
                                for pt in edge.Tessellate():
                                    pts.append((pt.X, pt.Y))
                        elif isinstance(gobj, DB.GeometryInstance):
                            try:
                                stacks.append(gobj.GetInstanceGeometry())
                            except Exception:
                                pass
                if len(pts) >= 3:
                    return pts
        except Exception:
            pass
    try:
        tr = e_s.GetTransform() if hasattr(e_s, 'GetTransform') else None
        if tr is not None:
            sym = doc.GetElement(e_s.GetTypeId()) if doc is not None else None
            w_aliases = ['b', 'b1', 'cx', 'dx', 'Width', 'Column Width', 'Diameter', 'D', u'Bề rộng', u'Rộng', u'Chiều rộng']
            d_aliases = ['h', 'b2', 'cy', 'dy', 'Depth', 'Length', 'Column Depth', 'Diameter', 'D', u'Chiều cao', u'Dài', u'Chiều dài']
            cw_ft = (
                _get_revit_bip_mm(sym, ['STRUCTURAL_SECTION_COMMON_WIDTH', 'FAMILY_WIDTH_PARAM', 'STRUCTURAL_SECTION_COMMON_DIAMETER'], 0.0)
                or _get_revit_param_mm(sym, w_aliases, 0.0)
                or _get_revit_param_mm(e_s, w_aliases, 0.0)
            ) / 304.8
            cd_ft = (
                _get_revit_bip_mm(sym, ['STRUCTURAL_SECTION_COMMON_HEIGHT', 'FAMILY_HEIGHT_PARAM', 'STRUCTURAL_SECTION_COMMON_DIAMETER'], 0.0)
                or _get_revit_param_mm(sym, d_aliases, 0.0)
                or _get_revit_param_mm(e_s, d_aliases, 0.0)
            ) / 304.8
            if cw_ft <= 0.1 or cd_ft <= 0.1:
                nb, nh = _parse_nxm_from_name(getattr(sym, 'Name', '') if sym is not None else '')
                if nb > 10.0 and nh > 10.0:
                    cw_ft, cd_ft = nb / 304.8, nh / 304.8
            if cw_ft > 0.1 and cd_ft > 0.1:
                ox, oy = tr.Origin.X, tr.Origin.Y
                # Verify origin is actually centered on bb (eccentric families use corner origin)
                origin_ok = True
                if bb is not None:
                    cx_bb = 0.5 * (bb.Min.X + bb.Max.X)
                    cy_bb = 0.5 * (bb.Min.Y + bb.Max.Y)
                    if abs(ox - cx_bb) > 0.15 or abs(oy - cy_bb) > 0.15:
                        origin_ok = False
                if origin_ok:
                    hx_x, hx_y = tr.BasisX.X * cw_ft * 0.5, tr.BasisX.Y * cw_ft * 0.5
                    hy_x, hy_y = tr.BasisY.X * cd_ft * 0.5, tr.BasisY.Y * cd_ft * 0.5
                    return [
                        (ox - hx_x - hy_x, oy - hx_y - hy_y),
                        (ox + hx_x - hy_x, oy + hx_y - hy_y),
                        (ox + hx_x + hy_x, oy + hx_y + hy_y),
                        (ox - hx_x + hy_x, oy - hx_y + hy_y),
                    ]
    except Exception:
        pass
    return None


def _revit_wall_info(e_w):
    """Extract centerline endpoints + thickness (ft) for OST_Walls."""
    if DB is None or e_w is None:
        return None
    try:
        loc = getattr(e_w, 'Location', None)
        if loc is not None and hasattr(loc, 'Curve') and loc.Curve is not None:
            c = loc.Curve
            p0, p1 = c.GetEndPoint(0), c.GetEndPoint(1)
            w_ft = float(getattr(e_w, 'Width', 0.0) or 0.0)
            if w_ft <= 0.05:
                wt = getattr(e_w, 'WallType', None)
                w_ft = float(getattr(wt, 'Width', 0.0) or 0.0) if wt is not None else 0.0
            if w_ft > 0.05:
                return ((p0.X, p0.Y), (p1.X, p1.Y), w_ft)
    except Exception:
        pass
    return None


def _rv_curve_endpoints_2d(el):
    loc = getattr(el, 'Location', None)
    if loc is not None and hasattr(loc, 'Curve') and loc.Curve is not None:
        c = loc.Curve
        p0 = c.GetEndPoint(0)
        p1 = c.GetEndPoint(1)
        return (p0.X, p0.Y, p0.Z), (p1.X, p1.Y, p1.Z), c.Length
    return None


def _read_revit_view_scales(doc=None, uidoc=None):
    res = {
        'elev_scale': 50,
        'sec_scale': 25,
        'active_view_name': '',
        'active_view_scale': 0,
        'view_scale_src': u'Mặc định (1/50 · 1/25)',
    }
    if DB is None:
        return res
    try:
        if uidoc is None and '__revit__' in globals():
            uidoc = __revit__.ActiveUIDocument
        if doc is None and uidoc is not None:
            doc = uidoc.Document
    except Exception:
        doc = None
    if doc is None:
        return res

    elev_sc = None
    sec_sc = None
    src_notes = []
    try:
        av = getattr(uidoc, 'ActiveView', None) if uidoc is not None else None
        if av is None:
            av = getattr(doc, 'ActiveView', None)
        if av is not None:
            av_nm = sstr(getattr(av, 'Name', ''))
            av_vt = sstr(getattr(av, 'ViewType', ''))
            av_sc = int(getattr(av, 'Scale', 0) or 0)
            res['active_view_name'] = av_nm
            res['active_view_scale'] = av_sc
            if av_vt == 'DrawingSheet' and hasattr(av, 'GetAllViewports'):
                try:
                    for vp_id in av.GetAllViewports():
                        vp = doc.GetElement(vp_id)
                        v_el = doc.GetElement(vp.ViewId) if vp is not None else None
                        if v_el is None:
                            continue
                        vsc = int(getattr(v_el, 'Scale', 0) or 0)
                        vvt = sstr(getattr(v_el, 'ViewType', ''))
                        if 5 <= vsc <= 250:
                            if vvt in ('Section', 'Detail', 'Elevation') and vsc <= 35 and sec_sc is None:
                                sec_sc = vsc
                            elif elev_sc is None:
                                elev_sc = vsc
                    if elev_sc or sec_sc:
                        src_notes.append(u'Sheet "%s"' % av_nm)
                except Exception:
                    pass
            elif 5 <= av_sc <= 250:
                norm_av = _norm_hdr(av_nm)
                if av_vt in ('Section', 'Detail', 'Elevation') and (av_sc <= 35 or 'mat cat' in norm_av or 'mc' in norm_av):
                    sec_sc = av_sc
                else:
                    elev_sc = av_sc
                src_notes.append(u'View "%s" (1/%d)' % (av_nm, av_sc))
    except Exception:
        pass

    # Scan project views for missing scale counterpart (plan/elevation vs detail section)
    try:
        for vw in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Views).WhereElementIsNotElementType():
            try:
                if getattr(vw, 'IsTemplate', False):
                    continue
                vsc = int(getattr(vw, 'Scale', 0) or 0)
                if not (5 <= vsc <= 250):
                    continue
                vvt = sstr(getattr(vw, 'ViewType', ''))
                vnm_norm = _norm_hdr(getattr(vw, 'Name', ''))
                is_beam_kw = any(k in vnm_norm for k in ('dam', 'beam', 'ket cau', 'san', 'mc'))
                if elev_sc is None and vvt in ('EngineeringPlan', 'StructuralPlan', 'FloorPlan', 'Elevation', 'Section') and vsc >= 40:
                    if is_beam_kw or elev_sc is None:
                        elev_sc = vsc
                if sec_sc is None and vvt in ('Detail', 'Section', 'DraftingView') and 5 <= vsc <= 35:
                    if is_beam_kw or sec_sc is None:
                        sec_sc = vsc
            except Exception:
                pass
    except Exception:
        pass

    if elev_sc is not None:
        res['elev_scale'] = int(elev_sc)
    if sec_sc is not None:
        res['sec_scale'] = int(sec_sc)
    if src_notes:
        res['view_scale_src'] = u'Revit: ' + u', '.join(src_notes)
    elif elev_sc is not None or sec_sc is not None:
        res['view_scale_src'] = u'Revit Views (1/%d · 1/%d)' % (res['elev_scale'], res['sec_scale'])
    return res


def _pick_revit_beams_interactive(uidoc, form=None):
    if DB is None or uidoc is None:
        return None
    try:
        import Autodesk.Revit.UI as RevitUI
    except Exception:
        return None
    doc = uidoc.Document
    if doc is None:
        return None

    sel_filter = None
    try:
        class _BeamSelFilter(RevitUI.Selection.ISelectionFilter):
            def AllowElement(self, elem):
                try:
                    cat = getattr(elem, 'Category', None)
                    if cat is not None and _eid_int(cat.Id) == int(DB.BuiltInCategory.OST_StructuralFraming):
                        return True
                except Exception:
                    pass
                return False

            def AllowReference(self, reference, position):
                return False
        sel_filter = _BeamSelFilter()
    except Exception:
        sel_filter = None

    old_ws = None
    if form is not None and not form.IsDisposed:
        try:
            old_ws = form.WindowState
            form.WindowState = WinForms.FormWindowState.Minimized
            WinForms.Application.DoEvents()
        except Exception:
            old_ws = None
    try:
        if '__revit__' in globals():
            try:
                import ctypes
                ctypes.windll.user32.SetForegroundWindow(__revit__.MainWindowHandle.ToInt64())
            except Exception:
                pass
        prompt = u'Chọn các dầm trên Revit rồi bấm Finish (hoặc ESC để hủy)'
        if sel_filter is not None:
            refs = uidoc.Selection.PickObjects(RevitUI.Selection.ObjectType.Element, sel_filter, prompt)
        else:
            refs = uidoc.Selection.PickObjects(RevitUI.Selection.ObjectType.Element, prompt)
        picked_ids = []
        seen_p = set()
        for rf in (refs or []):
            eid = rf.ElementId
            ei = _eid_int(eid)
            if ei > 0 and ei not in seen_p:
                el = doc.GetElement(eid)
                cat = getattr(el, 'Category', None) if el is not None else None
                if cat is not None and _eid_int(cat.Id) == int(DB.BuiltInCategory.OST_StructuralFraming):
                    seen_p.add(ei)
                    picked_ids.append(eid)
        try:
            if picked_ids:
                from System.Collections.Generic import List
                uidoc.Selection.SetElementIds(List[DB.ElementId](picked_ids))
        except Exception:
            pass
        return picked_ids
    except Exception:
        return None
    finally:
        if form is not None and not form.IsDisposed:
            try:
                form.WindowState = old_ws if old_ws is not None else WinForms.FormWindowState.Normal
                form.Activate()
                WinForms.Application.DoEvents()
            except Exception:
                pass


def _collect_revit_model_data(scan_scope='view', pick_eids=None):
    _collect_revit_model_data._last_view_cfg = _read_revit_view_scales()
    _collect_revit_model_data._last_scope_note = ''
    if DB is None:
        return [], {}, [], 0.0, 'Dam_Revit', os.path.expanduser('~\\Desktop')
    try:
        uidoc = __revit__.ActiveUIDocument
        doc = uidoc.Document
    except Exception:
        uidoc = None
        doc = None
    if doc is None:
        return [], {}, [], 0.0, 'Dam_Revit', os.path.expanduser('~\\Desktop')
    _collect_revit_model_data._last_view_cfg = _read_revit_view_scales(doc=doc, uidoc=uidoc)

    doc_title = re.sub(r'[\\/:*?"<>|]+', '_', sstr(doc.Title) or 'Dam_Revit')
    doc_dir = os.path.dirname(doc.PathName) if doc.PathName else os.path.expanduser('~\\Desktop')

    av = None
    try:
        av = getattr(uidoc, 'ActiveView', None) if uidoc is not None else getattr(doc, 'ActiveView', None)
    except Exception:
        av = None
    av_vt = sstr(getattr(av, 'ViewType', '')) if av is not None else ''
    av_nm = sstr(getattr(av, 'Name', '')) if av is not None else ''

    geom_opt = DB.Options()
    geom_opt.ComputeReferences = False
    geom_opt.IncludeNonVisibleObjects = False
    try:
        geom_opt.DetailLevel = DB.ViewDetailLevel.Medium
    except Exception:
        pass

    def _safe_bbox(el_x):
        if el_x is None:
            return None
        try:
            bb_x = el_x.get_BoundingBox(None)
            if bb_x is not None:
                return bb_x
        except Exception:
            pass
        if av is not None:
            try:
                return el_x.get_BoundingBox(av)
            except Exception:
                pass
        return None

    def _is_vertical_framing(ep_x, bb_x):
        if ep_x is not None:
            dx_v = ep_x[1][0] - ep_x[0][0]
            dy_v = ep_x[1][1] - ep_x[0][1]
            dz_v = abs(ep_x[1][2] - ep_x[0][2])
            dxy_v = math.hypot(dx_v, dy_v)
            if dz_v >= 0.8 and dz_v > 2.0 * dxy_v:
                return True
        elif bb_x is not None:
            dxy_b = math.hypot(bb_x.Max.X - bb_x.Min.X, bb_x.Max.Y - bb_x.Min.Y)
            dz_b = bb_x.Max.Z - bb_x.Min.Z
            if dz_b >= 1.5 and dz_b > 2.2 * dxy_b and dxy_b < 2.5:
                return True
        return False

    scope_norm = scan_scope if scan_scope in ('view', 'pick', 'project') else 'view'
    frames = []
    all_doc_frames = None
    scope_note = ''

    if scope_norm == 'pick':
        raw_eids = list(pick_eids) if pick_eids is not None else []
        if not raw_eids and uidoc is not None:
            try:
                raw_eids = list(uidoc.Selection.GetElementIds())
            except Exception:
                raw_eids = []
        seen_pk = set()
        for eid in raw_eids:
            try:
                el_pk = eid if hasattr(eid, 'Category') else doc.GetElement(eid)
                if el_pk is None:
                    continue
                cat_pk = getattr(el_pk, 'Category', None)
                if cat_pk is None or _eid_int(cat_pk.Id) != int(DB.BuiltInCategory.OST_StructuralFraming):
                    continue
                ei_pk = _eid_int(el_pk.Id)
                if ei_pk in seen_pk:
                    continue
                seen_pk.add(ei_pk)
                frames.append(el_pk)
            except Exception:
                pass
        scope_note = u'Chọn dầm (%d cấu kiện)' % len(frames)
    elif scope_norm == 'view' and av is not None and av_vt != 'DrawingSheet':
        try:
            frames = list(
                DB.FilteredElementCollector(doc, av.Id)
                .OfCategory(DB.BuiltInCategory.OST_StructuralFraming)
                .WhereElementIsNotElementType()
            )
            scope_note = u'View "%s"' % (av_nm or u'Đang mở')
        except Exception:
            frames = []
        if not frames:
            glvl_av = getattr(av, 'GenLevel', None)
            if glvl_av is not None:
                glvl_id = _eid_int(glvl_av.Id)
                all_doc_frames = list(
                    DB.FilteredElementCollector(doc)
                    .OfCategory(DB.BuiltInCategory.OST_StructuralFraming)
                    .WhereElementIsNotElementType()
                )
                for ef_l in all_doc_frames:
                    try:
                        p_l = ef_l.get_Parameter(DB.BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM)
                        if p_l and p_l.HasValue and _eid_int(p_l.AsElementId()) == glvl_id:
                            frames.append(ef_l)
                    except Exception:
                        pass
                scope_note = u'Tầng "%s"' % sstr(getattr(glvl_av, 'Name', av_nm or ''))
    if not frames and scope_norm != 'pick':
        if all_doc_frames is None:
            all_doc_frames = list(
                DB.FilteredElementCollector(doc)
                .OfCategory(DB.BuiltInCategory.OST_StructuralFraming)
                .WhereElementIsNotElementType()
            )
        frames = list(all_doc_frames)
        scope_note = u'Cả công trình'

    # Keep only horizontal/beam Structural Framing in target beams; compute fast XY/Z envelope
    horiz_frames = []
    env_xs, env_ys, env_zs = [], [], []
    beam_pre = {}  # eid -> (ep, bb)
    for ef_t in frames:
        try:
            ep_t = _rv_curve_endpoints_2d(ef_t)
            bb_t = _safe_bbox(ef_t)
            if _is_vertical_framing(ep_t, bb_t):
                continue
            eid_t = _eid_int(ef_t.Id)
            beam_pre[eid_t] = (ep_t, bb_t)
            horiz_frames.append(ef_t)
            if bb_t is not None:
                env_xs.extend((bb_t.Min.X, bb_t.Max.X))
                env_ys.extend((bb_t.Min.Y, bb_t.Max.Y))
                env_zs.extend((bb_t.Min.Z, bb_t.Max.Z))
            elif ep_t is not None:
                env_xs.extend((ep_t[0][0], ep_t[1][0]))
                env_ys.extend((ep_t[0][1], ep_t[1][1]))
                env_zs.extend((ep_t[0][2], ep_t[1][2]))
        except Exception:
            pass
    frames = horiz_frames
    _collect_revit_model_data._last_scope_note = scope_note or (u'Mặt bằng đang mở' if scope_norm == 'view' else u'Cả công trình')

    if not frames:
        _collect_revit_model_data._last_meta = {}
        return [], {}, [], 0.0, doc_title, doc_dir

    env_valid = bool(env_xs and env_ys and env_zs)
    if env_valid:
        env_xmin, env_xmax = min(env_xs) - 8.0, max(env_xs) + 8.0
        env_ymin, env_ymax = min(env_ys) - 8.0, max(env_ys) + 8.0
        env_zmin, env_zmax = min(env_zs) - 8.0, max(env_zs) + 10.0
    else:
        env_xmin = env_ymin = env_zmin = -1e9
        env_xmax = env_ymax = env_zmax = 1e9

    def _bb_in_env(bb_chk):
        if not env_valid or bb_chk is None:
            return True
        return not (
            bb_chk.Max.X < env_xmin or bb_chk.Min.X > env_xmax
            or bb_chk.Max.Y < env_ymin or bb_chk.Min.Y > env_ymax
            or bb_chk.Max.Z < env_zmin or bb_chk.Min.Z > env_zmax
        )

    def _read_col_name(e_c, is_w_c):
        col_nm = ''
        try:
            pm_c = e_c.get_Parameter(DB.BuiltInParameter.ALL_MODEL_MARK)
            if pm_c and pm_c.HasValue:
                col_nm = sstr(pm_c.AsString())
        except Exception:
            pass
        if not col_nm:
            for pnm_c in (u'Tên cột', 'Ten cot', 'Column Name', 'Ký hiệu', 'Ky hieu', 'Mark'):
                try:
                    p_x = e_c.LookupParameter(pnm_c)
                    if p_x and p_x.HasValue:
                        sv = sstr(p_x.AsString() or p_x.AsValueString())
                        if sv:
                            col_nm = sv
                            break
                except Exception:
                    pass
        if not col_nm:
            try:
                tp_c = doc.GetElement(e_c.GetTypeId())
                if tp_c is not None:
                    col_nm = sstr(getattr(tp_c, 'Name', '') or '')
            except Exception:
                pass
        return col_nm or ('V' if is_w_c else 'CC')

    sup_bbs = []  # [eid_int, kind, bb, col_nm, is_wall, fp_pts_2d, wall_info, elem, solid_tried]
    seen_sup_ids = set()
    for cat, kd, is_w in (
        (DB.BuiltInCategory.OST_StructuralColumns, 'C', False),
        (DB.BuiltInCategory.OST_Columns, 'C', False),
        (DB.BuiltInCategory.OST_Walls, 'C', True),
    ):
        try:
            for e_s in DB.FilteredElementCollector(doc).OfCategory(cat).WhereElementIsNotElementType():
                try:
                    eid_val = _eid_int(e_s.Id)
                    if eid_val in seen_sup_ids:
                        continue
                    bb = _safe_bbox(e_s)
                    if bb is None or not _bb_in_env(bb):
                        continue
                    if is_w and (bb.Max.Z - bb.Min.Z) < 0.5:
                        continue
                    seen_sup_ids.add(eid_val)
                    col_nm = _read_col_name(e_s, is_w)
                    wall_inf = _revit_wall_info(e_s) if is_w else None
                    # Fast parametric footprint first; defer expensive Solid tessellation until needed
                    fp_pts = None if is_w else _revit_col_footprint_pts_2d(e_s, doc, geom_opt, bb=bb, allow_solid=False)
                    sup_bbs.append([eid_val, kd, bb, col_nm, is_w, fp_pts, wall_inf, e_s, False])
                except Exception:
                    pass
        except Exception:
            pass

    frame_bbs = []  # (eid_int, e_f, bb, p0, p1)
    context_frames = all_doc_frames
    if context_frames is None:
        try:
            col_cf = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_StructuralFraming).WhereElementIsNotElementType()
            if env_valid and hasattr(DB, 'BoundingBoxIntersectsFilter') and hasattr(DB, 'Outline'):
                try:
                    out_env = DB.Outline(DB.XYZ(env_xmin, env_ymin, env_zmin), DB.XYZ(env_xmax, env_ymax, env_zmax))
                    col_cf = col_cf.WherePasses(DB.BoundingBoxIntersectsFilter(out_env))
                except Exception:
                    pass
            context_frames = list(col_cf)
        except Exception:
            context_frames = list(frames)

    for e_f in context_frames:
        try:
            bb = _safe_bbox(e_f)
            if bb is None or not _bb_in_env(bb):
                continue
            ep = _rv_curve_endpoints_2d(e_f)
            eid_f = _eid_int(e_f.Id)
            if _is_vertical_framing(ep, bb):
                if eid_f not in seen_sup_ids:
                    seen_sup_ids.add(eid_f)
                    col_nm_f = _read_col_name(e_f, False)
                    fp_pts_f = _revit_col_footprint_pts_2d(e_f, doc, geom_opt, bb=bb, allow_solid=False)
                    sup_bbs.append([eid_f, 'C', bb, col_nm_f, False, fp_pts_f, None, e_f, False])
                continue
            if ep is not None:
                frame_bbs.append((eid_f, e_f, bb, ep[0], ep[1]))
        except Exception:
            pass

    floor_bbs = []  # [fl_el, bb, thick_mm, top_faces_or_None] (lazy face extraction)
    floor_eids = set()
    try:
        for fl_el in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Floors).WhereElementIsNotElementType():
            try:
                eid_fl = _eid_int(fl_el.Id)
                floor_eids.add(eid_fl)
                bb = _safe_bbox(fl_el)
                if bb is None or not _bb_in_env(bb):
                    continue
                th = 0.0
                try:
                    p_th = fl_el.get_Parameter(DB.BuiltInParameter.FLOOR_ATTR_THICKNESS_PARAM)
                    if p_th and p_th.HasValue:
                        th = round(p_th.AsDouble() * 304.8, 1)
                except Exception:
                    pass
                if th <= 1.0:
                    th = round((bb.Max.Z - bb.Min.Z) * 304.8, 1)
                if th > 1.0:
                    floor_bbs.append([fl_el, bb, th, None])
            except Exception:
                pass
    except Exception:
        pass

    grid_items = []  # (name, p0_xy, p1_xy, ux, uy)
    try:
        for gr in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Grids).WhereElementIsNotElementType():
            try:
                c = gr.Curve
                if c is None:
                    continue
                p0, p1 = c.GetEndPoint(0), c.GetEndPoint(1)
                dx, dy = p1.X - p0.X, p1.Y - p0.Y
                ln = math.hypot(dx, dy)
                if ln > 1e-4:
                    grid_items.append((sstr(gr.Name), (p0.X, p0.Y), (p1.X, p1.Y), dx / ln, dy / ln))
            except Exception:
                pass
    except Exception:
        pass

    target_frame_eids = set(_eid_int(f.Id) for f in frames)
    rebar_by_host = {}
    unhosted_rebars = []  # (rid, rb, bb_rb) bounded to scanned beams' XY/Z envelope
    try:
        rb_col = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Rebar).WhereElementIsNotElementType()
        if env_valid and hasattr(DB, 'BoundingBoxIntersectsFilter') and hasattr(DB, 'Outline'):
            try:
                out_rb = DB.Outline(DB.XYZ(env_xmin, env_ymin, env_zmin), DB.XYZ(env_xmax, env_ymax, env_zmax))
                rb_col = rb_col.WherePasses(DB.BoundingBoxIntersectsFilter(out_rb))
            except Exception:
                pass
        for rb in rb_col:
            try:
                rid = _eid_int(rb.Id)
                hid = _eid_int(rb.GetHostId())
            except Exception:
                rid, hid = -1, -1
            if hid in target_frame_eids:
                rebar_by_host.setdefault(hid, []).append(rb)
            elif hid not in floor_eids:
                bb_rb = _safe_bbox(rb)
                if _bb_in_env(bb_rb):
                    unhosted_rebars.append((rid, rb, bb_rb))
    except Exception:
        pass

    # Determine ActiveView base level if on a floor/structural plan
    active_lvl_id = None
    active_lvl_proj_ft = None
    try:
        av = getattr(uidoc, 'ActiveView', None) if uidoc is not None else getattr(doc, 'ActiveView', None)
        glvl = getattr(av, 'GenLevel', None) if av is not None else None
        if glvl is not None:
            active_lvl_id = _eid_int(glvl.Id)
            p_pe = getattr(glvl, 'ProjectElevation', None)
            active_lvl_proj_ft = float(p_pe if p_pe is not None else glvl.Elevation)
    except Exception:
        pass

    lvl_counts = {}
    raw_by_mark = {}
    mark_order = []
    cover_votes = []

    for idx_f, el in enumerate(frames, 1):
        eid_f_cur = _eid_int(el.Id)
        ep, bb_el = beam_pre.get(eid_f_cur, (None, None))
        if ep is None:
            ep = _rv_curve_endpoints_2d(el)
        if bb_el is None:
            bb_el = _safe_bbox(el)
        length_mm = round(ep[2] * 304.8, 0) if ep else 0.0
        if length_mm < 200.0:
            length_mm = _get_revit_param_mm(el, ['Length', 'Cut Length'], 4000.0)
        if length_mm < 200.0:
            length_mm = 4000.0

        sym = doc.GetElement(el.GetTypeId())

        if ep is not None:
            (x0_e, y0_e, _), (x1_e, y1_e, _), _ = ep
            ln_e = math.hypot(x1_e - x0_e, y1_e - y0_e)
            vx_e, vy_e = (-(y1_e - y0_e) / ln_e, (x1_e - x0_e) / ln_e) if ln_e > 1e-4 else (0.0, 1.0)
        else:
            vx_e, vy_e = 0.0, 1.0

        bw, bh = _get_revit_beam_dims(el, sym, doc, geom_opt, vx_e, vy_e, bb_el)
        mat_s = _get_revit_beam_material(el, sym, doc)
        cov_f = _get_revit_beam_cover_mm(el, doc)
        if cov_f > 5.0:
            cover_votes.append(cov_f)

        mark = ''
        try:
            pm = el.get_Parameter(DB.BuiltInParameter.ALL_MODEL_MARK)
            if pm and pm.HasValue:
                mark = sstr(pm.AsString())
        except Exception:
            pass
        if not mark:
            for pnm_b in (u'Tên dầm', 'Ten dam', 'Beam Name', 'Ký hiệu', 'Ky hieu'):
                try:
                    pb_x = el.LookupParameter(pnm_b)
                    if pb_x and pb_x.HasValue:
                        sv_b = sstr(pb_x.AsString() or pb_x.AsValueString())
                        if sv_b:
                            mark = sv_b
                            break
                except Exception:
                    pass
        if not mark:
            mark = sstr(sym.Name if sym else '') or ('DAM-%d' % idx_f)

        sp_lvl_int_ft = 0.0
        sp_lvl_proj_ft = 0.0
        lid_int = -1
        try:
            p_lvl = el.get_Parameter(DB.BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM)
            if p_lvl and p_lvl.HasValue:
                lvl = doc.GetElement(p_lvl.AsElementId())
                if lvl is not None:
                    lid_int = _eid_int(lvl.Id)
                    sp_lvl_int_ft = float(lvl.Elevation)
                    p_pe = getattr(lvl, 'ProjectElevation', None)
                    sp_lvl_proj_ft = float(p_pe if p_pe is not None else sp_lvl_int_ft)
                    lvl_counts[sp_lvl_proj_ft] = lvl_counts.get(sp_lvl_proj_ft, 0) + 1
        except Exception:
            pass
        if lid_int < 0 and bb_el is not None:
            sp_lvl_int_ft = bb_el.Max.Z
            sp_lvl_proj_ft = bb_el.Max.Z

        top_z = _get_revit_beam_top_z_mm(el, ep, bb_el, sp_lvl_int_ft, bh)
        beam_lvl_mm = round(sp_lvl_proj_ft * 304.8, 1)

        if mark not in raw_by_mark:
            raw_by_mark[mark] = []
            mark_order.append(mark)
        raw_by_mark[mark].append({
            'el': el, 'bw': bw, 'bh': bh, 'len': length_mm, 'top': top_z,
            'ep': ep, 'bb': bb_el, 'lvl_int_ft': sp_lvl_int_ft, 'lvl_mm': beam_lvl_mm,
            'lid': lid_int, 'mat': mat_s,
        })

    if active_lvl_proj_ft is not None and active_lvl_proj_ft in lvl_counts:
        level_z_mm = round(active_lvl_proj_ft * 304.8, 1)
    elif lvl_counts:
        best_lvl_ft = max(lvl_counts.items(), key=lambda kv: kv[1])[0]
        level_z_mm = round(best_lvl_ft * 304.8, 1)
    else:
        level_z_mm = 0.0

    # Cluster elements sharing a Mark into geometrically continuous collinear chains (so identical beams become SL > 1 & differing beams get ~2, ~3)
    raw_grouped = {}
    sl_by_name = {}
    group_order = []

    def _split_mark_into_chains(elems):
        if len(elems) <= 1:
            return [elems]
        chains = []
        used = [False] * len(elems)
        for i0 in range(len(elems)):
            if used[i0]:
                continue
            used[i0] = True
            cur_chain = [elems[i0]]
            ep0 = elems[i0]['ep']
            if ep0 is None:
                chains.append(cur_chain)
                continue
            (ax0, ay0, _), (ax1, ay1, _), _ = ep0
            adx, ady = ax1 - ax0, ay1 - ay0
            aln = math.hypot(adx, ady)
            if aln < 1e-4:
                chains.append(cur_chain)
                continue
            c_ux, c_uy = adx / aln, ady / aln
            c_vx, c_vy = -c_uy, c_ux
            c_v0 = ax0 * c_vx + ay0 * c_vy
            c_lvl = elems[i0]['lid']

            grew = True
            while grew:
                grew = False
                us_cur = []
                for ce in cur_chain:
                    if ce['ep'] is not None:
                        us_cur.append(ce['ep'][0][0] * c_ux + ce['ep'][0][1] * c_uy)
                        us_cur.append(ce['ep'][1][0] * c_ux + ce['ep'][1][1] * c_uy)
                u_cmin, u_cmax = min(us_cur), max(us_cur)
                for j in range(len(elems)):
                    if used[j] or elems[j]['ep'] is None:
                        continue
                    if c_lvl >= 0 and elems[j]['lid'] >= 0 and elems[j]['lid'] != c_lvl:
                        continue
                    (bx0, by0, _), (bx1, by1, _), _ = elems[j]['ep']
                    bdx, bdy = bx1 - bx0, by1 - by0
                    bln = math.hypot(bdx, bdy)
                    if bln < 1e-4:
                        continue
                    if abs((bdx / bln) * c_ux + (bdy / bln) * c_uy) < 0.85:
                        continue
                    bv_mid = 0.5 * ((bx0 + bx1) * c_vx + (by0 + by1) * c_vy)
                    v_tol_ft = max(elems[i0]['bw'], elems[j]['bw'], 450.0) / 304.8
                    if abs(bv_mid - c_v0) > v_tol_ft:
                        continue
                    bu0 = bx0 * c_ux + by0 * c_uy
                    bu1 = bx1 * c_ux + by1 * c_uy
                    b_min, b_max = min(bu0, bu1), max(bu0, bu1)
                    gap_ft = max(b_min - u_cmax, u_cmin - b_max, 0.0)
                    if gap_ft <= 2500.0 / 304.8:
                        cur_chain.append(elems[j])
                        used[j] = True
                        grew = True
            chains.append(cur_chain)
        return chains

    for mk in mark_order:
        elems = raw_by_mark[mk]
        chains = _split_mark_into_chains(elems)
        if len(chains) == 1:
            raw_grouped[mk] = chains[0]
            sl_by_name[mk] = 1
            group_order.append(mk)
        else:
            # Group chains with identical span count & section/length signature -> SL = count; differing chains -> ~2, ~3
            buckets = []  # (sig, [chain, ...])
            for ch in chains:
                # Compute quick orientation to sort spans monotonically for stable signature
                ch_sorted = list(ch)
                ref_ep = next((x['ep'] for x in ch_sorted if x['ep'] is not None), None)
                if ref_ep is not None:
                    dxr = ref_ep[1][0] - ref_ep[0][0]
                    dyr = ref_ep[1][1] - ref_ep[0][1]
                    lnr = math.hypot(dxr, dyr) or 1.0
                    uxr, uyr = dxr / lnr, dyr / lnr
                    if uxr < -0.15 or (abs(uxr) <= 0.15 and uyr < 0):
                        uxr, uyr = -uxr, -uyr
                    ch_sorted.sort(key=lambda x: 0.5 * ((x['ep'][0][0] + x['ep'][1][0]) * uxr + (x['ep'][0][1] + x['ep'][1][1]) * uyr) if x['ep'] else 0.0)
                sig = tuple((int(round(x['bw'] / 10.0)), int(round(x['bh'] / 10.0)), int(round(x['len'] / 50.0)), int(round(x['top'] / 10.0))) for x in ch_sorted)
                placed_b = False
                for b_sig, b_list in buckets:
                    if b_sig == sig:
                        b_list.append(ch)
                        placed_b = True
                        break
                if not placed_b:
                    buckets.append((sig, [ch]))
            for bi, (_sig, ch_list) in enumerate(buckets):
                b_nm = mk if bi == 0 else ('%s~%d' % (mk, bi + 1))
                # Pick representative chain that has the most hosted rebars
                best_ch = max(ch_list, key=lambda c_items: sum(len(rebar_by_host.get(_eid_int(it['el'].Id), [])) for it in c_items))
                raw_grouped[b_nm] = best_ch
                sl_by_name[b_nm] = len(ch_list)
                group_order.append(b_nm)

    def _get_revit_bar_diam_mm(rb, rt):
        for obj in (rt, rb):
            if obj is None:
                continue
            try:
                p_d = obj.get_Parameter(DB.BuiltInParameter.REBAR_BAR_DIAMETER)
                if p_d and p_d.HasValue:
                    dv = round(p_d.AsDouble() * 304.8, 1)
                    if 4.0 <= dv <= 60.0:
                        return int(round(dv))
            except Exception:
                pass
            for attr_nm in ('BarModelDiameter', 'BarNominalDiameter', 'BarDiameter'):
                try:
                    val = getattr(obj, attr_nm, None)
                    if val is not None and float(val) > 0.0:
                        dv = round(float(val) * 304.8, 1)
                        if 4.0 <= dv <= 60.0:
                            return int(round(dv))
                except Exception:
                    pass
        dv_named = _get_revit_param_mm(rt, ['Bar Diameter', 'Bar Model Diameter', 'Nominal Diameter', 'Diameter', u'Đường kính'], 0.0)
        if 4.0 <= dv_named <= 60.0:
            return int(round(dv_named))
        if rt is not None:
            try:
                tnm = sstr(getattr(rt, 'Name', '') or '')
                for pat in (r'(?:ø|phi|d|t)\s*(\d{1,2})\b', r'\b(\d{1,2})\s*(?:mm|m)\b', r'\b(\d{1,2})\b'):
                    m_dm = re.search(pat, tnm, re.I)
                    if m_dm:
                        cand = int(m_dm.group(1))
                        if cand in (6, 8, 10, 12, 14, 16, 18, 20, 22, 25, 28, 30, 32, 36, 40):
                            return cand
            except Exception:
                pass
        return 18

    def _get_revit_bar_qty(rb):
        try:
            pq = rb.get_Parameter(DB.BuiltInParameter.REBAR_ELEM_QUANTITY_OF_BARS)
            if pq and pq.HasValue and pq.AsInteger() > 0:
                return int(pq.AsInteger())
        except Exception:
            pass
        for attr_nm in ('Quantity', 'NumberOfBarPositions'):
            try:
                v = getattr(rb, attr_nm, None)
                if v is not None and int(v) > 0:
                    return int(v)
            except Exception:
                pass
        return 1

    def _get_revit_stir_spacing_mm(rb):
        try:
            p_sp = rb.get_Parameter(DB.BuiltInParameter.REBAR_ELEM_BAR_SPACING)
            if p_sp and p_sp.HasValue and p_sp.StorageType == DB.StorageType.Double:
                spm = int(round(p_sp.AsDouble() * 304.8))
                if 40 <= spm <= 600:
                    return spm
        except Exception:
            pass
        try:
            acc = rb.GetShapeDrivenAccessor()
            spm = int(round(acc.MaxSpacing * 304.8))
            if 40 <= spm <= 600:
                return spm
            qty_s = _get_revit_bar_qty(rb)
            arr_len = float(getattr(acc, 'ArrayLength', 0.0) or 0.0) * 304.8
            if qty_s > 1 and arr_len > 40.0:
                spm2 = int(round(arr_len / float(qty_s - 1)))
                if 40 <= spm2 <= 600:
                    return spm2
        except Exception:
            pass
        spm3 = int(round(_get_revit_param_mm(rb, ['Spacing', 'Maximum Spacing', u'Khoảng cách'], 0.0)))
        if 40 <= spm3 <= 600:
            return spm3
        return 0

    def _ensure_col_footprint(sup_tup):
        if sup_tup[4]:  # is_wall
            return None
        if sup_tup[5] is None and not sup_tup[8]:
            sup_tup[8] = True
            fp_sol = _revit_col_footprint_pts_2d(sup_tup[7], doc, geom_opt, bb=sup_tup[2], allow_solid=True)
            if fp_sol:
                sup_tup[5] = fp_sol
        return sup_tup[5]

    def _is_lower_support_z(bb_s, z_lo, z_hi):
        return (
            bb_s.Max.Z >= z_lo - 0.80
            and (
                bb_s.Min.Z < z_lo - 0.80
                or (bb_s.Min.Z < z_lo - 0.15 and bb_s.Max.Z <= z_hi + 0.35)
            )
        )

    def _sup_u_span(sup_tup, pt_xy, ux, uy):
        _eid_s, _kd, bb, _col_nm, is_w, _fp_pts, wall_inf, _es, _stried = sup_tup
        if is_w and wall_inf is not None:
            (wp0, wp1), w_ft = (wall_inf[0], wall_inf[1]), wall_inf[2]
            wdx, wdy = wp1[0] - wp0[0], wp1[1] - wp0[1]
            wlen = math.hypot(wdx, wdy)
            if wlen > 1e-4:
                wtx, wty = wdx / wlen, wdy / wlen
                wnx, wny = -wty, wtx
                denom = ux * wnx + uy * wny
                if abs(denom) > 0.25:
                    t_int = ((wp0[0] - pt_xy[0]) * wnx + (wp0[1] - pt_xy[1]) * wny) / denom
                    ix, iy = pt_xy[0] + t_int * ux, pt_xy[1] + t_int * uy
                    s_on = (ix - wp0[0]) * wtx + (iy - wp0[1]) * wty
                    if -0.8 <= s_on <= wlen + 0.8:
                        half_u = (w_ft * 0.5) / abs(denom)
                        u_mid = ix * ux + iy * uy
                        return u_mid - half_u, u_mid + half_u
                    return None
                if wlen * 304.8 > 1500.0:
                    return None
        fp_pts = _ensure_col_footprint(sup_tup)
        if fp_pts:
            projs = [cx * ux + cy * uy for cx, cy in fp_pts]
            return min(projs), max(projs)
        projs = [cx * ux + cy * uy for cx in (bb.Min.X, bb.Max.X) for cy in (bb.Min.Y, bb.Max.Y)]
        return min(projs), max(projs)

    def _find_support_at(pt_xy, z_lo, z_hi, ux, uy, vx_b, vy_b, bw_ft, group_eids):
        px, py = pt_xy
        pad_u = 1.35
        pad_v = max(0.85, bw_ft * 0.5 + 0.45)
        u_pt = px * ux + py * uy
        v_pt = px * vx_b + py * vy_b
        cands = []  # (priority, dist_u, w_mm, kd, u0, u1, eid_s)
        # 1) Supporting Columns / Short Walls extending BELOW the beam soffit (never grabs upper planted columns)
        for sup_tup in sup_bbs:
            eid_s, kd, bb, _col_nm, is_w, _fp, _wi, _es, _st = sup_tup
            if (bb.Min.X - pad_u <= px <= bb.Max.X + pad_u) and (bb.Min.Y - pad_u <= py <= bb.Max.Y + pad_u):
                if _is_lower_support_z(bb, z_lo, z_hi):
                    span_uv = _sup_u_span(sup_tup, pt_xy, ux, uy)
                    if span_uv is None:
                        continue
                    u0, u1 = span_uv
                    if u0 - pad_u <= u_pt <= u1 + pad_u:
                        pts_v = _ensure_col_footprint(sup_tup)
                        if pts_v:
                            vs_s = [cx * vx_b + cy * vy_b for cx, cy in pts_v]
                        else:
                            vs_s = [cx * vx_b + cy * vy_b for cx in (bb.Min.X, bb.Max.X) for cy in (bb.Min.Y, bb.Max.Y)]
                        if not is_w and (max(vs_s) < v_pt - pad_v or min(vs_s) > v_pt + pad_v):
                            continue
                        w_mm = round((u1 - u0) * 304.8, 0)
                        if w_mm >= 80.0:
                            in_sup = 0.0 if (u0 <= u_pt <= u1) else min(abs(u_pt - u0), abs(u_pt - u1))
                            cands.append((1 if is_w else 0, in_sup, abs(0.5 * (u0 + u1) - u_pt), w_mm, kd, u0, u1, eid_s))
        if cands:
            cands.sort(key=lambda t: (t[0], t[1], t[2]))
            _pr, _in, _du, w_mm, kd, u0, u1, eid_s = cands[0]
            return w_mm, kd, u0, u1, eid_s

        # 2) Crossing Girders (intersect beam axis with girder centerline so Revit cutback does not shift u0..u1)
        pad_g = 1.15
        g_cands = []
        for eid_f, e_f, bb, fp0, fp1 in frame_bbs:
            if eid_f in group_eids:
                continue
            fdx, fdy = fp1[0] - fp0[0], fp1[1] - fp0[1]
            fln = math.hypot(fdx, fdy)
            if fln < 1e-4:
                continue
            if abs((fdx / fln) * ux + (fdy / fln) * uy) > 0.7:
                continue
            if (bb.Min.X - pad_g <= px <= bb.Max.X + pad_g) and (bb.Min.Y - pad_g <= py <= bb.Max.Y + pad_g):
                if bb.Min.Z <= z_hi + 0.5 and bb.Max.Z >= z_lo - 0.5:
                    sym_f = doc.GetElement(e_f.GetTypeId())
                    fw = (
                        _get_revit_bip_mm(sym_f, ['STRUCTURAL_SECTION_COMMON_WIDTH', 'FAMILY_WIDTH_PARAM'], 0.0)
                        or _get_revit_param_mm(sym_f, ['b', 'Width', 'Beam Width', u'Bề rộng', u'Rộng'], 0.0)
                        or _get_revit_param_mm(e_f, ['b', 'Width', u'Bề rộng', u'Rộng'], 0.0)
                    )
                    if fw <= 10.0:
                        fw, _ = _parse_nxm_from_name(getattr(sym_f, 'Name', '') if sym_f is not None else '')
                    if fw <= 10.0:
                        fw = 220.0
                    if fw >= 80.0:
                        half_ft = (fw / 304.8) * 0.5
                        nx_g, ny_g = -fdy / fln, fdx / fln
                        denom_g = ux * nx_g + uy * ny_g
                        u_mid_g = u_pt
                        if abs(denom_g) > 0.25:
                            t_g = ((fp0[0] - px) * nx_g + (fp0[1] - py) * ny_g) / denom_g
                            if abs(t_g) > pad_g + half_ft * 1.4:
                                continue
                            ix_g, iy_g = px + t_g * ux, py + t_g * uy
                            g_ux, g_uy = fdx / fln, fdy / fln
                            s_on_g = (ix_g - fp0[0]) * g_ux + (iy_g - fp0[1]) * g_uy
                            if not (-pad_g <= s_on_g <= fln + pad_g):
                                continue
                            u_mid_g = ix_g * ux + iy_g * uy
                        g_cands.append((abs(u_mid_g - u_pt), round(fw, 0), 'D', u_mid_g - half_ft, u_mid_g + half_ft, 0))
        if g_cands:
            g_cands.sort(key=lambda t: t[0])
            _du, fw_r, kd_g, u0_g, u1_g, eid_g = g_cands[0]
            return fw_r, kd_g, u0_g, u1_g, eid_g
        return 0.0, '', u_pt, u_pt, 0

    def _find_grid_near(pt_xy, u_mid_ft, ux, uy):
        px, py = pt_xy
        best_nm = ''
        best_dist = 2.5  # ft
        best_off_mm = 0.0
        for gname, gp0, _gp1, gux, guy in grid_items:
            if abs(gux * ux + guy * uy) > 0.45:
                continue
            nx, ny = -guy, gux
            d_perp = abs((px - gp0[0]) * nx + (py - gp0[1]) * ny)
            if d_perp < best_dist:
                denom = ux * nx + uy * ny
                if abs(denom) > 1e-4:
                    t = ((gp0[0] - px) * nx + (gp0[1] - py) * ny) / denom
                    u_grid_ft = (px * ux + py * uy) + t
                    best_dist = d_perp
                    best_nm = gname
                    off = round((u_grid_ft - u_mid_ft) * 304.8, 1)
                    best_off_mm = 0.0 if abs(off) < 2.0 else off
        return best_nm, best_off_mm

    def _find_side_slab(p0_xy, p1_xy, vx, vy, bw_mm, z_lo, z_hi, lvl_int_ft, side_sign):
        off_ft = (bw_mm * 0.5 + 140.0) / 304.8
        best_cand = None  # (abs(z_top - z_hi), th, top_rel_mm)
        for t_samp in (0.5, 0.25, 0.75):
            mx = p0_xy[0] + (p1_xy[0] - p0_xy[0]) * t_samp
            my = p0_xy[1] + (p1_xy[1] - p0_xy[1]) * t_samp
            sx = mx + side_sign * vx * off_ft
            sy = my + side_sign * vy * off_ft
            for fl_item in floor_bbs:
                fl_el, bb, th, top_faces = fl_item
                if not (bb.Min.X - 0.1 <= sx <= bb.Max.X + 0.1 and bb.Min.Y - 0.1 <= sy <= bb.Max.Y + 0.1):
                    continue
                if not (bb.Max.Z >= z_lo - 0.8 and bb.Min.Z <= z_hi + 1.2):
                    continue
                if top_faces is None:
                    top_faces = _revit_extract_floor_polys(fl_el, geom_opt)
                    fl_item[3] = top_faces
                z_face = bb.Max.Z
                if top_faces:
                    hit_face = False
                    for loops_2d, z_top_f in top_faces:
                        if _pt_in_loops_2d(sx, sy, loops_2d):
                            z_face = z_top_f
                            hit_face = True
                            break
                    if not hit_face:
                        continue
                cand = (abs(z_face - z_hi), th, round((z_face - lvl_int_ft) * 304.8, 1))
                if best_cand is None or cand[0] < best_cand[0]:
                    best_cand = cand
            if best_cand is not None:
                return best_cand[1], best_cand[2]
        return 0.0, 0.0

    def _get_rb_pts_ft(rb):
        pts = []
        is_exact = False
        pos_idx = 0
        try:
            n_pos_rb = int(getattr(rb, 'NumberOfBarPositions', 1) or 1)
            if hasattr(rb, 'DoesBarExistAtPosition'):
                for pi in range(max(1, n_pos_rb)):
                    if rb.DoesBarExistAtPosition(pi):
                        pos_idx = pi
                        break
        except Exception:
            pos_idx = 0
        for suppr_rad in (True, False):
            for mp_name in ('IncludeAllMultiplanarCurves', 'IncludeOnlyPlanarCurves'):
                try:
                    mp_opt = getattr(DB.MultiplanarOption, mp_name)
                    curves = rb.GetCenterlineCurves(False, False, suppr_rad, mp_opt, pos_idx)
                    if curves:
                        for c in curves:
                            try:
                                if not isinstance(c, DB.Line) and hasattr(c, 'Tessellate'):
                                    tpts = list(c.Tessellate())
                                    if tpts:
                                        pts.extend(tpts)
                                        continue
                            except Exception:
                                pass
                            pts.append(c.GetEndPoint(0))
                            pts.append(c.GetEndPoint(1))
                        if pts:
                            is_exact = True
                            return pts, is_exact
                except Exception:
                    pts = []
        if not pts:
            for suppr_rad in (True, False):
                try:
                    curves = rb.GetCenterlineCurves(False, False, suppr_rad)
                    if curves:
                        for c in curves:
                            pts.append(c.GetEndPoint(0))
                            pts.append(c.GetEndPoint(1))
                        if pts:
                            is_exact = True
                            return pts, is_exact
                except Exception:
                    pts = []
        if not pts:
            try:
                bb = rb.get_BoundingBox(None)
                if bb is not None:
                    pts = [bb.Min, bb.Max]
            except Exception:
                pass
        return pts, is_exact

    def _get_rb_api_hooks(rb):
        hk_s, hk_e = False, False
        try:
            inv_id = DB.ElementId.InvalidElementId
            if hasattr(rb, 'GetHookTypeId'):
                h0 = rb.GetHookTypeId(0)
                h1 = rb.GetHookTypeId(1)
                hk_s = (h0 is not None and h0 != inv_id)
                hk_e = (h1 is not None and h1 != inv_id)
        except Exception:
            pass
        for idx_h, bip_nm in ((0, 'REBAR_ELEM_HOOK_AT_START'), (1, 'REBAR_ELEM_HOOK_AT_END')):
            try:
                bip = getattr(DB.BuiltInParameter, bip_nm, None)
                if bip is not None:
                    p_hk = rb.get_Parameter(bip)
                    if p_hk and p_hk.HasValue and p_hk.AsElementId() != DB.ElementId.InvalidElementId:
                        if idx_h == 0:
                            hk_s = True
                        else:
                            hk_e = True
            except Exception:
                pass
        return hk_s, hk_e

    group_order.sort(key=_natural_beam_key)

    grouped = {}
    enriched_meta = {}
    summaries = []

    for nm in group_order:
        items = raw_grouped[nm]
        eids_set = set(_eid_int(it['el'].Id) for it in items)
        # Determine dominant axis and normalize left-to-right (+X) / bottom-to-top (+Y)
        ux, uy = 1.0, 0.0
        ref_xy = (0.0, 0.0)
        best_vec_len = -1.0
        for it in items:
            if it['ep'] is not None:
                (x0, y0, _), (x1, y1, _), _ = it['ep']
                ln = math.hypot(x1 - x0, y1 - y0)
                if ln > best_vec_len and ln > 1e-4:
                    best_vec_len = ln
                    ux, uy = (x1 - x0) / ln, (y1 - y0) / ln
                    ref_xy = (x0, y0)
        if ux < -0.15 or (abs(ux) <= 0.15 and uy < 0.0):
            ux, uy = -ux, -uy
        vx, vy = -uy, ux

        def _u_ft(xy):
            return (xy[0] - ref_xy[0]) * ux + (xy[1] - ref_xy[1]) * uy

        # Orient raw framing spans along +u and sub-split single continuous elements crossing intermediate lower columns
        oriented = []
        sub_eid_counts = {}
        for it in items:
            el, bw, bh, length_mm, top_z, ep, bb_el, sp_lvl_ft = (
                it['el'], it['bw'], it['bh'], it['len'], it['top'], it['ep'], it['bb'], it['lvl_int_ft']
            )
            if ep is not None:
                p0, p1, _ = ep
                if _u_ft((p1[0], p1[1])) < _u_ft((p0[0], p0[1])):
                    p0, p1 = p1, p0
                u_s, u_e = _u_ft((p0[0], p0[1])), _u_ft((p1[0], p1[1]))
            else:
                u_s = len(oriented) * (length_mm / 304.8)
                u_e = u_s + (length_mm / 304.8)
                p0 = (ref_xy[0] + ux * u_s, ref_xy[1] + uy * u_s, 0.0)
                p1 = (ref_xy[0] + ux * u_e, ref_xy[1] + uy * u_e, 0.0)
            is_horiz = (ep is not None and abs(ep[0][2] - ep[1][2]) <= 0.05)
            if is_horiz:
                z_hi = sp_lvl_ft + top_z / 304.8
                z_lo = z_hi - bh / 304.8
            else:
                z_hi = bb_el.Max.Z if bb_el is not None else (sp_lvl_ft + top_z / 304.8)
                z_lo = bb_el.Min.Z if bb_el is not None else (z_hi - bh / 304.8)
            if ep is not None:
                v_c_el = 0.5 * ((p0[0] + p1[0]) * vx + (p0[1] + p1[1]) * vy)
                v_sp_lo, v_sp_hi = v_c_el - (bw / 304.8) * 0.5, v_c_el + (bw / 304.8) * 0.5
            elif bb_el is not None:
                vs_el = [cx_ * vx + cy_ * vy for cx_ in (bb_el.Min.X, bb_el.Max.X) for cy_ in (bb_el.Min.Y, bb_el.Max.Y)]
                v_sp_lo, v_sp_hi = min(vs_el), max(vs_el)
            else:
                v_c_el = p0[0] * vx + p0[1] * vy
                v_sp_lo, v_sp_hi = v_c_el - (bw / 304.8) * 0.5, v_c_el + (bw / 304.8) * 0.5

            # Detect intermediate supporting columns/short walls crossing the middle of a single continuous framing element
            split_us = []
            if ep is not None and (u_e - u_s) > 3.5:
                delta_ref_sp = ref_xy[0] * ux + ref_xy[1] * uy
                mid_pt_sp = (0.5 * (p0[0] + p1[0]), 0.5 * (p0[1] + p1[1]))
                for sup_tup in sup_bbs:
                    bb_s = sup_tup[2]
                    if not _is_lower_support_z(bb_s, z_lo, z_hi):
                        continue
                    span_uv_s = _sup_u_span(sup_tup, mid_pt_sp, ux, uy)
                    if span_uv_s is None:
                        continue
                    fp_s = _ensure_col_footprint(sup_tup)
                    pts_check = fp_s if fp_s else [(cx, cy) for cx in (bb_s.Min.X, bb_s.Max.X) for cy in (bb_s.Min.Y, bb_s.Max.Y)]
                    vs_s = [cx * vx + cy * vy for cx, cy in pts_check]
                    if max(vs_s) < v_sp_lo - 0.35 or min(vs_s) > v_sp_hi + 0.35:
                        continue
                    u0_s, u1_s = span_uv_s
                    u_mid_s = 0.5 * (u0_s + u1_s) - delta_ref_sp
                    if u_s + 1.25 <= u_mid_s <= u_e - 1.25:
                        if not any(abs(u_mid_s - su_ex) < 1.2 for su_ex in split_us):
                            split_us.append(u_mid_s)
                # Also split continuous secondary beams across deeper crossing primary girders ('D')
                for eid_g, e_g, bb_g, gp0, gp1 in frame_bbs:
                    if eid_g in eids_set:
                        continue
                    if bb_g.Min.Z > z_hi + 0.35 or bb_g.Max.Z < z_lo - 0.35:
                        continue
                    gdx, gdy = gp1[0] - gp0[0], gp1[1] - gp0[1]
                    gln = math.hypot(gdx, gdy)
                    if gln < 1e-4:
                        continue
                    gux, guy = gdx / gln, gdy / gln
                    if abs(gux * ux + guy * uy) > 0.7:
                        continue
                    gnx, gny = -guy, gux
                    denom_sp = ux * gnx + uy * gny
                    if abs(denom_sp) <= 0.25:
                        continue
                    t_sp = ((gp0[0] - p0[0]) * gnx + (gp0[1] - p0[1]) * gny) / denom_sp
                    ix_sp, iy_sp = p0[0] + t_sp * ux, p0[1] + t_sp * uy
                    s_on_g = (ix_sp - gp0[0]) * gux + (iy_sp - gp0[1]) * guy
                    if not (-0.35 <= s_on_g <= gln + 0.35):
                        continue
                    u_mid_g = (ix_sp * ux + iy_sp * uy) - delta_ref_sp
                    if not (u_s + 1.25 <= u_mid_g <= u_e - 1.25):
                        continue
                    if any(abs(u_mid_g - su_ex) < 1.2 for su_ex in split_us):
                        continue
                    sym_g = doc.GetElement(e_g.GetTypeId())
                    gh_mm = (
                        _get_revit_bip_mm(sym_g, ['STRUCTURAL_SECTION_COMMON_HEIGHT', 'FAMILY_HEIGHT_PARAM'], 0.0)
                        or _get_revit_param_mm(sym_g, ['h', 'Height', 'Beam Height', u'Chiều cao', 'Cao'], 0.0)
                        or _get_revit_param_mm(e_g, ['h', 'Height', u'Chiều cao', 'Cao'], 0.0)
                    )
                    if gh_mm <= 10.0:
                        _, gh_mm = _parse_nxm_from_name(getattr(sym_g, 'Name', '') if sym_g is not None else '')
                    if gh_mm <= 10.0:
                        gh_mm = (bb_g.Max.Z - bb_g.Min.Z) * 304.8
                    if gh_mm > bh + 5.0:
                        split_us.append(u_mid_g)
                split_us.sort()

            eid_int_cur = _eid_int(el.Id)
            if split_us:
                pts_chain = [p0]
                for su_val in split_us:
                    t_f = (su_val - u_s) / max(1e-6, u_e - u_s)
                    pts_chain.append((
                        p0[0] + t_f * (p1[0] - p0[0]),
                        p0[1] + t_f * (p1[1] - p0[1]),
                        p0[2] + t_f * (p1[2] - p0[2]),
                    ))
                pts_chain.append(p1)
                sub_eid_counts[eid_int_cur] = len(pts_chain) - 1
                for si_sub in range(len(pts_chain) - 1):
                    pa, pb = pts_chain[si_sub], pts_chain[si_sub + 1]
                    ua, ub = _u_ft((pa[0], pa[1])), _u_ft((pb[0], pb[1]))
                    sub_len_mm = round((ub - ua) * 304.8, 0)
                    oriented.append((ua, ub, el, bw, bh, sub_len_mm, top_z, pa, pb, z_lo, z_hi, sp_lvl_ft, v_sp_lo, v_sp_hi))
            else:
                sub_eid_counts[eid_int_cur] = sub_eid_counts.get(eid_int_cur, 0) + 1
                oriented.append((u_s, u_e, el, bw, bh, length_mm, top_z, p0, p1, z_lo, z_hi, sp_lvl_ft, v_sp_lo, v_sp_hi))

        oriented.sort(key=lambda t: t[0])

        # Compute supports 0..n_sp
        n_sp = len(oriented)
        sups_meta = []
        used_sup_eids = set()
        lower_c_centers = []  # (u_mid_r, v_mid_raw) for lower 'C' column supports
        delta_ref = ref_xy[0] * ux + ref_xy[1] * uy
        for k in range(n_sp + 1):
            if k == 0:
                sp_ref = oriented[0]
                pt_j = (sp_ref[7][0], sp_ref[7][1])
                zl, zh, bw_j = sp_ref[9], sp_ref[10], sp_ref[3]
            elif k == n_sp:
                sp_ref = oriented[-1]
                pt_j = (sp_ref[8][0], sp_ref[8][1])
                zl, zh, bw_j = sp_ref[9], sp_ref[10], sp_ref[3]
            else:
                sL_r, sR_r = oriented[k - 1], oriented[k]
                pt_j = ((sL_r[8][0] + sR_r[7][0]) * 0.5, (sL_r[8][1] + sR_r[7][1]) * 0.5)
                zl, zh, bw_j = min(sL_r[9], sR_r[9]), max(sL_r[10], sR_r[10]), max(sL_r[3], sR_r[3])
            w_mm, kd, su0, su1, eid_sup = _find_support_at(pt_j, zl, zh, ux, uy, vx, vy, bw_j / 304.8, eids_set)
            if eid_sup:
                used_sup_eids.add(eid_sup)
            u_pt = _u_ft(pt_j)
            u_mid_raw = (su0 + su1) * 0.5
            su0_r = su0 - delta_ref if w_mm > 0.5 else u_pt
            su1_r = su1 - delta_ref if w_mm > 0.5 else u_pt
            if eid_sup and kd == 'C' and w_mm > 0.5:
                lower_c_centers.append((0.5 * (su0_r + su1_r), pt_j[0] * vx + pt_j[1] * vy))
            grid_nm, off_mm = _find_grid_near(pt_j, u_mid_raw, ux, uy)
            sups_meta.append({'w': w_mm, 'kind': kd, 'grid': grid_nm, 'off': off_mm, 'u0': su0_r, 'u1': su1_r})

        # Compute clear spans and slabs per span
        spans_meta = []
        grouped[nm] = []
        cx_cad = 0.0
        for i_sp, sp_tup in enumerate(oriented):
            u_s, u_e, el, bw, bh, length_mm, top_z, p0, p1, z_lo, z_hi, sp_lvl_ft, v_sp_lo, v_sp_hi = sp_tup
            supL, supR = sups_meta[i_sp], sups_meta[i_sp + 1]
            left_face_ft = supL['u1'] if supL['w'] > 0.5 else u_s
            right_face_ft = supR['u0'] if supR['w'] > 0.5 else u_e
            clear_mm = round((right_face_ft - left_face_ft) * 304.8, 0)
            if clear_mm < 200.0:
                clear_mm = max(200.0, length_mm - 0.5 * supL['w'] - 0.5 * supR['w'])
            sbL, sbL_top = _find_side_slab((p0[0], p0[1]), (p1[0], p1[1]), vx, vy, bw, z_lo, z_hi, sp_lvl_ft, +1.0)
            sbR, sbR_top = _find_side_slab((p0[0], p0[1]), (p1[0], p1[1]), vx, vy, bw, z_lo, z_hi, sp_lvl_ft, -1.0)
            if sbL <= 0.5:
                sbL_top = top_z
            if sbR <= 0.5:
                sbR_top = top_z
            if i_sp == 0:
                cx_cad += supL['w']
            fl_cad = cx_cad
            cx_cad += clear_mm
            fr_cad = cx_cad
            cx_cad += supR['w']

            # Scan span stirrups
            eid_cur = _eid_int(el.Id)
            hosted_sp = rebar_by_host.get(eid_cur, [])
            is_virt_split = sub_eid_counts.get(eid_cur, 1) > 1
            s_d, s_sp = [], []
            for rb in hosted_sp:
                try:
                    rt = doc.GetElement(rb.GetTypeId())
                    dm = _get_revit_bar_diam_mm(rb, rt)
                    if dm <= 12:
                        pts_rb, is_exact_rb = _get_rb_pts_ft(rb)
                        n_pos = 1
                        try:
                            n_pos = int(getattr(rb, 'NumberOfBarPositions', 1) or 1)
                        except Exception:
                            n_pos = 1
                        if pts_rb and is_exact_rb:
                            us_rb = [_u_ft((p.X, p.Y)) for p in pts_rb]
                            vs_rb = [(p.X * vx + p.Y * vy) * 304.8 for p in pts_rb]
                            zs_rb = [p.Z * 304.8 for p in pts_rb]
                            du_mm = (max(us_rb) - min(us_rb)) * 304.8
                            if du_mm > 220.0:
                                continue  # skip longitudinal bar
                            if n_pos <= 1 and ((max(zs_rb) - min(zs_rb)) < 80.0 or (max(vs_rb) - min(vs_rb)) < 50.0):
                                continue
                        elif n_pos <= 1:
                            continue
                        if is_virt_split:
                            try:
                                bb_st = rb.get_BoundingBox(None)
                                if bb_st is not None:
                                    us_st = [_u_ft((cx_, cy_)) for cx_ in (bb_st.Min.X, bb_st.Max.X) for cy_ in (bb_st.Min.Y, bb_st.Max.Y)]
                                    if max(us_st) < left_face_ft - 0.35 or min(us_st) > right_face_ft + 0.35:
                                        continue
                            except Exception:
                                pass
                        s_d.append(dm)
                        spm = _get_revit_stir_spacing_mm(rb)
                        if spm:
                            s_sp.append(spm)
                except Exception:
                    pass
            if s_d:
                sdv = min(s_d)
                sa1v = min(s_sp) if s_sp else 100
                sa2v = max(s_sp) if s_sp else 200
                if sa1v == sa2v and not s_sp:
                    sa2v = 200
                stir_sp_s = '%d-%d/%d' % (sdv, sa1v, sa2v)
            else:
                stir_sp_s = '6-100/200' if bh <= 300.0 else '8-100/200'

            spans_meta.append({
                'eid': eid_cur, 'bw': bw, 'bh': bh, 'clear': clear_mm, 'top': top_z,
                'sbL': sbL, 'sbL_top': sbL_top, 'sbR': sbR, 'sbR_top': sbR_top,
                'stir': stir_sp_s, 'has_3d_stir': bool(s_d), 'planted': [], 'fl_cad': fl_cad, 'fr_cad': fr_cad,
                'u_left': left_face_ft, 'u_right': right_face_ft,
                'u_zone_lo': (sups_meta[i_sp]['u0'] - 0.25) if sups_meta[i_sp]['w'] > 0.5 else (left_face_ft - 0.35),
                'u_zone_hi': (sups_meta[i_sp + 1]['u1'] + 0.25) if sups_meta[i_sp + 1]['w'] > 0.5 else (right_face_ft + 0.35),
                'v_lo': v_sp_lo, 'v_hi': v_sp_hi,
                'z_lo': z_lo, 'z_hi': z_hi,
            })
            grouped[nm].append((None, bw, bh, clear_mm, top_z))

        # Capture 100% of planted columns ('cột cấy lên dầm') along the entire beam (exclude walls & same-axis continuing upper columns)
        seen_pl_ids = set(used_sup_eids)
        delta_ref_sp = ref_xy[0] * ux + ref_xy[1] * uy
        for sup_tup in sup_bbs:
            eid_c, kd_c, bb_c, col_nm_c, is_w_c, fp_c, _wi_c, _es_c, _st_c = sup_tup
            if is_w_c or kd_c != 'C' or eid_c in seen_pl_ids:
                continue
            fp_c = _ensure_col_footprint(sup_tup)
            pts_c = fp_c if fp_c else [(cx_, cy_) for cx_ in (bb_c.Min.X, bb_c.Max.X) for cy_ in (bb_c.Min.Y, bb_c.Max.Y)]
            vs_c = [cx_ * vx + cy_ * vy for cx_, cy_ in pts_c]
            us_c = [cx_ * ux + cy_ * uy - delta_ref_sp for cx_, cy_ in pts_c]
            u0_c, u1_c = min(us_c), max(us_c)
            u_mid_c = (u0_c + u1_c) * 0.5
            v_mid_c = 0.5 * (min(vs_c) + max(vs_c))
            # Skip upper floor column stacked concentrically on top of an already-detected lower support column
            if any(abs(u_mid_c - luc_u) <= 0.15 and abs(v_mid_c - luc_v) <= 0.35 for luc_u, luc_v in lower_c_centers):
                continue
            best_sp_idx = -1
            best_sp_score = None
            for i_sp_c, sp_mc in enumerate(spans_meta):
                if not (sp_mc['z_lo'] - 0.90 <= bb_c.Min.Z <= sp_mc['z_hi'] + 1.35 and bb_c.Max.Z > sp_mc['z_hi'] + 0.25):
                    continue
                if max(vs_c) < sp_mc['v_lo'] - 0.65 or min(vs_c) > sp_mc['v_hi'] + 0.65:
                    continue
                if u1_c >= sp_mc['u_zone_lo'] - 0.15 and u0_c <= sp_mc['u_zone_hi'] + 0.15:
                    in_clear = (sp_mc['u_left'] <= u_mid_c <= sp_mc['u_right'])
                    sp_mid_u = 0.5 * (sp_mc['u_left'] + sp_mc['u_right'])
                    sc_c = (0 if in_clear else 1, abs(u_mid_c - sp_mid_u))
                    if best_sp_score is None or sc_c < best_sp_score:
                        best_sp_score = sc_c
                        best_sp_idx = i_sp_c
            if best_sp_idx >= 0:
                sp_own = spans_meta[best_sp_idx]
                w_c_mm = max(80.0, round((u1_c - u0_c) * 304.8, 0))
                pos_c_mm = round((u_mid_c - sp_own['u_left']) * 304.8, 0)
                seen_pl_ids.add(eid_c)
                sp_own['planted'].append({'name': col_nm_c or 'CC', 'pos': pos_c_mm, 'w': w_c_mm})

        # Map continuous u_ft -> CAD X coordinate (mm) piecewise across supports & clear spans
        sx0_cad = []
        cur_xc = 0.0
        for k_s in range(n_sp + 1):
            sx0_cad.append(cur_xc)
            cur_xc += sups_meta[k_s]['w']
            if k_s < n_sp:
                cur_xc += spans_meta[k_s]['clear']

        u_cad_segs = []
        for k_s in range(n_sp + 1):
            if sups_meta[k_s]['w'] > 0.5 and sups_meta[k_s]['u1'] > sups_meta[k_s]['u0'] + 1e-4:
                u_cad_segs.append((sups_meta[k_s]['u0'], sups_meta[k_s]['u1'], sx0_cad[k_s], sx0_cad[k_s] + sups_meta[k_s]['w']))
            if k_s < n_sp:
                sp_m = spans_meta[k_s]
                if sp_m['u_right'] > sp_m['u_left'] + 1e-4:
                    u_cad_segs.append((sp_m['u_left'], sp_m['u_right'], sp_m['fl_cad'], sp_m['fr_cad']))

        def _u_ft_to_cad_x(u_val_ft):
            if not u_cad_segs:
                u0_ref = sups_meta[0]['u0'] if sups_meta[0]['w'] > 0.5 else spans_meta[0]['u_left']
                return (u_val_ft - u0_ref) * 304.8
            if u_val_ft <= u_cad_segs[0][0]:
                return u_cad_segs[0][2] + (u_val_ft - u_cad_segs[0][0]) * 304.8
            for ua, ub, xa_c, xb_c in u_cad_segs:
                if ua - 1e-5 <= u_val_ft <= ub + 1e-5:
                    t = (u_val_ft - ua) / max(1e-6, ub - ua)
                    return xa_c + t * (xb_c - xa_c)
            last_s = u_cad_segs[-1]
            return last_s[3] + (u_val_ft - last_s[1]) * 304.8

        # Collect longitudinal rebars hosted on any span of this beam OR column-hosted/unhosted physically inside beam envelope
        beam_v_lo = min(s['v_lo'] for s in spans_meta) - 0.12
        beam_v_hi = max(s['v_hi'] for s in spans_meta) + 0.12
        beam_u_min = (sups_meta[0]['u0'] if sups_meta[0]['w'] > 0.5 else spans_meta[0]['u_left']) - 0.5
        beam_u_max = (sups_meta[-1]['u1'] if sups_meta[-1]['w'] > 0.5 else spans_meta[-1]['u_right']) + 0.5
        beam_z_lo = min(s['z_lo'] for s in spans_meta) - 0.15
        beam_z_hi = max(s['z_hi'] for s in spans_meta) + 0.15
        max_bh_ft = max(s['bh'] for s in spans_meta) / 304.8
        max_bw_ft = max(s['bw'] for s in spans_meta) / 304.8
        pad_xy = max_bw_ft * 0.65 + 0.45
        pts_xy_sp = [(sp_t[7][0], sp_t[7][1]) for sp_t in oriented] + [(sp_t[8][0], sp_t[8][1]) for sp_t in oriented]
        b_xmin = min(p[0] for p in pts_xy_sp) - pad_xy
        b_xmax = max(p[0] for p in pts_xy_sp) + pad_xy
        b_ymin = min(p[1] for p in pts_xy_sp) - pad_xy
        b_ymax = max(p[1] for p in pts_xy_sp) + pad_xy

        hosted_all = []
        pts_cache = {}
        seen_rb_ids = set()
        for sp_m in spans_meta:
            for rb in rebar_by_host.get(sp_m['eid'], []):
                rid = _eid_int(rb.Id)
                if rid not in seen_rb_ids:
                    seen_rb_ids.add(rid)
                    hosted_all.append((rid, rb))
        for rid, rb, bb_rb in unhosted_rebars:
            if rid in seen_rb_ids:
                continue
            if bb_rb is not None:
                if (bb_rb.Max.X < b_xmin or bb_rb.Min.X > b_xmax
                        or bb_rb.Max.Y < b_ymin or bb_rb.Min.Y > b_ymax
                        or bb_rb.Max.Z < beam_z_lo or bb_rb.Min.Z > beam_z_hi):
                    continue
            pts_chk, is_exact_chk = _get_rb_pts_ft(rb)
            pts_cache[rid] = (pts_chk, is_exact_chk)
            if not pts_chk or not is_exact_chk:
                continue
            us_chk = [_u_ft((p.X, p.Y)) for p in pts_chk]
            vs_chk = [p.X * vx + p.Y * vy for p in pts_chk]
            zs_chk = [p.Z for p in pts_chk]
            du_ft = max(us_chk) - min(us_chk)
            dz_ft = max(zs_chk) - min(zs_chk)
            if du_ft * 304.8 < 220.0:
                continue
            if dz_ft > 1.5 * du_ft and dz_ft > max_bh_ft * 1.2:
                continue  # skip predominantly vertical column bars
            v_mid = sum(vs_chk) / float(len(vs_chk))
            z_mid = sum(zs_chk) / float(len(zs_chk))
            if (beam_v_lo <= v_mid <= beam_v_hi) and (beam_z_lo <= z_mid <= beam_z_hi):
                if max(us_chk) >= beam_u_min and min(us_chk) <= beam_u_max:
                    seen_rb_ids.add(rid)
                    hosted_all.append((rid, rb))

        raw_long_bars = []
        for rid, rb in hosted_all:
            try:
                rt = doc.GetElement(rb.GetTypeId())
                d_mm = _get_revit_bar_diam_mm(rb, rt)
                pts_rb, is_exact_rb = pts_cache.pop(rid, None) or _get_rb_pts_ft(rb)
                if not pts_rb:
                    continue
                if not is_exact_rb:
                    try:
                        n_pos = int(getattr(rb, 'NumberOfBarPositions', 1) or 1)
                    except Exception:
                        n_pos = 1
                    if d_mm <= 12 and n_pos > 1:
                        continue
                us_mm = [_u_ft_to_cad_x(_u_ft((p.X, p.Y))) for p in pts_rb]
                vs_mm = [(p.X * vx + p.Y * vy) * 304.8 for p in pts_rb]
                zs_ft = [p.Z for p in pts_rb]
                x_min, x_max = min(us_mm), max(us_mm)
                du_bar_mm = x_max - x_min
                dz_bar_mm = (max(zs_ft) - min(zs_ft)) * 304.8
                if du_bar_mm < 220.0:
                    continue
                if dz_bar_mm > 2.0 * du_bar_mm and du_bar_mm < 350.0:
                    continue
                z_main = sum(zs_ft) / float(len(zs_ft))
                v_main = sum(vs_mm) / float(len(vs_mm))
                best_seg_dx = 0.0
                for pi in range(len(pts_rb) - 1):
                    dx_p = abs(us_mm[pi + 1] - us_mm[pi])
                    dz_p_mm = abs(zs_ft[pi + 1] - zs_ft[pi]) * 304.8
                    if dx_p > 120.0 and dx_p > 2.5 * dz_p_mm and dx_p > best_seg_dx:
                        best_seg_dx = dx_p
                        z_main = (zs_ft[pi] + zs_ft[pi + 1]) * 0.5
                        v_main = (vs_mm[pi] + vs_mm[pi + 1]) * 0.5
                end_win = min(450.0, max(220.0, (x_max - x_min) * 0.25))
                geom_hl_z = any(abs(us_mm[idx_p] - x_min) < end_win and abs(zs_ft[idx_p] - z_main) * 304.8 > 45.0 for idx_p in range(len(pts_rb)))
                geom_hr_z = any(abs(us_mm[idx_p] - x_max) < end_win and abs(zs_ft[idx_p] - z_main) * 304.8 > 45.0 for idx_p in range(len(pts_rb)))
                geom_hl_v = any(abs(us_mm[idx_p] - x_min) < end_win and abs(vs_mm[idx_p] - v_main) > 45.0 for idx_p in range(len(pts_rb)))
                geom_hr_v = any(abs(us_mm[idx_p] - x_max) < end_win and abs(vs_mm[idx_p] - v_main) > 45.0 for idx_p in range(len(pts_rb)))
                hk_s, hk_e = _get_rb_api_hooks(rb)
                if abs(us_mm[0] - x_min) <= abs(us_mm[-1] - x_min):
                    api_hl, api_hr = hk_s, hk_e
                else:
                    api_hl, api_hr = hk_e, hk_s

                mid_x_bar = (x_min + x_max) * 0.5
                ref_sp = spans_meta[0]
                for sp_m in spans_meta:
                    if sp_m['fl_cad'] - 200.0 <= mid_x_bar <= sp_m['fr_cad'] + 200.0:
                        ref_sp = sp_m
                        break
                sp_h_ft = max(0.3, ref_sp['z_hi'] - ref_sp['z_lo'])
                frac_top = (ref_sp['z_hi'] - z_main) / sp_h_ft
                dist_top_mm = (ref_sp['z_hi'] - z_main) * 304.8
                dist_bot_mm = (z_main - ref_sp['z_lo']) * 304.8
                bh_ref_mm = sp_h_ft * 304.8
                if bh_ref_mm >= 550.0 and dist_top_mm > 160.0 and dist_bot_mm > 160.0 and (0.24 <= frac_top <= 0.76):
                    pos_s = u'Giữa'
                elif frac_top < 0.45:
                    pos_s = u'Trên'
                elif frac_top > 0.55:
                    pos_s = u'Dưới'
                else:
                    pos_s = u'Giữa'

                if pos_s == u'Giữa':
                    has_hook_l = geom_hl_z
                    has_hook_r = geom_hr_z
                else:
                    at_outer_l = (x_min <= sx0_cad[0] + sups_meta[0]['w'] + 220.0)
                    at_outer_r = (x_max >= sx0_cad[-1] - 220.0)
                    has_hook_l = geom_hl_z or api_hl or (at_outer_l and geom_hl_v)
                    has_hook_r = geom_hr_z or api_hr or (at_outer_r and geom_hr_v)

                qty_b = _get_revit_bar_qty(rb)
                z_rel_mm = round((ref_sp['z_hi'] - z_main) * 304.8, 0)
                z_bot_mm = round((z_main - ref_sp['z_lo']) * 304.8, 0)
                z_abs_mm = round(z_main * 304.8, 0)
                raw_long_bars.append({
                    'pos': pos_s, 'd': d_mm, 'qty': qty_b,
                    'z_rel': z_rel_mm, 'z_bot': z_bot_mm, 'z_abs': z_abs_mm,
                    'x0': x_min, 'x1': x_max, 'hl': has_hook_l, 'hr': has_hook_r,
                })
            except Exception:
                pass

        # Merge identical individual bars placed at same Z & X span into combined bar count
        merged_bars = []
        for b in raw_long_bars:
            matched = False
            for mb in merged_bars:
                z_diff_ok = (abs(mb['z_rel'] - b['z_rel']) <= 22.0 or (b['pos'] == u'Dưới' and abs(mb['z_bot'] - b['z_bot']) <= 22.0))
                if (mb['pos'] == b['pos'] and mb['d'] == b['d']
                        and z_diff_ok
                        and abs(mb['x0'] - b['x0']) <= 60.0
                        and abs(mb['x1'] - b['x1']) <= 60.0):
                    mb['qty'] += b['qty']
                    mb['hl'] = mb['hl'] or b['hl']
                    mb['hr'] = mb['hr'] or b['hr']
                    matched = True
                    break
            if not matched:
                merged_bars.append(dict(b))

        # Coalesce continuous longitudinal bars split per-span in Revit
        def _coalesce_pass(allow_internal_hooks=False):
            max_passes = max(60, len(merged_bars) * max(2, n_sp) * 4 + 20)
            for _pass in range(max_passes):
                did_join = False
                for ks in range(1, n_sp):
                    sxL_k, sxR_k = sx0_cad[ks], sx0_cad[ks] + sups_meta[ks]['w']
                    len_l = spans_meta[ks - 1]['clear']
                    len_r = spans_meta[ks]['clear']
                    ext_l_lim = max(1500.0, len_r * 0.42)
                    ext_r_lim = max(1500.0, len_l * 0.42)
                    prev_sup_r = sx0_cad[ks - 1] + sups_meta[ks - 1]['w']
                    next_sup_l = sx0_cad[ks + 1]
                    sup_gap_lim = max(250.0, sups_meta[ks]['w'] + 80.0)

                    cand_as = []
                    for idx_a in range(len(merged_bars)):
                        bA = merged_bars[idx_a]
                        if bA.get('qty', 0) <= 0:
                            continue
                        if not allow_internal_hooks and bA['hr']:
                            continue
                        if allow_internal_hooks:
                            if bA['pos'] not in (u'Trên', u'Dưới'):
                                continue
                            face_d_a = bA['z_rel'] if bA['pos'] == u'Trên' else bA['z_bot']
                            if face_d_a > 140.0:
                                continue
                        if not (bA['x0'] < sxL_k - 150.0 and sxL_k - 450.0 <= bA['x1'] <= sxR_k + ext_l_lim):
                            continue
                        a_starts_sup = (bA['x0'] <= prev_sup_r + 250.0)
                        cand_as.append((0 if bA['x0'] <= sx0_cad[0] + sups_meta[0]['w'] + 350.0 else (1 if a_starts_sup else 2), -(bA['x1'] - bA['x0']), idx_a))
                    cand_as.sort()

                    for _rk_a, _neg_la, idx_a in cand_as:
                        bA = merged_bars[idx_a]
                        a_is_midcut = (bA['x0'] > prev_sup_r + 250.0)
                        best_idx_b = -1
                        best_score = None
                        for idx_b in range(len(merged_bars)):
                            if idx_b == idx_a:
                                continue
                            bB = merged_bars[idx_b]
                            if bB.get('qty', 0) <= 0:
                                continue
                            if not allow_internal_hooks and bB['hl']:
                                continue
                            if allow_internal_hooks:
                                face_d_b = bB['z_rel'] if bB['pos'] == u'Trên' else bB['z_bot']
                                if face_d_b > 140.0:
                                    continue
                            if bA['pos'] != bB['pos'] or bA['d'] != bB['d']:
                                continue
                            if not (sxL_k - ext_r_lim <= bB['x0'] <= sxR_k + 550.0 and bB['x1'] > max(sxR_k + 150.0, bA['x1'] + 250.0)):
                                continue
                            if bA['x1'] < bB['x0'] - sup_gap_lim:
                                continue
                            b_reaches_sup = (bB['x1'] >= next_sup_l - 250.0)
                            if a_is_midcut and b_reaches_sup:
                                continue
                            dz_ab = min(
                                abs(bA['z_rel'] - bB['z_rel']),
                                abs(bA['z_bot'] - bB['z_bot']) if bA['pos'] == u'Dưới' else 1e9,
                                abs(bA['z_abs'] - bB['z_abs'])
                            )
                            if dz_ab <= 85.0:
                                sc_b = (0 if b_reaches_sup else 1, round(dz_ab, 1), -(bB['x1'] - bB['x0']))
                                if best_score is None or sc_b < best_score:
                                    best_score = sc_b
                                    best_idx_b = idx_b
                        if best_idx_b >= 0:
                            bB = merged_bars[best_idx_b]
                            q_com = min(bA['qty'], bB['qty'])
                            z_com = min(bA['z_rel'], bB['z_rel']) if bA['pos'] == u'Trên' else max(bA['z_rel'], bB['z_rel'])
                            joined_b = {
                                'pos': bA['pos'], 'd': bA['d'], 'qty': q_com, 'z_rel': z_com,
                                'z_bot': min(bA['z_bot'], bB['z_bot']) if bA['pos'] == u'Dưới' else max(bA['z_bot'], bB['z_bot']),
                                'z_abs': 0.5 * (bA['z_abs'] + bB['z_abs']),
                                'x0': bA['x0'], 'x1': bB['x1'], 'hl': bA['hl'], 'hr': bB['hr'],
                            }
                            bA['qty'] -= q_com
                            bB['qty'] -= q_com
                            merged_bars.append(joined_b)
                            did_join = True
                            break
                    if did_join:
                        merged_bars[:] = [mb for mb in merged_bars if mb.get('qty', 0) > 0]
                        break
                if not did_join:
                    break

        _coalesce_pass(allow_internal_hooks=False)
        _coalesce_pass(allow_internal_hooks=True)

        # Assign layers (1 = closest to outer top/bot face) & map end anchors
        for pos_k in (u'Trên', u'Dưới', u'Giữa'):
            p_bars = [b for b in merged_bars if b['pos'] == pos_k]
            if pos_k == u'Dưới':
                p_bars.sort(key=lambda b: -b['z_rel'])
            else:
                p_bars.sort(key=lambda b: b['z_rel'])
            layer_buckets = []
            for b in p_bars:
                found_l = 0
                for li, items_l in enumerate(layer_buckets, 1):
                    conflict_ov = False
                    same_plane = False
                    for ob in items_l:
                        ov_x = min(b['x1'], ob['x1']) - max(b['x0'], ob['x0'])
                        dz_v = min(abs(b['z_rel'] - ob['z_rel']), abs(b['z_bot'] - ob['z_bot']) if pos_k == u'Dưới' else 1e9)
                        if ov_x > 250.0 and dz_v > 22.0:
                            conflict_ov = True
                            break
                        if dz_v <= (22.0 if ov_x > 250.0 else 48.0):
                            same_plane = True
                    if not conflict_ov and same_plane:
                        found_l = li
                        items_l.append(b)
                        break
                if not found_l:
                    layer_buckets.append([b])
                    found_l = len(layer_buckets)
                b['layer'] = found_l

        thep_grp_list = []
        for b in merged_bars:
            x0, x1 = b['x0'], b['x1']
            a_idx, lk_s, lv_s = 0, u'Neo vào gối', '30d'
            best_ks_l = -1
            best_d_l = 1e9
            for ks in range(n_sp + 1):
                sxL, sxR = sx0_cad[ks], sx0_cad[ks] + sups_meta[ks]['w']
                if sxL - 160.0 <= x0 <= sxR + 160.0:
                    dist_k = 0.0 if sxL <= x0 <= sxR else min(abs(x0 - sxL), abs(x0 - sxR))
                    if dist_k < best_d_l:
                        best_d_l = dist_k
                        best_ks_l = ks
            if best_ks_l >= 0:
                ks = best_ks_l
                sxL, sxR = sx0_cad[ks], sx0_cad[ks] + sups_meta[ks]['w']
                a_idx = ks
                if b['hl'] or (ks == 0 and b['pos'] == u'Trên') or (ks == 0 and b['pos'] == u'Dưới' and (sups_meta[ks]['w'] <= 0.5 or x0 <= sxL + max(80.0, sups_meta[ks]['w'] * 0.75))):
                    lk_s, lv_s = u'Gập vào cột', u'xuống'
                elif sups_meta[ks]['w'] > 0.5 and x0 <= sxL + 65.0:
                    lk_s, lv_s = u'Hết cột / đầu dầm', ''
                elif sups_meta[ks]['w'] > 0.5:
                    lk_s, lv_s = u'Neo vào gối', str(int(_round_cut_50(max(100.0, sxR - x0))))
                else:
                    lk_s, lv_s = u'Hết cột / đầu dầm', ''
            else:
                found_span_l = False
                for i_s, sp_m in enumerate(spans_meta):
                    if sp_m['fl_cad'] < x0 < sp_m['fr_cad']:
                        if x1 >= sp_m['fr_cad'] - 40.0 and (i_s + 1) <= n_sp and (sp_m['fr_cad'] - x0) <= sp_m['clear'] * 0.52:
                            a_idx = i_s + 1
                            lk_s = u'Kéo dài ra nhịp'
                            lv_s = str(int(_round_cut_50(sp_m['fr_cad'] - x0)))
                        else:
                            a_idx = i_s
                            lk_s = u'Cắt trong nhịp'
                            lv_s = str(int(_round_cut_50(x0 - sp_m['fl_cad'])))
                        found_span_l = True
                        break
                if not found_span_l and spans_meta and x0 <= spans_meta[0]['fl_cad'] + 180.0:
                    a_idx = 0
                    lk_s, lv_s = (u'Gập vào cột', u'xuống') if (b['hl'] or b['pos'] in (u'Trên', u'Dưới')) else (u'Hết cột / đầu dầm', '')
                elif found_span_l and a_idx == 0 and x0 <= spans_meta[0]['fl_cad'] + 180.0 and (b['hl'] or (b['pos'] == u'Trên' and lk_s != u'Kéo dài ra nhịp')):
                    lk_s, lv_s = u'Gập vào cột', u'xuống'

            b_idx, rk_s, rv_s = n_sp, u'Neo vào gối', '30d'
            best_ks_r = -1
            best_d_r = 1e9
            for ks in range(n_sp, -1, -1):
                sxL, sxR = sx0_cad[ks], sx0_cad[ks] + sups_meta[ks]['w']
                if sxL - 160.0 <= x1 <= sxR + 160.0:
                    dist_k = 0.0 if sxL <= x1 <= sxR else min(abs(x1 - sxL), abs(x1 - sxR))
                    if dist_k < best_d_r:
                        best_d_r = dist_k
                        best_ks_r = ks
            if best_ks_r >= 0:
                ks = best_ks_r
                sxL, sxR = sx0_cad[ks], sx0_cad[ks] + sups_meta[ks]['w']
                b_idx = ks
                if b['hr'] or (ks == n_sp and b['pos'] == u'Trên') or (ks == n_sp and b['pos'] == u'Dưới' and (sups_meta[ks]['w'] <= 0.5 or x1 >= sxR - max(80.0, sups_meta[ks]['w'] * 0.75))):
                    rk_s, rv_s = u'Gập vào cột', u'xuống'
                elif sups_meta[ks]['w'] > 0.5 and x1 >= sxR - 65.0:
                    rk_s, rv_s = u'Hết cột / đầu dầm', ''
                elif sups_meta[ks]['w'] > 0.5:
                    rk_s, rv_s = u'Neo vào gối', str(int(_round_cut_50(max(100.0, x1 - sxL))))
                else:
                    rk_s, rv_s = u'Hết cột / đầu dầm', ''
            else:
                found_span_r = False
                for i_s, sp_m in enumerate(spans_meta):
                    if sp_m['fl_cad'] < x1 < sp_m['fr_cad']:
                        if x0 <= sp_m['fl_cad'] + 40.0 and (x1 - sp_m['fl_cad']) <= sp_m['clear'] * 0.52:
                            b_idx = i_s
                            rk_s = u'Kéo dài ra nhịp'
                            rv_s = str(int(_round_cut_50(x1 - sp_m['fl_cad'])))
                        else:
                            b_idx = i_s + 1
                            rk_s = u'Cắt trong nhịp'
                            rv_s = str(int(_round_cut_50(sp_m['fr_cad'] - x1)))
                        found_span_r = True
                        break
                if not found_span_r and spans_meta and x1 >= spans_meta[-1]['fr_cad'] - 180.0:
                    b_idx = n_sp
                    rk_s, rv_s = (u'Gập vào cột', u'xuống') if (b['hr'] or b['pos'] in (u'Trên', u'Dưới')) else (u'Hết cột / đầu dầm', '')
                elif found_span_r and b_idx == n_sp and x1 >= spans_meta[-1]['fr_cad'] - 180.0 and (b['hr'] or (b['pos'] == u'Trên' and rk_s != u'Kéo dài ra nhịp')):
                    rk_s, rv_s = u'Gập vào cột', u'xuống'
            if b_idx < a_idx:
                b_idx = a_idx
            cross_str = u'Tự động'
            thep_grp_list.append([
                nm, '', b['pos'], b['layer'], b['qty'], b['d'],
                a_idx, lk_s, lv_s, b_idx, rk_s, rv_s, cross_str
            ])

        # Group-level Layer-1 main-bar continuity safeguard across multi-width spans
        if n_sp >= 2:
            for _mg_pass in range(max(4, n_sp * 4)):
                did_g_merge = False
                for ia in range(len(thep_grp_list)):
                    ga = thep_grp_list[ia]
                    if ga[4] <= 0 or ga[3] != 1 or ga[2] not in (u'Trên', u'Dưới'):
                        continue
                    if ga[7] == u'Cắt trong nhịp' or ga[10] == u'Cắt trong nhịp':
                        continue
                    if ga[7] == u'Kéo dài ra nhịp' and ga[10] == u'Kéo dài ra nhịp':
                        continue
                    k_join = ga[9]
                    if not (0 < k_join < n_sp):
                        continue
                    for ib in range(len(thep_grp_list)):
                        if ib == ia:
                            continue
                        gb = thep_grp_list[ib]
                        if gb[4] <= 0 or gb[3] != 1 or gb[2] != ga[2] or gb[5] != ga[5]:
                            continue
                        if gb[6] != k_join or gb[7] == u'Cắt trong nhịp' or gb[10] == u'Cắt trong nhịp':
                            continue
                        if gb[7] == u'Kéo dài ra nhịp' and gb[10] == u'Kéo dài ra nhịp':
                            continue
                        if gb[9] <= k_join:
                            continue
                        q_m = min(ga[4], gb[4])
                        ga[4] -= q_m
                        gb[4] -= q_m
                        thep_grp_list.append([
                            nm, '', ga[2], 1, q_m, ga[5],
                            ga[6], ga[7], ga[8], gb[9], gb[10], gb[11], u'Tự động'
                        ])
                        did_g_merge = True
                        break
                    if did_g_merge:
                        thep_grp_list[:] = [gr_ for gr_ in thep_grp_list if gr_[4] > 0]
                        break
                if not did_g_merge:
                    break

        sl_ck = sl_by_name.get(nm, 1)
        beam_lvl_z = items[0]['lvl_mm'] if items else level_z_mm
        beam_mat = next((it['mat'] for it in items if it.get('mat')), '')
        top_main = [b for b in merged_bars if b['pos'] == u'Trên' and b['layer'] == 1]
        bot_main = [b for b in merged_bars if b['pos'] == u'Dưới' and b['layer'] == 1]
        top_n = top_main[0]['qty'] if top_main else 2
        top_d = top_main[0]['d'] if top_main else 18
        bot_n = bot_main[0]['qty'] if bot_main else 2
        bot_d = bot_main[0]['d'] if bot_main else 18
        stir_specs = []
        for sp_m in spans_meta:
            if sp_m['stir'] not in stir_specs:
                stir_specs.append(sp_m['stir'])
        stir_disp = ' / '.join(u'Ø%s' % s for s in stir_specs[:2]) if stir_specs else u'Ø8-100/200'
        sl_pref = (u'SL: %d | ' % sl_ck) if sl_ck > 1 else ''
        if merged_bars:
            note = u'%sTrên %dØ%d · Dưới %dØ%d (%d thanh) · Đai %s' % (sl_pref, top_n, top_d, bot_n, bot_d, len(merged_bars), stir_disp)
        else:
            note = u'%sChưa có thép 3D (%dØ%d / %dØ%d) · Đai %s' % (sl_pref, top_n, top_d, bot_n, bot_d, stir_disp)
        first_sp = spans_meta[0]
        summaries.append((
            nm, n_sp, u'%d×%d' % (int(round(first_sp['bw'])), int(round(first_sp['bh']))),
            note, (top_n, top_d, bot_n, bot_d, spans_meta[0]['stir'])
        ))
        enriched_meta[nm] = {
            'sl': sl_ck, 'mat': beam_mat, 'level_z': beam_lvl_z, 'has_3d': bool(merged_bars),
            'sups': sups_meta, 'spans': spans_meta, 'thep': thep_grp_list
        }

    cover_mode_mm = max(set(cover_votes), key=cover_votes.count) if cover_votes else 30.0
    _collect_revit_model_data._last_cover_mm = cover_mode_mm
    conc_votes = [_norm_concrete_grade(m.get('mat', ''), '') for m in enriched_meta.values() if _norm_concrete_grade(m.get('mat', ''), '')]
    det_conc = max(set(conc_votes), key=conc_votes.count) if conc_votes else 'B25'
    det_steel = 'CB400-V'
    try:
        st_votes = []
        for lst_rb in rebar_by_host.values():
            for rb in lst_rb:
                rt = doc.GetElement(rb.GetTypeId())
                rtn = sstr(getattr(rt, 'Name', '') if rt is not None else '')
                if any(tok in rtn.upper() for tok in ('CB', '240', '300', '400', '500', 'AII', 'AIII', 'SD')):
                    st_votes.append(_norm_steel_grade(rtn, 'CB400-V'))
        if st_votes:
            det_steel = max(set(st_votes), key=st_votes.count)
    except Exception:
        pass
    _collect_revit_model_data._last_grades = {'concrete': det_conc, 'steel': det_steel}

    frames[:] = []
    sup_bbs[:] = []
    frame_bbs[:] = []
    floor_bbs[:] = []
    grid_items[:] = []
    rebar_by_host.clear()
    unhosted_rebars[:] = []
    raw_by_mark.clear()
    raw_grouped.clear()
    _gc.collect()
    _collect_revit_model_data._last_meta = enriched_meta
    return group_order, grouped, summaries, level_z_mm, doc_title, doc_dir


def _write_revit_cache_to_xlsx(group_order, grouped, summaries_map, level_z_mm, out_xlsx, rebar_by_host=None, doc=None, opt_override=None):
    if not group_order:
        raise ValueError(u'Không tìm thấy cấu kiện Dầm (Structural Framing) nào trong mô hình Revit.')
    meta_map = getattr(_collect_revit_model_data, '_last_meta', {}) or {}
    cover_mm = getattr(_collect_revit_model_data, '_last_cover_mm', 30.0) or 30.0
    grades = getattr(_collect_revit_model_data, '_last_grades', {}) or {}
    nhip_hdr = [
        'Tên dầm', 'SL', 'Nhịp', 'Vật liệu',
        'Gối trái (mm)', 'Loại GT', 'Trục T', 'Lệch trục T (mm)', 'L thông thủy (mm)', 'Cấu hình nhịp',
        'Gối phải (mm)', 'Loại GP', 'Trục P', 'Lệch trục P (mm)',
        'b (mm)', 'h (mm)', 'Cao đỉnh (mm)', 'h sàn (mm)', 'Sàn T dày (mm)', 'Sàn T đỉnh (mm)', 'Sàn P dày (mm)', 'Sàn P đỉnh (mm)',
    ]
    while len(nhip_hdr) < 35:
        if len(nhip_hdr) == 22:
            nhip_hdr.append(u'Cao độ tầng (mm)')
        elif len(nhip_hdr) == 26:
            nhip_hdr.append(u'Vai trò gối T')
        elif len(nhip_hdr) == 28:
            nhip_hdr.append(u'Vai trò gối P')
        elif len(nhip_hdr) == 29:
            nhip_hdr.append(u'Cột cấy (tên@vị trí@rộng)')
        elif len(nhip_hdr) == 34:
            nhip_hdr.append('Đai (Ø-a gối/a nhịp)')
        else:
            nhip_hdr.append('')
    nhip_rows = [nhip_hdr]
    thep_hdr = [
        'Tên dầm', 'Ghi chú', 'Vị trí', 'Lớp', 'SL', 'Phi', 'Gối A', 'Kiểu trái', 'Giá trị trái',
        'Gối B', 'Kiểu phải', 'Giá trị phải', 'Vượt gối'
    ]
    thep_rows = [thep_hdr]

    for bname in group_order:
        meta = meta_map.get(bname)
        if meta and meta.get('spans'):
            sups_m = meta['sups']
            spans_m = meta['spans']
            sl_val = max(1, int(meta.get('sl', 1) or 1))
            mat_val = sstr(meta.get('mat', '')) or grades.get('concrete', 'B25')
            blvl_val = round(num(meta.get('level_z', level_z_mm), level_z_mm), 1)
            for sp_i, sp_m in enumerate(spans_m, 1):
                supL, supR = sups_m[sp_i - 1], sups_m[sp_i]
                row = [''] * 35
                row[0] = bname; row[1] = sl_val; row[2] = sp_i; row[3] = mat_val
                row[4] = supL['w']; row[5] = supL['kind']; row[6] = supL['grid']; row[7] = supL['off']
                row[8] = sp_m['clear']
                row[10] = supR['w']; row[11] = supR['kind']; row[12] = supR['grid']; row[13] = supR['off']
                row[14] = sp_m['bw']; row[15] = sp_m['bh']; row[16] = sp_m['top']
                row[17] = max(sp_m['sbL'], sp_m['sbR'])
                row[18] = sp_m['sbL']; row[19] = sp_m['sbL_top']
                row[20] = sp_m['sbR']; row[21] = sp_m['sbR_top']
                row[22] = blvl_val
                if sp_m.get('planted'):
                    row[29] = ';'.join('%s@%d@%d' % (p['name'], int(round(p['pos'])), int(round(p['w']))) for p in sp_m['planted'])
                row[34] = sp_m['stir']
                nhip_rows.append(row)
            if meta.get('thep'):
                for tr_m in meta['thep']:
                    thep_rows.append(tr_m)
            else:
                s_info = summaries_map.get(bname, (2, 18, 2, 18, '8-100/200'))
                top_n, top_d, bot_n, bot_d = s_info[:4]
                n_sp = len(spans_m)
                thep_rows.append([bname, '', 'Trên', 1, top_n, top_d, 0, u'Gập vào cột', u'xuống', n_sp, u'Gập vào cột', u'xuống', u'Tự động'])
                thep_rows.append([bname, '', 'Dưới', 1, bot_n, bot_d, 0, u'Gập vào cột', u'xuống', n_sp, u'Gập vào cột', u'xuống', u'Tự động'])
        else:
            spans_el = grouped[bname]
            s_info = summaries_map.get(bname, (2, 18, 2, 18, '8-100/200'))
            top_n, top_d, bot_n, bot_d = s_info[:4]
            for sp_i, (_el_sp, bw, bh, clear_mm, top_z) in enumerate(spans_el, 1):
                row = [''] * 35
                row[0] = bname; row[1] = 1; row[2] = sp_i; row[3] = grades.get('concrete', 'B25')
                row[4] = 300.0; row[5] = 'C'; row[6] = str(sp_i); row[7] = 0.0; row[8] = clear_mm
                row[10] = 300.0; row[11] = 'C'; row[12] = str(sp_i + 1); row[13] = 0.0
                row[14] = bw; row[15] = bh; row[16] = top_z
                row[17] = 120.0; row[18] = 120.0; row[19] = top_z; row[20] = 120.0; row[21] = top_z
                row[22] = level_z_mm
                row[34] = '6-100/200' if bh <= 300.0 else '8-100/200'
                nhip_rows.append(row)
            n_sp = len(spans_el)
            thep_rows.append([bname, '', 'Trên', 1, top_n, top_d, 0, u'Gập vào cột', u'xuống', n_sp, u'Gập vào cột', u'xuống', u'Tự động'])
            thep_rows.append([bname, '', 'Dưới', 1, bot_n, bot_d, 0, u'Gập vào cột', u'xuống', n_sp, u'Gập vào cột', u'xuống', u'Tự động'])

    opt_eff = _default_beam_opt()
    opt_eff['cover'] = cover_mm
    if grades.get('concrete'):
        opt_eff['concrete'] = grades['concrete']
    if grades.get('steel'):
        opt_eff['steel'] = grades['steel']
    n_top_c, n_bot_c, lap_c = _calc_tcvn_anchorage(opt_eff['std'], opt_eff['concrete'], opt_eff['steel'])
    opt_eff['neo'] = n_top_c
    opt_eff['neo_top'] = n_top_c
    opt_eff['neo_bot'] = n_bot_c
    opt_eff['lap'] = lap_c
    if isinstance(opt_override, dict):
        opt_eff.update(opt_override)
    caidat_rows = [
        [u'Thông số', u'Giá trị'],
        [u'Tiêu chuẩn thiết kế', opt_eff.get('std', u'TCVN 5574:2018')],
        [u'Mác bê tông', opt_eff.get('concrete', 'B25')],
        [u'Nhóm thép chủ', opt_eff.get('steel', 'CB400-V')],
        [u'Chế độ neo thép', opt_eff.get('neo_mode', _NEO_MODES[0])],
        [u'Neo dầm chênh cốt', opt_eff.get('step_neo', _STEP_NEO_MODES[0])],
        [u'Lớp bảo vệ (mm)', opt_eff.get('cover', cover_mm)],
        [u'Chiều dài neo mặc định', opt_eff.get('neo', n_top_c)],
        [u'Chiều dài neo kéo (Trên)', opt_eff.get('neo_top', n_top_c)],
        [u'Chiều dài neo nén (Dưới)', opt_eff.get('neo_bot', n_bot_c)],
        [u'Chiều dài nối chồng', opt_eff.get('lap', lap_c)],
        [u'Chiều dài gập mặc định', opt_eff.get('gap', u'xuống')],
        [u'Kéo dài ra nhịp mặc định', opt_eff.get('ext', 'L/4')],
        [u'Cắt trong nhịp mặc định', opt_eff.get('cut', 'L/4')],
        [u'TC luôn gập vào cột', '1' if bool(opt_eff.get('tc_hook', 1.0)) else '0'],
    ]
    info_rows = [['Cao độ tầng theo Project Base Point (mm)', level_z_mm]]
    write_simple_xlsx(out_xlsx, [('Nhip', nhip_rows), ('Thep', thep_rows), ('CaiDat', caidat_rows), ('Info', info_rows)])
    return len(group_order)


def _extract_revit_beams_to_xlsx(out_xlsx):
    group_order, grouped, summaries, level_z_mm, _, _ = _collect_revit_model_data()
    smap = {s[0]: s[4] for s in summaries}
    return _write_revit_cache_to_xlsx(group_order, grouped, smap, level_z_mm, out_xlsx)


def _parse_rebar_quick_spec(spec_str, default_n=2, default_d=18, allow_zero=False):
    s = sstr(spec_str).strip()
    if not s or s in ('0', '-', u'Không', u'Khong', 'none', 'None'):
        return (0, default_d) if allow_zero else (default_n, default_d)
    m = re.match(u'^(\\d+)\\s*(?:ø|Ø|phi|d|t|f|x|\\*|-)?\\s*(\\d{1,2})$', s, re.I)
    if m:
        nv = int(m.group(1))
        dv = max(6, min(40, int(m.group(2))))
        if nv == 0:
            return (0, dv) if allow_zero else (default_n, dv)
        return max(1, min(20, nv)), dv
    m2 = re.search(u'(\\d+)\\s*(?:ø|Ø|phi|d|t|f|x|\\*|-)\\s*(\\d{1,2})', s, re.I)
    if m2:
        nv = int(m2.group(1))
        dv = max(6, min(40, int(m2.group(2))))
        if nv == 0 and allow_zero:
            return 0, dv
        return max(1, min(20, nv)), dv
    if re.match(r'^\d+$', s):
        val = int(s)
        if val == 0 and allow_zero:
            return 0, default_d
        if val >= 6:
            return default_n, max(6, min(40, val))
        return max(1, val), default_d
    return (0 if allow_zero else default_n), default_d


def _fmt_rebar_quick_spec(n, d):
    nv = int(round(num(n, 0)))
    dv = max(6, min(40, int(round(num(d, 18)))))
    if nv <= 0:
        return '0'
    return u'%dØ%d' % (nv, dv)


def _default_revit_section_rule(b_mm, h_mm, cover_mm=25.0):
    bw = max(80, int(round(num(b_mm, 200))))
    bh = max(80, int(round(num(h_mm, 400))))
    if bh <= 300:
        tn, td, bn, bd, sd = 2, 16, 2, 16, 6
    elif bh <= 500:
        tn, td, bn, bd, sd = 2, 18, 2, 18, 8
    elif bh < 700:
        tn, td, bn, bd, sd = 3, 20, 3, 20, 8
    else:
        tn, td, bn, bd, sd = 3, 22, 3, 22, 8
    mn, md = (2, 12) if bh >= 700 else (0, 12)
    cov = max(15, min(70, int(round(num(cover_mm, 25.0)))))
    return {
        'sec_key': '%dx%d' % (bw, bh),
        'b': bw, 'h': bh,
        'top_n': tn, 'top_d': td,
        'bot_n': bn, 'bot_d': bd,
        'mid_n': mn, 'mid_d': md,
        'stir_d': sd, 'stir_a1': 100, 'stir_a2': 200,
        'cover': cov,
        'beams': [],
    }


def _collect_unique_sections_from_rv(rv_order, meta_map=None, rv_grouped=None, cover_mm=25.0):
    meta_map = meta_map or {}
    rv_grouped = rv_grouped or {}
    sec_map = {}
    for bname in (rv_order or []):
        m = meta_map.get(bname)
        sp_pairs = []
        if m and m.get('spans'):
            sp_pairs = [(sp.get('bw', 200.0), sp.get('bh', 400.0)) for sp in m['spans']]
        elif bname in rv_grouped:
            sp_pairs = [(it[1], it[2]) for it in rv_grouped[bname]]
        for bw_f, bh_f in sp_pairs:
            bw_i = max(80, int(round(num(bw_f, 200.0))))
            bh_i = max(80, int(round(num(bh_f, 400.0))))
            sk = '%dx%d' % (bw_i, bh_i)
            if sk not in sec_map:
                sec_map[sk] = _default_revit_section_rule(bw_i, bh_i, cover_mm=cover_mm)
            if bname not in sec_map[sk]['beams']:
                sec_map[sk]['beams'].append(bname)
    sec_keys = sorted(sec_map.keys(), key=lambda k: (sec_map[k]['b'], sec_map[k]['h']))
    return sec_keys, sec_map


def _apply_section_rule_to_payload(pl, sec_rules, keep_existing_3d=False, m_rv=None):
    spans = pl.get('spans') or []
    if not spans:
        return False
    m_rv = m_rv or {}
    rv_spans = m_rv.get('spans') or []
    has_3d_long = bool(m_rv.get('has_3d'))

    span_rules = []
    for idx_s, sp in enumerate(spans):
        sk = '%dx%d' % (int(round(num(sp.get('b', 200.0)))), int(round(num(sp.get('h', 400.0)))))
        r_sec = sec_rules.get(sk)
        if r_sec is None:
            r_sec = _default_revit_section_rule(sp.get('b', 200.0), sp.get('h', 400.0))
        span_rules.append(r_sec)
        rv_has_st = (idx_s < len(rv_spans) and bool(rv_spans[idx_s].get('has_3d_stir')))
        if not (keep_existing_3d and rv_has_st):
            sd_v = max(6, min(14, int(round(num(r_sec.get('stir_d', 8), 8)))))
            a1_v = max(50, min(600, int(round(num(r_sec.get('stir_a1', 100), 100)))))
            a2_v = max(50, min(600, int(round(num(r_sec.get('stir_a2', 200), 200)))))
            sp['stir'] = '%d-%d/%d' % (sd_v, a1_v, a2_v)

    if not (keep_existing_3d and has_3d_long):
        dom_rule = max(span_rules, key=lambda r: (r.get('h', 400), r.get('top_n', 2) * (r.get('top_d', 18) ** 2)))
        if 'opt' not in pl or not isinstance(pl['opt'], dict):
            pl['opt'] = _default_beam_opt()
        pl['opt']['cover'] = max(10.0, min(80.0, num(dom_rule.get('cover', 25.0), 25.0)))
        sd_dom, _, _ = parse_stir_spec((spans[0] or {}).get('stir', '8-100/200'))
        pl['opt']['stir'] = float(sd_dom)

        n_sp = len(spans)
        all_same_h = (len(set(int(round(num(sp.get('h', 400.0)))) for sp in spans)) <= 1)
        new_grps = []
        for pos_s, nk, dk, lk_def, lv_def in (
            (u'Trên', 'top_n', 'top_d', u'Gập vào cột', u'xuống'),
            (u'Dưới', 'bot_n', 'bot_d', u'Gập vào cột', u'xuống'),
            (u'Giữa', 'mid_n', 'mid_d', u'Neo vào gối', '30d'),
        ):
            if all_same_h:
                best_r = max(span_rules, key=lambda r: int(r.get(nk, 0)) * (int(r.get(dk, 12)) ** 2))
                qn, qd = int(best_r.get(nk, 0)), int(best_r.get(dk, 18))
                if qn > 0:
                    new_grps.append({
                        'pos': pos_s, 'layer': 1, 'n': qn, 'd': qd,
                        'a': 0, 'lk': lk_def, 'lv': lv_def,
                        'b': n_sp, 'rk': lk_def, 'rv': lv_def,
                        'cross': u'Tự động', 'note': u'Tiết diện chung',
                    })
            else:
                runs = []
                for i_r, rr in enumerate(span_rules):
                    pair = (int(rr.get(nk, 0)), int(rr.get(dk, 18)))
                    if runs and runs[-1][0] == pair:
                        runs[-1][2] = i_r + 1
                    else:
                        runs.append([pair, i_r, i_r + 1])
                for (qn, qd), a_i, b_i in runs:
                    if qn <= 0:
                        continue
                    new_grps.append({
                        'pos': pos_s, 'layer': 1, 'n': qn, 'd': qd,
                        'a': a_i,
                        'lk': lk_def if a_i == 0 else u'Neo vào gối',
                        'lv': lv_def if a_i == 0 else '30d',
                        'b': b_i,
                        'rk': lk_def if b_i == n_sp else u'Neo vào gối',
                        'rv': lv_def if b_i == n_sp else '30d',
                        'cross': u'Tự động', 'note': u'Tiết diện chung',
                    })
        pl['grps'] = new_grps
    return True


def _apply_revit_section_rules_to_xlsx(xlsx_path, sec_rules, target_beams=None, keep_existing_3d=False, meta_map=None, return_wb=False):
    if not xlsx_path or not os.path.isfile(xlsx_path):
        return (0, {}) if return_wb else 0
    meta_map = meta_map or {}

    def _mut_sec(bname, pl):
        return _apply_section_rule_to_payload(pl, sec_rules, keep_existing_3d=keep_existing_3d, m_rv=meta_map.get(bname))

    updated, wb_out, _errs = _batch_update_xlsx_payloads(xlsx_path, target_beams, _mut_sec, xlsx_path)
    return (updated, wb_out) if return_wb else updated


_CAD_PROGS = (
    'AutoCAD.Application',
    'AutoCAD.Application.26.1',
    'AutoCAD.Application.26',
    'AutoCAD.Application.25.1',
    'AutoCAD.Application.25.0',
    'AutoCAD.Application.25',
    'AutoCAD.Application.24.3',
    'AutoCAD.Application.24.2',
    'AutoCAD.Application.24.1',
    'AutoCAD.Application.24',
    'AutoCAD.Application.23.1',
    'AutoCAD.Application.23',
    'AutoCAD.Application.22',
    'ZWCAD.Application',
    'GstarCAD.Application',
    'BricscadApp.AcadApplication',
)


def _com_get(obj, name):
    try:
        return getattr(obj, name)
    except Exception:
        from System.Reflection import BindingFlags
        return obj.GetType().InvokeMember(name, BindingFlags.GetProperty, None, obj, None)


def _com_set(obj, name, val):
    try:
        setattr(obj, name, val)
    except Exception:
        from System.Reflection import BindingFlags
        arr = System.Array[System.Object]([val])
        obj.GetType().InvokeMember(name, BindingFlags.SetProperty, None, obj, arr)


def _com_call(obj, name, *args):
    try:
        return getattr(obj, name)(*args)
    except Exception:
        from System.Reflection import BindingFlags
        arr = System.Array[System.Object](list(args)) if args else None
        return obj.GetType().InvokeMember(name, BindingFlags.InvokeMethod, None, obj, arr)


def _get_active_com_win32(prog, diag=None):
    """Lay Active COM object tren .NET 8 (Revit 2025 da bo Marshal.GetActiveObject) qua ole32 + oleaut32."""
    if Marshal is None or System is None:
        return None
    import ctypes

    class _GUID(ctypes.Structure):
        _fields_ = [
            ('Data1', ctypes.c_ulong),
            ('Data2', ctypes.c_ushort),
            ('Data3', ctypes.c_ushort),
            ('Data4', ctypes.c_ubyte * 8),
        ]

    ole32 = ctypes.windll.ole32
    oleaut32 = ctypes.windll.oleaut32
    ole32.CLSIDFromProgID.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(_GUID)]
    ole32.CLSIDFromProgID.restype = ctypes.c_long
    oleaut32.GetActiveObject.argtypes = [ctypes.POINTER(_GUID), ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    oleaut32.GetActiveObject.restype = ctypes.c_long

    clsid = _GUID()
    hr = ole32.CLSIDFromProgID(prog, ctypes.byref(clsid))
    if hr != 0:
        return None
    p_unk = ctypes.c_void_p()
    hr2 = oleaut32.GetActiveObject(ctypes.byref(clsid), None, ctypes.byref(p_unk))
    if hr2 != 0 or not p_unk.value:
        if diag is not None and prog == 'AutoCAD.Application':
            diag.append('GetActiveObject(%s)=0x%08X' % (prog, hr2 & 0xFFFFFFFF))
        return None
    try:
        ptr = System.IntPtr(System.Int64(ctypes.c_int64(p_unk.value).value))
    except Exception:
        ptr = System.IntPtr(p_unk.value)
    try:
        return Marshal.GetObjectForIUnknown(ptr)
    finally:
        try:
            Marshal.Release(ptr)
        except Exception:
            pass


def _bring_hwnd_front(hwnd):
    if not hwnd:
        return
    try:
        import ctypes
        user32 = ctypes.windll.user32
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, 9)   # SW_RESTORE
        user32.SetForegroundWindow(hwnd)
    except Exception:
        pass


def _bring_cad_process_front():
    try:
        from System.Diagnostics import Process
        for nm in ('acad', 'zwcad', 'gcad', 'bricscad'):
            procs = Process.GetProcessesByName(nm)
            for pr in procs:
                try:
                    h = int(pr.MainWindowHandle.ToInt64())
                    if h:
                        _bring_hwnd_front(h)
                        return h
                except Exception:
                    pass
    except Exception:
        pass
    return 0


def _build_inline_pick_lisp(dxf_path, prompt_label=u'ban ve dam'):
    drop_lsp = _write_cad_drop_lisp(dxf_path, prompt_label=prompt_label)
    return (
        u'(progn (if (findfile "%s") (load "%s") '
        u'(princ "\\n[BeamCAD] Khong tim thay file LISP: %s")) (princ))'
    ) % (drop_lsp, drop_lsp, drop_lsp)


def _send_via_powershell_sta(cmd):
    """Fallback qua Windows PowerShell 5.1 STA (khong dung Add-Type de chay nhanh < 0.5s)."""
    try:
        import base64
        import subprocess
        b64_cmd = base64.b64encode(cmd.encode('utf-8')).decode('ascii')
        progs_ps = ', '.join("'%s'" % p for p in _CAD_PROGS)
        ps_code = (
            "$ErrorActionPreference='Stop';"
            "$progs=@(" + progs_ps + ");"
            "$acad=$null;"
            "foreach($p in $progs){ try { $acad=[Runtime.InteropServices.Marshal]::GetActiveObject($p); if($acad -ne $null){break} } catch {} };"
            "if($acad -eq $null){ exit 2 };"
            "try{ $acad.Visible=$true }catch{};"
            "$c=[System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String('" + b64_cmd + "'));"
            "$ok=$false;"
            "for($i=0;$i -lt 3;$i++){ try{ $acad.ActiveDocument.SendCommand($c); $ok=$true; break } catch { Start-Sleep -Milliseconds 200 } };"
            "if(-not $ok){ exit 3 };"
            "$h=0; try{ $h=[int64]$acad.HWND }catch{};"
            "Write-Output ('OK:'+$h)"
        )
        encoded = base64.b64encode(ps_code.encode('utf-16le')).decode('ascii')
        ps_exe = os.path.join(os.environ.get('SystemRoot', r'C:\Windows'), 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
        if not os.path.isfile(ps_exe):
            ps_exe = 'powershell.exe'
        cf = getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)
        p = subprocess.Popen(
            [ps_exe, '-NoProfile', '-NonInteractive', '-STA', '-EncodedCommand', encoded],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=cf,
        )
        out, _err = p.communicate(timeout=5)
        if p.returncode == 0 and b'OK:' in (out or b''):
            try:
                txt = out.decode('ascii', 'ignore')
                m = re.search(r'OK:(\d+)', txt)
                if m and int(m.group(1)) > 0:
                    _bring_hwnd_front(int(m.group(1)))
                else:
                    _bring_cad_process_front()
            except Exception:
                _bring_cad_process_front()
            return True
    except Exception:
        pass
    return False


def _is_cad_process_running():
    try:
        from System.Diagnostics import Process
        for nm in ('acad', 'zwcad', 'gcad', 'bricscad'):
            if len(Process.GetProcessesByName(nm)) > 0:
                return True
    except Exception:
        pass
    return False


def _release_com_rcw(obj):
    if obj is None or Marshal is None:
        return
    try:
        if Marshal.IsComObject(obj):
            Marshal.FinalReleaseComObject(obj)
    except Exception:
        pass


def _send_cad_command(cmd):
    acad = None
    doc = None
    try:
        # 1) .NET Framework 4.8 (Revit <= 2024)
        if Marshal is not None and hasattr(Marshal, 'GetActiveObject'):
            for prog in _CAD_PROGS:
                try:
                    acad = Marshal.GetActiveObject(prog)
                    if acad is not None:
                        break
                except Exception:
                    acad = None

        diag = []
        # 2) .NET 8 (Revit 2025 + pyRevit 7): goi truc tiep ole32/oleaut32 GetActiveObject + GetObjectForIUnknown
        if acad is None:
            for prog in _CAD_PROGS:
                try:
                    acad = _get_active_com_win32(prog, diag)
                    if acad is not None:
                        break
                except Exception as ex_com:
                    diag.append('win32:%s' % sstr(ex_com))
                    acad = None

        # 3) Python win32com neu may co cai pywin32
        if acad is None:
            try:
                import win32com.client
                for prog in _CAD_PROGS:
                    try:
                        acad = win32com.client.GetActiveObject(prog)
                        if acad is not None:
                            break
                    except Exception:
                        acad = None
            except Exception:
                pass

        if acad is not None:
            for _attempt in range(3):
                try:
                    try:
                        _com_set(acad, 'Visible', True)
                    except Exception:
                        pass
                    try:
                        _bring_hwnd_front(int(_com_get(acad, 'HWND')))
                    except Exception:
                        _bring_cad_process_front()
                    doc = _com_get(acad, 'ActiveDocument')
                    if doc is not None:
                        _com_call(doc, 'SendCommand', cmd)
                        return True, 'OK'
                except Exception as ex_send:
                    diag.append('Send:%s' % sstr(ex_send))
                    _release_com_rcw(doc)
                    doc = None
                    time.sleep(0.15)
    finally:
        _release_com_rcw(doc)
        _release_com_rcw(acad)

    # 4) Fallback qua Windows PowerShell 5.1 STA (tuong thich chuan IDispatch, khong Add-Type)
    if _send_via_powershell_sta(cmd):
        return True, 'OK'

    if _is_cad_process_running():
        diag_txt = ('\nChi tiết kỹ thuật: ' + '; '.join(diag[:3])) if diag else ''
        return False, (
            u'Đã thấy AutoCAD đang chạy nhưng Windows chặn kết nối COM.\n'
            u'Lưu ý: Nếu AutoCAD đang chạy quyền Administrator (Elevated = Yes), '
            u'Windows/AutoCAD sẽ KHÔNG đăng ký COM để nhận lệnh tự động (kể cả khi Revit cũng là Yes).'
            + diag_txt
        )
    return False, u'Không tìm thấy AutoCAD đang mở.'


def _send_dxf_to_open_autocad_dotnet(dxf_path, prompt_label=u'ban ve dam'):
    cmd = u'\x03\x03' + _build_inline_pick_lisp(dxf_path, prompt_label) + u' \n'
    return _send_cad_command(cmd)


def _is_valid_enabled_hwnd(hwnd_val):
    if not hwnd_val:
        return False
    try:
        import ctypes
        user32 = ctypes.windll.user32
        return bool(user32.IsWindow(hwnd_val) and user32.IsWindowVisible(hwnd_val) and user32.IsWindowEnabled(hwnd_val))
    except Exception:
        return False


def _resolve_safe_owner_window():
    if WinForms is None or System is None:
        return None
    try:
        af = WinForms.Form.ActiveForm
        if af is not None and not af.IsDisposed:
            h_af = int(af.Handle.ToInt64())
            if _is_valid_enabled_hwnd(h_af):
                return af
    except Exception:
        pass

    cand_hwnds = []
    try:
        import ctypes
        from System.Diagnostics import Process
        user32 = ctypes.windll.user32
        cur_pid = int(Process.GetCurrentProcess().Id)
        h_act = user32.GetActiveWindow()
        if h_act:
            pid = ctypes.c_ulong(0)
            user32.GetWindowThreadProcessId(h_act, ctypes.byref(pid))
            if int(pid.value) == cur_pid:
                cand_hwnds.append(int(h_act))
    except Exception:
        pass

    try:
        if '__revit__' in globals():
            h_rv = __revit__.MainWindowHandle
            if h_rv:
                cand_hwnds.append(int(h_rv.ToInt64()))
    except Exception:
        pass
    try:
        from System.Diagnostics import Process
        h_pr = Process.GetCurrentProcess().MainWindowHandle
        if h_pr:
            cand_hwnds.append(int(h_pr.ToInt64()))
    except Exception:
        pass

    for hv in cand_hwnds:
        if hv and _is_valid_enabled_hwnd(hv):
            try:
                class _RevitWin32Owner(WinForms.IWin32Window):
                    __namespace__ = 'BeamCAD_RevitOwner'

                    def __init__(self, h):
                        self._h = System.IntPtr(h)

                    @property
                    def Handle(self):
                        return self._h

                return _RevitWin32Owner(hv)
            except Exception:
                return None
    return None



def run_revit_export():
    if WinForms is None:
        return
    try:
        WinForms.Application.EnableVisualStyles()
    except Exception:
        pass

    rv_order, rv_grouped, rv_summaries, rv_lvl, doc_title, doc_dir = _collect_revit_model_data(scan_scope='view')
    rv_meta = dict(getattr(_collect_revit_model_data, '_last_meta', None) or {})
    rv_smap = {s[0]: s[4] for s in rv_summaries}
    rv_scope_note = getattr(_collect_revit_model_data, '_last_scope_note', '') or u'Mặt bằng đang mở'
    view_cfg = dict(getattr(_collect_revit_model_data, '_last_view_cfg', None) or _read_revit_view_scales())

    form = WinForms.Form()
    form.Text = u'BeamCAD — Triển khai Thép Dầm & Thống Kê AutoCAD'
    form.ClientSize = Drawing.Size(1280, 860)
    form.MinimumSize = Drawing.Size(1140, 760)
    form.StartPosition = WinForms.FormStartPosition.CenterScreen
    form.FormBorderStyle = WinForms.FormBorderStyle.Sizable
    form.MaximizeBox = True
    form.MinimizeBox = True
    form.ShowInTaskbar = False
    form.BackColor = Drawing.Color.White
    form.Font = Drawing.Font('Segoe UI', 9.75)

    c_slate900 = Drawing.Color.FromArgb(15, 23, 42)
    c_slate600 = Drawing.Color.FromArgb(71, 85, 105)
    c_slate100 = Drawing.Color.FromArgb(248, 250, 252)
    c_border = Drawing.Color.FromArgb(226, 232, 240)
    c_blue = Drawing.Color.FromArgb(29, 78, 216)
    c_amber = Drawing.Color.FromArgb(180, 83, 9)
    c_btn_blue = Drawing.Color.FromArgb(66, 133, 244)
    c_emerald = Drawing.Color.FromArgb(5, 150, 105)

    def _mk_tlp(cols, rows, pad=None, bg=None):
        t = WinForms.TableLayoutPanel()
        t.Dock = WinForms.DockStyle.Fill
        t.ColumnCount = len(cols)
        t.RowCount = len(rows)
        t.Margin = WinForms.Padding(0)
        if pad is not None:
            t.Padding = pad
        if bg is not None:
            t.BackColor = bg
        for st_t, val_t in cols:
            t.ColumnStyles.Add(WinForms.ColumnStyle(st_t, float(val_t)))
        for st_r, val_r in rows:
            t.RowStyles.Add(WinForms.RowStyle(st_r, float(val_r)))
        return t

    def _mk_tb_btn(txt, x, w, bg, fg=c_slate900, bold=True, y=1, h=30, fsz=9.25):
        b = WinForms.Button()
        b.Text = txt
        b.UseMnemonic = False
        b.Location = Drawing.Point(x, y)
        b.Size = Drawing.Size(w, h)
        b.FlatStyle = WinForms.FlatStyle.Flat
        b.BackColor = bg
        b.ForeColor = fg
        b.Margin = WinForms.Padding(0, 1, 6, 1)
        b.Font = Drawing.Font('Segoe UI', fsz, Drawing.FontStyle.Bold if bold else Drawing.FontStyle.Regular)
        return b

    def _rl(txt, x=0, y=0, bold=False, fg=c_slate900, fsz=9.25):
        lb = WinForms.Label()
        lb.UseMnemonic = False
        lb.Text = txt
        lb.Location = Drawing.Point(x, y + 2)
        lb.AutoSize = True
        lb.ForeColor = fg
        lb.Margin = WinForms.Padding(6, 6, 3, 2)
        lb.Font = Drawing.Font('Segoe UI', fsz, Drawing.FontStyle.Bold if bold else Drawing.FontStyle.Regular)
        return lb

    def _rtb(x=0, y=0, w=48, val='', fsz=9.5):
        t = WinForms.TextBox()
        t.Location = Drawing.Point(x, y)
        t.Size = Drawing.Size(w, 25)
        t.Margin = WinForms.Padding(0, 3, 8, 2)
        t.Font = Drawing.Font('Consolas', fsz, Drawing.FontStyle.Bold)
        t.TextAlign = WinForms.HorizontalAlignment.Center
        t.Text = sstr(val)
        return t

    def _mk_cbo(items, cur_val='', w=140, editable=False, fsz=9.25):
        cb = WinForms.ComboBox()
        cb.DropDownStyle = WinForms.ComboBoxStyle.DropDown if editable else WinForms.ComboBoxStyle.DropDownList
        cb.Size = Drawing.Size(w, 26)
        cb.Margin = WinForms.Padding(0, 2, 8, 2)
        cb.Font = Drawing.Font('Consolas' if editable else 'Segoe UI', fsz, Drawing.FontStyle.Bold if editable else Drawing.FontStyle.Regular)
        for _it in items:
            cb.Items.Add(_it)
        if cur_val:
            cb.Text = cur_val
            if not editable and cb.SelectedIndex < 0 and cb.Items.Count > 0:
                cb.SelectedIndex = 0
        elif cb.Items.Count > 0 and not editable:
            cb.SelectedIndex = 0
        return cb

    # Root responsive TableLayoutPanel (scales smoothly to Full Screen)
    tlp_root = _mk_tlp(
        [(WinForms.SizeType.Percent, 100)],
        [
            (WinForms.SizeType.Absolute, 58),   # 0: Header
            (WinForms.SizeType.Percent, 100),   # 1: Main Tabs (Revit / Excel)
            (WinForms.SizeType.Absolute, 110),  # 2: 3. Neo / Kéo / Tiêu chuẩn
            (WinForms.SizeType.Absolute, 86),   # 3: 4. Tỉ lệ bản vẽ & Quy cách
            (WinForms.SizeType.Absolute, 28),   # 4: Status bar
            (WinForms.SizeType.Absolute, 60),   # 5: Footer actions
        ],
        pad=WinForms.Padding(0),
        bg=Drawing.Color.White,
    )
    form.Controls.Add(tlp_root)

    # 0. Header
    pnl_hdr = _mk_tlp(
        [(WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 152)],
        [(WinForms.SizeType.Percent, 100)],
        pad=WinForms.Padding(14, 6, 14, 6),
        bg=c_slate100,
    )
    pnl_hdr_txt = _mk_tlp(
        [(WinForms.SizeType.Percent, 100)],
        [(WinForms.SizeType.Percent, 54), (WinForms.SizeType.Percent, 46)],
        bg=c_slate100,
    )
    lbl_title = WinForms.Label()
    lbl_title.UseMnemonic = False
    lbl_title.Dock = WinForms.DockStyle.Fill
    lbl_title.Text = u'BeamCAD — Triển khai Thép Dầm & Thống Kê AutoCAD'
    lbl_title.Font = Drawing.Font('Segoe UI', 12.25, Drawing.FontStyle.Bold)
    lbl_title.ForeColor = c_slate900
    lbl_title.TextAlign = Drawing.ContentAlignment.MiddleLeft

    lbl_sub = WinForms.Label()
    lbl_sub.UseMnemonic = False
    lbl_sub.Dock = WinForms.DockStyle.Fill
    lbl_sub.AutoEllipsis = True
    lbl_sub.Text = u'2 bên trực quan: [Bên trái: Đầy đủ] ⇄ [Bên phải: Chỉ mặt cắt] · Tick [✓ Vẽ] những dầm nào thì vẽ dầm đó · Hỗ trợ TCVN Neo/Kéo'
    lbl_sub.Font = Drawing.Font('Segoe UI', 9.0)
    lbl_sub.ForeColor = c_slate600
    lbl_sub.TextAlign = Drawing.ContentAlignment.MiddleLeft

    pnl_hdr_txt.Controls.Add(lbl_title, 0, 0)
    pnl_hdr_txt.Controls.Add(lbl_sub, 0, 1)

    btn_help = _mk_tb_btn(u'? Hướng dẫn', 0, 138, Drawing.Color.FromArgb(239, 246, 255), c_blue, True, 0, 36, 9.5)
    btn_help.Anchor = WinForms.AnchorStyles.Right
    pnl_hdr.Controls.Add(pnl_hdr_txt, 0, 0)
    pnl_hdr.Controls.Add(btn_help, 1, 0)
    tlp_root.Controls.Add(pnl_hdr, 0, 0)

    # 1. Separated 2-Tab Workspace (1. Revit | 2. Excel)
    pnl_tabs_pad = WinForms.Panel()
    pnl_tabs_pad.Dock = WinForms.DockStyle.Fill
    pnl_tabs_pad.Padding = WinForms.Padding(10, 6, 10, 4)
    main_tabs = WinForms.TabControl()
    main_tabs.Dock = WinForms.DockStyle.Fill
    main_tabs.Font = Drawing.Font('Segoe UI', 10.0, Drawing.FontStyle.Bold)

    tab_revit = WinForms.TabPage(u'  1. Quét trực tiếp Mặt bằng Revit  ')
    tab_revit.BackColor = Drawing.Color.White
    tab_revit.Font = Drawing.Font('Segoe UI', 9.75)

    tab_excel = WinForms.TabPage(u'  2. Nhập từ Excel BeamRebar (.xlsx)  ')
    tab_excel.BackColor = Drawing.Color.White
    tab_excel.Font = Drawing.Font('Segoe UI', 9.75)

    main_tabs.TabPages.Add(tab_revit)
    main_tabs.TabPages.Add(tab_excel)
    pnl_tabs_pad.Controls.Add(main_tabs)
    tlp_root.Controls.Add(pnl_tabs_pad, 0, 1)

    # Shared MC config state & UI registry (synchronized across Tab 1 and Tab 2 inline panes)
    mc_cfg_state = {
        'sd': '8', 'a1': '100', 'a2': '200', 'uni': False, 'cov': '25',
        'sync_main': False, 'tn': '2', 'td': '18', 'bn': '2', 'bd': '18', 'mn': '0', 'md': '12',
    }
    mc_widgets = {}
    split_views = {}
    mc_syncing = {'busy': False}

    def _build_split_beam_workspace(parent, tab_kind):
        pnl_wrap = _mk_tlp(
            [(WinForms.SizeType.Percent, 100)],
            [(WinForms.SizeType.Absolute, 40), (WinForms.SizeType.Percent, 100)],
            pad=WinForms.Padding(0),
            bg=Drawing.Color.White,
        )

        # Top selection + search bar
        pnl_bar = _mk_tlp(
            [(WinForms.SizeType.Percent, 60), (WinForms.SizeType.Percent, 40)],
            [(WinForms.SizeType.Percent, 100)],
            pad=WinForms.Padding(6, 4, 8, 4),
            bg=c_slate100,
        )
        flp_bar_l = WinForms.FlowLayoutPanel()
        flp_bar_l.Dock = WinForms.DockStyle.Fill
        flp_bar_l.FlowDirection = WinForms.FlowDirection.LeftToRight
        flp_bar_l.WrapContents = False
        flp_bar_l.Margin = WinForms.Padding(0)

        lbl_q = _rl(u'Tìm dầm:', 0, 0, True, c_slate900, 9.25)
        txt_search = WinForms.TextBox()
        txt_search.Size = Drawing.Size(136, 25)
        txt_search.Margin = WinForms.Padding(0, 3, 8, 0)
        txt_search.Font = Drawing.Font('Segoe UI', 9.5)

        btn_sel_all = _mk_tb_btn(u'☑ Chọn cả (Vẽ tất cả)', 0, 174, Drawing.Color.FromArgb(219, 234, 254), c_blue, True, 0, 28, 9.0)
        btn_sel_none = _mk_tb_btn(u'☐ Bỏ chọn hết', 0, 126, Drawing.Color.White, c_slate900, False, 0, 28, 9.0)
        btn_edit = _mk_tb_btn(u'✎ Sửa chi tiết dầm', 0, 152, Drawing.Color.FromArgb(236, 253, 245), Drawing.Color.FromArgb(4, 120, 87), True, 0, 28, 9.0)
        for _c in (lbl_q, txt_search, btn_sel_all, btn_sel_none, btn_edit):
            flp_bar_l.Controls.Add(_c)

        lbl_count = WinForms.Label()
        lbl_count.UseMnemonic = False
        lbl_count.Dock = WinForms.DockStyle.Fill
        lbl_count.Text = u'Chọn vẽ: 0 / 0 dầm (Đầy đủ: 0 · Chỉ MC: 0)'
        lbl_count.TextAlign = Drawing.ContentAlignment.MiddleRight
        lbl_count.ForeColor = c_blue
        lbl_count.Font = Drawing.Font('Segoe UI', 9.25, Drawing.FontStyle.Bold)

        pnl_bar.Controls.Add(flp_bar_l, 0, 0)
        pnl_bar.Controls.Add(lbl_count, 1, 0)
        pnl_wrap.Controls.Add(pnl_bar, 0, 0)

        # 50% Left [FULL] / 50% Right [MC_ONLY]
        tlp_panes = _mk_tlp(
            [(WinForms.SizeType.Percent, 50), (WinForms.SizeType.Absolute, 8), (WinForms.SizeType.Percent, 50)],
            [(WinForms.SizeType.Percent, 100)],
            pad=WinForms.Padding(0, 4, 0, 0),
        )

        # LEFT PANE: FULL BEAMS (Docked TableLayout inside GroupBox respects DisplayRectangle cleanly)
        grp_full = WinForms.GroupBox()
        grp_full.Dock = WinForms.DockStyle.Fill
        grp_full.Text = u'BÊN TRÁI — DẦM VẼ [ĐẦY ĐỦ] (0)'
        grp_full.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold)
        grp_full.ForeColor = Drawing.Color.FromArgb(6, 95, 70)
        grp_full.Padding = WinForms.Padding(8, 6, 8, 8)

        tlp_full = _mk_tlp(
            [(WinForms.SizeType.Percent, 100)],
            [(WinForms.SizeType.Absolute, 36), (WinForms.SizeType.Percent, 100)],
        )
        tlp_full_bar = _mk_tlp(
            [(WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 162)],
            [(WinForms.SizeType.Percent, 100)],
            pad=WinForms.Padding(0, 2, 0, 4),
        )
        flp_full_l = WinForms.FlowLayoutPanel()
        flp_full_l.Dock = WinForms.DockStyle.Fill
        flp_full_l.WrapContents = False
        flp_full_l.Margin = WinForms.Padding(0)
        btn_f_all = _mk_tb_btn(u'☑ Vẽ hết', 0, 92, Drawing.Color.FromArgb(236, 253, 245), Drawing.Color.FromArgb(4, 120, 87), True, 0, 28, 8.75)
        btn_f_none = _mk_tb_btn(u'☐ Bỏ vẽ', 0, 86, Drawing.Color.White, c_slate900, False, 0, 28, 8.75)
        flp_full_l.Controls.Add(btn_f_all)
        flp_full_l.Controls.Add(btn_f_none)
        btn_f_to_mc = _mk_tb_btn(u'Chuyển → Chỉ MC', 0, 158, Drawing.Color.FromArgb(254, 243, 199), Drawing.Color.FromArgb(146, 64, 14), True, 0, 28, 8.75)
        btn_f_to_mc.Anchor = WinForms.AnchorStyles.Right
        tlp_full_bar.Controls.Add(flp_full_l, 0, 0)
        tlp_full_bar.Controls.Add(btn_f_to_mc, 1, 0)

        dgv_full = WinForms.DataGridView()
        dgv_full.Dock = WinForms.DockStyle.Fill
        dgv_full.AllowUserToAddRows = False
        dgv_full.AllowUserToDeleteRows = False
        dgv_full.AllowUserToResizeRows = False
        dgv_full.RowHeadersVisible = False
        dgv_full.SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect
        dgv_full.MultiSelect = True
        dgv_full.BackgroundColor = Drawing.Color.White
        dgv_full.Font = Drawing.Font('Segoe UI', 9.5)
        dgv_full.RowTemplate.Height = 28
        dgv_full.ColumnHeadersHeight = 32
        dgv_full.ColumnHeadersHeightSizeMode = WinForms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing

        c_f_chk = WinForms.DataGridViewCheckBoxColumn(); c_f_chk.HeaderText = u'Vẽ'; c_f_chk.Width = 42
        c_f_nm = WinForms.DataGridViewTextBoxColumn(); c_f_nm.HeaderText = u'Tên dầm'; c_f_nm.Width = 104; c_f_nm.ReadOnly = True
        c_f_sec = WinForms.DataGridViewTextBoxColumn(); c_f_sec.HeaderText = u'Tiết diện'; c_f_sec.Width = 110; c_f_sec.ReadOnly = True
        c_f_det = WinForms.DataGridViewTextBoxColumn(); c_f_det.HeaderText = u'Thép / Đai gốc'; c_f_det.MinimumWidth = 160; c_f_det.AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill; c_f_det.ReadOnly = True
        c_f_mv = WinForms.DataGridViewCheckBoxColumn(); c_f_mv.HeaderText = u'Chỉ MC →'; c_f_mv.Width = 76
        for _col in (c_f_chk, c_f_nm, c_f_sec, c_f_det, c_f_mv):
            _col.SortMode = WinForms.DataGridViewColumnSortMode.NotSortable
            dgv_full.Columns.Add(_col)

        tlp_full.Controls.Add(tlp_full_bar, 0, 0)
        tlp_full.Controls.Add(dgv_full, 0, 1)
        grp_full.Controls.Add(tlp_full)
        tlp_panes.Controls.Add(grp_full, 0, 0)

        # RIGHT PANE: MC_ONLY BEAMS + INLINE SETUP PANEL
        grp_mc = WinForms.GroupBox()
        grp_mc.Dock = WinForms.DockStyle.Fill
        grp_mc.Text = u'BÊN PHẢI — DẦM VẼ [CHỈ MẶT CẮT] (0)'
        grp_mc.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold)
        grp_mc.ForeColor = c_amber
        grp_mc.Padding = WinForms.Padding(8, 6, 8, 8)

        tlp_mc = _mk_tlp(
            [(WinForms.SizeType.Percent, 100)],
            [(WinForms.SizeType.Absolute, 36), (WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 158)],
        )
        tlp_mc_bar = _mk_tlp(
            [(WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 174)],
            [(WinForms.SizeType.Percent, 100)],
            pad=WinForms.Padding(0, 2, 0, 4),
        )
        flp_mc_l = WinForms.FlowLayoutPanel()
        flp_mc_l.Dock = WinForms.DockStyle.Fill
        flp_mc_l.WrapContents = False
        flp_mc_l.Margin = WinForms.Padding(0)
        btn_m_all = _mk_tb_btn(u'☑ Vẽ hết', 0, 92, Drawing.Color.FromArgb(254, 243, 199), c_amber, True, 0, 28, 8.75)
        btn_m_none = _mk_tb_btn(u'☐ Bỏ vẽ', 0, 86, Drawing.Color.White, c_slate900, False, 0, 28, 8.75)
        flp_mc_l.Controls.Add(btn_m_all)
        flp_mc_l.Controls.Add(btn_m_none)
        btn_m_to_full = _mk_tb_btn(u'← Chuyển về Đầy đủ', 0, 170, Drawing.Color.FromArgb(209, 250, 229), Drawing.Color.FromArgb(6, 95, 70), True, 0, 28, 8.75)
        btn_m_to_full.Anchor = WinForms.AnchorStyles.Right
        tlp_mc_bar.Controls.Add(flp_mc_l, 0, 0)
        tlp_mc_bar.Controls.Add(btn_m_to_full, 1, 0)

        dgv_mc = WinForms.DataGridView()
        dgv_mc.Dock = WinForms.DockStyle.Fill
        dgv_mc.AllowUserToAddRows = False
        dgv_mc.AllowUserToDeleteRows = False
        dgv_mc.AllowUserToResizeRows = False
        dgv_mc.RowHeadersVisible = False
        dgv_mc.SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect
        dgv_mc.MultiSelect = True
        dgv_mc.BackgroundColor = Drawing.Color.White
        dgv_mc.Font = Drawing.Font('Segoe UI', 9.5)
        dgv_mc.RowTemplate.Height = 28
        dgv_mc.ColumnHeadersHeight = 32
        dgv_mc.ColumnHeadersHeightSizeMode = WinForms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing

        c_m_chk = WinForms.DataGridViewCheckBoxColumn(); c_m_chk.HeaderText = u'Vẽ'; c_m_chk.Width = 42
        c_m_nm = WinForms.DataGridViewTextBoxColumn(); c_m_nm.HeaderText = u'Tên dầm'; c_m_nm.Width = 104; c_m_nm.ReadOnly = True
        c_m_sec = WinForms.DataGridViewTextBoxColumn(); c_m_sec.HeaderText = u'Tiết diện'; c_m_sec.Width = 110; c_m_sec.ReadOnly = True
        c_m_det = WinForms.DataGridViewTextBoxColumn(); c_m_det.HeaderText = u'Đai / Thép MC'; c_m_det.MinimumWidth = 160; c_m_det.AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill; c_m_det.ReadOnly = True
        c_m_mv = WinForms.DataGridViewCheckBoxColumn(); c_m_mv.HeaderText = u'← Đầy đủ'; c_m_mv.Width = 76
        for _col in (c_m_chk, c_m_nm, c_m_sec, c_m_det, c_m_mv):
            _col.SortMode = WinForms.DataGridViewColumnSortMode.NotSortable
            dgv_mc.Columns.Add(_col)

        pnl_mc_set = WinForms.Panel()
        pnl_mc_set.Dock = WinForms.DockStyle.Fill
        pnl_mc_set.Margin = WinForms.Padding(0, 6, 0, 0)
        pnl_mc_set.BackColor = Drawing.Color.FromArgb(255, 247, 237)
        pnl_mc_set.BorderStyle = WinForms.BorderStyle.FixedSingle

        tlp_mcs = _mk_tlp(
            [(WinForms.SizeType.Percent, 100)],
            [
                (WinForms.SizeType.Absolute, 26),
                (WinForms.SizeType.Absolute, 36),
                (WinForms.SizeType.Absolute, 26),
                (WinForms.SizeType.Absolute, 34),
                (WinForms.SizeType.Absolute, 20),
            ],
            pad=WinForms.Padding(6, 2, 6, 2),
        )
        tlp_mcs_r0 = _mk_tlp(
            [(WinForms.SizeType.Percent, 72), (WinForms.SizeType.Percent, 28)],
            [(WinForms.SizeType.Percent, 100)],
        )
        lbl_ms_hdr = _rl(u'⚙ Setup [Chỉ mặt cắt] (lấy ngay khi đẩy sang phải):', 0, 0, True, Drawing.Color.FromArgb(154, 52, 18), 8.75)
        lbl_ms_hdr.Dock = WinForms.DockStyle.Fill
        lbl_ms_hdr.Margin = WinForms.Padding(0)
        lbl_ms_hdr.TextAlign = Drawing.ContentAlignment.MiddleLeft
        lbl_ms_prev = _rl(u'Ø8a100/200', 0, 0, True, c_emerald, 9.25)
        lbl_ms_prev.AutoSize = False
        lbl_ms_prev.Dock = WinForms.DockStyle.Fill
        lbl_ms_prev.Margin = WinForms.Padding(0)
        lbl_ms_prev.TextAlign = Drawing.ContentAlignment.MiddleRight
        tlp_mcs_r0.Controls.Add(lbl_ms_hdr, 0, 0)
        tlp_mcs_r0.Controls.Add(lbl_ms_prev, 1, 0)

        tlp_mcs_r1 = _mk_tlp(
            [(WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 148)],
            [(WinForms.SizeType.Percent, 100)],
        )
        flp_mcs_r1 = WinForms.FlowLayoutPanel()
        flp_mcs_r1.Dock = WinForms.DockStyle.Fill
        flp_mcs_r1.WrapContents = False
        flp_mcs_r1.Margin = WinForms.Padding(0)

        cbo_sd = _mk_cbo(('6', '8', '10', '12'), mc_cfg_state['sd'], w=48, editable=True, fsz=9.25)
        tb_a1 = _rtb(0, 0, 44, mc_cfg_state['a1'], 9.25)
        tb_a2 = _rtb(0, 0, 44, mc_cfg_state['a2'], 9.25)
        chk_uni = WinForms.CheckBox()
        chk_uni.UseMnemonic = False
        chk_uni.Text = u'Đai đều'
        chk_uni.AutoSize = True
        chk_uni.Margin = WinForms.Padding(2, 6, 6, 0)
        chk_uni.Font = Drawing.Font('Segoe UI', 8.75, Drawing.FontStyle.Bold)
        chk_uni.Checked = mc_cfg_state['uni']
        tb_cov = _rtb(0, 0, 40, mc_cfg_state['cov'], 9.25)
        btn_apply_mc = _mk_tb_btn(u'↻ Cập nhật MC', 0, 144, c_amber, Drawing.Color.White, True, 0, 28, 8.75)
        btn_apply_mc.Anchor = WinForms.AnchorStyles.Right

        for _c in (
            _rl(u'Đai Ø', 0, 0, True, c_amber, 8.75), cbo_sd,
            _rl(u'a1:', 0, 0, False, c_slate900, 8.75), tb_a1,
            _rl(u'a2:', 0, 0, False, c_slate900, 8.75), tb_a2,
            chk_uni,
            _rl(u'BV:', 0, 0, False, c_slate900, 8.75), tb_cov,
        ):
            flp_mcs_r1.Controls.Add(_c)
        tlp_mcs_r1.Controls.Add(flp_mcs_r1, 0, 0)
        tlp_mcs_r1.Controls.Add(btn_apply_mc, 1, 0)

        chk_main = WinForms.CheckBox()
        chk_main.UseMnemonic = False
        chk_main.Dock = WinForms.DockStyle.Fill
        chk_main.Text = u'Đồng bộ thép chủ MC (bỏ tick = giữ thép gốc của dầm):'
        chk_main.Font = Drawing.Font('Segoe UI', 8.75, Drawing.FontStyle.Bold)
        chk_main.ForeColor = c_blue
        chk_main.Checked = mc_cfg_state['sync_main']

        flp_mcs_r3 = WinForms.FlowLayoutPanel()
        flp_mcs_r3.Dock = WinForms.DockStyle.Fill
        flp_mcs_r3.WrapContents = False
        flp_mcs_r3.Margin = WinForms.Padding(0)
        tb_tn = _rtb(0, 0, 36, mc_cfg_state['tn'], 9.25); tb_td = _rtb(0, 0, 40, mc_cfg_state['td'], 9.25)
        tb_bn = _rtb(0, 0, 36, mc_cfg_state['bn'], 9.25); tb_bd = _rtb(0, 0, 40, mc_cfg_state['bd'], 9.25)
        tb_mn = _rtb(0, 0, 36, mc_cfg_state['mn'], 9.25); tb_md = _rtb(0, 0, 40, mc_cfg_state['md'], 9.25)
        for _c in (
            _rl(u'Trên:', 0, 0, True, c_slate900, 8.75), tb_tn, _rl(u'Ø', 0, 0, True, c_slate900, 8.75), tb_td,
            _rl(u'Dưới:', 0, 0, True, c_slate900, 8.75), tb_bn, _rl(u'Ø', 0, 0, True, c_slate900, 8.75), tb_bd,
            _rl(u'Giữa:', 0, 0, False, c_slate900, 8.75), tb_mn, _rl(u'Ø', 0, 0, False, c_slate900, 8.75), tb_md,
        ):
            flp_mcs_r3.Controls.Add(_c)

        lbl_mc_tip = _rl(u'Mẹo: Tick [Chỉ MC →] ở bảng trái để đẩy qua phải, tick [← Đầy đủ] ở bảng phải để trả về bên trái.', 0, 0, False, c_slate600, 8.25)
        lbl_mc_tip.AutoSize = False
        lbl_mc_tip.Dock = WinForms.DockStyle.Fill
        lbl_mc_tip.Margin = WinForms.Padding(0)
        lbl_mc_tip.AutoEllipsis = True

        tlp_mcs.Controls.Add(tlp_mcs_r0, 0, 0)
        tlp_mcs.Controls.Add(tlp_mcs_r1, 0, 1)
        tlp_mcs.Controls.Add(chk_main, 0, 2)
        tlp_mcs.Controls.Add(flp_mcs_r3, 0, 3)
        tlp_mcs.Controls.Add(lbl_mc_tip, 0, 4)
        pnl_mc_set.Controls.Add(tlp_mcs)

        tlp_mc.Controls.Add(tlp_mc_bar, 0, 0)
        tlp_mc.Controls.Add(dgv_mc, 0, 1)
        tlp_mc.Controls.Add(pnl_mc_set, 0, 2)
        grp_mc.Controls.Add(tlp_mc)
        tlp_panes.Controls.Add(grp_mc, 2, 0)

        pnl_wrap.Controls.Add(tlp_panes, 0, 1)
        parent.Controls.Add(pnl_wrap)
        mc_widgets[tab_kind] = {
            'cbo_sd': cbo_sd, 'tb_a1': tb_a1, 'tb_a2': tb_a2, 'chk_uni': chk_uni,
            'tb_cov': tb_cov, 'lbl_prev': lbl_ms_prev, 'chk_main': chk_main,
            'tb_tn': tb_tn, 'tb_td': tb_td, 'tb_bn': tb_bn, 'tb_bd': tb_bd,
            'tb_mn': tb_mn, 'tb_md': tb_md, 'btn_apply_mc': btn_apply_mc,
        }
        split_views[tab_kind] = {
            'wrap': pnl_wrap, 'txt_search': txt_search, 'lbl_count': lbl_count,
            'btn_sel_all': btn_sel_all, 'btn_sel_none': btn_sel_none, 'btn_edit': btn_edit,
            'grp_full': grp_full, 'grp_mc': grp_mc,
            'dgv_full': dgv_full, 'dgv_mc': dgv_mc,
            'btn_f_all': btn_f_all, 'btn_f_none': btn_f_none, 'btn_f_to_mc': btn_f_to_mc,
            'btn_m_all': btn_m_all, 'btn_m_none': btn_m_none, 'btn_m_to_full': btn_m_to_full,
            'last_selected': None,
        }
        return split_views[tab_kind]

    # =========================================================================
    # TAB 1: QUÉT TRỰC TIẾP MẶT BẰNG REVIT (1A: DANH SÁCH 2 BÊN | 1B: TIẾT DIỆN CHUNG)
    # =========================================================================
    tlp_rv = _mk_tlp(
        [(WinForms.SizeType.Percent, 100)],
        [(WinForms.SizeType.Absolute, 36), (WinForms.SizeType.Absolute, 38), (WinForms.SizeType.Percent, 100)],
        pad=WinForms.Padding(8),
        bg=Drawing.Color.White,
    )
    tab_revit.Controls.Add(tlp_rv)

    pnl_rv_scope = _mk_tlp(
        [(WinForms.SizeType.Percent, 68), (WinForms.SizeType.Percent, 32)],
        [(WinForms.SizeType.Percent, 100)],
        pad=WinForms.Padding(6, 3, 8, 3),
        bg=Drawing.Color.FromArgb(239, 246, 255),
    )
    flp_rv_sc = WinForms.FlowLayoutPanel()
    flp_rv_sc.Dock = WinForms.DockStyle.Fill
    flp_rv_sc.WrapContents = False
    flp_rv_sc.Margin = WinForms.Padding(0)

    lbl_scope_ttl = _rl(u'Phạm vi quét:', 0, 0, True, c_blue, 9.25)
    rb_scope_view = WinForms.RadioButton()
    rb_scope_view.UseMnemonic = False
    rb_scope_view.Text = u'Mặt bằng đang mở'
    rb_scope_view.AutoSize = True
    rb_scope_view.Margin = WinForms.Padding(6, 5, 10, 0)
    rb_scope_view.Font = Drawing.Font('Segoe UI', 9.25, Drawing.FontStyle.Bold)
    rb_scope_view.ForeColor = c_slate900
    rb_scope_view.Checked = True

    rb_scope_pick = WinForms.RadioButton()
    rb_scope_pick.UseMnemonic = False
    rb_scope_pick.Text = u'Chọn từng dầm'
    rb_scope_pick.AutoSize = True
    rb_scope_pick.Margin = WinForms.Padding(4, 5, 10, 0)
    rb_scope_pick.Font = Drawing.Font('Segoe UI', 9.25)
    rb_scope_pick.ForeColor = c_slate900

    rb_scope_proj = WinForms.RadioButton()
    rb_scope_proj.UseMnemonic = False
    rb_scope_proj.Text = u'Cả công trình'
    rb_scope_proj.AutoSize = True
    rb_scope_proj.Margin = WinForms.Padding(4, 5, 10, 0)
    rb_scope_proj.Font = Drawing.Font('Segoe UI', 9.25)
    rb_scope_proj.ForeColor = c_slate900

    btn_rv_rescan = _mk_tb_btn(u'↻ Quét Revit', 0, 140, Drawing.Color.White, c_blue, True, 0, 27, 9.0)
    for _c in (lbl_scope_ttl, rb_scope_view, rb_scope_pick, rb_scope_proj, btn_rv_rescan):
        flp_rv_sc.Controls.Add(_c)

    lbl_rv_doc = WinForms.Label()
    lbl_rv_doc.UseMnemonic = False
    lbl_rv_doc.Dock = WinForms.DockStyle.Fill
    lbl_rv_doc.AutoEllipsis = True
    lbl_rv_doc.Text = u'%s (%d dầm)' % (rv_scope_note, len(rv_summaries))
    lbl_rv_doc.Font = Drawing.Font('Segoe UI', 9.25, Drawing.FontStyle.Bold)
    lbl_rv_doc.ForeColor = c_slate900
    lbl_rv_doc.TextAlign = Drawing.ContentAlignment.MiddleRight

    pnl_rv_scope.Controls.Add(flp_rv_sc, 0, 0)
    pnl_rv_scope.Controls.Add(lbl_rv_doc, 1, 0)
    tlp_rv.Controls.Add(pnl_rv_scope, 0, 0)

    pnl_rv_top = _mk_tlp(
        [(WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 296), (WinForms.SizeType.Absolute, 244)],
        [(WinForms.SizeType.Percent, 100)],
        pad=WinForms.Padding(6, 4, 6, 4),
        bg=c_slate100,
    )
    flp_rv_md = WinForms.FlowLayoutPanel()
    flp_rv_md.Dock = WinForms.DockStyle.Fill
    flp_rv_md.WrapContents = False
    flp_rv_md.Margin = WinForms.Padding(0)

    rb_rv_sec = WinForms.RadioButton()
    rb_rv_sec.UseMnemonic = False
    rb_rv_sec.Text = u'Theo Tiết diện chung'
    rb_rv_sec.AutoSize = True
    rb_rv_sec.Margin = WinForms.Padding(4, 5, 12, 0)
    rb_rv_sec.Font = Drawing.Font('Segoe UI', 9.25, Drawing.FontStyle.Bold)
    rb_rv_sec.ForeColor = c_emerald
    rb_rv_sec.Checked = True

    rb_rv_3d = WinForms.RadioButton()
    rb_rv_3d.UseMnemonic = False
    rb_rv_3d.Text = u'Ưu tiên thép 3D Revit (thiếu lấy TD chung)'
    rb_rv_3d.AutoSize = True
    rb_rv_3d.Margin = WinForms.Padding(4, 5, 8, 0)
    rb_rv_3d.Font = Drawing.Font('Segoe UI', 9.25)

    flp_rv_md.Controls.Add(rb_rv_sec)
    flp_rv_md.Controls.Add(rb_rv_3d)

    btn_rv_view_list = _mk_tb_btn(u'☰ 1A. Danh sách Dầm (Đầy đủ ↔ Chỉ MC)', 0, 290, c_blue, Drawing.Color.White, True, 0, 28, 9.0)
    btn_rv_view_list.Anchor = WinForms.AnchorStyles.Right
    btn_rv_view_sec = _mk_tb_btn(u'⚙ 1B. Thép Tiết diện chung (0)', 0, 238, Drawing.Color.White, c_emerald, True, 0, 28, 9.0)
    btn_rv_view_sec.Anchor = WinForms.AnchorStyles.Right

    pnl_rv_top.Controls.Add(flp_rv_md, 0, 0)
    pnl_rv_top.Controls.Add(btn_rv_view_list, 1, 0)
    pnl_rv_top.Controls.Add(btn_rv_view_sec, 2, 0)
    tlp_rv.Controls.Add(pnl_rv_top, 0, 1)

    pnl_rv_body = WinForms.Panel()
    pnl_rv_body.Dock = WinForms.DockStyle.Fill
    pnl_rv_body.Margin = WinForms.Padding(0, 4, 0, 0)
    tlp_rv.Controls.Add(pnl_rv_body, 0, 2)

    # Sub-view 1A: 2-side split beam list (default visible)
    _build_split_beam_workspace(pnl_rv_body, 'revit')

    # Sub-view 1B: Full-height Common Cross-Section Table + Dedicated Stirrup Setup
    pnl_rv_sec = _mk_tlp(
        [(WinForms.SizeType.Percent, 64), (WinForms.SizeType.Absolute, 10), (WinForms.SizeType.Percent, 36)],
        [(WinForms.SizeType.Percent, 100)],
        bg=Drawing.Color.White,
    )
    pnl_rv_sec.Visible = False
    pnl_rv_body.Controls.Add(pnl_rv_sec)

    grp_rv_sec = WinForms.GroupBox()
    grp_rv_sec.Dock = WinForms.DockStyle.Fill
    grp_rv_sec.Text = u'Bảng Tiết diện chung (b×h) — Sửa trực tiếp hoặc chọn dòng để chỉnh bên phải'
    grp_rv_sec.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold)
    grp_rv_sec.ForeColor = c_slate900
    grp_rv_sec.Padding = WinForms.Padding(8, 6, 8, 8)

    dgv_rv_sec = WinForms.DataGridView()
    dgv_rv_sec.Dock = WinForms.DockStyle.Fill
    dgv_rv_sec.AllowUserToAddRows = False
    dgv_rv_sec.AllowUserToDeleteRows = False
    dgv_rv_sec.RowHeadersVisible = False
    dgv_rv_sec.SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect
    dgv_rv_sec.MultiSelect = False
    dgv_rv_sec.BackgroundColor = Drawing.Color.White
    dgv_rv_sec.Font = Drawing.Font('Segoe UI', 9.5)
    dgv_rv_sec.RowTemplate.Height = 28
    dgv_rv_sec.ColumnHeadersHeight = 32
    dgv_rv_sec.ColumnHeadersHeightSizeMode = WinForms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing

    def _rv_col(hdr, w, ro=False, fill=False):
        c = WinForms.DataGridViewTextBoxColumn()
        c.HeaderText = hdr
        if fill:
            c.MinimumWidth = w
            c.AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill
        else:
            c.Width = w
        c.ReadOnly = ro
        c.SortMode = WinForms.DataGridViewColumnSortMode.NotSortable
        dgv_rv_sec.Columns.Add(c)

    _rv_col(u'Tiết diện', 102, True, False)
    _rv_col(u'Dầm', 54, True, False)
    _rv_col(u'Thép Trên', 110, False, True)
    _rv_col(u'Thép Dưới', 110, False, True)
    _rv_col(u'Thép Giữa', 96, False, True)
    _rv_col(u'Đai (Ø-a1/a2)', 118, False, True)
    _rv_col(u'BV', 48, False, False)
    grp_rv_sec.Controls.Add(dgv_rv_sec)
    pnl_rv_sec.Controls.Add(grp_rv_sec, 0, 0)

    grp_rv_edit = WinForms.GroupBox()
    grp_rv_edit.Dock = WinForms.DockStyle.Fill
    grp_rv_edit.Text = u'Ô thiết lập Đai riêng & Thép mặc định'
    grp_rv_edit.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold)
    grp_rv_edit.ForeColor = c_blue
    grp_rv_edit.Padding = WinForms.Padding(10, 8, 10, 8)

    tlp_rve = _mk_tlp(
        [(WinForms.SizeType.Percent, 100)],
        [
            (WinForms.SizeType.Absolute, 26),   # lbl_sec_sel
            (WinForms.SizeType.Absolute, 78),   # pnl_stir_box
            (WinForms.SizeType.Absolute, 36),   # top rebar
            (WinForms.SizeType.Absolute, 36),   # bot rebar
            (WinForms.SizeType.Absolute, 36),   # mid rebar
            (WinForms.SizeType.Absolute, 40),   # save btn
            (WinForms.SizeType.Absolute, 42),   # apply btn
            (WinForms.SizeType.Percent, 100),   # hint
        ],
    )

    lbl_sec_sel = _rl(u'Chưa có tiết diện', 0, 0, True, c_blue, 9.5)
    lbl_sec_sel.AutoSize = False
    lbl_sec_sel.Dock = WinForms.DockStyle.Fill
    lbl_sec_sel.Margin = WinForms.Padding(0)

    pnl_stir_box = WinForms.Panel()
    pnl_stir_box.Dock = WinForms.DockStyle.Fill
    pnl_stir_box.Margin = WinForms.Padding(0, 2, 0, 4)
    pnl_stir_box.BackColor = Drawing.Color.FromArgb(255, 247, 237)
    pnl_stir_box.BorderStyle = WinForms.BorderStyle.FixedSingle

    tlp_sb = _mk_tlp(
        [(WinForms.SizeType.Percent, 100)],
        [(WinForms.SizeType.Percent, 50), (WinForms.SizeType.Percent, 50)],
        pad=WinForms.Padding(4, 2, 4, 2),
    )
    flp_sb0 = WinForms.FlowLayoutPanel(); flp_sb0.Dock = WinForms.DockStyle.Fill; flp_sb0.WrapContents = False; flp_sb0.Margin = WinForms.Padding(0)
    flp_sb1 = WinForms.FlowLayoutPanel(); flp_sb1.Dock = WinForms.DockStyle.Fill; flp_sb1.WrapContents = False; flp_sb1.Margin = WinForms.Padding(0)

    cbo_sec_sd = _mk_cbo(('6', '8', '10', '12'), '8', w=52, editable=True, fsz=9.5)
    tb_sec_a1 = _rtb(0, 0, 50, '100', 9.5)
    tb_sec_a2 = _rtb(0, 0, 50, '200', 9.5)
    chk_sec_uni = WinForms.CheckBox()
    chk_sec_uni.UseMnemonic = False
    chk_sec_uni.Text = u'Đai đều'
    chk_sec_uni.AutoSize = True
    chk_sec_uni.Margin = WinForms.Padding(2, 6, 8, 0)
    chk_sec_uni.Font = Drawing.Font('Segoe UI', 9.0, Drawing.FontStyle.Bold)
    tb_sec_cov = _rtb(0, 0, 48, '25', 9.5)
    btn_rv_sync_stir = _mk_tb_btn(u'⇄ Đai mọi TD', 0, 126, Drawing.Color.White, c_amber, True, 0, 27, 8.75)

    for _c in (_rl(u'Đai Ø', 0, 0, True, c_amber, 9.0), cbo_sec_sd, _rl(u'a1:', 0, 0, False, c_slate900, 9.0), tb_sec_a1, _rl(u'a2:', 0, 0, False, c_slate900, 9.0), tb_sec_a2):
        flp_sb0.Controls.Add(_c)
    for _c in (chk_sec_uni, _rl(u'BV:', 0, 0, False, c_slate900, 9.0), tb_sec_cov, btn_rv_sync_stir):
        flp_sb1.Controls.Add(_c)
    tlp_sb.Controls.Add(flp_sb0, 0, 0)
    tlp_sb.Controls.Add(flp_sb1, 0, 1)
    pnl_stir_box.Controls.Add(tlp_sb)

    tb_sec_tn = _rtb(0, 0, 56, '2', 9.75); tb_sec_td = _rtb(0, 0, 62, '18', 9.75)
    tb_sec_bn = _rtb(0, 0, 56, '2', 9.75); tb_sec_bd = _rtb(0, 0, 62, '18', 9.75)
    tb_sec_mn = _rtb(0, 0, 56, '0', 9.75); tb_sec_md = _rtb(0, 0, 62, '12', 9.75)

    def _mk_rebar_row(lbl_t, tb_n, tb_d, bold_r=True):
        f = WinForms.FlowLayoutPanel(); f.Dock = WinForms.DockStyle.Fill; f.WrapContents = False; f.Margin = WinForms.Padding(0)
        l = _rl(lbl_t, 0, 0, bold_r, c_slate900, 9.5); l.AutoSize = False; l.Size = Drawing.Size(96, 24); l.Margin = WinForms.Padding(2, 4, 4, 0)
        f.Controls.Add(l); f.Controls.Add(tb_n); f.Controls.Add(_rl(u'Ø', 0, 0, True, c_slate900, 9.5)); f.Controls.Add(tb_d)
        return f

    btn_rv_save_sec = _mk_tb_btn(u'✓ Cập nhật Tiết diện đang chọn', 0, 320, c_blue, Drawing.Color.White, True, 0, 34, 9.5)
    btn_rv_save_sec.Dock = WinForms.DockStyle.Fill; btn_rv_save_sec.Margin = WinForms.Padding(0, 3, 0, 3)
    btn_rv_apply_sec = _mk_tb_btn(u'⚡ Áp dụng toàn bộ & Xem Danh sách Dầm', 0, 320, c_emerald, Drawing.Color.White, True, 0, 36, 9.5)
    btn_rv_apply_sec.Dock = WinForms.DockStyle.Fill; btn_rv_apply_sec.Margin = WinForms.Padding(0, 3, 0, 3)
    lbl_sec_hint = _rl(u'Gợi ý: Có thể gõ 2+18 hoặc 2d18 trực tiếp trong bảng bên trái.\nBấm nút xanh lá để đồng bộ và chuyển về danh sách 2 bên.', 0, 0, False, c_slate600, 8.75)
    lbl_sec_hint.AutoSize = False; lbl_sec_hint.Dock = WinForms.DockStyle.Fill; lbl_sec_hint.Margin = WinForms.Padding(0, 4, 0, 0)

    tlp_rve.Controls.Add(lbl_sec_sel, 0, 0)
    tlp_rve.Controls.Add(pnl_stir_box, 0, 1)
    tlp_rve.Controls.Add(_mk_rebar_row(u'Thép Trên:', tb_sec_tn, tb_sec_td, True), 0, 2)
    tlp_rve.Controls.Add(_mk_rebar_row(u'Thép Dưới:', tb_sec_bn, tb_sec_bd, True), 0, 3)
    tlp_rve.Controls.Add(_mk_rebar_row(u'Thép Giữa:', tb_sec_mn, tb_sec_md, False), 0, 4)
    tlp_rve.Controls.Add(btn_rv_save_sec, 0, 5)
    tlp_rve.Controls.Add(btn_rv_apply_sec, 0, 6)
    tlp_rve.Controls.Add(lbl_sec_hint, 0, 7)
    grp_rv_edit.Controls.Add(tlp_rve)
    pnl_rv_sec.Controls.Add(grp_rv_edit, 2, 0)

    # =========================================================================
    # TAB 2: NHẬP TỪ EXCEL BEAMREBAR (.XLSX) — GIỮ NGUYÊN 100% CHỨC NĂNG CŨ
    # =========================================================================
    tlp_ex = _mk_tlp(
        [(WinForms.SizeType.Percent, 100)],
        [(WinForms.SizeType.Absolute, 64), (WinForms.SizeType.Percent, 100)],
        pad=WinForms.Padding(8),
        bg=Drawing.Color.White,
    )
    tab_excel.Controls.Add(tlp_ex)

    grp_ex_src = WinForms.GroupBox()
    grp_ex_src.Dock = WinForms.DockStyle.Fill
    grp_ex_src.Text = u'1. Chọn file Excel BeamRebar (.xlsx) hoặc Quét dầm trực tiếp từ AutoCAD'
    grp_ex_src.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold)
    grp_ex_src.ForeColor = c_slate900
    grp_ex_src.Padding = WinForms.Padding(8, 6, 8, 6)

    tlp_ex_src = _mk_tlp(
        [(WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 128), (WinForms.SizeType.Absolute, 148)],
        [(WinForms.SizeType.Percent, 100)],
    )
    txt_ex_path = WinForms.TextBox()
    txt_ex_path.Dock = WinForms.DockStyle.Fill
    txt_ex_path.Margin = WinForms.Padding(0, 3, 8, 2)
    txt_ex_path.Font = Drawing.Font('Segoe UI', 9.5)
    txt_ex_path.ReadOnly = True
    txt_ex_path.BackColor = c_slate100
    txt_ex_path.Text = u'(Bấm "Chọn file..." để nạp Dam_*.xlsx hoặc "Quét từ CAD")'

    btn_ex_browse = _mk_tb_btn(u'Chọn file...', 0, 120, Drawing.Color.White, c_slate900, True, 0, 29, 9.25)
    btn_ex_browse.Anchor = WinForms.AnchorStyles.Right
    btn_ex_scan_cad = _mk_tb_btn(u'🔍 Quét từ CAD', 0, 142, Drawing.Color.FromArgb(239, 246, 255), Drawing.Color.FromArgb(30, 64, 175), True, 0, 29, 9.25)
    btn_ex_scan_cad.Anchor = WinForms.AnchorStyles.Right

    tlp_ex_src.Controls.Add(txt_ex_path, 0, 0)
    tlp_ex_src.Controls.Add(btn_ex_browse, 1, 0)
    tlp_ex_src.Controls.Add(btn_ex_scan_cad, 2, 0)
    grp_ex_src.Controls.Add(tlp_ex_src)
    tlp_ex.Controls.Add(grp_ex_src, 0, 0)

    pnl_ex_body = WinForms.Panel()
    pnl_ex_body.Dock = WinForms.DockStyle.Fill
    pnl_ex_body.Margin = WinForms.Padding(0, 4, 0, 0)
    tlp_ex.Controls.Add(pnl_ex_body, 0, 1)
    _build_split_beam_workspace(pnl_ex_body, 'excel')

    # 2. 3. Chế độ Neo · Kéo · Tiêu chuẩn (Thép dầm)
    pnl_neo_pad = WinForms.Panel()
    pnl_neo_pad.Dock = WinForms.DockStyle.Fill
    pnl_neo_pad.Padding = WinForms.Padding(10, 2, 10, 2)
    grp_neo = WinForms.GroupBox()
    grp_neo.Dock = WinForms.DockStyle.Fill
    grp_neo.Text = u'3. Chế độ Neo · Kéo · Tiêu chuẩn (Thép dầm)'
    grp_neo.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold)
    grp_neo.ForeColor = c_blue
    grp_neo.Padding = WinForms.Padding(8, 4, 8, 6)
    grp_neo.BackColor = Drawing.Color.FromArgb(240, 249, 255)

    tlp_neo = _mk_tlp(
        [(WinForms.SizeType.Percent, 100)],
        [(WinForms.SizeType.Percent, 50), (WinForms.SizeType.Percent, 50)],
        bg=Drawing.Color.FromArgb(240, 249, 255),
    )

    flp_neo_top = WinForms.FlowLayoutPanel()
    flp_neo_top.Dock = WinForms.DockStyle.Fill
    flp_neo_top.WrapContents = False
    flp_neo_top.Margin = WinForms.Padding(0)

    cbo_std = _mk_cbo((u'TCVN 5574:2018', u'TCVN 5574:2012', u'Tùy chỉnh'), u'TCVN 5574:2018', w=140, editable=False, fsz=9.0)
    cbo_conc = _mk_cbo(_CONCRETE_GRADES, 'B25', w=66, editable=False, fsz=9.0)
    cbo_steel = _mk_cbo(_STEEL_GRADES, 'CB400-V', w=88, editable=False, fsz=9.0)
    cbo_neo_mode = _mk_cbo(_NEO_MODES, _NEO_MODES[0], w=174, editable=False, fsz=9.0)
    cbo_step_neo = _mk_cbo(_STEP_NEO_MODES, _STEP_NEO_MODES[0], w=174, editable=False, fsz=9.0)

    for _c in (
        _rl(u'Tiêu chuẩn:', 0, 0, True, c_slate900, 9.0), cbo_std,
        _rl(u'BT:', 0, 0, True, c_slate900, 9.0), cbo_conc,
        _rl(u'Thép:', 0, 0, True, c_slate900, 9.0), cbo_steel,
        _rl(u'Chế độ neo:', 0, 0, True, c_blue, 9.0), cbo_neo_mode,
        _rl(u'Chênh cốt:', 0, 0, True, c_amber, 9.0), cbo_step_neo,
    ):
        flp_neo_top.Controls.Add(_c)

    tlp_neo_bot = _mk_tlp(
        [(WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 154)],
        [(WinForms.SizeType.Percent, 100)],
        bg=Drawing.Color.FromArgb(240, 249, 255),
    )
    flp_neo_bot = WinForms.FlowLayoutPanel()
    flp_neo_bot.Dock = WinForms.DockStyle.Fill
    flp_neo_bot.WrapContents = False
    flp_neo_bot.Margin = WinForms.Padding(0)

    tb_neo_top = _rtb(0, 0, 50, '35d', 9.25)
    tb_neo_bot = _rtb(0, 0, 50, '25d', 9.25)
    tb_ext_g = _rtb(0, 0, 50, 'L/4', 9.25)
    tb_cut_g = _rtb(0, 0, 50, 'L/4', 9.25)
    tb_lap_g = _rtb(0, 0, 50, '40d', 9.25)
    cbo_gap_g = _mk_cbo((u'xuống', '15d', '20d', '25d', '30d'), u'xuống', w=68, editable=True, fsz=9.0)

    chk_tc_hook = WinForms.CheckBox()
    chk_tc_hook.UseMnemonic = False
    chk_tc_hook.Text = u'TC luôn gập cột'
    chk_tc_hook.AutoSize = True
    chk_tc_hook.Margin = WinForms.Padding(2, 5, 4, 0)
    chk_tc_hook.Font = Drawing.Font('Segoe UI', 8.75, Drawing.FontStyle.Bold)
    chk_tc_hook.ForeColor = c_slate900
    chk_tc_hook.Checked = True

    for _c in (
        _rl(u'Neo Trên (kéo):', 0, 0, True, c_slate900, 9.0), tb_neo_top,
        _rl(u'Neo Dưới (nén):', 0, 0, True, c_slate900, 9.0), tb_neo_bot,
        _rl(u'Kéo gối:', 0, 0, False, c_slate900, 9.0), tb_ext_g,
        _rl(u'Cắt nhịp:', 0, 0, False, c_slate900, 9.0), tb_cut_g,
        _rl(u'Nối:', 0, 0, False, c_slate900, 9.0), tb_lap_g,
        _rl(u'Gập:', 0, 0, False, c_slate900, 9.0), cbo_gap_g,
        chk_tc_hook,
    ):
        flp_neo_bot.Controls.Add(_c)

    btn_apply_neo = _mk_tb_btn(u'✓ Áp dụng Neo/TC', 0, 148, c_blue, Drawing.Color.White, True, 0, 29, 9.0)
    btn_apply_neo.Anchor = WinForms.AnchorStyles.Right
    tlp_neo_bot.Controls.Add(flp_neo_bot, 0, 0)
    tlp_neo_bot.Controls.Add(btn_apply_neo, 1, 0)

    tlp_neo.Controls.Add(flp_neo_top, 0, 0)
    tlp_neo.Controls.Add(tlp_neo_bot, 0, 1)
    grp_neo.Controls.Add(tlp_neo)
    pnl_neo_pad.Controls.Add(grp_neo)
    tlp_root.Controls.Add(pnl_neo_pad, 0, 2)

    # 3. 4. Shared Scale & Sheet Options (default 1/50, 1/25, split 50)
    pnl_opt_pad = WinForms.Panel()
    pnl_opt_pad.Dock = WinForms.DockStyle.Fill
    pnl_opt_pad.Padding = WinForms.Padding(10, 2, 10, 2)
    grp_opt = WinForms.GroupBox()
    grp_opt.Dock = WinForms.DockStyle.Fill
    grp_opt.Text = u'4. Tỉ lệ bản vẽ & Quy cách xuất (Mặc định: 1/50 · 1/25 · Cắt TK 50)'
    grp_opt.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold)
    grp_opt.ForeColor = c_slate900
    grp_opt.Padding = WinForms.Padding(8, 2, 8, 4)

    tlp_opt = _mk_tlp(
        [(WinForms.SizeType.Percent, 100)],
        [(WinForms.SizeType.Absolute, 32), (WinForms.SizeType.Percent, 100)],
    )
    tlp_opt_r0 = _mk_tlp(
        [(WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 162)],
        [(WinForms.SizeType.Percent, 100)],
    )
    flp_opt_l = WinForms.FlowLayoutPanel()
    flp_opt_l.Dock = WinForms.DockStyle.Fill
    flp_opt_l.WrapContents = False
    flp_opt_l.Margin = WinForms.Padding(0)

    def _mk_lbl(txt):
        return _rl(txt, 0, 0, False, c_slate900, 9.25)

    def _mk_tb(val, w=56):
        return _rtb(0, 0, w, val, 9.5)

    chk_rv_scale = WinForms.CheckBox()
    chk_rv_scale.UseMnemonic = False
    chk_rv_scale.Text = u'Lấy theo View Revit'
    chk_rv_scale.Font = Drawing.Font('Segoe UI', 9.25, Drawing.FontStyle.Bold)
    chk_rv_scale.ForeColor = c_blue
    chk_rv_scale.AutoSize = True
    chk_rv_scale.Margin = WinForms.Padding(4, 5, 14, 0)
    chk_rv_scale.Checked = False

    tb_elev = _mk_tb(50, 56)
    tb_sec = _mk_tb(25, 56)
    tb_lim = _mk_tb(50, 58)
    for _c in (chk_rv_scale, _mk_lbl(u'MC dọc 1/:'), tb_elev, _mk_lbl(u'MC ngang 1/:'), tb_sec, _mk_lbl(u'Cắt bảng TK (số ô):'), tb_lim):
        flp_opt_l.Controls.Add(_c)

    btn_read_view = _mk_tb_btn(u'↻ Đọc View Revit', 0, 156, Drawing.Color.FromArgb(239, 246, 255), c_blue, True, 0, 28, 9.0)
    btn_read_view.Anchor = WinForms.AnchorStyles.Right
    tlp_opt_r0.Controls.Add(flp_opt_l, 0, 0)
    tlp_opt_r0.Controls.Add(btn_read_view, 1, 0)

    lbl_rv_scale = WinForms.Label()
    lbl_rv_scale.UseMnemonic = False
    lbl_rv_scale.Dock = WinForms.DockStyle.Fill
    lbl_rv_scale.Text = u'Mặc định: MC dọc 1/50 · MC ngang 1/25 · Cắt TK 50 (tick "Lấy theo View Revit" nếu muốn đồng bộ View)'
    lbl_rv_scale.Font = Drawing.Font('Segoe UI', 8.75)
    lbl_rv_scale.ForeColor = c_slate600
    lbl_rv_scale.TextAlign = Drawing.ContentAlignment.MiddleLeft

    tlp_opt.Controls.Add(tlp_opt_r0, 0, 0)
    tlp_opt.Controls.Add(lbl_rv_scale, 0, 1)
    grp_opt.Controls.Add(tlp_opt)
    pnl_opt_pad.Controls.Add(grp_opt)
    tlp_root.Controls.Add(pnl_opt_pad, 0, 3)

    # 4. Status Bar
    lbl_status = WinForms.Label()
    lbl_status.UseMnemonic = False
    lbl_status.Dock = WinForms.DockStyle.Fill
    lbl_status.Padding = WinForms.Padding(12, 0, 12, 0)
    lbl_status.Text = u'Tick [✓ Vẽ] các dầm cần xuất (hoặc bấm Chọn cả) → Tick [Chỉ MC →] / [← Đầy đủ] để chuyển bên → Bấm Vẽ vào CAD.'
    lbl_status.Font = Drawing.Font('Segoe UI', 9.25, Drawing.FontStyle.Bold)
    lbl_status.ForeColor = c_slate600
    lbl_status.TextAlign = Drawing.ContentAlignment.MiddleLeft
    tlp_root.Controls.Add(lbl_status, 0, 4)

    # 5. Footer buttons
    pnl_ftr = _mk_tlp(
        [
            (WinForms.SizeType.AutoSize, 0),
            (WinForms.SizeType.AutoSize, 0),
            (WinForms.SizeType.Percent, 100),
            (WinForms.SizeType.AutoSize, 0),
            (WinForms.SizeType.AutoSize, 0),
            (WinForms.SizeType.AutoSize, 0),
        ],
        [(WinForms.SizeType.Percent, 100)],
        pad=WinForms.Padding(10, 10, 10, 10),
        bg=c_slate100,
    )

    btn_ftr_sel_all = _mk_tb_btn(u'☑ Chọn cả (Vẽ cả)', 0, 166, Drawing.Color.FromArgb(219, 234, 254), c_blue, True, 0, 38, 9.5)
    btn_ftr_sel_none = _mk_tb_btn(u'☐ Bỏ chọn hết', 0, 132, Drawing.Color.White, c_slate900, False, 0, 38, 9.5)
    btn_send_beam = _mk_tb_btn(u'➡ Vẽ Bản vẽ Dầm vào CAD (0)', 0, 276, c_btn_blue, Drawing.Color.White, True, 0, 38, 9.75)
    btn_send_beam.FlatAppearance.BorderSize = 0
    btn_send_tk = _mk_tb_btn(u'➡ Vẽ Bảng TK vào CAD (0)', 0, 256, c_emerald, Drawing.Color.White, True, 0, 38, 9.75)
    btn_send_tk.FlatAppearance.BorderSize = 0
    btn_close = _mk_tb_btn(u'Đóng', 0, 104, Drawing.Color.White, c_slate900, False, 0, 38, 9.5)

    for _b in (btn_ftr_sel_all, btn_ftr_sel_none, btn_send_beam, btn_send_tk, btn_close):
        _b.Margin = WinForms.Padding(0, 0, 8, 0)
    btn_close.Margin = WinForms.Padding(0)

    pnl_ftr.Controls.Add(btn_ftr_sel_all, 0, 0)
    pnl_ftr.Controls.Add(btn_ftr_sel_none, 1, 0)
    pnl_ftr.Controls.Add(btn_send_beam, 3, 0)
    pnl_ftr.Controls.Add(btn_send_tk, 4, 0)
    pnl_ftr.Controls.Add(btn_close, 5, 0)
    tlp_root.Controls.Add(pnl_ftr, 0, 5)

    _NEO_OPT_KEYS = ('std', 'concrete', 'steel', 'neo_mode', 'step_neo', 'neo_top', 'neo_bot', 'neo', 'ext', 'cut', 'lap', 'gap', 'tc_hook')

    def _init_neo_opt_from_defaults(grades=None):
        op = _default_beam_opt()
        if isinstance(grades, dict):
            if grades.get('concrete'):
                op['concrete'] = _norm_concrete_grade(grades['concrete'], op['concrete'])
            if grades.get('steel'):
                op['steel'] = _norm_steel_grade(grades['steel'], op['steel'])
        nt, nb, lp = _calc_tcvn_anchorage(op['std'], op['concrete'], op['steel'])
        op['neo_top'] = nt
        op['neo_bot'] = nb
        op['neo'] = nt
        op['lap'] = lp
        return dict((k, op.get(k)) for k in _NEO_OPT_KEYS)

    # Strictly isolated state objects for Tab 1 (Revit) and Tab 2 (Excel)
    rv_state = {
        'kind': 'revit',
        'rows': [],
        'checked': set([s[0] for s in rv_summaries]),
        'modes': {},
        'full_cache': {},
        'mc_cache': {},
        'orig_xlsx': '',
        'custom_xlsx': '',
        'beam_dxf': '',
        'tk_dxf': '',
        'dirty': True,
        'sec_keys': [],
        'sec_rules': {},
        'manual_edited': set(),
        'rebar_mode': 'sec',
        'scan_scope': 'view',
        'pick_eids': None,
        'scope_note': rv_scope_note,
        'scope_loading': False,
        'populating': False,
        'sending': False,
        'sec_loading': False,
        'sub_view': 'list',
        'rv_order': rv_order,
        'rv_grouped': rv_grouped,
        'rv_summaries': rv_summaries,
        'rv_smap': rv_smap,
        'rv_lvl': rv_lvl,
        'rv_meta': rv_meta,
        'doc_title': doc_title,
        'neo_opt': _init_neo_opt_from_defaults(getattr(_collect_revit_model_data, '_last_grades', None)),
    }

    ex_state = {
        'kind': 'excel',
        'rows': [],
        'checked': set(),
        'modes': {},
        'full_cache': {},
        'mc_cache': {},
        'xlsx': '',
        'custom_xlsx': '',
        'beam_dxf': '',
        'tk_dxf': '',
        'dirty': True,
        'manual_edited': set(),
        'populating': False,
        'sending': False,
        'scanning': False,
        'scan_json': '',
        'scan_timer': None,
        'neo_opt': _init_neo_opt_from_defaults(None),
    }

    ui_nav = {'data_tab': 'revit', 'neo_loading': False}

    def _load_neo_opt_to_ui(op):
        if not isinstance(op, dict):
            return
        ui_nav['neo_loading'] = True
        try:
            cbo_std.Text = _norm_std_name(op.get('std', u'TCVN 5574:2018'))
            cbo_conc.Text = _norm_concrete_grade(op.get('concrete', 'B25'))
            cbo_steel.Text = _norm_steel_grade(op.get('steel', 'CB400-V'))
            cbo_neo_mode.Text = _norm_neo_mode(op.get('neo_mode', _NEO_MODES[0]))
            cbo_step_neo.Text = _norm_step_neo(op.get('step_neo', _STEP_NEO_MODES[0]))
            nt_d, nb_d, lp_d = _calc_tcvn_anchorage(cbo_std.Text, cbo_conc.Text, cbo_steel.Text)
            tb_neo_top.Text = sstr(op.get('neo_top') or op.get('neo') or nt_d)
            tb_neo_bot.Text = sstr(op.get('neo_bot') or op.get('neo') or nb_d)
            tb_ext_g.Text = sstr(op.get('ext') or 'L/4')
            tb_cut_g.Text = sstr(op.get('cut') or 'L/4')
            tb_lap_g.Text = sstr(op.get('lap') or lp_d)
            cbo_gap_g.Text = sstr(op.get('gap') or u'xuống')
            chk_tc_hook.Checked = bool(num(op.get('tc_hook', 1.0), 1.0) > 0.0)
        finally:
            ui_nav['neo_loading'] = False

    def _read_neo_opt_from_ui():
        std_v = _norm_std_name(cbo_std.Text)
        conc_v = _norm_concrete_grade(cbo_conc.Text)
        steel_v = _norm_steel_grade(cbo_steel.Text)
        nt_d, nb_d, lp_d = _calc_tcvn_anchorage(std_v, conc_v, steel_v)
        nt_v = sstr(tb_neo_top.Text) or nt_d
        nb_v = sstr(tb_neo_bot.Text) or nb_d
        return {
            'std': std_v,
            'concrete': conc_v,
            'steel': steel_v,
            'neo_mode': _norm_neo_mode(cbo_neo_mode.Text),
            'step_neo': _norm_step_neo(cbo_step_neo.Text),
            'neo_top': nt_v,
            'neo_bot': nb_v,
            'neo': nt_v,
            'ext': sstr(tb_ext_g.Text) or 'L/4',
            'cut': sstr(tb_cut_g.Text) or 'L/4',
            'lap': sstr(tb_lap_g.Text) or lp_d,
            'gap': sstr(cbo_gap_g.Text) or u'xuống',
            'tc_hook': 1.0 if chk_tc_hook.Checked else 0.0,
        }

    def _sync_neo_tcvn_fields(*_a):
        if ui_nav.get('neo_loading'):
            return
        std_v = _norm_std_name(cbo_std.Text)
        conc_v = _norm_concrete_grade(cbo_conc.Text)
        steel_v = _norm_steel_grade(cbo_steel.Text)
        if std_v != u'Tùy chỉnh':
            nt, nb, lp = _calc_tcvn_anchorage(std_v, conc_v, steel_v)
            ui_nav['neo_loading'] = True
            try:
                tb_neo_top.Text = nt
                tb_neo_bot.Text = nb
                tb_lap_g.Text = lp
            finally:
                ui_nav['neo_loading'] = False
        _ctx()[0]['neo_opt'] = _read_neo_opt_from_ui()
        mark_dirty(_ctx()[2])

    def _write_neo_opt_to_wb(wb, op_vals):
        caidat = [list(r) for r in (wb.get('CaiDat') or [])]
        if not caidat:
            caidat = [[u'Thông số', u'Giá trị']]
        updates = [
            (u'Tiêu chuẩn thiết kế', op_vals.get('std', u'TCVN 5574:2018'), ('tieu chuan', 'standard')),
            (u'Mác bê tông', op_vals.get('concrete', 'B25'), ('mac be tong', 'be tong', 'concrete')),
            (u'Nhóm thép chủ', op_vals.get('steel', 'CB400-V'), ('nhom thep', 'mac thep', 'steel')),
            (u'Chế độ neo thép', op_vals.get('neo_mode', _NEO_MODES[0]), ('che do neo', 'kieu neo')),
            (u'Neo dầm chênh cốt', op_vals.get('step_neo', _STEP_NEO_MODES[0]), ('neo dam chenh', 'neo chenh', 'neo lech', 'giat cap', 'chenh cot')),
            (u'Chiều dài neo mặc định', op_vals.get('neo', '35d'), ('chieu dai neo',)),
            (u'Chiều dài neo kéo (Trên)', op_vals.get('neo_top', '35d'), ('neo keo', 'neo tren')),
            (u'Chiều dài neo nén (Dưới)', op_vals.get('neo_bot', '25d'), ('neo nen', 'neo duoi')),
            (u'Chiều dài nối chồng', op_vals.get('lap', '40d'), ('noi chong', 'chieu dai noi')),
            (u'Chiều dài gập mặc định', op_vals.get('gap', u'xuống'), ('chieu dai gap',)),
            (u'Kéo dài ra nhịp mặc định', op_vals.get('ext', 'L/4'), ('keo dai ra nhip', 'keo goi')),
            (u'Cắt trong nhịp mặc định', op_vals.get('cut', 'L/4'), ('cat trong nhip', 'cat nhip')),
            (u'TC luôn gập vào cột', '1' if bool(num(op_vals.get('tc_hook', 1.0), 1.0) > 0) else '0', ('tc luon gap', 'tang cuong gap')),
        ]
        for ck, cv, toks in updates:
            hit_i = None
            for idx_r in range(1, len(caidat)):
                row_r = caidat[idx_r]
                if not row_r:
                    continue
                col_k = _norm_hdr(row_r[1] if (len(row_r) >= 3 and (sstr(row_r[0]).isdigit() or not sstr(row_r[0]))) else row_r[0]).lower()
                if any(tok in col_k for tok in toks):
                    hit_i = idx_r
                    break
            if hit_i is not None:
                if len(caidat[hit_i]) >= 3 and (sstr(caidat[hit_i][0]).isdigit() or not sstr(caidat[hit_i][0])):
                    caidat[hit_i][2] = cv
                else:
                    while len(caidat[hit_i]) < 2:
                        caidat[hit_i].append('')
                    caidat[hit_i][1] = cv
            else:
                caidat.append([ck, cv])
        wb['CaiDat'] = caidat
        return wb

    def _apply_neo_opt_to_active_tab(tab_kind=None, silent=False, target_xlsx=None):
        st_n, _sv_n, kd_n = _ctx(tab_kind)
        if ui_nav.get('neo_loading'):
            return st_n.get('neo_opt') or _init_neo_opt_from_defaults(None)
        if tab_kind is None or kd_n == _ctx()[2]:
            op_vals = _read_neo_opt_from_ui()
            st_n['neo_opt'] = op_vals
        else:
            op_vals = st_n.get('neo_opt') or _init_neo_opt_from_defaults(None)
        work_x = target_xlsx
        if kd_n == 'excel' and work_x and st_n.get('xlsx') and os.path.abspath(work_x) == os.path.abspath(st_n['xlsx']):
            work_x = _ensure_editable_xlsx('excel')
        if work_x is None:
            if st_n.get('custom_xlsx') and os.path.isfile(st_n['custom_xlsx']):
                work_x = st_n['custom_xlsx']
            elif kd_n == 'revit' and st_n.get('rv_order'):
                work_x = _ensure_revit_work_xlsx()
            elif kd_n == 'excel' and st_n.get('xlsx') and os.path.isfile(st_n['xlsx']):
                work_x = _ensure_editable_xlsx('excel')
        if work_x and os.path.isfile(work_x):
            try:
                wb_u = read_xlsx_rows(work_x)
                _write_neo_opt_to_wb(wb_u, op_vals)
                write_simple_xlsx(work_x, _wb_to_sheets_ordered(wb_u))
                st_n['full_cache'].clear()
            except Exception:
                pass
        if not silent:
            mark_dirty(kd_n)
            lbl_status.ForeColor = c_emerald
            lbl_status.Text = u'✓ Đã áp dụng [%s · %s · %s | %s | %s | Neo Kéo:%s Nén:%s] cho Tab %s!' % (
                op_vals['std'], op_vals['concrete'], op_vals['steel'],
                op_vals['neo_mode'], op_vals['step_neo'], op_vals['neo_top'], op_vals['neo_bot'],
                u'Excel' if kd_n == 'excel' else u'Revit',
            )
        return op_vals

    def _ctx(tab_kind=None):
        if tab_kind == 'revit':
            return rv_state, split_views['revit'], 'revit'
        if tab_kind == 'excel':
            return ex_state, split_views['excel'], 'excel'
        if main_tabs.SelectedTab == tab_excel:
            return ex_state, split_views['excel'], 'excel'
        return rv_state, split_views['revit'], 'revit'

    def mark_dirty(tab_kind=None):
        st_d, _sv_d, _kd = _ctx(tab_kind)
        st_d['dirty'] = True
        st_d['beam_dxf'] = ''
        st_d['tk_dxf'] = ''
        if tab_kind is None or _ctx()[2] == _kd:
            lbl_status.ForeColor = c_slate600
            if _kd == 'revit':
                lbl_status.Text = u'[Tab Revit] Tick [✓ Vẽ] dầm muốn xuất, tick [Chỉ MC →] / [← Đầy đủ] để chuyển bên → Bấm Vẽ vào CAD.'
            else:
                lbl_status.Text = u'[Tab Excel] Tick [✓ Vẽ] dầm muốn xuất, tick [Chỉ MC →] / [← Đầy đủ] để chuyển bên → Bấm Vẽ vào CAD.'

    def _sync_revit_view_scales(force_apply=True):
        fresh = _read_revit_view_scales()
        view_cfg.clear()
        view_cfg.update(fresh)
        if force_apply and chk_rv_scale.Checked:
            lbl_rv_scale.Text = u'Nguồn tỉ lệ: %s' % view_cfg.get('view_scale_src', u'Mặc định (1/50 · 1/25)')
            tb_elev.Text = str(view_cfg.get('elev_scale', 50))
            tb_sec.Text = str(view_cfg.get('sec_scale', 25))
        else:
            lbl_rv_scale.Text = u'Mặc định: MC dọc 1/50 · MC ngang 1/25 · Cắt TK 50 (tick "Lấy theo View Revit" nếu muốn đồng bộ View)'
            tb_elev.Text = '50'
            tb_sec.Text = '25'

    def update_count(tab_kind=None):
        st_u, sv_u, kd_u = _ctx(tab_kind)
        n_tot = len(st_u['rows'])
        n_chk = len(st_u['checked'])
        n_mc = sum(1 for r in st_u['rows'] if st_u['modes'].get(r[0]) == 'MC_ONLY')
        n_full = n_tot - n_mc
        sv_u['lbl_count'].Text = u'Chọn vẽ: %d / %d dầm (Đầy đủ: %d · Chỉ MC: %d)' % (n_chk, n_tot, n_full, n_mc)
        sv_u['grp_full'].Text = u'BÊN TRÁI — DẦM VẼ [ĐẦY ĐỦ] (%d dầm)' % n_full
        sv_u['grp_mc'].Text = u'BÊN PHẢI — DẦM VẼ [CHỈ MẶT CẮT] (%d dầm)' % n_mc
        if _ctx()[2] == kd_u:
            btn_send_beam.Text = u'➡ Vẽ Bản vẽ Dầm vào CAD (%d)' % n_chk
            btn_send_tk.Text = u'➡ Vẽ Bảng TK vào CAD (%d)' % n_chk

    def populate_list(tab_kind=None):
        st_p, sv_p, kd_p = _ctx(tab_kind)
        q = sstr(sv_p['txt_search'].Text).lower()
        dgv_f = sv_p['dgv_full']
        dgv_m = sv_p['dgv_mc']
        st_p['populating'] = True
        dgv_f.SuspendLayout()
        dgv_m.SuspendLayout()
        try:
            dgv_f.Rows.Clear()
            dgv_m.Rows.Clear()
            for row in st_p['rows']:
                nm = row[0]
                if q and q not in nm.lower():
                    continue
                is_chk = (nm in st_p['checked'])
                sec_lbl = u'%s (%sn)' % (row[2], str(row[1]))
                if st_p['modes'].get(nm) == 'MC_ONLY':
                    ri = dgv_m.Rows.Add(is_chk, nm, sec_lbl, row[3], False)
                    dgv_m.Rows[ri].DefaultCellStyle.BackColor = Drawing.Color.FromArgb(255, 251, 235) if is_chk else Drawing.Color.White
                else:
                    ri = dgv_f.Rows.Add(is_chk, nm, sec_lbl, row[3], False)
                    dgv_f.Rows[ri].DefaultCellStyle.BackColor = Drawing.Color.FromArgb(240, 253, 244) if is_chk else Drawing.Color.White
            dgv_f.ClearSelection()
            dgv_m.ClearSelection()
        finally:
            dgv_f.ResumeLayout()
            dgv_m.ResumeLayout()
            st_p['populating'] = False
        update_count(kd_p)

    def _active_selected_beam(tab_kind=None):
        st_a, sv_a, _kd_a = _ctx(tab_kind)
        valid = set(r[0] for r in st_a['rows'])
        for dg in (sv_a['dgv_full'], sv_a['dgv_mc']):
            if dg.SelectedRows.Count > 0:
                bn = sstr(dg.SelectedRows[0].Cells[1].Value)
                if bn in valid:
                    return bn
            if dg.CurrentRow is not None:
                bn = sstr(dg.CurrentRow.Cells[1].Value)
                if bn in valid:
                    return bn
        last_b = sv_a.get('last_selected')
        if last_b in valid:
            return last_b
        return None

    # --- TAB 1 (REVIT) COMMON CROSS-SECTION & STIRRUP LOGIC ---
    def _selected_rv_sec_key():
        if dgv_rv_sec.CurrentRow is not None and 0 <= dgv_rv_sec.CurrentRow.Index < len(rv_state['sec_keys']):
            return rv_state['sec_keys'][dgv_rv_sec.CurrentRow.Index]
        if dgv_rv_sec.SelectedRows.Count > 0:
            ri = dgv_rv_sec.SelectedRows[0].Index
            if 0 <= ri < len(rv_state['sec_keys']):
                return rv_state['sec_keys'][ri]
        return rv_state['sec_keys'][0] if rv_state['sec_keys'] else None

    def _load_sec_rule_to_editor(sk):
        if not sk or sk not in rv_state['sec_rules']:
            lbl_sec_sel.Text = u'Chưa phát hiện tiết diện dầm Revit'
            return
        rule = rv_state['sec_rules'][sk]
        rv_state['sec_loading'] = True
        try:
            lbl_sec_sel.Text = u'Tiết diện: %s (%d dầm)' % (sk, len(rule.get('beams') or []))
            cbo_sec_sd.Text = str(int(round(rule.get('stir_d', 8))))
            a1 = int(round(rule.get('stir_a1', 100)))
            a2 = int(round(rule.get('stir_a2', 200)))
            tb_sec_a1.Text = str(a1)
            tb_sec_a2.Text = str(a2)
            chk_sec_uni.Checked = (a1 == a2)
            tb_sec_a2.Enabled = not chk_sec_uni.Checked
            tb_sec_cov.Text = str(int(round(rule.get('cover', 25.0))))
            tb_sec_tn.Text = str(int(round(rule.get('top_n', 2))))
            tb_sec_td.Text = str(int(round(rule.get('top_d', 18))))
            tb_sec_bn.Text = str(int(round(rule.get('bot_n', 2))))
            tb_sec_bd.Text = str(int(round(rule.get('bot_d', 18))))
            tb_sec_mn.Text = str(int(round(rule.get('mid_n', 0))))
            tb_sec_md.Text = str(int(round(rule.get('mid_d', 12))))
        finally:
            rv_state['sec_loading'] = False

    def _write_rule_to_dgv_row(row_idx, sk):
        rule = rv_state['sec_rules'].get(sk)
        if not rule or not (0 <= row_idx < dgv_rv_sec.Rows.Count):
            return
        row_g = dgv_rv_sec.Rows[row_idx]
        row_g.Cells[0].Value = sk
        row_g.Cells[1].Value = str(len(rule.get('beams') or []))
        row_g.Cells[2].Value = _fmt_rebar_quick_spec(rule['top_n'], rule['top_d'])
        row_g.Cells[3].Value = _fmt_rebar_quick_spec(rule['bot_n'], rule['bot_d'])
        row_g.Cells[4].Value = _fmt_rebar_quick_spec(rule['mid_n'], rule['mid_d'])
        row_g.Cells[5].Value = '%d-%d/%d' % (int(rule['stir_d']), int(rule['stir_a1']), int(rule['stir_a2']))
        row_g.Cells[6].Value = str(int(round(rule['cover'])))

    def populate_rv_sec_table():
        rv_state['sec_loading'] = True
        dgv_rv_sec.Rows.Clear()
        try:
            for idx_s, sk in enumerate(rv_state['sec_keys']):
                rule = rv_state['sec_rules'][sk]
                dgv_rv_sec.Rows.Add(
                    sk,
                    str(len(rule.get('beams') or [])),
                    _fmt_rebar_quick_spec(rule['top_n'], rule['top_d']),
                    _fmt_rebar_quick_spec(rule['bot_n'], rule['bot_d']),
                    _fmt_rebar_quick_spec(rule['mid_n'], rule['mid_d']),
                    '%d-%d/%d' % (int(rule['stir_d']), int(rule['stir_a1']), int(rule['stir_a2'])),
                    str(int(round(rule['cover'])))
                )
                dgv_rv_sec.Rows[idx_s].Cells[0].Style.BackColor = c_slate100
                dgv_rv_sec.Rows[idx_s].Cells[1].Style.BackColor = c_slate100
            if dgv_rv_sec.Rows.Count > 0:
                dgv_rv_sec.Rows[0].Selected = True
        finally:
            rv_state['sec_loading'] = False
        if rv_state['sec_keys']:
            _load_sec_rule_to_editor(rv_state['sec_keys'][0])
        else:
            _load_sec_rule_to_editor(None)

    def _ensure_revit_work_xlsx():
        if not rv_state['rv_order']:
            return ''
        out_dir = _get_out_dir()
        safe_doc = re.sub(r'[\\/:*?"<>|]+', '_', sstr(rv_state['doc_title']) or 'RevitModel')
        neo_ov = rv_state.get('neo_opt')
        if not rv_state['orig_xlsx'] or not os.path.isfile(rv_state['orig_xlsx']):
            orig_x = os.path.join(out_dir, 'Revit_Direct_%s_Orig.xlsx' % safe_doc)
            _write_revit_cache_to_xlsx(rv_state['rv_order'], rv_state['rv_grouped'], rv_state['rv_smap'], rv_state['rv_lvl'], orig_x, opt_override=neo_ov)
            rv_state['orig_xlsx'] = orig_x
        if not rv_state['custom_xlsx'] or not os.path.isfile(rv_state['custom_xlsx']):
            work_x = os.path.join(out_dir, 'Revit_Direct_%s_Work.xlsx' % safe_doc)
            _write_revit_cache_to_xlsx(rv_state['rv_order'], rv_state['rv_grouped'], rv_state['rv_smap'], rv_state['rv_lvl'], work_x, opt_override=neo_ov)
            rv_state['custom_xlsx'] = work_x
        return rv_state['custom_xlsx']

    def _sync_rv_work_xlsx(target_beams=None, force_all=False):
        if not rv_state['rv_order']:
            rv_state['rows'] = []
            rv_state['checked'] = set()
            populate_list('revit')
            return
        work_x = _ensure_revit_work_xlsx()
        if not work_x or not os.path.isfile(work_x):
            return
        if force_all:
            rv_state['manual_edited'].clear()
            rv_state['full_cache'].clear()
            eff_targets = None
        elif target_beams is not None:
            eff_targets = [b for b in target_beams if b not in rv_state['manual_edited']]
            if not eff_targets:
                return
        else:
            eff_targets = [b for b in rv_state['rv_order'] if b not in rv_state['manual_edited']]
        _upd_cnt, wb_out = _apply_revit_section_rules_to_xlsx(
            work_x,
            rv_state['sec_rules'],
            target_beams=eff_targets,
            keep_existing_3d=(rv_state['rebar_mode'] == '3d'),
            meta_map=rv_state['rv_meta'],
            return_wb=True,
        )
        prev_chk = set(rv_state['checked'])
        rv_state['rows'] = read_excel_beam_summaries_from_wb(wb_out) if wb_out else read_excel_beam_summaries(work_x)
        rv_state['modes'].update(read_excel_beam_modes_from_wb(wb_out) if wb_out else read_excel_beam_modes(work_x))
        all_names = set(r[0] for r in rv_state['rows'])
        rv_state['checked'] = (prev_chk & all_names)
        # Refresh cached FULL snapshots for applied targets
        for bnm in (eff_targets if eff_targets is not None else rv_state['rv_order']):
            rv_state['full_cache'].pop(bnm, None)
        populate_list('revit')
        mark_dirty('revit')

    def _set_scope_radio_silently(scope_val):
        rv_state['scope_loading'] = True
        try:
            rb_scope_view.Checked = (scope_val == 'view')
            rb_scope_pick.Checked = (scope_val == 'pick')
            rb_scope_proj.Checked = (scope_val == 'project')
            btn_rv_rescan.Text = u'⊕ Chọn & Quét dầm' if scope_val == 'pick' else u'↻ Quét lại Revit'
        finally:
            rv_state['scope_loading'] = False

    def init_revit_tab(rescan=False, scope=None, force_pick=False):
        sc_use = scope if scope in ('view', 'pick', 'project') else rv_state.get('scan_scope', 'view')
        if rescan:
            pick_eids_use = rv_state.get('pick_eids')
            if sc_use == 'pick':
                try:
                    uid_cur = __revit__.ActiveUIDocument if '__revit__' in globals() else None
                except Exception:
                    uid_cur = None
                if force_pick or not pick_eids_use:
                    pre_ids = []
                    if not force_pick and uid_cur is not None:
                        try:
                            doc_cur = uid_cur.Document
                            for eid_p in uid_cur.Selection.GetElementIds():
                                el_p = doc_cur.GetElement(eid_p)
                                cat_p = getattr(el_p, 'Category', None) if el_p is not None else None
                                if cat_p is not None and _eid_int(cat_p.Id) == int(DB.BuiltInCategory.OST_StructuralFraming):
                                    pre_ids.append(eid_p)
                        except Exception:
                            pre_ids = []
                    if pre_ids and not force_pick:
                        pick_eids_use = pre_ids
                    else:
                        picked = _pick_revit_beams_interactive(uid_cur, form=form)
                        if picked is None:
                            _set_scope_radio_silently(rv_state.get('scan_scope', 'view'))
                            lbl_status.ForeColor = c_slate600
                            lbl_status.Text = u'Đã hủy chọn dầm trên Revit.'
                            return
                        if not picked:
                            _set_scope_radio_silently(rv_state.get('scan_scope', 'view'))
                            WinForms.MessageBox.Show(form, u'Chưa có dầm (Structural Framing) nào được chọn.', u'Chọn dầm Revit')
                            return
                        pick_eids_use = picked
                rv_state['pick_eids'] = pick_eids_use
            else:
                pick_eids_use = None
                rv_state['pick_eids'] = None

            rv_state['scan_scope'] = sc_use
            _set_scope_radio_silently(sc_use)
            lbl_status.ForeColor = c_blue
            lbl_status.Text = u'⏳ Đang quét dữ liệu dầm / cột / sàn / cột cấy từ Revit...'
            WinForms.Application.DoEvents()

            ro, rg, rs, rl, dt, _dd = _collect_revit_model_data(scan_scope=sc_use, pick_eids=pick_eids_use)
            rm = dict(getattr(_collect_revit_model_data, '_last_meta', None) or {})
            snote = getattr(_collect_revit_model_data, '_last_scope_note', '') or sc_use
            rv_state['rv_order'] = ro
            rv_state['rv_grouped'] = rg
            rv_state['rv_summaries'] = rs
            rv_state['rv_smap'] = {s[0]: s[4] for s in rs}
            rv_state['rv_lvl'] = rl
            rv_state['rv_meta'] = rm
            rv_state['doc_title'] = dt
            rv_state['scope_note'] = snote
            rv_state['orig_xlsx'] = ''
            rv_state['custom_xlsx'] = ''
            rv_state['full_cache'].clear()
            rv_state['mc_cache'].clear()
            rv_state['modes'].clear()
            rv_state['manual_edited'].clear()
            rv_state['checked'] = set([s[0] for s in rs])
            lbl_rv_doc.Text = u'%s (%d dầm)' % (snote, len(rs))
            gr_rv = getattr(_collect_revit_model_data, '_last_grades', None)
            if isinstance(gr_rv, dict):
                op_rv = rv_state.get('neo_opt') or _init_neo_opt_from_defaults(gr_rv)
                if gr_rv.get('concrete'):
                    op_rv['concrete'] = _norm_concrete_grade(gr_rv['concrete'], op_rv.get('concrete', 'B25'))
                if gr_rv.get('steel'):
                    op_rv['steel'] = _norm_steel_grade(gr_rv['steel'], op_rv.get('steel', 'CB400-V'))
                if op_rv.get('std', u'TCVN 5574:2018') != u'Tùy chỉnh':
                    nt_r, nb_r, lp_r = _calc_tcvn_anchorage(op_rv.get('std', u'TCVN 5574:2018'), op_rv['concrete'], op_rv['steel'])
                    op_rv['neo_top'] = nt_r
                    op_rv['neo_bot'] = nb_r
                    op_rv['neo'] = nt_r
                    op_rv['lap'] = lp_r
                rv_state['neo_opt'] = op_rv
                if _ctx()[2] == 'revit':
                    _load_neo_opt_to_ui(op_rv)

        sec_keys, new_rules = _collect_unique_sections_from_rv(
            rv_state['rv_order'],
            meta_map=rv_state['rv_meta'],
            rv_grouped=rv_state['rv_grouped'],
            cover_mm=25.0,
        )
        if not rescan and rv_state['sec_rules']:
            for sk, r_new in new_rules.items():
                if sk in rv_state['sec_rules']:
                    rv_state['sec_rules'][sk]['beams'] = r_new['beams']
                else:
                    rv_state['sec_rules'][sk] = r_new
        else:
            rv_state['sec_rules'] = new_rules
        rv_state['sec_keys'] = sec_keys
        btn_rv_view_sec.Text = u'⚙ 1B. Thép Tiết diện chung (%d)' % len(sec_keys)
        populate_rv_sec_table()
        if rv_state['rv_order']:
            _sync_rv_work_xlsx(force_all=True)
            lbl_status.ForeColor = c_emerald
            lbl_status.Text = u'✓ Đã quét %d dầm · %d tiết diện chung [%s] (tách biệt với Tab Excel).' % (
                len(rv_state['rv_summaries']), len(sec_keys), rv_state.get('scope_note', '')
            )
        else:
            rv_state['rows'] = []
            populate_list('revit')

    def on_rv_save_sec(sender, args):
        try:
            dgv_rv_sec.EndEdit()
        except Exception:
            pass
        sk = _selected_rv_sec_key()
        if not sk or sk not in rv_state['sec_rules']:
            return
        rule = rv_state['sec_rules'][sk]
        sd_v = max(6, min(14, int(round(num(cbo_sec_sd.Text, 8)))))
        a1_v = max(50, min(600, int(round(num(tb_sec_a1.Text, 100)))))
        a2_v = a1_v if chk_sec_uni.Checked else max(50, min(600, int(round(num(tb_sec_a2.Text, 200)))))
        cov_v = max(15.0, min(80.0, num(tb_sec_cov.Text, 25.0)))
        tn_v = max(1, int(round(num(tb_sec_tn.Text, 2))))
        td_v = max(6, int(round(num(tb_sec_td.Text, 18))))
        bn_v = max(1, int(round(num(tb_sec_bn.Text, 2))))
        bd_v = max(6, int(round(num(tb_sec_bd.Text, 18))))
        mn_v = max(0, int(round(num(tb_sec_mn.Text, 0))))
        md_v = max(6, int(round(num(tb_sec_md.Text, 12))))

        rule.update({
            'stir_d': sd_v, 'stir_a1': a1_v, 'stir_a2': a2_v, 'cover': cov_v,
            'top_n': tn_v, 'top_d': td_v, 'bot_n': bn_v, 'bot_d': bd_v,
            'mid_n': mn_v, 'mid_d': md_v,
        })
        ri = rv_state['sec_keys'].index(sk)
        rv_state['sec_loading'] = True
        try:
            _write_rule_to_dgv_row(ri, sk)
        finally:
            rv_state['sec_loading'] = False
        _load_sec_rule_to_editor(sk)
        affected = list(rule.get('beams') or [])
        for bnm in affected:
            rv_state['manual_edited'].discard(bnm)
        _sync_rv_work_xlsx(target_beams=affected)
        lbl_status.ForeColor = c_emerald
        lbl_status.Text = u'✓ Đã cập nhật tiết diện [%s]: Trên %s · Dưới %s · Đai Ø%da%d/%d (%d dầm).' % (
            sk, _fmt_rebar_quick_spec(tn_v, td_v), _fmt_rebar_quick_spec(bn_v, bd_v), sd_v, a1_v, a2_v, len(affected)
        )

    def on_rv_sync_stir_all(sender, args):
        try:
            dgv_rv_sec.EndEdit()
        except Exception:
            pass
        if not rv_state['sec_keys']:
            return
        sd_v = max(6, min(14, int(round(num(cbo_sec_sd.Text, 8)))))
        a1_v = max(50, min(600, int(round(num(tb_sec_a1.Text, 100)))))
        a2_v = a1_v if chk_sec_uni.Checked else max(50, min(600, int(round(num(tb_sec_a2.Text, 200)))))
        cov_v = max(15.0, min(80.0, num(tb_sec_cov.Text, 25.0)))
        rv_state['sec_loading'] = True
        try:
            for ri, sk in enumerate(rv_state['sec_keys']):
                r_s = rv_state['sec_rules'][sk]
                r_s['stir_d'] = sd_v
                r_s['stir_a1'] = a1_v
                r_s['stir_a2'] = a2_v
                r_s['cover'] = cov_v
                _write_rule_to_dgv_row(ri, sk)
        finally:
            rv_state['sec_loading'] = False
        _sync_rv_work_xlsx(force_all=False)
        lbl_status.ForeColor = c_emerald
        lbl_status.Text = u'✓ Đã đồng bộ đai Ø%da%d/%d (BV %dmm) cho tất cả %d tiết diện!' % (sd_v, a1_v, a2_v, int(round(cov_v)), len(rv_state['sec_keys']))

    def on_rv_sec_cell_end(sender, args):
        if rv_state['sec_loading']:
            return
        ri = args.RowIndex
        if not (0 <= ri < len(rv_state['sec_keys'])):
            return
        sk = rv_state['sec_keys'][ri]
        rule = rv_state['sec_rules'][sk]
        row_g = dgv_rv_sec.Rows[ri]
        tn, td = _parse_rebar_quick_spec(row_g.Cells[2].Value, rule['top_n'], rule['top_d'], allow_zero=False)
        bn, bd = _parse_rebar_quick_spec(row_g.Cells[3].Value, rule['bot_n'], rule['bot_d'], allow_zero=False)
        mn, md = _parse_rebar_quick_spec(row_g.Cells[4].Value, rule['mid_n'], rule['mid_d'], allow_zero=True)
        sd, a1, a2 = parse_stir_spec(sstr(row_g.Cells[5].Value, '%d-%d/%d' % (rule['stir_d'], rule['stir_a1'], rule['stir_a2'])))
        cov = max(15.0, min(80.0, num(row_g.Cells[6].Value, rule['cover'])))
        rule.update({
            'top_n': tn, 'top_d': td, 'bot_n': bn, 'bot_d': bd,
            'mid_n': mn, 'mid_d': md, 'stir_d': sd, 'stir_a1': a1, 'stir_a2': a2, 'cover': cov,
        })
        rv_state['sec_loading'] = True
        try:
            _write_rule_to_dgv_row(ri, sk)
        finally:
            rv_state['sec_loading'] = False
        _load_sec_rule_to_editor(sk)
        affected = list(rule.get('beams') or [])
        for bnm in affected:
            rv_state['manual_edited'].discard(bnm)
        _sync_rv_work_xlsx(target_beams=affected)
        lbl_status.ForeColor = c_emerald
        lbl_status.Text = u'✓ Đã cập nhật tiết diện [%s] cho %d dầm Revit.' % (sk, len(affected))

    def on_rv_sec_sel_changed(sender, args):
        if rv_state['sec_loading']:
            return
        _load_sec_rule_to_editor(_selected_rv_sec_key())

    def on_rv_rebar_mode_changed(sender, args):
        if sender is not None and not sender.Checked:
            return
        rv_state['rebar_mode'] = '3d' if rb_rv_3d.Checked else 'sec'
        _sync_rv_work_xlsx(force_all=False)
        lbl_status.ForeColor = c_blue
        lbl_status.Text = (
            u'Chế độ Revit: Ưu tiên thép 3D trong mô hình, dầm chưa có thép 3D lấy theo Bảng Tiết diện chung.'
            if rv_state['rebar_mode'] == '3d' else
            u'Chế độ Revit: Toàn bộ dầm lấy thép & đai mặc định theo Bảng Tiết diện chung.'
        )

    def _set_rv_subview(view_name):
        is_sec = (view_name == 'sec')
        rv_state['sub_view'] = 'sec' if is_sec else 'list'
        split_views['revit']['wrap'].Visible = not is_sec
        pnl_rv_sec.Visible = is_sec
        btn_rv_view_list.BackColor = Drawing.Color.White if is_sec else c_blue
        btn_rv_view_list.ForeColor = c_blue if is_sec else Drawing.Color.White
        btn_rv_view_sec.BackColor = c_emerald if is_sec else Drawing.Color.White
        btn_rv_view_sec.ForeColor = Drawing.Color.White if is_sec else c_emerald
        if is_sec:
            lbl_status.ForeColor = c_blue
            lbl_status.Text = u'[1B. Bảng Tiết diện chung] Chỉnh thép Trên/Dưới/Giữa & Đai riêng → Bấm [⚡ Áp dụng toàn bộ & Xem Danh sách Dầm].'
        else:
            lbl_status.ForeColor = c_slate600
            lbl_status.Text = u'[1A. Danh sách Dầm 2 bên] Tick [✓ Vẽ] dầm muốn xuất, tick [Chỉ MC →] / [← Đầy đủ] để chuyển chế độ giữa 2 bên.'

    def on_rv_apply_sec(sender, args):
        try:
            dgv_rv_sec.EndEdit()
        except Exception:
            pass
        _sync_rv_work_xlsx(force_all=True)
        _set_rv_subview('list')
        lbl_status.ForeColor = c_emerald
        lbl_status.Text = u'✓ Đã áp dụng toàn bộ Bảng Tiết diện chung vào %d dầm Revit!' % len(rv_state['rows'])

    # --- TAB 2 (EXCEL) LOGIC — GIỮ NGUYÊN 100% ---
    def _load_excel_file(xlsx_file):
        ex_state['xlsx'] = xlsx_file
        ex_state['custom_xlsx'] = ''
        ex_state['full_cache'] = {}
        ex_state['mc_cache'] = {}
        txt_ex_path.Text = xlsx_file
        try:
            wb_xl = read_xlsx_rows(xlsx_file)
            opt_xl, _lvl_xl = _read_wb_opt_and_level(wb_xl)
            ex_state['neo_opt'] = dict((k, opt_xl.get(k)) for k in _NEO_OPT_KEYS)
            sums = read_excel_beam_summaries_from_wb(wb_xl)
            ex_state['modes'] = read_excel_beam_modes_from_wb(wb_xl)
        except Exception:
            sums = read_excel_beam_summaries(xlsx_file)
            ex_state['modes'] = read_excel_beam_modes(xlsx_file)
        ex_state['rows'] = sums
        ex_state['checked'] = set([s[0] for s in sums])
        if _ctx()[2] == 'excel':
            _load_neo_opt_to_ui(ex_state['neo_opt'])
        populate_list('excel')
        mark_dirty('excel')

    def pick_excel_and_load():
        dlg = WinForms.OpenFileDialog()
        dlg.Filter = 'Excel BeamRebar (*.xlsx)|*.xlsx'
        dlg.Title = u'Chọn file Excel Dam_*.xlsx'
        def_dir = os.path.join(os.path.expanduser('~'), 'Documents', 'BeamRebar')
        if os.path.isdir(def_dir):
            dlg.InitialDirectory = def_dir
        elif os.path.isdir(doc_dir):
            dlg.InitialDirectory = doc_dir
        if dlg.ShowDialog() == WinForms.DialogResult.OK:
            _load_excel_file(dlg.FileName)

    def on_all_tab(tab_kind=None):
        st_a, _sv_a, kd_a = _ctx(tab_kind)
        st_a['checked'] = set([r[0] for r in st_a['rows']])
        populate_list(kd_a)
        mark_dirty(kd_a)
        lbl_status.ForeColor = c_blue
        lbl_status.Text = u'✓ Đã chọn cả %d dầm để vẽ (%s).' % (len(st_a['checked']), u'Tab Excel' if kd_a == 'excel' else u'Tab Revit')

    def on_none_tab(tab_kind=None):
        st_n, _sv_n, kd_n = _ctx(tab_kind)
        st_n['checked'] = set()
        populate_list(kd_n)
        mark_dirty(kd_n)
        lbl_status.ForeColor = c_slate600
        lbl_status.Text = u'Đã bỏ chọn tất cả dầm — hãy tick [✓ Vẽ] từng dầm muốn vẽ hoặc bấm [☑ Chọn cả].'

    def on_pane_check(tab_kind, pane_mode, is_chk):
        st_p, _sv_p, kd_p = _ctx(tab_kind)
        for row in st_p['rows']:
            nm = row[0]
            cur_m = 'MC_ONLY' if st_p['modes'].get(nm) == 'MC_ONLY' else 'FULL'
            if cur_m == pane_mode:
                if is_chk:
                    st_p['checked'].add(nm)
                else:
                    st_p['checked'].discard(nm)
        populate_list(kd_p)
        mark_dirty(kd_p)

    def _pick_pane_move_targets(tab_kind, src_pane_mode):
        st_t, sv_t, _kd_t = _ctx(tab_kind)
        dg = sv_t['dgv_mc'] if src_pane_mode == 'MC_ONLY' else sv_t['dgv_full']
        if dg.SelectedRows.Count > 1:
            sel_nm = [sstr(rw.Cells[1].Value) for rw in dg.SelectedRows if sstr(rw.Cells[1].Value)]
            if sel_nm:
                return sel_nm
        vis_nm = [sstr(rw.Cells[1].Value) for rw in dg.Rows if sstr(rw.Cells[1].Value)]
        if vis_nm:
            return vis_nm
        return [r[0] for r in st_t['rows'] if ('MC_ONLY' if st_t['modes'].get(r[0]) == 'MC_ONLY' else 'FULL') == src_pane_mode]

    def _ensure_editable_xlsx(tab_kind=None):
        st_e, _sv_e, kd_e = _ctx(tab_kind)
        if kd_e == 'revit':
            return _ensure_revit_work_xlsx()
        if st_e['custom_xlsx'] and os.path.isfile(st_e['custom_xlsx']):
            return st_e['custom_xlsx']
        src_x = st_e['xlsx']
        if src_x and os.path.isfile(src_x):
            work_x = os.path.join(_get_out_dir(), 'BeamCAD_Work_%s' % os.path.basename(src_x))
            with io.open(src_x, 'rb') as _f_src, io.open(work_x, 'wb') as _f_dst:
                _f_dst.write(_f_src.read())
            st_e['custom_xlsx'] = work_x
            return work_x
        work_x = os.path.join(_get_out_dir(), 'BeamCAD_Scanned_Work.xlsx')
        st_e['xlsx'] = work_x
        st_e['custom_xlsx'] = work_x
        txt_ex_path.Text = work_x
        return work_x

    def _get_orig_full_snapshot(bname, tab_kind=None):
        st_g, _sv_g, kd_g = _ctx(tab_kind)
        if bname in st_g['full_cache']:
            return st_g['full_cache'][bname]
        if kd_g == 'excel' and st_g['xlsx'] and os.path.isfile(st_g['xlsx']):
            try:
                pl_orig = _load_beam_payload_from_xlsx(st_g['xlsx'], bname)
                snap = _snapshot_beam_style(pl_orig)
                st_g['full_cache'][bname] = snap
                return snap
            except Exception:
                return None
        if kd_g == 'revit' and st_g['rv_order']:
            try:
                _ensure_revit_work_xlsx()
                src_rv = st_g['orig_xlsx']
                pl_orig = _load_beam_payload_from_xlsx(src_rv, bname)
                if st_g['sec_rules']:
                    _apply_section_rule_to_payload(
                        pl_orig,
                        st_g['sec_rules'],
                        keep_existing_3d=(st_g['rebar_mode'] == '3d'),
                        m_rv=st_g['rv_meta'].get(bname),
                    )
                snap = _snapshot_beam_style(pl_orig)
                st_g['full_cache'][bname] = snap
                return snap
            except Exception:
                return None
        return None

    def _sync_mc_from_widget(src_kind):
        if mc_syncing['busy'] or src_kind not in mc_widgets:
            return
        w_src = mc_widgets[src_kind]
        mc_syncing['busy'] = True
        try:
            if w_src['chk_uni'].Checked:
                w_src['tb_a2'].Text = w_src['tb_a1'].Text
            mc_cfg_state['sd'] = sstr(w_src['cbo_sd'].Text) or '8'
            mc_cfg_state['a1'] = sstr(w_src['tb_a1'].Text) or '100'
            mc_cfg_state['a2'] = mc_cfg_state['a1'] if w_src['chk_uni'].Checked else (sstr(w_src['tb_a2'].Text) or '200')
            mc_cfg_state['uni'] = bool(w_src['chk_uni'].Checked)
            mc_cfg_state['cov'] = sstr(w_src['tb_cov'].Text) or '25'
            mc_cfg_state['sync_main'] = bool(w_src['chk_main'].Checked)
            mc_cfg_state['tn'] = sstr(w_src['tb_tn'].Text) or '2'
            mc_cfg_state['td'] = sstr(w_src['tb_td'].Text) or '18'
            mc_cfg_state['bn'] = sstr(w_src['tb_bn'].Text) or '2'
            mc_cfg_state['bd'] = sstr(w_src['tb_bd'].Text) or '18'
            mc_cfg_state['mn'] = sstr(w_src['tb_mn'].Text) or '0'
            mc_cfg_state['md'] = sstr(w_src['tb_md'].Text) or '12'
            st_txt = (u'Ø%sa%s' % (mc_cfg_state['sd'], mc_cfg_state['a1'])) if mc_cfg_state['a1'] == mc_cfg_state['a2'] else (u'Ø%sa%s/%s' % (mc_cfg_state['sd'], mc_cfg_state['a1'], mc_cfg_state['a2']))
            for k_w, w_t in mc_widgets.items():
                if k_w != src_kind:
                    w_t['cbo_sd'].Text = mc_cfg_state['sd']
                    w_t['tb_a1'].Text = mc_cfg_state['a1']
                    w_t['tb_a2'].Text = mc_cfg_state['a2']
                    w_t['chk_uni'].Checked = mc_cfg_state['uni']
                    w_t['tb_cov'].Text = mc_cfg_state['cov']
                    w_t['chk_main'].Checked = mc_cfg_state['sync_main']
                    w_t['tb_tn'].Text = mc_cfg_state['tn']
                    w_t['tb_td'].Text = mc_cfg_state['td']
                    w_t['tb_bn'].Text = mc_cfg_state['bn']
                    w_t['tb_bd'].Text = mc_cfg_state['bd']
                    w_t['tb_mn'].Text = mc_cfg_state['mn']
                    w_t['tb_md'].Text = mc_cfg_state['md']
                w_t['tb_a2'].Enabled = not mc_cfg_state['uni']
                w_t['lbl_prev'].Text = st_txt
                for _wm in (w_t['tb_tn'], w_t['tb_td'], w_t['tb_bn'], w_t['tb_bd'], w_t['tb_mn'], w_t['tb_md']):
                    _wm.Enabled = mc_cfg_state['sync_main']
        finally:
            mc_syncing['busy'] = False

    def _read_mc_tab_cfg(show_err=True, tab_kind=None):
        kd_cfg = tab_kind if tab_kind in mc_widgets else _ctx()[2]
        if kd_cfg in mc_widgets:
            _sync_mc_from_widget(kd_cfg)
        try:
            sd_new = max(6, min(14, int(round(num(mc_cfg_state['sd'], 8)))))
            a1_new = max(50, min(600, int(round(num(mc_cfg_state['a1'], 100)))))
            a2_new = a1_new if mc_cfg_state['uni'] else max(50, min(600, int(round(num(mc_cfg_state['a2'], 200)))))
            cov_new = max(15.0, min(80.0, num(mc_cfg_state['cov'], 25.0)))
            stir_new = '%d-%d/%d' % (sd_new, a1_new, a2_new)
            tn_new = max(1, int(round(num(mc_cfg_state['tn'], 2))))
            td_new = max(6, int(round(num(mc_cfg_state['td'], 18))))
            bn_new = max(1, int(round(num(mc_cfg_state['bn'], 2))))
            bd_new = max(6, int(round(num(mc_cfg_state['bd'], 18))))
            mn_new = max(0, int(round(num(mc_cfg_state['mn'], 0))))
            md_new = max(6, int(round(num(mc_cfg_state['md'], 12))))
            st_lbl = (u'Ø%da%d' % (sd_new, a1_new)) if a1_new == a2_new else (u'Ø%da%d/%d' % (sd_new, a1_new, a2_new))
            return {
                'sd': sd_new, 'a1': a1_new, 'a2': a2_new, 'cov': cov_new, 'stir': stir_new,
                'sync_main': bool(mc_cfg_state['sync_main']),
                'tn': tn_new, 'td': td_new, 'bn': bn_new, 'bd': bd_new, 'mn': mn_new, 'md': md_new,
                'st_lbl': st_lbl,
            }
        except Exception:
            if show_err:
                WinForms.MessageBox.Show(form, u'Thông số đai / thép trong khung [Setup Chỉ mặt cắt] không hợp lệ.', u'Lỗi nhập liệu')
            return None

    def _apply_mc_cfg_to_payload(pl_t, cfg_mc):
        if 'opt' not in pl_t or not isinstance(pl_t['opt'], dict):
            pl_t['opt'] = _default_beam_opt()
        pl_t['mode'] = 'MC_ONLY'
        pl_t['opt']['cover'] = cfg_mc['cov']
        pl_t['opt']['stir'] = float(cfg_mc['sd'])
        for sp_t in (pl_t.get('spans') or []):
            sp_t['stir'] = cfg_mc['stir']
        if cfg_mc['sync_main']:
            n_sp_t = max(1, len(pl_t.get('spans') or [1]))
            grps_t = [
                {'pos': u'Trên', 'layer': 1, 'n': cfg_mc['tn'], 'd': cfg_mc['td'], 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': n_sp_t, 'rk': u'Gập vào cột', 'rv': u'xuống', 'cross': u'Tự động', 'note': ''},
                {'pos': u'Dưới', 'layer': 1, 'n': cfg_mc['bn'], 'd': cfg_mc['bd'], 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': n_sp_t, 'rk': u'Gập vào cột', 'rv': u'xuống', 'cross': u'Tự động', 'note': ''},
            ]
            if cfg_mc['mn'] > 0:
                grps_t.append({'pos': u'Giữa', 'layer': 1, 'n': cfg_mc['mn'], 'd': cfg_mc['md'], 'a': 0, 'lk': u'Neo vào gối', 'lv': '30d', 'b': n_sp_t, 'rk': u'Neo vào gối', 'rv': '30d', 'cross': u'Tự động', 'note': u'Chống phình'})
            pl_t['grps'] = grps_t
        return pl_t

    def _apply_mc_tab_to_targets(targets, tab_kind=None):
        if not targets:
            return False
        st_m, _sv_m, kd_m = _ctx(tab_kind)
        cfg_mc = _read_mc_tab_cfg(show_err=True, tab_kind=kd_m)
        if not cfg_mc:
            return False
        try:
            work_x = _ensure_editable_xlsx(kd_m)
            if not work_x or not os.path.isfile(work_x):
                WinForms.MessageBox.Show(form, u'Chưa có dữ liệu dầm để áp dụng chế độ Chỉ mặt cắt.', u'Thiếu dữ liệu')
                return False

            def _mut_mc(tnm, pl_t):
                if pl_t.get('mode', 'FULL') != 'MC_ONLY' and tnm not in st_m['full_cache']:
                    st_m['full_cache'][tnm] = _snapshot_beam_style(pl_t)
                _apply_mc_cfg_to_payload(pl_t, cfg_mc)
                st_m['mc_cache'][tnm] = _snapshot_beam_style(pl_t)
                st_m['modes'][tnm] = 'MC_ONLY'
                st_m['manual_edited'].add(tnm)

            _cnt_mc, wb_out, save_errs = _batch_update_xlsx_payloads(work_x, targets, _mut_mc, work_x)
            if save_errs:
                WinForms.MessageBox.Show(form, u'Không lưu được một số dầm:\n%s' % u'\n'.join(save_errs[:6]), u'Cảnh báo BeamCAD')
            prev_chk = set(st_m['checked'])
            st_m['rows'] = read_excel_beam_summaries_from_wb(wb_out) if wb_out else read_excel_beam_summaries(work_x)
            st_m['modes'].update(read_excel_beam_modes_from_wb(wb_out) if wb_out else read_excel_beam_modes(work_x))
            st_m['checked'] = prev_chk & set(r[0] for r in st_m['rows'])
            populate_list(kd_m)
            mark_dirty(kd_m)
            lbl_status.ForeColor = c_emerald
            lbl_status.Text = u'✓ Đã chuyển %d dầm sang bên phải [Chỉ mặt cắt] (%s · BV %dmm)!' % (len(targets), cfg_mc['st_lbl'], int(round(cfg_mc['cov'])))
            return True
        except Exception as ex:
            WinForms.MessageBox.Show(form, u'Lỗi áp dụng Chỉ mặt cắt:\n%s' % sstr(ex), u'Lỗi BeamCAD')
            return False

    def _switch_beams_to_full(targets, tab_kind=None):
        if not targets:
            return
        st_f, _sv_f, kd_f = _ctx(tab_kind)
        work_x = _ensure_editable_xlsx(kd_f)
        if not work_x or not os.path.isfile(work_x):
            for nm in targets:
                st_f['modes'][nm] = 'FULL'
            populate_list(kd_f)
            mark_dirty(kd_f)
            return
        src_had_mc = []
        src_wb_cache = {}
        if kd_f == 'excel' and st_f['xlsx'] and os.path.isfile(st_f['xlsx']):
            try:
                src_wb_cache['wb'] = read_xlsx_rows(st_f['xlsx'])
            except Exception:
                src_wb_cache['wb'] = None
        elif kd_f == 'revit' and st_f['rv_order']:
            _ensure_revit_work_xlsx()
            if st_f.get('orig_xlsx') and os.path.isfile(st_f['orig_xlsx']):
                try:
                    src_wb_cache['wb'] = read_xlsx_rows(st_f['orig_xlsx'])
                except Exception:
                    src_wb_cache['wb'] = None

        def _mut_full(tnm, pl_cur):
            if pl_cur.get('mode') == 'MC_ONLY':
                st_f['mc_cache'][tnm] = _snapshot_beam_style(pl_cur)
            if tnm in st_f['full_cache']:
                snap_full = st_f['full_cache'][tnm]
            else:
                snap_full = None
                wb_src = src_wb_cache.get('wb')
                if wb_src is not None:
                    try:
                        pl_src = _extract_payload_from_wb(wb_src, tnm)
                        if kd_f == 'excel' and pl_src.get('mode') == 'MC_ONLY':
                            src_had_mc.append(tnm)
                        if kd_f == 'revit' and st_f['sec_rules']:
                            _apply_section_rule_to_payload(
                                pl_src,
                                st_f['sec_rules'],
                                keep_existing_3d=(st_f['rebar_mode'] == '3d'),
                                m_rv=st_f['rv_meta'].get(tnm),
                            )
                        snap_full = _snapshot_beam_style(pl_src)
                        st_f['full_cache'][tnm] = snap_full
                    except Exception:
                        snap_full = None
                if snap_full is None:
                    snap_full = _get_orig_full_snapshot(tnm, tab_kind=kd_f)
            if snap_full is not None:
                _restore_beam_style(pl_cur, snap_full, 'FULL')
            else:
                pl_cur['mode'] = 'FULL'
            st_f['modes'][tnm] = 'FULL'

        _cnt_fl, wb_out, full_errs = _batch_update_xlsx_payloads(work_x, targets, _mut_full, work_x)
        if full_errs:
            WinForms.MessageBox.Show(form, u'Lỗi khi chuyển sang [Đầy đủ]:\n%s' % u'\n'.join(full_errs[:6]), u'Cảnh báo BeamCAD')
        prev_chk = set(st_f['checked'])
        st_f['rows'] = read_excel_beam_summaries_from_wb(wb_out) if wb_out else read_excel_beam_summaries(work_x)
        st_f['modes'].update(read_excel_beam_modes_from_wb(wb_out) if wb_out else read_excel_beam_modes(work_x))
        for _tn in targets:
            st_f['modes'][_tn] = 'FULL'
        st_f['checked'] = prev_chk & set(r[0] for r in st_f['rows'])
        populate_list(kd_f)
        mark_dirty(kd_f)
        if src_had_mc:
            lbl_status.ForeColor = c_amber
            lbl_status.Text = u'⚠ Đã trả %d dầm về bên trái [Đầy đủ] — File Excel nguồn lưu sẵn thông số MC cũ cho %s.' % (len(targets), ', '.join(src_had_mc[:3]))
        else:
            lbl_status.ForeColor = c_emerald
            lbl_status.Text = u'✓ Đã trả %d dầm về bên trái [Đầy đủ] (thép gốc theo Excel/Revit)!' % len(targets)

    def _move_pane_bulk(tab_kind, src_pane_mode):
        targets = _pick_pane_move_targets(tab_kind, src_pane_mode)
        if not targets:
            WinForms.MessageBox.Show(form, u'Không có dầm nào ở cột này để chuyển.', u'Thông báo')
            return
        if src_pane_mode == 'MC_ONLY':
            _switch_beams_to_full(targets, tab_kind=tab_kind)
        else:
            _apply_mc_tab_to_targets(targets, tab_kind=tab_kind)

    def _on_apply_mc_inline(tab_kind):
        st_m, _sv_m, kd_m = _ctx(tab_kind)
        sv_m = split_views[kd_m]
        dg_m = sv_m['dgv_mc']
        if dg_m.SelectedRows.Count > 1:
            targets = [sstr(rw.Cells[1].Value) for rw in dg_m.SelectedRows if sstr(rw.Cells[1].Value)]
        else:
            targets = [r[0] for r in st_m['rows'] if st_m['modes'].get(r[0]) == 'MC_ONLY']
        if not targets:
            WinForms.MessageBox.Show(form, u'Chưa có dầm nào bên phải [Chỉ mặt cắt]. Hãy tick [Chỉ MC →] ở bảng bên trái để đẩy dầm sang.', u'Chưa có dầm Chỉ mặt cắt')
            return
        _apply_mc_tab_to_targets(targets, tab_kind=kd_m)

    def _open_beam_detail_editor(filter_beam=None, scan_payload=None, tab_kind=None):
        ctx_s, ctx_sv, ctx_kind = _ctx(tab_kind)
        try:
            work_xlsx = _ensure_editable_xlsx(ctx_kind)
            if scan_payload is not None:
                _save_beam_payload_to_xlsx(work_xlsx, scan_payload, scan_payload.get('bname'), work_xlsx)
                ctx_s['modes'][scan_payload.get('bname')] = scan_payload.get('mode', 'FULL')
                ctx_s['rows'] = read_excel_beam_summaries(work_xlsx)
                ctx_s['checked'].add(scan_payload.get('bname'))
                populate_list(ctx_kind)

            if not work_xlsx or not os.path.isfile(work_xlsx):
                WinForms.MessageBox.Show(form, u'Chưa có dữ liệu dầm. Hãy chọn file Excel hoặc dùng [🔍 Quét từ CAD].', u'Thiếu dữ liệu')
                return

            avail_beams = read_excel_beam_names(work_xlsx)
            if not avail_beams:
                WinForms.MessageBox.Show(form, u'Không có dầm nào trong dữ liệu.', u'Thiếu dữ liệu')
                return

            cur_bname = filter_beam
            if not cur_bname or cur_bname not in avail_beams:
                act_bn = _active_selected_beam(ctx_kind)
                if act_bn and act_bn in avail_beams:
                    cur_bname = act_bn
                else:
                    picked_chk = [b for b in avail_beams if b in ctx_s['checked']]
                    cur_bname = picked_chk[0] if picked_chk else avail_beams[0]

            dlg = WinForms.Form()
            dlg.Text = u'BeamCAD — Xem trực quan & Sửa chi tiết Dầm (Tiêu đề · Nhịp · Đai · Thép dọc · Neo/TCVN)'
            dlg.ClientSize = Drawing.Size(1240, 820)
            dlg.MinimumSize = Drawing.Size(1040, 700)
            dlg.StartPosition = WinForms.FormStartPosition.CenterParent
            dlg.FormBorderStyle = WinForms.FormBorderStyle.Sizable
            dlg.MaximizeBox = True
            dlg.MinimizeBox = True
            dlg.BackColor = Drawing.Color.White
            dlg.Font = Drawing.Font('Segoe UI', 9.75)

            pl_init = _load_beam_payload_from_xlsx(work_xlsx, cur_bname)
            ed_state = {
                'orig_bname': cur_bname,
                'payload': pl_init,
                'cur_mode': 'MC_ONLY' if pl_init.get('mode') == 'MC_ONLY' else 'FULL',
                'loading': False,
                'action': 'none',
            }

            tlp_dlg = _mk_tlp(
                [(WinForms.SizeType.Percent, 100)],
                [
                    (WinForms.SizeType.Absolute, 46),   # 0: Top selector
                    (WinForms.SizeType.Percent, 36),   # 1: Preview
                    (WinForms.SizeType.Percent, 64),   # 2: Tabs
                    (WinForms.SizeType.Absolute, 60),   # 3: Footer
                ],
                bg=Drawing.Color.White,
            )
            dlg.Controls.Add(tlp_dlg)

            # Top selector bar
            pnl_top = _mk_tlp(
                [(WinForms.SizeType.AutoSize, 0), (WinForms.SizeType.Absolute, 210), (WinForms.SizeType.Percent, 100)],
                [(WinForms.SizeType.Percent, 100)],
                pad=WinForms.Padding(12, 6, 12, 6),
                bg=c_slate100,
            )

            lbl_sel = WinForms.Label()
            lbl_sel.UseMnemonic = False
            lbl_sel.Text = u'Dầm đang sửa:'
            lbl_sel.Font = Drawing.Font('Segoe UI', 9.75, Drawing.FontStyle.Bold)
            lbl_sel.AutoSize = True
            lbl_sel.Margin = WinForms.Padding(0, 6, 8, 0)

            cbo_beam = WinForms.ComboBox()
            cbo_beam.DropDownStyle = WinForms.ComboBoxStyle.DropDownList
            cbo_beam.Dock = WinForms.DockStyle.Fill
            cbo_beam.Margin = WinForms.Padding(0, 2, 12, 0)
            cbo_beam.Font = Drawing.Font('Segoe UI', 9.75, Drawing.FontStyle.Bold)
            for _bn in avail_beams:
                cbo_beam.Items.Add(_bn)
            cbo_beam.SelectedItem = cur_bname

            lbl_sum_ed = WinForms.Label()
            lbl_sum_ed.UseMnemonic = False
            lbl_sum_ed.Dock = WinForms.DockStyle.Fill
            lbl_sum_ed.Text = ''
            lbl_sum_ed.TextAlign = Drawing.ContentAlignment.MiddleLeft
            lbl_sum_ed.ForeColor = c_blue
            lbl_sum_ed.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold)

            pnl_top.Controls.Add(lbl_sel, 0, 0)
            pnl_top.Controls.Add(cbo_beam, 1, 0)
            pnl_top.Controls.Add(lbl_sum_ed, 2, 0)
            tlp_dlg.Controls.Add(pnl_top, 0, 0)

            # Live CAD-style preview PictureBox
            pnl_prev_wrap = WinForms.Panel()
            pnl_prev_wrap.Dock = WinForms.DockStyle.Fill
            pnl_prev_wrap.Padding = WinForms.Padding(12, 6, 12, 4)
            pic_preview = WinForms.PictureBox()
            pic_preview.Dock = WinForms.DockStyle.Fill
            pic_preview.BackColor = Drawing.Color.FromArgb(15, 23, 42)
            pic_preview.BorderStyle = WinForms.BorderStyle.FixedSingle
            pnl_prev_wrap.Controls.Add(pic_preview)
            tlp_dlg.Controls.Add(pnl_prev_wrap, 0, 1)

            # Tabs
            pnl_ed_tabs = WinForms.Panel()
            pnl_ed_tabs.Dock = WinForms.DockStyle.Fill
            pnl_ed_tabs.Padding = WinForms.Padding(12, 4, 12, 6)
            tabs = WinForms.TabControl()
            tabs.Dock = WinForms.DockStyle.Fill
            tabs.Font = Drawing.Font('Segoe UI', 9.75, Drawing.FontStyle.Bold)

            tab_info = WinForms.TabPage(u'1. Tiêu đề · Neo/Kéo · Tiêu chuẩn')
            tab_info.BackColor = Drawing.Color.White
            tab_info.Font = Drawing.Font('Segoe UI', 9.5)
            tab_span = WinForms.TabPage(u'2. Kích thước Nhịp · Gối · Đai')
            tab_span.BackColor = Drawing.Color.White
            tab_span.Font = Drawing.Font('Segoe UI', 9.5)
            tab_rebar = WinForms.TabPage(u'3. Thép dọc & Gia cường')
            tab_rebar.BackColor = Drawing.Color.White
            tab_rebar.Font = Drawing.Font('Segoe UI', 9.5)
            tabs.TabPages.Add(tab_info)
            tabs.TabPages.Add(tab_span)
            tabs.TabPages.Add(tab_rebar)
            pnl_ed_tabs.Controls.Add(tabs)
            tlp_dlg.Controls.Add(pnl_ed_tabs, 0, 2)

            # --- Tab 1 Controls (Responsive 3-Column TableLayoutPanel + Full Neo/Kéo/TCVN) ---
            tlp_t1_outer = _mk_tlp(
                [(WinForms.SizeType.Percent, 100)],
                [(WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 36)],
                pad=WinForms.Padding(12, 10, 12, 8),
                bg=Drawing.Color.White,
            )
            tlp_t1_cols = _mk_tlp(
                [
                    (WinForms.SizeType.Percent, 33.3),
                    (WinForms.SizeType.Absolute, 16),
                    (WinForms.SizeType.Percent, 33.3),
                    (WinForms.SizeType.Absolute, 16),
                    (WinForms.SizeType.Percent, 33.4),
                ],
                [(WinForms.SizeType.Percent, 100)],
            )
            tlp_t1_outer.Controls.Add(tlp_t1_cols, 0, 0)

            def _mk_t1_grid(nrows):
                return _mk_tlp(
                    [(WinForms.SizeType.Absolute, 168), (WinForms.SizeType.Percent, 100)],
                    [(WinForms.SizeType.Absolute, 34) for _ in range(nrows)] + [(WinForms.SizeType.Percent, 100)],
                    pad=WinForms.Padding(4, 2, 4, 2),
                )

            def _t1_lbl(txt, bold=False, fg=None):
                l = WinForms.Label()
                l.UseMnemonic = False
                l.Text = txt
                l.Dock = WinForms.DockStyle.Fill
                l.TextAlign = Drawing.ContentAlignment.MiddleLeft
                l.ForeColor = fg if fg is not None else c_slate900
                l.Font = Drawing.Font('Segoe UI', 9.25, Drawing.FontStyle.Bold if bold else Drawing.FontStyle.Regular)
                return l

            def _t1_tb(val='', bold=False):
                t = WinForms.TextBox()
                t.Dock = WinForms.DockStyle.Fill
                t.Margin = WinForms.Padding(0, 4, 0, 4)
                t.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold if bold else Drawing.FontStyle.Regular)
                t.Text = sstr(val)
                return t

            def _t1_cbo(items, editable=False):
                c = WinForms.ComboBox()
                c.DropDownStyle = WinForms.ComboBoxStyle.DropDown if editable else WinForms.ComboBoxStyle.DropDownList
                c.Dock = WinForms.DockStyle.Fill
                c.Margin = WinForms.Padding(0, 3, 0, 3)
                c.Font = Drawing.Font('Segoe UI', 9.25)
                for _it in items:
                    c.Items.Add(_it)
                if c.Items.Count > 0 and not editable:
                    c.SelectedIndex = 0
                return c

            # Column 0: Thông tin chung & Tiêu chuẩn
            g_t1_0 = _mk_t1_grid(7)
            tb_bname = _t1_tb('', True)
            tb_sl = _t1_tb('1')
            cbo_mode_ed = _t1_cbo((u'Đầy đủ (Mặt đứng + Mặt cắt)', u'Chỉ 1 mặt cắt (Không vẽ MC dọc)'))
            tb_mat = _t1_tb('B25', True)
            cbo_ed_steel = _t1_cbo(_STEEL_GRADES)
            cbo_ed_std = _t1_cbo((u'TCVN 5574:2018', u'TCVN 5574:2012', u'Tùy chỉnh'))
            tb_lvl = _t1_tb('0')
            for r_i, (lb_t, ctrl_t) in enumerate((
                (_t1_lbl(u'Tên dầm (Tiêu đề):', True), tb_bname),
                (_t1_lbl(u'Số lượng (SL):'), tb_sl),
                (_t1_lbl(u'Chế độ vẽ:'), cbo_mode_ed),
                (_t1_lbl(u'Mác bê tông (BT):', True), tb_mat),
                (_t1_lbl(u'Nhóm thép chủ:'), cbo_ed_steel),
                (_t1_lbl(u'Tiêu chuẩn thiết kế:', True, c_blue), cbo_ed_std),
                (_t1_lbl(u'Cao độ tầng (mm):'), tb_lvl),
            )):
                g_t1_0.Controls.Add(lb_t, 0, r_i)
                g_t1_0.Controls.Add(ctrl_t, 1, r_i)
            tlp_t1_cols.Controls.Add(g_t1_0, 0, 0)

            # Column 1: Neo · Kéo · Cắt
            g_t1_1 = _mk_t1_grid(7)
            cbo_ed_neo_mode = _t1_cbo(_NEO_MODES)
            tb_cov = _t1_tb('30')
            tb_neo_top = _t1_tb('35d', True)
            tb_neo_bot = _t1_tb('25d', True)
            tb_neo = _t1_tb('35d')
            tb_ext = _t1_tb('L/4')
            tb_cut = _t1_tb('L/4')
            for r_i, (lb_t, ctrl_t) in enumerate((
                (_t1_lbl(u'Chế độ neo thép:', True, c_blue), cbo_ed_neo_mode),
                (_t1_lbl(u'Lớp bảo vệ BV (mm):'), tb_cov),
                (_t1_lbl(u'Neo Trên (kéo):', True), tb_neo_top),
                (_t1_lbl(u'Neo Dưới (nén):', True), tb_neo_bot),
                (_t1_lbl(u'Neo mặc định (khác):'), tb_neo),
                (_t1_lbl(u'Kéo dài ra nhịp (gối):'), tb_ext),
                (_t1_lbl(u'Cắt trong nhịp:'), tb_cut),
            )):
                g_t1_1.Controls.Add(lb_t, 0, r_i)
                g_t1_1.Controls.Add(ctrl_t, 1, r_i)
            tlp_t1_cols.Controls.Add(g_t1_1, 2, 0)

            # Column 2: Chênh cốt · Nối · Gập
            g_t1_2 = _mk_t1_grid(8)
            cbo_ed_step_neo = _t1_cbo(_STEP_NEO_MODES)
            tb_lap = _t1_tb('40d')
            tb_gap = _t1_tb(u'xuống')
            tb_pitch = _t1_tb('25')
            tb_straight = _t1_tb('0')
            tb_thr = _t1_tb('100')
            tb_slope = _t1_tb('6')
            chk_ed_tchook = WinForms.CheckBox()
            chk_ed_tchook.UseMnemonic = False
            chk_ed_tchook.Text = u'Thép tăng cường luôn gập vào cột'
            chk_ed_tchook.Dock = WinForms.DockStyle.Fill
            chk_ed_tchook.Font = Drawing.Font('Segoe UI', 9.0, Drawing.FontStyle.Bold)
            chk_ed_tchook.Checked = True
            for r_i, (lb_t, ctrl_t) in enumerate((
                (_t1_lbl(u'Neo dầm chênh cốt:', True, c_amber), cbo_ed_step_neo),
                (_t1_lbl(u'Chiều dài nối chồng:'), tb_lap),
                (_t1_lbl(u'Chiều dài gập đầu:'), tb_gap),
                (_t1_lbl(u'Khoảng hở lớp (mm):'), tb_pitch),
                (_t1_lbl(u'Chênh cao chạy thẳng:'), tb_straight),
                (_t1_lbl(u'Ngưỡng cắt neo (mm):'), tb_thr),
                (_t1_lbl(u'Độ dốc uốn (1:k):'), tb_slope),
            )):
                g_t1_2.Controls.Add(lb_t, 0, r_i)
                g_t1_2.Controls.Add(ctrl_t, 1, r_i)
            g_t1_2.Controls.Add(chk_ed_tchook, 0, 7)
            g_t1_2.SetColumnSpan(chk_ed_tchook, 2)
            tlp_t1_cols.Controls.Add(g_t1_2, 4, 0)

            lbl_tip_t1 = WinForms.Label()
            lbl_tip_t1.UseMnemonic = False
            lbl_tip_t1.Dock = WinForms.DockStyle.Fill
            lbl_tip_t1.Text = u'Mẹo: Chọn Tiêu chuẩn TCVN + Bê tông + Thép để tự tính chiều dài neo kéo/nén & nối. Bề rộng b đổi tự chạy thẳng; chênh cao tuân theo chế độ Neo dầm chênh cốt.'
            lbl_tip_t1.ForeColor = c_blue
            lbl_tip_t1.Font = Drawing.Font('Segoe UI', 9.0, Drawing.FontStyle.Bold)
            lbl_tip_t1.TextAlign = Drawing.ContentAlignment.MiddleLeft
            tlp_t1_outer.Controls.Add(lbl_tip_t1, 0, 1)
            tab_info.Controls.Add(tlp_t1_outer)

            # --- Tab 2 Controls (Spans, Supports, Stirrups, Planted cols) ---
            tlp_t2 = _mk_tlp(
                [(WinForms.SizeType.Percent, 100)],
                [(WinForms.SizeType.Absolute, 40), (WinForms.SizeType.Percent, 100)],
                pad=WinForms.Padding(8),
                bg=Drawing.Color.White,
            )
            pnl_sp_bar = _mk_tlp(
                [(WinForms.SizeType.AutoSize, 0), (WinForms.SizeType.Percent, 100)],
                [(WinForms.SizeType.Percent, 100)],
                pad=WinForms.Padding(4, 4, 8, 4),
                bg=c_slate100,
            )
            flp_sp_bar = WinForms.FlowLayoutPanel()
            flp_sp_bar.Dock = WinForms.DockStyle.Fill
            flp_sp_bar.WrapContents = False
            flp_sp_bar.AutoSize = True
            flp_sp_bar.Margin = WinForms.Padding(0)

            def _mk_mini_btn(txt, x, w, bg=None, fg=None):
                b = WinForms.Button()
                b.Text = txt
                b.UseMnemonic = False
                b.Size = Drawing.Size(w, 29)
                b.Margin = WinForms.Padding(0, 1, 6, 1)
                b.FlatStyle = WinForms.FlatStyle.Flat
                b.Font = Drawing.Font('Segoe UI', 8.75, Drawing.FontStyle.Bold)
                if bg is not None:
                    b.BackColor = bg
                if fg is not None:
                    b.ForeColor = fg
                return b

            btn_sp_add = _mk_mini_btn(u'+ Thêm nhịp', 0, 108, Drawing.Color.FromArgb(236, 253, 245), Drawing.Color.FromArgb(4, 120, 87))
            btn_sp_del = _mk_mini_btn(u'− Xóa nhịp cuối', 0, 124, Drawing.Color.FromArgb(254, 242, 242), Drawing.Color.FromArgb(185, 28, 28))
            btn_sp_sec = _mk_mini_btn(u'⇄ Đồng bộ b×h toàn dầm', 0, 184, Drawing.Color.White, c_slate900)
            btn_sp_stir = _mk_mini_btn(u'⇄ Đồng bộ Đai toàn dầm', 0, 184, Drawing.Color.White, c_slate900)
            for _c in (btn_sp_add, btn_sp_del, btn_sp_sec, btn_sp_stir):
                flp_sp_bar.Controls.Add(_c)

            lbl_sp_hint = WinForms.Label()
            lbl_sp_hint.UseMnemonic = False
            lbl_sp_hint.Dock = WinForms.DockStyle.Fill
            lbl_sp_hint.AutoEllipsis = True
            lbl_sp_hint.Text = u'Sửa b×h ở từng nhịp để làm dầm nhiều tiết diện; thép chủ tự chạy đều qua các nhịp.'
            lbl_sp_hint.TextAlign = Drawing.ContentAlignment.MiddleRight
            lbl_sp_hint.ForeColor = c_slate600
            lbl_sp_hint.Font = Drawing.Font('Segoe UI', 8.75)

            pnl_sp_bar.Controls.Add(flp_sp_bar, 0, 0)
            pnl_sp_bar.Controls.Add(lbl_sp_hint, 1, 0)
            tlp_t2.Controls.Add(pnl_sp_bar, 0, 0)

            dgv_sp = WinForms.DataGridView()
            dgv_sp.Dock = WinForms.DockStyle.Fill
            dgv_sp.Margin = WinForms.Padding(0, 6, 0, 0)
            dgv_sp.AllowUserToAddRows = False
            dgv_sp.AllowUserToDeleteRows = False
            dgv_sp.RowHeadersVisible = False
            dgv_sp.BackgroundColor = Drawing.Color.White
            dgv_sp.Font = Drawing.Font('Segoe UI', 9.25)
            dgv_sp.RowTemplate.Height = 28
            dgv_sp.ColumnHeadersHeight = 32
            dgv_sp.ColumnHeadersHeightSizeMode = WinForms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing

            def _dgv_tb(dg, hdr, w, ro=False, fill=False):
                c = WinForms.DataGridViewTextBoxColumn(); c.HeaderText = hdr; c.ReadOnly = ro
                if fill:
                    c.MinimumWidth = w
                    c.AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill
                else:
                    c.Width = w
                dg.Columns.Add(c)

            def _dgv_cb(dg, hdr, w, items):
                c = WinForms.DataGridViewComboBoxColumn(); c.HeaderText = hdr; c.Width = w
                for _it in items:
                    c.Items.Add(_it)
                dg.Columns.Add(c)

            _dgv_tb(dgv_sp, u'Nhịp', 48, True)
            _dgv_tb(dgv_sp, u'Gối T (mm)', 78)
            _dgv_cb(dgv_sp, u'Loại GT', 66, ['C', 'D'])
            _dgv_tb(dgv_sp, u'Trục T', 62)
            _dgv_tb(dgv_sp, u'L thông thủy', 98)
            _dgv_tb(dgv_sp, u'Gối P (mm)', 78)
            _dgv_cb(dgv_sp, u'Loại GP', 66, ['C', 'D'])
            _dgv_tb(dgv_sp, u'Trục P', 62)
            _dgv_tb(dgv_sp, u'b (mm)', 68)
            _dgv_tb(dgv_sp, u'h (mm)', 68)
            _dgv_tb(dgv_sp, u'Cao đỉnh', 76)
            _dgv_tb(dgv_sp, u'Sàn dày', 70)
            _dgv_tb(dgv_sp, u'Đai (Ø-a gối/nhịp)', 130, False, True)
            _dgv_tb(dgv_sp, u'Cột cấy (tên@vt@b)', 140, False, True)
            tlp_t2.Controls.Add(dgv_sp, 0, 1)
            tab_span.Controls.Add(tlp_t2)

            # --- Tab 3 Controls (Longitudinal Rebar & Extra Bars) ---
            tlp_t3 = _mk_tlp(
                [(WinForms.SizeType.Percent, 100)],
                [(WinForms.SizeType.Absolute, 40), (WinForms.SizeType.Percent, 100)],
                pad=WinForms.Padding(8),
                bg=Drawing.Color.White,
            )
            pnl_rb_bar = WinForms.FlowLayoutPanel()
            pnl_rb_bar.Dock = WinForms.DockStyle.Fill
            pnl_rb_bar.WrapContents = False
            pnl_rb_bar.Padding = WinForms.Padding(4, 4, 4, 4)
            pnl_rb_bar.BackColor = c_slate100

            btn_rb_top = _mk_mini_btn(u'+ Chủ Trên', 0, 102, Drawing.Color.FromArgb(254, 242, 242), Drawing.Color.FromArgb(185, 28, 28))
            btn_rb_bot = _mk_mini_btn(u'+ Chủ Dưới', 0, 102, Drawing.Color.FromArgb(254, 243, 199), Drawing.Color.FromArgb(146, 64, 14))
            btn_rb_tcg = _mk_mini_btn(u'+ Tăng cường Gối', 0, 140, Drawing.Color.FromArgb(239, 246, 255), c_blue)
            btn_rb_tcn = _mk_mini_btn(u'+ Tăng cường Nhịp', 0, 146, Drawing.Color.FromArgb(236, 253, 245), Drawing.Color.FromArgb(4, 120, 87))
            btn_rb_mid = _mk_mini_btn(u'+ Chống phình Giữa', 0, 152, Drawing.Color.White, c_slate900)
            btn_rb_dup = _mk_mini_btn(u'⧉ Nhân đôi dòng', 0, 128, Drawing.Color.White, c_slate900)
            btn_rb_del = _mk_mini_btn(u'− Xóa dòng', 0, 100, Drawing.Color.FromArgb(254, 242, 242), Drawing.Color.FromArgb(185, 28, 28))

            for _c in (btn_rb_top, btn_rb_bot, btn_rb_tcg, btn_rb_tcn, btn_rb_mid, btn_rb_dup, btn_rb_del):
                pnl_rb_bar.Controls.Add(_c)
            tlp_t3.Controls.Add(pnl_rb_bar, 0, 0)

            dgv_rb = WinForms.DataGridView()
            dgv_rb.Dock = WinForms.DockStyle.Fill
            dgv_rb.Margin = WinForms.Padding(0, 6, 0, 0)
            dgv_rb.AllowUserToAddRows = False
            dgv_rb.AllowUserToDeleteRows = False
            dgv_rb.RowHeadersVisible = False
            dgv_rb.BackgroundColor = Drawing.Color.White
            dgv_rb.Font = Drawing.Font('Segoe UI', 9.25)
            dgv_rb.RowTemplate.Height = 28
            dgv_rb.ColumnHeadersHeight = 32
            dgv_rb.ColumnHeadersHeightSizeMode = WinForms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing

            _end_choices = [u'Gập vào cột', u'Neo vào gối', u'Hết cột / đầu dầm', u'Giữa gối', u'Kéo dài ra nhịp', u'Cắt trong nhịp']
            _cross_choices = [u'Tự động', u'Luôn thẳng (nối liền)', u'Luôn uốn', u'Luôn neo (cắt)']
            _dgv_tb(dgv_rb, u'SH', 42, True)
            _dgv_cb(dgv_rb, u'Vị trí', 68, [u'Trên', u'Dưới', u'Giữa'])
            _dgv_cb(dgv_rb, u'Lớp', 52, ['1', '2', '3'])
            _dgv_tb(dgv_rb, u'SL', 46)
            _dgv_cb(dgv_rb, u'Phi', 56, ['6', '8', '10', '12', '14', '16', '18', '20', '22', '25', '28', '32'])
            _dgv_tb(dgv_rb, u'Gối A', 54)
            _dgv_cb(dgv_rb, u'Kiểu neo trái', 148, _end_choices)
            _dgv_tb(dgv_rb, u'GT trái', 74)
            _dgv_tb(dgv_rb, u'Gối B', 54)
            _dgv_cb(dgv_rb, u'Kiểu neo phải', 148, _end_choices)
            _dgv_tb(dgv_rb, u'GT phải', 74)
            _dgv_cb(dgv_rb, u'Qua gối', 156, _cross_choices)
            _dgv_tb(dgv_rb, u'Ghi chú', 120, False, True)
            tlp_t3.Controls.Add(dgv_rb, 0, 1)
            tab_rebar.Controls.Add(tlp_t3)

            # --- Bottom Action Bar ---
            pnl_ed_ftr = _mk_tlp(
                [
                    (WinForms.SizeType.AutoSize, 0),
                    (WinForms.SizeType.AutoSize, 0),
                    (WinForms.SizeType.AutoSize, 0),
                    (WinForms.SizeType.Percent, 100),
                    (WinForms.SizeType.AutoSize, 0),
                ],
                [(WinForms.SizeType.Percent, 100)],
                pad=WinForms.Padding(12, 10, 12, 10),
                bg=c_slate100,
            )

            btn_ed_save = _mk_tb_btn(u'✓ Lưu thay đổi', 0, 162, c_slate900, Drawing.Color.White, True, 0, 38, 9.5)
            btn_ed_save.FlatAppearance.BorderSize = 0
            btn_ed_draw_beam = _mk_tb_btn(u'➡ Lưu & Pick vẽ lại Dầm vào CAD', 0, 272, c_btn_blue, Drawing.Color.White, True, 0, 38, 9.5)
            btn_ed_draw_beam.FlatAppearance.BorderSize = 0
            btn_ed_draw_tk = _mk_tb_btn(u'📊 Lưu & Pick vẽ Bảng TK vào CAD', 0, 272, c_emerald, Drawing.Color.White, True, 0, 38, 9.5)
            btn_ed_draw_tk.FlatAppearance.BorderSize = 0
            btn_ed_close = _mk_tb_btn(u'Đóng', 0, 108, Drawing.Color.White, c_slate900, False, 0, 38, 9.5)

            for _b in (btn_ed_save, btn_ed_draw_beam, btn_ed_draw_tk, btn_ed_close):
                _b.Margin = WinForms.Padding(0, 0, 8, 0)
            btn_ed_close.Margin = WinForms.Padding(0)

            pnl_ed_ftr.Controls.Add(btn_ed_save, 0, 0)
            pnl_ed_ftr.Controls.Add(btn_ed_draw_beam, 1, 0)
            pnl_ed_ftr.Controls.Add(btn_ed_draw_tk, 2, 0)
            pnl_ed_ftr.Controls.Add(btn_ed_close, 4, 0)
            tlp_dlg.Controls.Add(pnl_ed_ftr, 0, 3)

            def _pull_ui_to_payload():
                pl = ed_state['payload']
                pl['bname'] = sstr(tb_bname.Text) or ed_state['orig_bname'] or 'D1'
                pl['sl'] = max(1, int(round(num(tb_sl.Text, 1))))
                pl['mode'] = 'MC_ONLY' if cbo_mode_ed.SelectedIndex == 1 else 'FULL'
                pl['mat'] = sstr(tb_mat.Text) or 'B25'
                pl['level_z'] = num(tb_lvl.Text, 0.0)
                op_e = pl['opt']
                op_e['std'] = _norm_std_name(cbo_ed_std.Text)
                op_e['concrete'] = _norm_concrete_grade(pl['mat'], op_e.get('concrete', 'B25'))
                op_e['steel'] = _norm_steel_grade(cbo_ed_steel.Text)
                op_e['neo_mode'] = _norm_neo_mode(cbo_ed_neo_mode.Text)
                op_e['step_neo'] = _norm_step_neo(cbo_ed_step_neo.Text)
                op_e['cover'] = max(10.0, num(tb_cov.Text, 30.0))
                op_e['neo_top'] = sstr(tb_neo_top.Text) or '35d'
                op_e['neo_bot'] = sstr(tb_neo_bot.Text) or '25d'
                op_e['neo'] = sstr(tb_neo.Text) or op_e['neo_top']
                op_e['ext'] = sstr(tb_ext.Text) or 'L/4'
                op_e['cut'] = sstr(tb_cut.Text) or 'L/4'
                op_e['lap'] = sstr(tb_lap.Text) or '40d'
                op_e['gap'] = sstr(tb_gap.Text) or u'xuống'
                op_e['pitch'] = max(15.0, num(tb_pitch.Text, 25.0))
                op_e['straight'] = max(0.0, num(tb_straight.Text, 0.0))
                op_e['thr'] = max(0.0, num(tb_thr.Text, 100.0))
                op_e['slope'] = max(1.0, num(tb_slope.Text, 6.0))
                op_e['tc_hook'] = 1.0 if chk_ed_tchook.Checked else 0.0

                new_spans = []
                new_sups = []
                for idx_r, row_g in enumerate(dgv_sp.Rows):
                    gt_w = max(0.0, num(row_g.Cells[1].Value, 220.0))
                    gt_k = sstr(row_g.Cells[2].Value) or 'C'
                    gt_g = sstr(row_g.Cells[3].Value)
                    cl_v = max(200.0, num(row_g.Cells[4].Value, 3000.0))
                    gp_w = max(0.0, num(row_g.Cells[5].Value, 220.0))
                    gp_k = sstr(row_g.Cells[6].Value) or 'C'
                    gp_g = sstr(row_g.Cells[7].Value)
                    bw_v = max(80.0, num(row_g.Cells[8].Value, 200.0))
                    bh_v = max(80.0, num(row_g.Cells[9].Value, 400.0))
                    top_v = num(row_g.Cells[10].Value, 0.0)
                    hs_v = max(0.0, num(row_g.Cells[11].Value, 120.0))
                    st_v = sstr(row_g.Cells[12].Value, '6-100/200') or '6-100/200'
                    pl_v = _parse_planted_str(row_g.Cells[13].Value)
                    if idx_r == 0:
                        old_s0 = pl['sups'][0] if pl.get('sups') else {}
                        new_sups.append({'w': gt_w, 'kind': gt_k, 'grid': gt_g, 'off': old_s0.get('off', 0.0), 'role': old_s0.get('role', '')})
                    old_sr = pl['sups'][idx_r + 1] if (pl.get('sups') and idx_r + 1 < len(pl['sups'])) else {}
                    new_sups.append({'w': gp_w, 'kind': gp_k, 'grid': gp_g, 'off': old_sr.get('off', 0.0), 'role': old_sr.get('role', '')})
                    new_spans.append({
                        'clear': cl_v, 'b': bw_v, 'h': bh_v, 'top': top_v,
                        'hs': hs_v, 'slabL': hs_v, 'slabL_top': top_v, 'slabR': hs_v, 'slabR_top': top_v,
                        'stir': st_v, 'planted': pl_v,
                    })
                if new_spans:
                    pl['spans'] = new_spans
                    pl['sups'] = new_sups

                n_sp = len(pl['spans'])
                new_grps = []
                for row_g in dgv_rb.Rows:
                    a_v = max(0, min(n_sp, int(round(num(row_g.Cells[5].Value, 0)))))
                    b_v = max(a_v, min(n_sp, int(round(num(row_g.Cells[8].Value, n_sp)))))
                    new_grps.append({
                        'pos': norm_pos(row_g.Cells[1].Value),
                        'layer': max(1, min(3, int(round(num(row_g.Cells[2].Value, 1))))),
                        'n': max(1, int(round(num(row_g.Cells[3].Value, 2)))),
                        'd': max(6, int(round(num(row_g.Cells[4].Value, 18)))),
                        'a': a_v,
                        'lk': norm_end(row_g.Cells[6].Value),
                        'lv': sstr(row_g.Cells[7].Value),
                        'b': b_v,
                        'rk': norm_end(row_g.Cells[9].Value),
                        'rv': sstr(row_g.Cells[10].Value),
                        'cross': norm_cross(row_g.Cells[11].Value),
                        'note': sstr(row_g.Cells[12].Value),
                    })
                pl['grps'] = new_grps
                return pl

            def _render_preview():
                try:
                    pl = ed_state['payload']
                    spans = pl.get('spans') or []
                    sups = pl.get('sups') or []
                    grps = pl.get('grps') or []
                    opt_p = pl.get('opt') or _default_beam_opt()
                    if not spans or pic_preview.Width < 50 or pic_preview.Height < 50:
                        return

                    W, H = int(pic_preview.Width), int(pic_preview.Height)
                    bmp = Drawing.Bitmap(W, H)
                    g2 = Drawing.Graphics.FromImage(bmp)
                    g2.SmoothingMode = Drawing.Drawing2D.SmoothingMode.AntiAlias
                    g2.TextRenderingHint = Drawing.Text.TextRenderingHint.ClearTypeGridFit
                    g2.Clear(Drawing.Color.FromArgb(15, 23, 42))

                    # Build CAD coordinate system (matching build_dxf_from_excel)
                    cx = 0.0
                    sx0, fl, fr = [], [], []
                    for i, sp in enumerate(spans):
                        sx0.append(cx)
                        cx += sups[i]['w']
                        fl.append(cx)
                        cx += sp['clear']
                        fr.append(cx)
                    sx0.append(cx)
                    if len(sups) > len(spans):
                        cx += sups[len(spans)]['w']
                    maxtop = max([sp['top'] for sp in spans] or [0.0])
                    maxh = max([(maxtop - sp['top'] + sp['h']) for sp in spans] or [400.0])
                    lay = {'n': len(spans), 'sx0': sx0, 'fl': fl, 'fr': fr, 'L': cx, 'maxtop': maxtop}

                    # Reserve right 28% of preview for unique cross-sections
                    sec_w_px = min(310.0, W * 0.28)
                    elev_w_px = W - sec_w_px - 36.0
                    sc_x = elev_w_px / max(1200.0, cx + 200.0)
                    sc_y = min(sc_x * 2.4, (H - 120.0) / max(320.0, maxh))
                    x0_px = 26.0
                    y0_px = 68.0  # top of highest beam
                    px = lambda vx: float(x0_px + vx * sc_x)
                    py = lambda vy: float(y0_px + vy * sc_y)

                    pen_grid = Drawing.Pen(Drawing.Color.FromArgb(100, 148, 163, 184), 1.0)
                    pen_grid.DashStyle = Drawing.Drawing2D.DashStyle.DashDot
                    pen_col = Drawing.Pen(Drawing.Color.FromArgb(148, 163, 184), 1.0)
                    br_col = Drawing.SolidBrush(Drawing.Color.FromArgb(30, 41, 59))
                    pen_beam = Drawing.Pen(Drawing.Color.FromArgb(34, 211, 238), 1.6)
                    pen_slab = Drawing.Pen(Drawing.Color.FromArgb(56, 189, 248), 1.0)
                    pen_slab.DashStyle = Drawing.Drawing2D.DashStyle.Dash
                    pen_stir = Drawing.Pen(Drawing.Color.FromArgb(192, 132, 252), 1.0)
                    pen_top = Drawing.Pen(Drawing.Color.FromArgb(248, 113, 113), 2.2)
                    pen_bot = Drawing.Pen(Drawing.Color.FromArgb(251, 191, 36), 2.2)
                    pen_mid = Drawing.Pen(Drawing.Color.FromArgb(96, 165, 250), 1.8)
                    pen_dim = Drawing.Pen(Drawing.Color.FromArgb(100, 116, 139), 1.0)
                    br_txt_dim = Drawing.SolidBrush(Drawing.Color.FromArgb(74, 222, 128))
                    br_txt_sh = Drawing.SolidBrush(Drawing.Color.FromArgb(250, 204, 21))
                    br_txt_w = Drawing.SolidBrush(Drawing.Color.FromArgb(241, 245, 249))
                    f_dim = Drawing.Font('Consolas', 7.5)
                    f_tag = Drawing.Font('Segoe UI', 7.5, Drawing.FontStyle.Bold)
                    f_title = Drawing.Font('Segoe UI', 8.5, Drawing.FontStyle.Bold)

                    # Draw Title
                    lvl_m = num(pl.get('level_z', 0.0), 0.0) / 1000.0
                    g2.DrawString(
                        u'DẦM %s (SL=%d · L=%d mm · Cao độ %+.3f · %s)' % (
                            pl['bname'], pl['sl'], int(round(cx)), lvl_m,
                            u'CHỈ 1 MẶT CẮT (KHÔNG VẼ MC DỌC)' if pl['mode'] == 'MC_ONLY' else u'ĐẦY ĐỦ'
                        ),
                        f_title, br_txt_w, 12.0, 6.0
                    )

                    # Supports & grids
                    bot_max_px = py(maxh)
                    for k, su in enumerate(sups):
                        if su['w'] > 0.5:
                            rx = px(sx0[k])
                            rw = max(4.0, (sx0[k] + su['w']) * sc_x - sx0[k] * sc_x)
                            g2.FillRectangle(br_col, rx, y0_px - 18.0, rw, (bot_max_px - y0_px) + 36.0)
                            g2.DrawRectangle(pen_col, rx, y0_px - 18.0, rw, (bot_max_px - y0_px) + 36.0)
                        gx = px(sx0[k] + su['w'] * 0.5 + su.get('off', 0.0))
                        if su.get('grid'):
                            g2.DrawLine(pen_grid, gx, y0_px - 24.0, gx, bot_max_px + 42.0)
                            g2.DrawEllipse(pen_col, gx - 9.0, bot_max_px + 42.0, 18.0, 18.0)
                            sz_g = g2.MeasureString(sstr(su['grid']), f_dim)
                            g2.DrawString(sstr(su['grid']), f_dim, br_txt_w, gx - sz_g.Width * 0.5, bot_max_px + 44.0)

                    # Spans, slabs, planted cols & top stirrup tags
                    for i, sp in enumerate(spans):
                        ty = py(maxtop - sp['top'])
                        by = py(maxtop - sp['top'] + sp['h'])
                        xL, xR = px(fl[i]), px(fr[i])
                        g2.DrawRectangle(pen_beam, xL, ty, max(2.0, xR - xL), max(4.0, by - ty))
                        if sp.get('hs', 0) > 0:
                            sy_s = py(maxtop - sp['top'] + sp['hs'])
                            g2.DrawLine(pen_slab, xL, sy_s, xR, sy_s)
                        for pcol in (sp.get('planted') or []):
                            pxc = px(fl[i] + num(pcol.get('pos', 1000.0)))
                            pw_px = max(4.0, num(pcol.get('w', 200.0)) * sc_x)
                            g2.FillRectangle(br_col, pxc - pw_px * 0.5, ty - 22.0, pw_px, 22.0)
                            g2.DrawRectangle(pen_col, pxc - pw_px * 0.5, ty - 22.0, pw_px, 22.0)

                        # Stirrup ticks & tag
                        sd, sa1, sa2 = parse_stir_spec(sp['stir'])
                        x_cur = fl[i] + 50.0
                        while x_cur < fr[i] - 30.0:
                            sx_p = px(x_cur)
                            g2.DrawLine(pen_stir, sx_p, ty + 2.0, sx_p, by - 2.0)
                            step_z = sa1 if (x_cur - fl[i] < sp['clear'] * 0.25 or fr[i] - x_cur < sp['clear'] * 0.25) else sa2
                            x_cur += max(120.0, step_z)
                        stir_lbl = u'Ø%da%d/%d' % (sd, sa1, sa2) if sa1 != sa2 else u'Ø%da%d' % (sd, sa1)
                        g2.DrawString(stir_lbl, f_dim, br_txt_dim, 0.5 * (xL + xR) - 24.0, ty - 16.0)
                        g2.DrawString(u'%d (%dx%d)' % (int(round(sp['clear'])), int(round(sp['b'])), int(round(sp['h']))),
                                      f_dim, br_txt_dim, 0.5 * (xL + xR) - 34.0, bot_max_px + 20.0)

                    # Bottom dim line
                    g2.DrawLine(pen_dim, px(0.0), bot_max_px + 18.0, px(cx), bot_max_px + 18.0)

                    # Longitudinal rebar polylines via build_group_polylines!
                    sh_idx = 1
                    top_tag_x = []
                    bot_tag_x = []
                    for g_item in grps:
                        polys = build_group_polylines(g_item, spans, sups, lay, opt_p, grps)
                        pen_use = pen_top if g_item['pos'] == u'Trên' else (pen_bot if g_item['pos'] == u'Dưới' else pen_mid)
                        for pts in polys:
                            if len(pts) < 2:
                                continue
                            pt_arr = [Drawing.PointF(px(pt[0]), py(pt[1])) for pt in pts]
                            for pi in range(len(pt_arr) - 1):
                                g2.DrawLine(pen_use, pt_arr[pi], pt_arr[pi + 1])
                            best_seg = max(zip(pts[:-1], pts[1:]), key=lambda ab: abs(ab[1][0] - ab[0][0]))
                            mx = px(0.5 * (best_seg[0][0] + best_seg[1][0]))
                            my = py(0.5 * (best_seg[0][1] + best_seg[1][1]))
                            lbl_rb = u'(%d) %dØ%d' % (sh_idx, g_item['n'], g_item['d'])
                            if g_item['pos'] == u'Trên':
                                lane = sum(1 for ux in top_tag_x if abs(ux - mx) < 75.0)
                                top_tag_x.append(mx)
                                ty_tg = y0_px - 30.0 - lane * 14.0
                                g2.DrawLine(pen_dim, mx, my, mx, ty_tg + 6.0)
                                g2.DrawString(lbl_rb, f_tag, br_txt_sh, mx - 18.0, ty_tg - 6.0)
                            elif g_item['pos'] == u'Dưới':
                                lane = sum(1 for ux in bot_tag_x if abs(ux - mx) < 75.0)
                                bot_tag_x.append(mx)
                                by_tg = bot_max_px + 4.0 + lane * 13.0
                                g2.DrawLine(pen_dim, mx, my, mx, by_tg)
                                g2.DrawString(lbl_rb, f_tag, br_txt_sh, mx - 18.0, by_tg)
                            else:
                                g2.DrawString(lbl_rb, f_tag, br_txt_sh, mx - 18.0, my - 7.0)
                            sh_idx += 1

                    # Draw unique cross-sections on right panel (strictly 1 MC in MC_ONLY mode)
                    uniq_secs = []
                    seen_sec = set()
                    for sp in spans:
                        sk = (int(round(sp['b'])), int(round(sp['h'])))
                        if sk not in seen_sec:
                            seen_sec.add(sk)
                            uniq_secs.append(sk)
                    max_sec_show = 1 if pl.get('mode') == 'MC_ONLY' else 2
                    sec_base_x = W - sec_w_px + 12.0
                    sec_slot_w = (sec_w_px - 24.0) / max(1, min(max_sec_show, len(uniq_secs)))
                    for si, (sb, sh) in enumerate(uniq_secs[:max_sec_show]):
                        sc_s = min((sec_slot_w - 44.0) / max(100.0, sb), (H - 108.0) / max(120.0, sh))
                        rw_s, rh_s = sb * sc_s, sh * sc_s
                        sx_l = sec_base_x + si * sec_slot_w + (sec_slot_w - rw_s) * 0.5
                        sy_t = 52.0
                        g2.DrawRectangle(pen_beam, sx_l, sy_t, rw_s, rh_s)
                        pad_s = max(4.0, opt_p.get('cover', 30.0) * sc_s)
                        g2.DrawRectangle(pen_stir, sx_l + pad_s, sy_t + pad_s, max(4.0, rw_s - 2 * pad_s), max(4.0, rh_s - 2 * pad_s))
                        # Rebar dots from layer-1 groups
                        top_n = sum(g_x['n'] for g_x in grps if g_x['pos'] == u'Trên' and g_x['layer'] == 1) or 2
                        bot_n = sum(g_x['n'] for g_x in grps if g_x['pos'] == u'Dưới' and g_x['layer'] == 1) or 2
                        for ni in range(min(6, top_n)):
                            dx_r = sx_l + pad_s + 3.0 + (0.5 if top_n == 1 else float(ni) / (min(6, top_n) - 1)) * max(4.0, rw_s - 2 * pad_s - 6.0)
                            g2.FillEllipse(Drawing.Brushes.OrangeRed, dx_r - 2.5, sy_t + pad_s + 1.0, 5.0, 5.0)
                        for ni in range(min(6, bot_n)):
                            dx_r = sx_l + pad_s + 3.0 + (0.5 if bot_n == 1 else float(ni) / (min(6, bot_n) - 1)) * max(4.0, rw_s - 2 * pad_s - 6.0)
                            g2.FillEllipse(Drawing.Brushes.Gold, dx_r - 2.5, sy_t + rh_s - pad_s - 6.0, 5.0, 5.0)
                        g2.DrawString(u'%d' % sb, f_dim, br_txt_dim, sx_l + rw_s * 0.5 - 12.0, sy_t + rh_s + 4.0)
                        g2.DrawString(u'%d' % sh, f_dim, br_txt_dim, sx_l + rw_s + 4.0, sy_t + rh_s * 0.5 - 6.0)
                        g2.DrawString(u'MC %d-%d' % (si + 1, si + 1), f_tag, br_txt_w, sx_l + rw_s * 0.5 - 20.0, sy_t + rh_s + 22.0)

                    # Update SH preview & header summary
                    tot_bars = max(0, sh_idx - 1)
                    lbl_sum_ed.Text = u'L = %d mm | %d nhịp | %d đoạn thép dọc | %s' % (
                        int(round(cx)), len(spans), tot_bars,
                        u'Quét từ AutoCAD' if pl.get('from_cad') else u'Dữ liệu Revit / Excel'
                    )
                    g2.Dispose()
                    old_img = pic_preview.Image
                    pic_preview.Image = bmp
                    if old_img is not None:
                        old_img.Dispose()
                except Exception:
                    pass

            def _load_payload_to_ui(pl):
                ed_state['loading'] = True
                try:
                    ed_state['payload'] = pl
                    ed_state['cur_mode'] = 'MC_ONLY' if pl.get('mode') == 'MC_ONLY' else 'FULL'
                    tb_bname.Text = sstr(pl.get('bname', ''))
                    tb_sl.Text = str(max(1, int(round(num(pl.get('sl', 1), 1)))))
                    cbo_mode_ed.SelectedIndex = 1 if ed_state['cur_mode'] == 'MC_ONLY' else 0
                    tb_mat.Text = sstr(pl.get('mat', 'B25')) or 'B25'
                    tb_lvl.Text = str(int(round(num(pl.get('level_z', 0.0), 0.0))))
                    op = pl.get('opt') or _default_beam_opt()
                    cbo_ed_std.Text = _norm_std_name(op.get('std', u'TCVN 5574:2018'))
                    cbo_ed_steel.Text = _norm_steel_grade(op.get('steel', 'CB400-V'))
                    cbo_ed_neo_mode.Text = _norm_neo_mode(op.get('neo_mode', _NEO_MODES[0]))
                    cbo_ed_step_neo.Text = _norm_step_neo(op.get('step_neo', _STEP_NEO_MODES[0]))
                    nt_d, nb_d, lp_d = _calc_tcvn_anchorage(cbo_ed_std.Text, _norm_concrete_grade(tb_mat.Text, op.get('concrete', 'B25')), cbo_ed_steel.Text)
                    tb_cov.Text = str(int(round(num(op.get('cover', 30.0), 30.0))))
                    tb_neo_top.Text = sstr(op.get('neo_top') or op.get('neo') or nt_d)
                    tb_neo_bot.Text = sstr(op.get('neo_bot') or op.get('neo') or nb_d)
                    tb_neo.Text = sstr(op.get('neo') or nt_d)
                    tb_ext.Text = sstr(op.get('ext', 'L/4'))
                    tb_cut.Text = sstr(op.get('cut', 'L/4'))
                    tb_lap.Text = sstr(op.get('lap') or lp_d)
                    tb_gap.Text = sstr(op.get('gap', u'xuống'))
                    tb_pitch.Text = str(int(round(num(op.get('pitch', 25.0), 25.0))))
                    tb_straight.Text = str(int(round(num(op.get('straight', 0.0), 0.0))))
                    tb_thr.Text = str(int(round(num(op.get('thr', 100.0), 100.0))))
                    tb_slope.Text = str(int(round(num(op.get('slope', 6.0), 6.0))))
                    chk_ed_tchook.Checked = bool(num(op.get('tc_hook', 1.0), 1.0) > 0.0)

                    dgv_sp.Rows.Clear()
                    sups = pl.get('sups') or []
                    for i, sp in enumerate(pl.get('spans') or []):
                        sL = sups[i] if i < len(sups) else {'w': 220.0, 'kind': 'C', 'grid': ''}
                        sR = sups[i + 1] if i + 1 < len(sups) else {'w': 220.0, 'kind': 'C', 'grid': ''}
                        dgv_sp.Rows.Add(
                            str(i + 1),
                            str(int(round(num(sL.get('w', 220.0))))),
                            'D' if sstr(sL.get('kind', 'C')).upper().startswith('D') else 'C',
                            sstr(sL.get('grid', '')),
                            str(int(round(num(sp.get('clear', 3000.0))))),
                            str(int(round(num(sR.get('w', 220.0))))),
                            'D' if sstr(sR.get('kind', 'C')).upper().startswith('D') else 'C',
                            sstr(sR.get('grid', '')),
                            str(int(round(num(sp.get('b', 200.0))))),
                            str(int(round(num(sp.get('h', 400.0))))),
                            str(int(round(num(sp.get('top', 0.0))))),
                            str(int(round(num(sp.get('hs', 120.0))))),
                            sstr(sp.get('stir', '6-100/200')),
                            _fmt_planted_str(sp.get('planted')),
                        )
                        dgv_sp.Rows[i].Cells[0].Style.BackColor = c_slate100

                    dgv_rb.Rows.Clear()
                    sh_c = 1
                    lay_t = {'n': len(pl.get('spans') or []), 'sx0': [], 'fl': [], 'fr': [], 'L': 0.0, 'maxtop': 0.0}
                    cx_t = 0.0
                    for si, sp in enumerate(pl.get('spans') or []):
                        lay_t['sx0'].append(cx_t)
                        cx_t += sups[si]['w'] if si < len(sups) else 220.0
                        lay_t['fl'].append(cx_t)
                        cx_t += sp['clear']
                        lay_t['fr'].append(cx_t)
                    lay_t['sx0'].append(cx_t)
                    lay_t['L'] = cx_t
                    for gi, g_item in enumerate(pl.get('grps') or []):
                        polys = build_group_polylines(g_item, pl.get('spans') or [], sups, lay_t, op, pl.get('grps'))
                        sh_disp = str(sh_c) if len(polys) <= 1 else ('%d-%d' % (sh_c, sh_c + len(polys) - 1))
                        sh_c += max(1, len(polys))
                        pos_v = norm_pos(g_item.get('pos', u'Trên'))
                        lay_v = str(max(1, min(3, int(round(num(g_item.get('layer', 1), 1))))))
                        phi_v = str(int(round(num(g_item.get('d', 18), 18))))
                        if phi_v not in ('6', '8', '10', '12', '14', '16', '18', '20', '22', '25', '28', '32'):
                            phi_v = '18'
                        lk_v = norm_end(g_item.get('lk', u'Gập vào cột'))
                        rk_v = norm_end(g_item.get('rk', u'Gập vào cột'))
                        cr_v = norm_cross(g_item.get('cross', u'Tự động'))
                        dgv_rb.Rows.Add(
                            sh_disp, pos_v, lay_v,
                            str(max(1, int(round(num(g_item.get('n', 2), 2))))),
                            phi_v,
                            str(int(round(num(g_item.get('a', 0), 0)))),
                            lk_v if lk_v in _end_choices else u'Gập vào cột',
                            sstr(g_item.get('lv', '')),
                            str(int(round(num(g_item.get('b', len(pl.get('spans') or [])), 1)))),
                            rk_v if rk_v in _end_choices else u'Gập vào cột',
                            sstr(g_item.get('rv', '')),
                            cr_v if cr_v in _cross_choices else u'Tự động',
                            sstr(g_item.get('note', '')),
                        )
                        dgv_rb.Rows[gi].Cells[0].Style.BackColor = c_slate100
                finally:
                    ed_state['loading'] = False
                _render_preview()

            def _on_any_ed_change(*_a):
                if ed_state['loading']:
                    return
                _pull_ui_to_payload()
                _render_preview()

            def _on_sp_cell_end(sender, args):
                if ed_state['loading']:
                    return
                r_i, c_i = args.RowIndex, args.ColumnIndex
                if 0 <= r_i < dgv_sp.Rows.Count:
                    ed_state['loading'] = True
                    try:
                        if c_i == 5 and r_i + 1 < dgv_sp.Rows.Count:
                            dgv_sp.Rows[r_i + 1].Cells[1].Value = dgv_sp.Rows[r_i].Cells[5].Value
                        elif c_i == 1 and r_i - 1 >= 0:
                            dgv_sp.Rows[r_i - 1].Cells[5].Value = dgv_sp.Rows[r_i].Cells[1].Value
                        elif c_i == 7 and r_i + 1 < dgv_sp.Rows.Count:
                            dgv_sp.Rows[r_i + 1].Cells[3].Value = dgv_sp.Rows[r_i].Cells[7].Value
                        elif c_i == 3 and r_i - 1 >= 0:
                            dgv_sp.Rows[r_i - 1].Cells[7].Value = dgv_sp.Rows[r_i].Cells[3].Value
                    finally:
                        ed_state['loading'] = False
                _on_any_ed_change()

            def _add_span_click(s, e):
                pl = _pull_ui_to_payload()
                last_sp = dict(pl['spans'][-1]) if pl['spans'] else {'clear': 3000.0, 'b': 200.0, 'h': 400.0, 'top': 0.0, 'hs': 120.0, 'slabL': 120.0, 'slabL_top': 0.0, 'slabR': 120.0, 'slabR_top': 0.0, 'stir': '6-100/200', 'planted': []}
                last_sp['planted'] = []
                pl['spans'].append(last_sp)
                pl['sups'].append({'w': pl['sups'][-1]['w'] if pl['sups'] else 220.0, 'kind': 'C', 'grid': str(len(pl['sups']) + 1), 'off': 0.0, 'role': ''})
                old_n = len(pl['spans']) - 1
                for gx in pl['grps']:
                    if gx['b'] == old_n and gx['rk'] in (u'Gập vào cột', u'Neo vào gối', u'Hết cột / đầu dầm'):
                        gx['b'] = len(pl['spans'])
                _load_payload_to_ui(pl)

            def _del_span_click(s, e):
                pl = _pull_ui_to_payload()
                if len(pl['spans']) <= 1:
                    WinForms.MessageBox.Show(dlg, u'Dầm phải có ít nhất 1 nhịp.', u'Không thể xóa')
                    return
                pl['spans'].pop()
                if len(pl['sups']) > len(pl['spans']) + 1:
                    pl['sups'].pop()
                n_sp = len(pl['spans'])
                for gx in pl['grps']:
                    gx['a'] = min(gx['a'], n_sp)
                    gx['b'] = max(gx['a'], min(gx['b'], n_sp))
                _load_payload_to_ui(pl)

            def _sync_bh_click(s, e):
                pl = _pull_ui_to_payload()
                if not pl['spans']:
                    return
                row_sel = dgv_sp.CurrentCell.RowIndex if dgv_sp.CurrentCell is not None else 0
                ref = pl['spans'][max(0, min(len(pl['spans']) - 1, row_sel))]
                for sp in pl['spans']:
                    sp['b'] = ref['b']
                    sp['h'] = ref['h']
                _load_payload_to_ui(pl)

            def _sync_stir_click(s, e):
                pl = _pull_ui_to_payload()
                if not pl['spans']:
                    return
                row_sel = dgv_sp.CurrentCell.RowIndex if dgv_sp.CurrentCell is not None else 0
                ref = pl['spans'][max(0, min(len(pl['spans']) - 1, row_sel))]
                for sp in pl['spans']:
                    sp['stir'] = ref['stir']
                _load_payload_to_ui(pl)

            def _add_rebar(kind):
                pl = _pull_ui_to_payload()
                n_sp = len(pl['spans'])
                cur_row = dgv_sp.CurrentCell.RowIndex if dgv_sp.CurrentCell is not None else 0
                if kind == 'top':
                    pl['grps'].append({'pos': u'Trên', 'layer': 1, 'n': 2, 'd': 18, 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': n_sp, 'rk': u'Gập vào cột', 'rv': u'xuống', 'cross': u'Tự động', 'note': u'Chủ trên'})
                elif kind == 'bot':
                    pl['grps'].append({'pos': u'Dưới', 'layer': 1, 'n': 2, 'd': 18, 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': n_sp, 'rk': u'Gập vào cột', 'rv': u'xuống', 'cross': u'Tự động', 'note': u'Chủ dưới'})
                elif kind == 'tc_goi':
                    goi_i = min(max(1, cur_row + 1), max(0, n_sp - 1)) if n_sp >= 2 else 0
                    if n_sp >= 2:
                        pl['grps'].append({'pos': u'Trên', 'layer': 2, 'n': 2, 'd': 18, 'a': goi_i, 'lk': u'Kéo dài ra nhịp', 'lv': 'L/4', 'b': goi_i, 'rk': u'Kéo dài ra nhịp', 'rv': 'L/4', 'cross': u'Tự động', 'note': u'TC gối'})
                    else:
                        pl['grps'].append({'pos': u'Trên', 'layer': 2, 'n': 2, 'd': 18, 'a': 0, 'lk': u'Gập vào cột', 'lv': u'xuống', 'b': 0, 'rk': u'Kéo dài ra nhịp', 'rv': 'L/4', 'cross': u'Tự động', 'note': u'TC gối'})
                elif kind == 'tc_nhip':
                    sp_idx = max(0, min(n_sp - 1, cur_row))
                    pl['grps'].append({'pos': u'Dưới', 'layer': 2, 'n': 2, 'd': 18, 'a': sp_idx, 'lk': u'Cắt trong nhịp', 'lv': '800', 'b': sp_idx + 1, 'rk': u'Cắt trong nhịp', 'rv': '800', 'cross': u'Tự động', 'note': u'TC nhịp'})
                elif kind == 'mid':
                    pl['grps'].append({'pos': u'Giữa', 'layer': 1, 'n': 2, 'd': 12, 'a': 0, 'lk': u'Neo vào gối', 'lv': '30d', 'b': n_sp, 'rk': u'Neo vào gối', 'rv': '30d', 'cross': u'Tự động', 'note': u'Chống phình'})
                _load_payload_to_ui(pl)

            def _dup_rebar(s, e):
                pl = _pull_ui_to_payload()
                if not pl['grps']:
                    return
                ri = dgv_rb.CurrentCell.RowIndex if dgv_rb.CurrentCell is not None else (len(pl['grps']) - 1)
                ri = max(0, min(len(pl['grps']) - 1, ri))
                pl['grps'].insert(ri + 1, dict(pl['grps'][ri]))
                _load_payload_to_ui(pl)

            def _del_rebar(s, e):
                pl = _pull_ui_to_payload()
                if not pl['grps']:
                    return
                ri = dgv_rb.CurrentCell.RowIndex if dgv_rb.CurrentCell is not None else (len(pl['grps']) - 1)
                if 0 <= ri < len(pl['grps']):
                    pl['grps'].pop(ri)
                _load_payload_to_ui(pl)

            def _commit_current_to_xlsx():
                pl = _pull_ui_to_payload()
                if pl.get('mode') == 'MC_ONLY':
                    ctx_s['mc_cache'][pl['bname']] = _snapshot_beam_style(pl)
                else:
                    ctx_s['full_cache'][pl['bname']] = _snapshot_beam_style(pl)
                _save_beam_payload_to_xlsx(work_xlsx, pl, ed_state['orig_bname'], work_xlsx)
                if ed_state['orig_bname'] and ed_state['orig_bname'] != pl['bname']:
                    ctx_s['checked'].discard(ed_state['orig_bname'])
                    ctx_s['modes'].pop(ed_state['orig_bname'], None)
                ed_state['orig_bname'] = pl['bname']
                ctx_s['modes'][pl['bname']] = pl['mode']
                ctx_s['checked'].add(pl['bname'])
                ctx_s['manual_edited'].add(pl['bname'])
                return pl['bname']

            def _on_cbo_beam_changed(s, e):
                if ed_state['loading']:
                    return
                nxt = sstr(cbo_beam.SelectedItem)
                if not nxt or nxt == ed_state['orig_bname']:
                    return
                _commit_current_to_xlsx()
                ed_state['orig_bname'] = nxt
                _load_payload_to_ui(_load_beam_payload_from_xlsx(work_xlsx, nxt))

            def _on_mode_ed_changed(*_a):
                if ed_state['loading']:
                    return
                new_mode = 'MC_ONLY' if cbo_mode_ed.SelectedIndex == 1 else 'FULL'
                old_mode = ed_state.get('cur_mode', 'FULL')
                if new_mode == old_mode:
                    _on_any_ed_change()
                    return
                ed_state['loading'] = True
                try:
                    cbo_mode_ed.SelectedIndex = 1 if old_mode == 'MC_ONLY' else 0
                    pl_cur = _pull_ui_to_payload()
                finally:
                    ed_state['loading'] = False
                bn = pl_cur.get('bname') or ed_state['orig_bname']
                if old_mode == 'FULL':
                    ctx_s['full_cache'][bn] = _snapshot_beam_style(pl_cur)
                else:
                    ctx_s['mc_cache'][bn] = _snapshot_beam_style(pl_cur)

                if new_mode == 'FULL':
                    snap_target = ctx_s['full_cache'].get(bn) or ctx_s['full_cache'].get(ed_state['orig_bname']) or _get_orig_full_snapshot(ed_state['orig_bname'], tab_kind=ctx_kind) or _get_orig_full_snapshot(bn, tab_kind=ctx_kind)
                    _restore_beam_style(pl_cur, snap_target, 'FULL')
                else:
                    snap_mc = ctx_s['mc_cache'].get(bn)
                    if snap_mc:
                        _restore_beam_style(pl_cur, snap_mc, 'MC_ONLY')
                    else:
                        cfg_mc_ed = _read_mc_tab_cfg(show_err=False)
                        if cfg_mc_ed:
                            _apply_mc_cfg_to_payload(pl_cur, cfg_mc_ed)
                        else:
                            pl_cur['mode'] = 'MC_ONLY'
                ed_state['cur_mode'] = new_mode
                _load_payload_to_ui(pl_cur)

            def _do_ed_action(act_name):
                saved_nm = _commit_current_to_xlsx()
                ed_state['action'] = act_name
                ed_state['saved_name'] = saved_nm
                dlg.DialogResult = WinForms.DialogResult.OK
                dlg.Close()

            def _on_ed_tcvn_change(*_a):
                if ed_state['loading']:
                    return
                std_e = _norm_std_name(cbo_ed_std.Text)
                if std_e != u'Tùy chỉnh':
                    conc_e = _norm_concrete_grade(tb_mat.Text, 'B25')
                    steel_e = _norm_steel_grade(cbo_ed_steel.Text, 'CB400-V')
                    nt_e, nb_e, lp_e = _calc_tcvn_anchorage(std_e, conc_e, steel_e)
                    ed_state['loading'] = True
                    try:
                        tb_neo_top.Text = nt_e
                        tb_neo_bot.Text = nb_e
                        tb_neo.Text = nt_e
                        tb_lap.Text = lp_e
                    finally:
                        ed_state['loading'] = False
                _on_any_ed_change()

            for _tb in (tb_bname, tb_sl, tb_lvl, tb_cov, tb_neo_top, tb_neo_bot, tb_neo, tb_ext, tb_cut, tb_lap, tb_gap, tb_pitch, tb_straight, tb_thr, tb_slope):
                _tb.TextChanged += _on_any_ed_change
            tb_mat.TextChanged += _on_ed_tcvn_change
            cbo_ed_std.SelectedIndexChanged += _on_ed_tcvn_change
            cbo_ed_steel.SelectedIndexChanged += _on_ed_tcvn_change
            cbo_ed_neo_mode.SelectedIndexChanged += _on_any_ed_change
            cbo_ed_step_neo.SelectedIndexChanged += _on_any_ed_change
            chk_ed_tchook.CheckedChanged += _on_any_ed_change
            cbo_mode_ed.SelectedIndexChanged += _on_mode_ed_changed
            cbo_beam.SelectedIndexChanged += _on_cbo_beam_changed
            pic_preview.SizeChanged += lambda s, e: _render_preview()
            dgv_sp.CellEndEdit += _on_sp_cell_end
            dgv_sp.CellValueChanged += _on_any_ed_change
            dgv_sp.CurrentCellDirtyStateChanged += lambda s, e: (dgv_sp.CommitEdit(WinForms.DataGridViewDataErrorContexts.Commit) if (dgv_sp.IsCurrentCellDirty and isinstance(dgv_sp.CurrentCell, WinForms.DataGridViewComboBoxCell)) else None)
            dgv_rb.CellValueChanged += _on_any_ed_change
            dgv_rb.CellEndEdit += _on_any_ed_change
            dgv_rb.CurrentCellDirtyStateChanged += lambda s, e: (dgv_rb.CommitEdit(WinForms.DataGridViewDataErrorContexts.Commit) if (dgv_rb.IsCurrentCellDirty and isinstance(dgv_rb.CurrentCell, WinForms.DataGridViewComboBoxCell)) else None)

            btn_sp_add.Click += _add_span_click
            btn_sp_del.Click += _del_span_click
            btn_sp_sec.Click += _sync_bh_click
            btn_sp_stir.Click += _sync_stir_click
            btn_rb_top.Click += lambda s, e: _add_rebar('top')
            btn_rb_bot.Click += lambda s, e: _add_rebar('bot')
            btn_rb_tcg.Click += lambda s, e: _add_rebar('tc_goi')
            btn_rb_tcn.Click += lambda s, e: _add_rebar('tc_nhip')
            btn_rb_mid.Click += lambda s, e: _add_rebar('mid')
            btn_rb_dup.Click += _dup_rebar
            btn_rb_del.Click += _del_rebar

            btn_ed_save.Click += lambda s, e: _do_ed_action('save')
            btn_ed_draw_beam.Click += lambda s, e: _do_ed_action('draw_beam')
            btn_ed_draw_tk.Click += lambda s, e: _do_ed_action('draw_tk')
            btn_ed_close.Click += lambda s, e: dlg.Close()

            _load_payload_to_ui(ed_state['payload'])
            res_dlg = dlg.ShowDialog(form)
            try:
                if pic_preview.Image is not None:
                    pic_preview.Image.Dispose()
                dlg.Dispose()
            except Exception:
                pass

            if res_dlg == WinForms.DialogResult.OK:
                prev_checked = set(ctx_s['checked'])
                ctx_s['rows'] = read_excel_beam_summaries(work_xlsx)
                ctx_s['modes'].update(read_excel_beam_modes(work_xlsx))
                ctx_s['checked'] = prev_checked & set(r[0] for r in ctx_s['rows'])
                if ed_state.get('saved_name'):
                    ctx_s['checked'].add(ed_state['saved_name'])
                saved_opt = (ed_state.get('payload') or {}).get('opt') or {}
                if saved_opt:
                    ctx_s['neo_opt'] = dict((k, saved_opt.get(k)) for k in _NEO_OPT_KEYS)
                    if ctx_kind == _ctx()[2]:
                        _load_neo_opt_to_ui(ctx_s['neo_opt'])
                populate_list(ctx_kind)
                mark_dirty(ctx_kind)
                lbl_status.ForeColor = c_emerald
                lbl_status.Text = u'✓ Đã lưu dầm [%s] — sẵn sàng vẽ lại vào CAD!' % sstr(ed_state.get('saved_name', ''))
                if ed_state['action'] == 'draw_beam':
                    send_part_to_cad('beam_dxf', tab_kind=ctx_kind)
                elif ed_state['action'] == 'draw_tk':
                    send_part_to_cad('tk_dxf', tab_kind=ctx_kind)
        except Exception as ex:
            WinForms.MessageBox.Show(form, u'Lỗi trình sửa chi tiết dầm:\n%s\n\n%s' % (sstr(ex), sstr(traceback.format_exc())), u'Lỗi BeamCAD')

    def parse_cfg():
        try:
            lim = max(1, int(sstr(tb_lim.Text) or 50))
            s_elev = max(5, int(sstr(tb_elev.Text) or 50))
            s_sec = max(5, int(sstr(tb_sec.Text) or 25))
            return lim, s_elev, s_sec
        except Exception:
            WinForms.MessageBox.Show(form, u'Vui lòng nhập số nguyên hợp lệ cho cắt bảng và tỉ lệ.', u'Lỗi nhập liệu', WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning)
            return None

    def generate_to_cad_payload(target_dxf, part='all', src_xlsx_override=None, tab_kind=None):
        st_g, _lv_g, kd_g = _ctx(tab_kind)
        cfg = parse_cfg()
        if cfg is None:
            return None
        lim, s_elev, s_sec = cfg
        sel = [r[0] for r in st_g['rows'] if r[0] in st_g['checked']]
        if not sel:
            WinForms.MessageBox.Show(form, u'Vui lòng chọn ít nhất 1 dầm để vẽ.', u'Chưa chọn dầm')
            return None
        if kd_g == 'revit':
            if src_xlsx_override and os.path.isfile(src_xlsx_override):
                src_use = src_xlsx_override
            elif st_g['custom_xlsx'] and os.path.isfile(st_g['custom_xlsx']):
                src_use = st_g['custom_xlsx']
            else:
                src_use = _ensure_revit_work_xlsx()
            if not src_use or not os.path.isfile(src_use):
                WinForms.MessageBox.Show(form, u'Không tìm thấy dầm nào trong mô hình Revit đang mở.', u'Thiếu dữ liệu Revit')
                return None
        else:
            if src_xlsx_override and os.path.isfile(src_xlsx_override):
                src_use = src_xlsx_override
            elif st_g['custom_xlsx'] and os.path.isfile(st_g['custom_xlsx']):
                src_use = st_g['custom_xlsx']
            elif st_g['xlsx'] and os.path.isfile(st_g['xlsx']):
                src_use = _ensure_editable_xlsx('excel')
            else:
                WinForms.MessageBox.Show(form, u'Vui lòng chọn file Excel Dam_*.xlsx hoặc quét dầm từ CAD trước.', u'Thiếu dữ liệu Excel')
                return None
        _apply_neo_opt_to_active_tab(tab_kind=kd_g, silent=True, target_xlsx=src_use)
        cnt, grand = build_dxf_from_excel(src_use, target_dxf, lim, s_elev, s_sec, sel, part=part, beam_modes=st_g['modes'])
        return cnt, grand, lim, s_elev, s_sec, src_use

    def build_split_payloads(tab_kind=None):
        st_p, _lv_p, kd_p = _ctx(tab_kind)
        out_dir = _get_out_dir()
        for _old_fn in os.listdir(out_dir):
            if _old_fn.lower().endswith(('.dxf', '.lsp')):
                try:
                    os.remove(os.path.join(out_dir, _old_fn))
                except Exception:
                    pass
        for _st_clr in (rv_state, ex_state):
            _st_clr['dirty'] = True
            _st_clr['beam_dxf'] = ''
            _st_clr['tk_dxf'] = ''

        stamp = time.strftime('%H%M%S')
        beam_dxf = os.path.join(out_dir, 'BeamCAD_BanVeDam_%s.dxf' % stamp)
        tk_dxf = os.path.join(out_dir, 'BeamCAD_BangTK_%s.dxf' % stamp)

        src_cache = None
        if kd_p == 'revit':
            sel = [r[0] for r in st_p['rows'] if r[0] in st_p['checked']]
            if not sel:
                WinForms.MessageBox.Show(form, u'Vui lòng chọn ít nhất 1 dầm Revit để vẽ.', u'Chưa chọn dầm')
                return None
            src_cache = st_p['custom_xlsx'] if (st_p['custom_xlsx'] and os.path.isfile(st_p['custom_xlsx'])) else _ensure_revit_work_xlsx()
        elif st_p['custom_xlsx'] and os.path.isfile(st_p['custom_xlsx']):
            src_cache = st_p['custom_xlsx']

        info_b = generate_to_cad_payload(beam_dxf, part='beam', src_xlsx_override=src_cache, tab_kind=kd_p)
        if not info_b:
            return None
        info_t = generate_to_cad_payload(tk_dxf, part='tk', src_xlsx_override=src_cache, tab_kind=kd_p)
        if not info_t:
            return None

        _write_beamcad_tools_lisp(out_dir)
        st_p['beam_dxf'] = beam_dxf
        st_p['tk_dxf'] = tk_dxf
        st_p['dirty'] = False
        return info_t

    def _on_cad_sent(st_cb, ok, err_msg, target_dxf, is_beam, title_vi, prompt_lbl):
        st_cb['sending'] = False
        try:
            if form.IsDisposed:
                return
            btn_send_beam.Enabled = True
            btn_send_tk.Enabled = True
            if ok:
                lbl_status.ForeColor = c_blue
                lbl_status.Text = (
                    u'➡ Đã gửi %s sang Model Space AutoCAD! Pick điểm chèn trong CAD rồi quay lại bấm [➡ Vẽ Bảng TK vào CAD].'
                    if is_beam else
                    u'➡ Đã gửi %s sang Model Space AutoCAD! Pick điểm chèn bảng trong CAD.'
                ) % title_vi
                _bring_cad_process_front()
            else:
                clip_cmd = _build_inline_pick_lisp(target_dxf, prompt_lbl)
                clip_ok = False
                try:
                    WinForms.Clipboard.SetText(clip_cmd)
                    clip_ok = True
                except Exception:
                    clip_ok = False
                lbl_status.ForeColor = c_slate900
                lbl_status.Text = u'⚠ Windows chặn COM — Đã copy lệnh Pick [%s] vào Clipboard (qua CAD: bấm vào dòng Command hoặc F2 → Ctrl+V → Enter).' % title_vi
                msg = (
                    u'%s\n\n'
                    u'• Bấm YES: Qua AutoCAD ngay — bấm vào ô Command ở dưới (hoặc phím F2) → Ctrl+V → Enter → Pick điểm chèn.\n'
                    u'• Bấm NO: Mở thẳng bản vẽ %s sang tab mới trong AutoCAD.\n'
                    u'• Bấm CANCEL: Đóng thông báo để quay lại BeamCAD.'
                ) % (err_msg, title_vi)
                if not clip_ok:
                    msg = (
                        u'%s\n\n'
                        u'• Bấm YES / NO: Mở thẳng bản vẽ %s sang tab mới trong AutoCAD.'
                    ) % (err_msg, title_vi)
                ans = WinForms.MessageBox.Show(
                    form,
                    msg,
                    u'Vẽ %s trong AutoCAD' % title_vi,
                    WinForms.MessageBoxButtons.YesNoCancel,
                    WinForms.MessageBoxIcon.Information
                )
                if ans == WinForms.DialogResult.Yes:
                    if clip_ok:
                        _bring_cad_process_front()
                    else:
                        os.startfile(target_dxf)
                elif ans == WinForms.DialogResult.No:
                    os.startfile(target_dxf)
        except Exception as ex_cb:
            try:
                if not form.IsDisposed:
                    WinForms.MessageBox.Show(form, u'Lỗi gửi CAD:\n%s' % sstr(ex_cb), u'Lỗi BeamCAD')
            except Exception:
                pass

    def send_part_to_cad(kind, tab_kind=None):
        st_s, _lv_s, kd_s = _ctx(tab_kind)
        if kd_s == 'revit':
            try:
                dgv_rv_sec.EndEdit()
            except Exception:
                pass
        if st_s['sending']:
            return
        try:
            if st_s['dirty'] or not st_s.get(kind) or not os.path.isfile(st_s[kind]):
                if not build_split_payloads(tab_kind=kd_s):
                    return
            target_dxf = st_s[kind]
            is_beam = (kind == 'beam_dxf')
            title_vi = u'BẢN VẼ DẦM' if is_beam else u'BẢNG THỐNG KÊ'
            prompt_lbl = u'ban ve dam' if is_beam else u'bang thong ke'
            cmd_str = u'\x03\x03' + _build_inline_pick_lisp(target_dxf, prompt_lbl) + u' \n'

            st_s['sending'] = True
            btn_send_beam.Enabled = False
            btn_send_tk.Enabled = False
            lbl_status.ForeColor = c_blue
            lbl_status.Text = u'⏳ Đang kết nối AutoCAD để Pick chèn %s...' % title_vi
            WinForms.Application.DoEvents()

            def _worker():
                ok_w, err_w = False, ''
                try:
                    ok_w, err_w = _send_cad_command(cmd_str)
                except Exception as ex_w:
                    ok_w, err_w = False, sstr(ex_w)
                try:
                    if not form.IsDisposed and form.IsHandleCreated:
                        form.BeginInvoke(System.Action(lambda: _on_cad_sent(st_s, ok_w, err_w, target_dxf, is_beam, title_vi, prompt_lbl)))
                    else:
                        st_s['sending'] = False
                except Exception:
                    st_s['sending'] = False

            from System.Threading import Thread, ThreadStart, ApartmentState
            th = Thread(ThreadStart(_worker))
            th.SetApartmentState(ApartmentState.STA)
            th.IsBackground = True
            th.Start()
        except Exception as ex:
            st_s['sending'] = False
            btn_send_beam.Enabled = True
            btn_send_tk.Enabled = True
            WinForms.MessageBox.Show(form, u'Lỗi:\n%s\n\n%s' % (sstr(ex), sstr(traceback.format_exc())), u'Lỗi BeamCAD')

    def _stop_cad_scan():
        ex_state['scanning'] = False
        if ex_state.get('scan_timer') is not None:
            try:
                ex_state['scan_timer'].Stop()
                ex_state['scan_timer'].Dispose()
            except Exception:
                pass
            ex_state['scan_timer'] = None
        if not form.IsDisposed:
            btn_ex_scan_cad.Text = u'🔍 Quét từ CAD'
            btn_ex_scan_cad.BackColor = Drawing.Color.FromArgb(239, 246, 255)
            btn_ex_scan_cad.ForeColor = Drawing.Color.FromArgb(30, 64, 175)

    def on_scan_cad(s, e):
        if ex_state['scanning']:
            _stop_cad_scan()
            lbl_status.ForeColor = c_slate600
            lbl_status.Text = u'Đã hủy chờ quét CAD.'
            return
        try:
            out_dir = _get_out_dir()
            tools_lsp = _write_beamcad_tools_lisp(out_dir)
            scan_json = os.path.join(out_dir, 'BeamCAD_ScanResult.json')
            for _p in (scan_json, scan_json + '.tmp'):
                if os.path.isfile(_p):
                    try:
                        os.remove(_p)
                    except Exception:
                        pass

            ex_state['scanning'] = True
            ex_state['scan_json'] = scan_json
            btn_ex_scan_cad.Text = u'✕ Hủy quét CAD'
            btn_ex_scan_cad.BackColor = Drawing.Color.FromArgb(254, 226, 226)
            btn_ex_scan_cad.ForeColor = Drawing.Color.FromArgb(185, 28, 28)
            lbl_status.ForeColor = c_blue
            lbl_status.Text = u'⏳ Qua AutoCAD quét chọn dầm cần sửa (nhấn Enter sau khi chọn)... hoặc gõ lệnh DAM_QUET trong CAD.'

            tm = WinForms.Timer()
            tm.Interval = 250

            def _on_scan_tick(_ts, _te):
                if not ex_state['scanning'] or form.IsDisposed:
                    _stop_cad_scan()
                    return
                if os.path.isfile(scan_json) and os.path.getsize(scan_json) > 10:
                    _stop_cad_scan()
                    try:
                        pl_scan = _parse_cad_scan_to_payload(scan_json)
                        try:
                            form.Activate()
                        except Exception:
                            pass
                        _open_beam_detail_editor(filter_beam=pl_scan['bname'], scan_payload=pl_scan, tab_kind='excel')
                    except Exception as ex_sc:
                        WinForms.MessageBox.Show(form, u'Lỗi đọc dữ liệu quét CAD:\n%s' % sstr(ex_sc), u'Lỗi Quét CAD')

            tm.Tick += _on_scan_tick
            ex_state['scan_timer'] = tm
            tm.Start()

            cmd_scan = u'\x03\x03(progn (if (and (not c:_BC_SCAN_BEAM) (findfile "%s")) (load "%s" nil)) (if c:_BC_SCAN_BEAM (c:_BC_SCAN_BEAM))) \n' % (tools_lsp, tools_lsp)

            def _scan_worker():
                ok_s, err_s = False, ''
                try:
                    ok_s, err_s = _send_cad_command(cmd_scan)
                except Exception as ex_sw:
                    ok_s, err_s = False, sstr(ex_sw)

                def _after_scan_send():
                    if form.IsDisposed or not ex_state['scanning']:
                        return
                    if ok_s:
                        _bring_cad_process_front()
                    else:
                        try:
                            WinForms.Clipboard.SetText(cmd_scan.strip())
                        except Exception:
                            pass
                        lbl_status.ForeColor = c_slate900
                        lbl_status.Text = u'⚠ Qua AutoCAD gõ DAM_QUET (hoặc Ctrl+V vào Command) rồi quét dầm & Enter — BeamCAD đang tự chờ kết quả!'

                try:
                    if not form.IsDisposed and form.IsHandleCreated:
                        form.BeginInvoke(System.Action(_after_scan_send))
                except Exception:
                    pass

            from System.Threading import Thread, ThreadStart, ApartmentState
            th = Thread(ThreadStart(_scan_worker))
            th.SetApartmentState(ApartmentState.STA)
            th.IsBackground = True
            th.Start()
        except Exception as ex:
            _stop_cad_scan()
            WinForms.MessageBox.Show(form, u'Lỗi khởi động quét CAD:\n%s' % sstr(ex), u'Lỗi BeamCAD')

    def on_read_view(s, e):
        chk_rv_scale.Checked = True
        _sync_revit_view_scales(force_apply=True)
        mark_dirty()

    def _on_tab_changed(s, e):
        prev_kd = ui_nav.get('data_tab')
        new_kd = 'excel' if main_tabs.SelectedTab == tab_excel else 'revit'
        if prev_kd in ('revit', 'excel') and prev_kd != new_kd and not ui_nav.get('neo_loading'):
            st_prev = rv_state if prev_kd == 'revit' else ex_state
            st_prev['neo_opt'] = _read_neo_opt_from_ui()
        ui_nav['data_tab'] = new_kd
        st_new = ex_state if new_kd == 'excel' else rv_state
        _load_neo_opt_to_ui(st_new.get('neo_opt') or _init_neo_opt_from_defaults(None))
        if new_kd == 'excel':
            update_count('excel')
            lbl_status.ForeColor = c_slate600
            lbl_status.Text = u'[Tab Excel] Tick [✓ Vẽ] dầm muốn xuất, tick [Chỉ MC →] / [← Đầy đủ] để chuyển bên → Bấm Vẽ vào CAD.'
        else:
            update_count('revit')
            _set_rv_subview(rv_state.get('sub_view', 'list'))

    def _on_chk_sec_uni_changed(s, e):
        if rv_state['sec_loading']:
            return
        if chk_sec_uni.Checked:
            tb_sec_a2.Text = tb_sec_a1.Text
        tb_sec_a2.Enabled = not chk_sec_uni.Checked

    def _on_sec_a1_changed(s, e):
        if rv_state['sec_loading']:
            return
        if chk_sec_uni.Checked:
            tb_sec_a2.Text = tb_sec_a1.Text

    def _move_one_beam(tab_kind, bname, src_pane_mode):
        if not bname or form.IsDisposed:
            return
        if src_pane_mode == 'FULL':
            _apply_mc_tab_to_targets([bname], tab_kind=tab_kind)
        else:
            _switch_beams_to_full([bname], tab_kind=tab_kind)

    def _bind_split_workspace_events(tab_kind):
        sv = split_views[tab_kind]
        mcw = mc_widgets[tab_kind]

        sv['txt_search'].TextChanged += lambda s, e, k=tab_kind: populate_list(k)
        sv['btn_sel_all'].Click += lambda s, e, k=tab_kind: on_all_tab(k)
        sv['btn_sel_none'].Click += lambda s, e, k=tab_kind: on_none_tab(k)
        sv['btn_edit'].Click += lambda s, e, k=tab_kind: _open_beam_detail_editor(_active_selected_beam(k), tab_kind=k)

        sv['btn_f_all'].Click += lambda s, e, k=tab_kind: on_pane_check(k, 'FULL', True)
        sv['btn_f_none'].Click += lambda s, e, k=tab_kind: on_pane_check(k, 'FULL', False)
        sv['btn_f_to_mc'].Click += lambda s, e, k=tab_kind: _move_pane_bulk(k, 'FULL')

        sv['btn_m_all'].Click += lambda s, e, k=tab_kind: on_pane_check(k, 'MC_ONLY', True)
        sv['btn_m_none'].Click += lambda s, e, k=tab_kind: on_pane_check(k, 'MC_ONLY', False)
        sv['btn_m_to_full'].Click += lambda s, e, k=tab_kind: _move_pane_bulk(k, 'MC_ONLY')

        def _attach_dgv(dg, pane_mode):
            def _on_dirty(sender, args):
                if sender.IsCurrentCellDirty:
                    sender.CommitEdit(WinForms.DataGridViewDataErrorContexts.Commit)

            def _on_val_chg(sender, args):
                st_c, sv_c, kd_c = _ctx(tab_kind)
                if st_c['populating'] or args.RowIndex < 0 or args.RowIndex >= sender.Rows.Count:
                    return
                row_g = sender.Rows[args.RowIndex]
                bn = sstr(row_g.Cells[1].Value)
                if not bn:
                    return
                if args.ColumnIndex == 0:
                    chk_v = bool(row_g.Cells[0].Value)
                    if chk_v:
                        st_c['checked'].add(bn)
                        row_g.DefaultCellStyle.BackColor = (
                            Drawing.Color.FromArgb(255, 251, 235)
                            if pane_mode == 'MC_ONLY' else
                            Drawing.Color.FromArgb(240, 253, 244)
                        )
                    else:
                        st_c['checked'].discard(bn)
                        row_g.DefaultCellStyle.BackColor = Drawing.Color.White
                    update_count(kd_c)
                    mark_dirty(kd_c)
                elif args.ColumnIndex == 4 and bool(row_g.Cells[4].Value):
                    if not form.IsDisposed and form.IsHandleCreated:
                        form.BeginInvoke(System.Action(lambda _b=bn, _k=tab_kind, _pm=pane_mode: _move_one_beam(_k, _b, _pm)))

            def _on_sel_chg(sender, args):
                if _ctx(tab_kind)[0]['populating']:
                    return
                if sender.CurrentRow is not None and 0 <= sender.CurrentRow.Index < sender.Rows.Count:
                    bn = sstr(sender.Rows[sender.CurrentRow.Index].Cells[1].Value)
                    if bn:
                        split_views[tab_kind]['last_selected'] = bn

            def _on_dbl_clk(sender, args):
                if args.RowIndex >= 0 and args.RowIndex < sender.Rows.Count:
                    bn = sstr(sender.Rows[args.RowIndex].Cells[1].Value)
                    if bn:
                        _open_beam_detail_editor(bn, tab_kind=tab_kind)

            dg.CurrentCellDirtyStateChanged += _on_dirty
            dg.CellValueChanged += _on_val_chg
            dg.SelectionChanged += _on_sel_chg
            dg.CellDoubleClick += _on_dbl_clk

        _attach_dgv(sv['dgv_full'], 'FULL')
        _attach_dgv(sv['dgv_mc'], 'MC_ONLY')

        mcw['chk_uni'].CheckedChanged += lambda s, e, k=tab_kind: _sync_mc_from_widget(k)
        mcw['cbo_sd'].TextChanged += lambda s, e, k=tab_kind: _sync_mc_from_widget(k)
        mcw['tb_a1'].TextChanged += lambda s, e, k=tab_kind: _sync_mc_from_widget(k)
        mcw['tb_a2'].TextChanged += lambda s, e, k=tab_kind: _sync_mc_from_widget(k)
        mcw['tb_cov'].TextChanged += lambda s, e, k=tab_kind: _sync_mc_from_widget(k)
        mcw['chk_main'].CheckedChanged += lambda s, e, k=tab_kind: _sync_mc_from_widget(k)
        for _tbm in (mcw['tb_tn'], mcw['tb_td'], mcw['tb_bn'], mcw['tb_bd'], mcw['tb_mn'], mcw['tb_md']):
            _tbm.TextChanged += lambda s, e, k=tab_kind: _sync_mc_from_widget(k)
        mcw['btn_apply_mc'].Click += lambda s, e, k=tab_kind: _on_apply_mc_inline(k)

    def _show_help_dialog(*_a):
        hdlg = WinForms.Form()
        hdlg.Text = u'Hướng dẫn sử dụng BeamCAD (Revit · Excel · Đầy đủ ⇄ Chỉ MC · TCVN Neo/Kéo)'
        hdlg.ClientSize = Drawing.Size(800, 560)
        hdlg.MinimumSize = Drawing.Size(680, 480)
        hdlg.StartPosition = WinForms.FormStartPosition.CenterParent
        hdlg.FormBorderStyle = WinForms.FormBorderStyle.Sizable
        hdlg.MaximizeBox = True
        hdlg.MinimizeBox = False
        hdlg.BackColor = Drawing.Color.White
        hdlg.Font = Drawing.Font('Segoe UI', 9.75)

        tlp_h = _mk_tlp(
            [(WinForms.SizeType.Percent, 100)],
            [(WinForms.SizeType.Percent, 100), (WinForms.SizeType.Absolute, 54)],
            pad=WinForms.Padding(14),
            bg=Drawing.Color.White,
        )
        tb_help = WinForms.TextBox()
        tb_help.Dock = WinForms.DockStyle.Fill
        tb_help.Multiline = True
        tb_help.ReadOnly = True
        tb_help.ScrollBars = WinForms.ScrollBars.Vertical
        tb_help.BackColor = c_slate100
        tb_help.ForeColor = c_slate900
        tb_help.Font = Drawing.Font('Segoe UI', 9.75)
        tb_help.Text = (
            u'HƯỚNG DẪN SỬ DỤNG NHANH BEAMCAD (GIAO DIỆN 2 BÊN TRỰC QUAN & TCVN NEO/KÉO)\r\n'
            u'==================================================================================\r\n\r\n'
            u'1. CHIA 2 BÊN RÕ RÀNG: [ĐẦY ĐỦ] ⇄ [CHỈ MẶT CẮT]\r\n'
            u'   • BÊN TRÁI là danh sách các dầm sẽ vẽ [ĐẦY ĐỦ] (Mặt đứng dọc + Mặt cắt ngang, giữ 100% thép Excel/Revit).\r\n'
            u'   • BÊN PHẢI là danh sách các dầm sẽ vẽ [CHỈ MẶT CẮT] (Chỉ vẽ 1 mặt cắt ngang, không vẽ MC dọc).\r\n'
            u'   • Đổi bên chỉ 1 cú click: tick [Chỉ MC →] ở bảng trái hoặc tick [← Đầy đủ] ở bảng phải.\r\n\r\n'
            u'2. SETUP [CHỈ MẶT CẮT] NẰM NGAY DƯỚI CỘT BÊN PHẢI\r\n'
            u'   • Chỉnh Đai Ø, a1/a2 (hoặc Đai đều), Lớp bảo vệ (BV), tùy chọn [Đồng bộ thép chủ MC].\r\n'
            u'   • Dầm đẩy sang phải sẽ nhận ngay thông số này, không hiện hộp thoại hỏi lại.\r\n\r\n'
            u'3. MỤC [3. CHẾ ĐỘ NEO · KÉO · TIÊU CHUẨN] (TCVN 5574:2018 / 2012)\r\n'
            u'   • Chọn Tiêu chuẩn + Mác bê tông (B15..B50) + Nhóm thép (CB240-T..CB500-V) để tự tính Neo Trên (kéo), Neo Dưới (nén) và Nối chồng.\r\n'
            u'   • Chế độ neo thép: [Tự động (gập khi thiếu)] | [Luôn gập vào cột (móc 90°)] | [Neo thẳng vào gối (Lan)].\r\n'
            u'   • Neo dầm chênh cốt (giật cấp): [Neo sang nhịp sâu (Lan)] (đo chuẩn từ mép gối vào nhịp sâu) hoặc [Gập vào cột (cắt tại gối)].\r\n'
            u'   • Kéo gối / Cắt nhịp / Gập / TC luôn gập cột được áp dụng đồng bộ ngay khi bấm [✓ Áp dụng Neo/TC] hoặc khi bấm Vẽ vào CAD.\r\n\r\n'
            u'4. CHỌN DẦM ĐỂ VẼ VÀO AUTOCAD & TAB ĐỘC LẬP\r\n'
            u'   • Chỉ vẽ những dầm được tick cột [Vẽ] (hoặc bấm [☑ Chọn cả (Vẽ cả)]). Cửa sổ hỗ trợ kéo giãn Toàn màn hình (Full Screen).\r\n'
            u'   • Nhấp đúp vào bất kỳ dầm nào để mở trình xem trước CAD & chỉnh từng nhịp/gối/thép tăng cường.\r\n'
            u'   • Lệnh AutoCAD hỗ trợ: DAM_SUA · DAM_QUET · DAM_THEP · DAM_DAI · DAM_TEN · DAM_QTK.'
        )

        btn_h_close = _mk_tb_btn(u'Đã hiểu — Đóng', 0, 168, c_blue, Drawing.Color.White, True, 0, 38, 9.75)
        btn_h_close.FlatAppearance.BorderSize = 0
        btn_h_close.Anchor = WinForms.AnchorStyles.Right
        btn_h_close.Click += lambda _s, _e: hdlg.Close()

        tlp_h.Controls.Add(tb_help, 0, 0)
        tlp_h.Controls.Add(btn_h_close, 0, 1)
        hdlg.Controls.Add(tlp_h)
        try:
            hdlg.ShowDialog(form)
        finally:
            try:
                hdlg.Dispose()
            except Exception:
                pass

    def _on_scope_radio_changed(scope_val, sender, args):
        if rv_state.get('scope_loading') or (sender is not None and not sender.Checked):
            return
        init_revit_tab(rescan=True, scope=scope_val, force_pick=False)

    def _on_rescan_click(sender, args):
        cur_sc = 'pick' if rb_scope_pick.Checked else ('project' if rb_scope_proj.Checked else 'view')
        init_revit_tab(rescan=True, scope=cur_sc, force_pick=(cur_sc == 'pick'))

    def _sync_neo_field_dirty(*_a):
        if ui_nav.get('neo_loading'):
            return
        _ctx()[0]['neo_opt'] = _read_neo_opt_from_ui()
        mark_dirty(_ctx()[2])

    # Bind Tab 1 (Revit) events
    btn_help.Click += _show_help_dialog
    rb_scope_view.CheckedChanged += lambda s, e: _on_scope_radio_changed('view', s, e)
    rb_scope_pick.CheckedChanged += lambda s, e: _on_scope_radio_changed('pick', s, e)
    rb_scope_proj.CheckedChanged += lambda s, e: _on_scope_radio_changed('project', s, e)
    btn_rv_view_list.Click += lambda s, e: _set_rv_subview('list')
    btn_rv_view_sec.Click += lambda s, e: _set_rv_subview('sec')
    dgv_rv_sec.SelectionChanged += on_rv_sec_sel_changed
    dgv_rv_sec.CellEndEdit += on_rv_sec_cell_end
    chk_sec_uni.CheckedChanged += _on_chk_sec_uni_changed
    tb_sec_a1.TextChanged += _on_sec_a1_changed
    btn_rv_save_sec.Click += on_rv_save_sec
    btn_rv_sync_stir.Click += on_rv_sync_stir_all
    btn_rv_apply_sec.Click += on_rv_apply_sec
    btn_rv_rescan.Click += _on_rescan_click
    rb_rv_sec.CheckedChanged += on_rv_rebar_mode_changed
    rb_rv_3d.CheckedChanged += on_rv_rebar_mode_changed
    _bind_split_workspace_events('revit')

    # Bind Tab 2 (Excel) events — 100% original workflow preserved
    btn_ex_browse.Click += lambda s, e: pick_excel_and_load()
    btn_ex_scan_cad.Click += on_scan_cad
    _bind_split_workspace_events('excel')
    _sync_mc_from_widget('revit')

    # Bind Neo · Kéo · Tiêu chuẩn events
    cbo_std.SelectedIndexChanged += _sync_neo_tcvn_fields
    cbo_conc.SelectedIndexChanged += _sync_neo_tcvn_fields
    cbo_steel.SelectedIndexChanged += _sync_neo_tcvn_fields
    cbo_neo_mode.SelectedIndexChanged += _sync_neo_field_dirty
    cbo_step_neo.SelectedIndexChanged += _sync_neo_field_dirty
    cbo_gap_g.TextChanged += _sync_neo_field_dirty
    chk_tc_hook.CheckedChanged += _sync_neo_field_dirty
    for _tbn in (tb_neo_top, tb_neo_bot, tb_ext_g, tb_cut_g, tb_lap_g):
        _tbn.TextChanged += _sync_neo_field_dirty
    btn_apply_neo.Click += lambda s, e: _apply_neo_opt_to_active_tab(silent=False)

    # Shared scale & footer events
    main_tabs.SelectedIndexChanged += _on_tab_changed
    tb_lim.TextChanged += lambda s, e: mark_dirty()
    tb_elev.TextChanged += lambda s, e: mark_dirty()
    tb_sec.TextChanged += lambda s, e: mark_dirty()
    chk_rv_scale.CheckedChanged += lambda s, e: (_sync_revit_view_scales(force_apply=True), mark_dirty())
    btn_read_view.Click += on_read_view
    btn_ftr_sel_all.Click += lambda s, e: on_all_tab()
    btn_ftr_sel_none.Click += lambda s, e: on_none_tab()
    btn_send_beam.Click += lambda s, e: send_part_to_cad('beam_dxf')
    btn_send_tk.Click += lambda s, e: send_part_to_cad('tk_dxf')
    btn_close.Click += lambda s, e: form.Close()

    init_revit_tab(rescan=False)
    ui_nav['data_tab'] = 'revit' if rv_summaries else 'excel'
    _load_neo_opt_to_ui((rv_state if rv_summaries else ex_state)['neo_opt'])
    main_tabs.SelectedTab = tab_revit if rv_summaries else tab_excel
    _on_tab_changed(None, None)

    try:
        owner_win = _resolve_safe_owner_window()
        if owner_win is not None:
            try:
                form.ShowDialog(owner_win)
            except Exception:
                form.ShowDialog()
        else:
            form.ShowDialog()
    finally:
        _stop_cad_scan()
        rv_state['sending'] = False
        ex_state['sending'] = False
        try:
            form.Dispose()
        except Exception:
            pass
        _collect_revit_model_data._last_meta = None
        _collect_revit_model_data._last_view_cfg = None
        rv_grouped.clear()
        rv_summaries[:] = []
        for _st_f in (rv_state, ex_state):
            _st_f['rows'][:] = []
            _st_f['modes'].clear()
            _st_f['full_cache'].clear()
            _st_f['mc_cache'].clear()
        _gc.collect()


if __name__ == '__main__':
    run_revit_export()
