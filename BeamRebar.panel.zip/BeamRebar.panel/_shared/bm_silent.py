# -*- coding: utf-8 -*-
"""Tat hoan toan cua so Output / thong bao cua pyRevit khi bat tools (Revit 2025 + pyRevit 7)."""
import io
import logging
import os
import sys
import warnings


class _SilentStream(io.TextIOBase):
    def __init__(self, log_errors=False):
        self._log_errors = log_errors
        self.encoding = 'utf-8'

    def writable(self):
        return True

    def isatty(self):
        return False

    def write(self, s):
        if self._log_errors and s and ('Traceback' in s or 'Error' in s):
            try:
                d = os.path.join(os.path.expanduser('~'), 'Documents', 'BeamRebar')
                if not os.path.isdir(d):
                    os.makedirs(d)
                with io.open(os.path.join(d, 'pyrevit_silent.log'), 'a', encoding='utf-8') as f:
                    f.write(s)
            except Exception:
                pass
        return len(s) if s else 0

    def flush(self):
        pass


_INSTALLED = False


def silence():
    global _INSTALLED
    try:
        warnings.filterwarnings('ignore')
    except Exception:
        pass
    try:
        logging.disable(logging.CRITICAL)
    except Exception:
        pass
    if not _INSTALLED:
        try:
            sys.stdout = _SilentStream(False)
            sys.stderr = _SilentStream(True)
            sys.__stdout__ = sys.stdout
            sys.__stderr__ = sys.stderr
        except Exception:
            pass
        _INSTALLED = True
    # Tat logger/toast cua pyRevit neu da duoc nap san trong bo nho
    for mod_name in ('pyrevit.coreutils.logger', 'pyrevit.output', 'pyrevit.forms', 'pyrevit.script'):
        mod = sys.modules.get(mod_name)
        if mod is None:
            continue
        try:
            if hasattr(mod, 'logger_has_errors'):
                mod.logger_has_errors = lambda *a, **kw: False
            if hasattr(mod, 'get_output'):
                out_obj = mod.get_output()
                if out_obj is not None and hasattr(out_obj, 'hide'):
                    out_obj.hide()
        except Exception:
            pass
    # Neu pyRevit tao san cua so output (__window__), an ngay lap tuc (ho tro ca WinForms va WPF)
    try:
        import builtins
        w = getattr(builtins, '__window__', None)
        if w is not None:
            if hasattr(w, 'Hide'):
                w.Hide()
            if hasattr(w, 'Visibility'):
                try:
                    import clr
                    clr.AddReference('PresentationCore')
                    from System.Windows import Visibility
                    w.Visibility = Visibility.Collapsed
                except Exception:
                    pass
    except Exception:
        pass

