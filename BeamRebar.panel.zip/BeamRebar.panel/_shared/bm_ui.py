# -*- coding: utf-8 -*-
"""Giao dien WinForms hien dai (Python 3 + WinForms): bang mau Sang / Toi, nut phang, luoi du lieu, tab ve tay."""
import clr
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
import System
from System.Windows.Forms import (FlatStyle, TabDrawMode, TabSizeMode, DataGridViewCellBorderStyle, BorderStyle,
                                  Appearance, Cursors, DataGridViewColumnHeadersHeightSizeMode)
from System.Drawing import Color, Font, FontStyle, SolidBrush, StringFormat, StringAlignment, RectangleF, Size, Point

F = System.Single

LIGHT = dict(name='light', bg=(241, 244, 249), panel=(255, 255, 255), text=(30, 41, 59), muted=(100, 116, 139),
             border=(208, 217, 230), accent=(37, 99, 235), accent_text=(255, 255, 255),
             head=(30, 41, 59), head_text=(255, 255, 255), btn=(229, 235, 245), btn_text=(30, 41, 59),
             btn_hover=(209, 220, 238), toggle_on=(191, 219, 254), input=(255, 255, 255),
             grid_head=(51, 65, 85), grid_head_text=(255, 255, 255), grid_alt=(246, 248, 252),
             grid_line=(226, 232, 240), sel=(255, 196, 110), sel_text=(15, 23, 42), ro=(238, 241, 246),
             tab_bg=(226, 232, 242))
DARK = dict(name='dark', bg=(24, 28, 36), panel=(33, 38, 49), text=(226, 232, 240), muted=(148, 163, 184),
            border=(55, 65, 81), accent=(96, 165, 250), accent_text=(15, 23, 42),
            head=(15, 18, 25), head_text=(226, 232, 240), btn=(51, 60, 77), btn_text=(226, 232, 240),
            btn_hover=(71, 85, 105), toggle_on=(51, 85, 140), input=(44, 51, 66),
            grid_head=(15, 18, 25), grid_head_text=(226, 232, 240), grid_alt=(38, 44, 56),
            grid_line=(55, 65, 81), sel=(176, 96, 12), sel_text=(255, 255, 255), ro=(46, 53, 68),
            tab_bg=(24, 28, 36))
CUR = [LIGHT]
_HOOKED = set()


def rgb(t):
    return Color.FromArgb(int(t[0]), int(t[1]), int(t[2]))


def darker(t, k=0.88):
    return tuple(int(v * k) for v in t)


def font(size=9.0, bold=False):
    return Font("Segoe UI", F(size), FontStyle.Bold if bold else FontStyle.Regular)


def style_button(b, pal, primary=False, toggle=False):
    b.FlatStyle = FlatStyle.Flat
    fa = b.FlatAppearance
    fa.BorderSize = 0
    bg = pal['accent'] if primary else pal['btn']
    b.BackColor = rgb(bg)
    b.ForeColor = rgb(pal['accent_text'] if primary else pal['btn_text'])
    fa.MouseOverBackColor = rgb(darker(bg, 0.9) if primary else pal['btn_hover'])
    fa.MouseDownBackColor = rgb(darker(bg, 0.8))
    if toggle:
        fa.CheckedBackColor = rgb(pal['toggle_on'])
    b.Cursor = Cursors.Hand


def style_grid(g, pal):
    g.EnableHeadersVisualStyles = False
    g.BorderStyle = getattr(BorderStyle, 'None')
    g.BackgroundColor = rgb(pal['panel'])
    g.GridColor = rgb(pal['grid_line'])
    g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
    g.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
    g.ColumnHeadersHeight = 30
    h = g.ColumnHeadersDefaultCellStyle
    h.BackColor = rgb(pal['grid_head'])
    h.ForeColor = rgb(pal['grid_head_text'])
    h.SelectionBackColor = rgb(pal['grid_head'])
    h.SelectionForeColor = rgb(pal['grid_head_text'])
    h.Font = font(9.0, True)
    d = g.DefaultCellStyle
    d.BackColor = rgb(pal['panel'])
    d.ForeColor = rgb(pal['text'])
    d.SelectionBackColor = rgb(pal['sel'])
    d.SelectionForeColor = rgb(pal['sel_text'])
    d.Font = font(9.0)
    g.AlternatingRowsDefaultCellStyle.BackColor = rgb(pal['grid_alt'])
    g.AlternatingRowsDefaultCellStyle.ForeColor = rgb(pal['text'])
    g.RowTemplate.Height = 26
    for c in g.Columns:                       # cot chi doc: nen xam nhat
        if c.ReadOnly:
            c.DefaultCellStyle.BackColor = rgb(pal['ro'])
            c.DefaultCellStyle.ForeColor = rgb(pal['muted'])


def _draw_tab(s, e):
    pal = CUR[0]
    g, b = e.Graphics, e.Bounds
    sel = (e.Index == s.SelectedIndex)
    bg = SolidBrush(rgb(pal['panel'] if sel else pal['tab_bg']))
    fg = SolidBrush(rgb(pal['accent'] if sel else pal['muted']))
    ac = SolidBrush(rgb(pal['accent']))
    sf = StringFormat()
    sf.Alignment = StringAlignment.Center
    sf.LineAlignment = StringAlignment.Center
    f = font(9.5, sel)
    try:
        g.FillRectangle(bg, F(b.X), F(b.Y), F(b.Width), F(b.Height))
        g.DrawString(s.TabPages[e.Index].Text, f, fg, RectangleF(F(b.X), F(b.Y), F(b.Width), F(b.Height)), sf)
        if sel:
            g.FillRectangle(ac, F(b.X), F(b.Y + b.Height - 3), F(b.Width), F(3))
    finally:
        for o in (bg, fg, ac, sf, f):
            o.Dispose()


def style_tabs(tc, pal):
    # ve tieu de tab mac dinh cua WinForms (OwnerDraw truoc day lam tieu de tab bi trang)
    tc.DrawMode = TabDrawMode.Normal
    tc.SizeMode = TabSizeMode.Normal
    tc.Padding = Point(16, 5)
    tc.Font = font(9.5, True)
    tc.Invalidate()


def apply(ctrl, pal, role=None):
    """Ap bang mau cho control va toan bo control con (goi lai khi doi Sang/Toi)."""
    CUR[0] = pal
    n = ctrl.GetType().Name
    try:
        tag = str(ctrl.Tag) if ctrl.Tag is not None else ''
    except Exception:
        tag = ''
    if tag == 'head':
        role = 'head'
    try:
        if n == 'Form':
            ctrl.BackColor, ctrl.ForeColor = rgb(pal['bg']), rgb(pal['text'])
        elif n == 'SplitContainer':
            ctrl.BackColor = rgb(pal['border'])
        elif n in ('Panel', 'FlowLayoutPanel', 'TableLayoutPanel', 'TabPage', 'SplitterPanel', 'GroupBox'):
            if role == 'head':
                ctrl.BackColor = rgb(pal['head'])
            elif tag == 'bg':
                ctrl.BackColor = rgb(pal['bg'])
            else:
                ctrl.BackColor = rgb(pal['panel'])
            ctrl.ForeColor = rgb(pal['text'])
        elif n == 'Label':
            ctrl.BackColor = Color.Transparent
            if role == 'head':
                ctrl.ForeColor = rgb(pal['head_text'])
            elif tag == 'muted':
                ctrl.ForeColor = rgb(pal['muted'])
            elif tag == 'accent':
                ctrl.ForeColor = rgb(pal['accent'])
            else:
                ctrl.ForeColor = rgb(pal['text'])
        elif n in ('TextBox', 'NumericUpDown', 'CheckedListBox', 'ListBox'):
            ctrl.BackColor, ctrl.ForeColor = rgb(pal['input']), rgb(pal['text'])
        elif n == 'ComboBox':
            ctrl.FlatStyle = FlatStyle.Flat
            ctrl.BackColor, ctrl.ForeColor = rgb(pal['input']), rgb(pal['text'])
        elif n == 'Button':
            style_button(ctrl, pal, primary=(tag == 'primary'))
        elif n == 'CheckBox':
            if ctrl.Appearance == Appearance.Button:
                style_button(ctrl, pal, toggle=True)
            else:
                ctrl.BackColor = Color.Transparent
                ctrl.ForeColor = rgb(pal['text'])
        elif n == 'DataGridView':
            style_grid(ctrl, pal)
        elif n == 'TabControl':
            style_tabs(ctrl, pal)
            ctrl.BackColor = rgb(pal['bg'])
        elif n == 'PictureBox':
            ctrl.BackColor = Color.White
    except Exception:
        pass
    try:
        for c in ctrl.Controls:
            apply(c, pal, role)
    except Exception:
        pass