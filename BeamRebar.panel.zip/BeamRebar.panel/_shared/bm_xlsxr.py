# -*- coding: utf-8 -*-
"""Doc file .xlsx (do tool xuat ra, hoac da duoc Excel luu lai) -> {ten_sheet: [[gia tri,...],...]}"""
import re
import zipfile
import xml.etree.ElementTree as ET

class FNum(float):
    """So co cong thuc: giu .f (text cong thuc) de ghi lai nguyen ven."""
    f = ''


class FStr(str):
    """Chuoi co cong thuc: giu .f."""
    f = ''


NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
RNS = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'


def _colidx(ref):
    letters = re.match(r'[A-Z]+', ref).group(0)
    n = 0
    for ch in letters:
        n = n * 26 + ord(ch) - 64
    return n - 1


def _text(el):
    return ''.join(t.text or '' for t in el.iter(NS + 't'))


def read_xlsx(path):
    out = {}
    with zipfile.ZipFile(path) as z:
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            root = ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared = [_text(si) for si in root.iter(NS + 'si')]
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target = {r.get('Id'): r.get('Target') for r in rels}
        for sh in wb.iter(NS + 'sheet'):
            t = target[sh.get(RNS + 'id')]
            t = t.lstrip('/')
            if not t.startswith('xl/'):
                t = 'xl/' + t
            root = ET.fromstring(z.read(t))
            rows = []
            for row in root.iter(NS + 'row'):
                r = int(row.get('r')) - 1
                while len(rows) <= r:
                    rows.append([])
                cur = rows[r]
                for c in row.iter(NS + 'c'):
                    ci = _colidx(c.get('r'))
                    while len(cur) <= ci:
                        cur.append(None)
                    ty = c.get('t')
                    v = c.find(NS + 'v')
                    if ty == 's' and v is not None:
                        val = shared[int(v.text)]
                    elif ty == 'inlineStr':
                        is_ = c.find(NS + 'is')
                        val = _text(is_) if is_ is not None else ''
                    elif ty == 'b' and v is not None:
                        val = bool(int(v.text))
                    elif v is not None and v.text is not None:
                        if ty in ('str', 'e'):
                            val = v.text
                        else:
                            f = float(v.text)
                            val = int(f) if f == int(f) and 'E' not in v.text.upper() and '.' not in v.text else f
                    else:
                        val = None
                    fe = c.find(NS + 'f')
                    # chi giu cong thuc don gian (co text, khong phai shared/array) va co gia tri cache
                    if (fe is not None and fe.text and fe.get('t') not in ('shared', 'array', 'dataTable')
                            and val is not None and not isinstance(val, bool)):
                        if isinstance(val, (int, float)):
                            val = FNum(val)
                        else:
                            val = FStr(val)
                        val.f = fe.text
                    cur[ci] = val
            out[sh.get('name')] = rows
    return out
