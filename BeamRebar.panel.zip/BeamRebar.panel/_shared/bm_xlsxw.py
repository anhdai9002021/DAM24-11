# -*- coding: utf-8 -*-
"""Ghi file .xlsx toi thieu bang zipfile (khong can openpyxl/Excel)."""
import zipfile
from xml.sax.saxutils import escape


def _col(n):
    s = ''
    n += 1
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def _clean(t):
    return ''.join(ch for ch in t if ch >= ' ' or ch in '\t\n')


def _sheet_xml(sh):
    rows = sh['rows']
    inp = sh.get('input_cols', ())
    widths = sh.get('widths', ())
    x = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
         '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
         '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" '
         'activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>']
    if widths:
        x.append('<cols>')
        for i, w in enumerate(widths):
            x.append('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (i + 1, i + 1, w))
        x.append('</cols>')
    x.append('<sheetData>')
    ncol = max([len(r) for r in rows] + [max(inp) + 1 if inp else 0])
    for ri, row in enumerate(rows):
        x.append('<row r="%d">' % (ri + 1))
        for ci in range(ncol):
            v = row[ci] if ci < len(row) else None
            st = 1 if ri == 0 else (2 if ci in inp else 0)
            ref = '%s%d' % (_col(ci), ri + 1)
            if v is None or v == '':
                if st:
                    x.append('<c r="%s" s="%d"/>' % (ref, st))
            elif getattr(v, 'f', None) and isinstance(v, (int, float, str)) and not isinstance(v, bool):
                fx = escape(_clean(v.f))
                if isinstance(v, str):
                    x.append('<c r="%s" s="%d" t="str"><f>%s</f><v>%s</v></c>' % (ref, st, fx, escape(_clean(str(v)))))
                else:
                    x.append('<c r="%s" s="%d"><f>%s</f><v>%s</v></c>' % (ref, st, fx, repr(round(float(v), 6))))
            elif isinstance(v, bool):
                x.append('<c r="%s" s="%d" t="b"><v>%d</v></c>' % (ref, st, int(v)))
            elif isinstance(v, (int, float)):
                x.append('<c r="%s" s="%d"><v>%s</v></c>' % (ref, st, repr(round(v, 3)) if isinstance(v, float) else v))
            else:
                x.append('<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>'
                         % (ref, st, escape(_clean(str(v)))))
        x.append('</row>')
    x.append('</sheetData></worksheet>')
    return ''.join(x)


STYLES = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
          '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>'
          '<font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
          '<fills count="4"><fill><patternFill patternType="none"/></fill>'
          '<fill><patternFill patternType="gray125"/></fill>'
          '<fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill>'
          '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/></patternFill></fill></fills>'
          '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
          '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
          '<cellXfs count="3">'
          '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
          '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1">'
          '<alignment wrapText="1" vertical="center"/></xf>'
          '<xf numFmtId="49" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1" applyNumberFormat="1"/>'
          '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')


def write_xlsx(path, sheets):
    """sheets: list of dict(name, rows, widths=[], input_cols={idx})"""
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
              '<Default Extension="xml" ContentType="application/xml"/>'
              '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
              '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
        wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
              'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>']
        rel = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
        has_f = False
        for i, sh in enumerate(sheets, 1):
            ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % i)
            wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (escape(sh['name'][:31]), i, i))
            rel.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i, i))
            xml = _sheet_xml(sh)
            has_f = has_f or ('<f>' in xml)
            z.writestr('xl/worksheets/sheet%d.xml' % i, xml)
        n = len(sheets) + 1
        rel.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % n)
        wb.append('</sheets>' + ('<calcPr fullCalcOnLoad="1"/>' if has_f else '') + '</workbook>')
        ct.append('</Types>')
        z.writestr('[Content_Types].xml', ''.join(ct))
        z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml', ''.join(wb))
        z.writestr('xl/_rels/workbook.xml.rels', ''.join(rel))
        z.writestr('xl/styles.xml', STYLES)
